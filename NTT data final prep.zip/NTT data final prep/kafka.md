**KAFKA - Essential Topics for 3.3 YOE (Interview-Ready)**

## MUST KNOW (Core 70% - Focus here):

**1. What is Kafka & Why it exists (5 mins)**
- Distributed streaming platform
- Pub-sub messaging + durable storage
- When to use vs Azure Service Bus

**2. Core Architecture (15 mins)**
- **Topics**: Category of messages (like "training-events", "ticket-updates")
- **Partitions**: Topics split into partitions for parallel processing
- **Producers**: Services that write messages to Kafka
- **Consumers**: Services that read messages from Kafka
- **Brokers**: Kafka servers that store data
- **Consumer Groups**: Multiple consumers working together

**3. Key Concepts (20 mins)**
- **Offset**: Position in partition (like bookmark in a book)
- **Retention**: How long messages are stored (default 7 days)
- **Replication**: Data copied across brokers (fault tolerance)
- **Partitioning**: Messages distributed across partitions by key

**4. How to connect to YOUR projects (15 mins)**
- AI Virtual Customer Training → streaming conversation events
- GTE AI Support → ticket event stream
- HICVy → real-time coaching analytics

## GOOD TO KNOW (Additional 25% - If time permits):

**5. Producer & Consumer basics (10 mins)**
- How producer sends messages
- How consumer reads messages
- Consumer group coordination

**6. Kafka vs Service Bus comparison (5 mins)**
- When to choose Kafka
- When to choose Service Bus

## SKIP FOR NOW (Not needed for 3.3 YOE interview):
- ❌ ZooKeeper internals
- ❌ Exactly-once semantics deep dive
- ❌ Kafka Streams API
- ❌ Schema Registry details
- ❌ Performance tuning parameters
- ❌ Cluster administration

---

**TOTAL TIME NEEDED: 1.5 - 2 hours max**

**Interview expectation at your level:**
✅ "I understand Kafka is for streaming events with replay capability"
✅ "Messages go into topics, which have partitions for parallel processing"
✅ "We could use it for real-time dashboard updates in our training platform"

❌ NOT expected: "Let me explain rebalancing protocols and ISR lists"

---

**Ready to start? Choose:**
1. **Give me the quick summary version** (30 min cheat sheet)
2. **Teach me properly with examples** (1.5 hour deep dive)
3. **Just give code examples with my projects** (practical approach)

Which one?