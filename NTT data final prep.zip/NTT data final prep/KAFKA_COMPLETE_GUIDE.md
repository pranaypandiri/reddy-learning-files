# Kafka Complete Guide - NTT Data Interview Prep

## Table of Contents
1. [What is Kafka & Why](#1-what-is-kafka--why)
2. [Core Architecture](#2-core-architecture)
3. [Key Concepts](#3-key-concepts)
4. [Producer - Writing Messages](#4-producer---writing-messages)
5. [Consumer - Reading Messages](#5-consumer---reading-messages)
6. [Offset Management](#6-offset-management)
7. [Key & Partitioning Strategy](#7-key--partitioning-strategy)
8. [Error Handling & Cleanup](#8-error-handling--cleanup)
9. [ZooKeeper & KRaft](#9-zookeeper--kraft)
10. [Kafka vs Service Bus](#10-kafka-vs-service-bus)

---

## 1. What is Kafka & Why

### What is Kafka?
Kafka is a **distributed event streaming platform** that:
- Stores events permanently (for retention period)
- Handles millions of messages per second
- Allows multiple consumers to read same data independently
- Supports replay of past events

### Key Difference from Traditional Message Queues
- **Service Bus/RabbitMQ**: Message consumed → deleted (like phone call)
- **Kafka**: Message consumed → stays there (like YouTube video - can replay)

### When to Use Kafka
✅ High-volume event streaming (>10K messages/sec)  
✅ Need to replay events (event sourcing)  
✅ Multiple consumers need same data at different speeds  
✅ Real-time data pipelines (logs, metrics, analytics)  
✅ Event-driven microservices with complex flows  

### When NOT to Use Kafka
❌ Low volume messaging (<1K messages/sec)  
❌ Need transactional guarantees (use Service Bus)  
❌ Simple request-reply patterns  
❌ Don't need event replay  

---

## 2. Core Architecture

### 6 Core Components

#### 1. **Topic**
Named category where events are stored
```
Example topics:
- "user-events"
- "payment-transactions"
- "order-updates"
```

#### 2. **Partition**
Topic split into multiple partitions for parallel processing
```
Topic: "orders" (3 partitions)
├── Partition 0: [Event1, Event4, Event7...]
├── Partition 1: [Event2, Event5, Event8...]
└── Partition 2: [Event3, Event6, Event9...]
```

**Why partitions?**
- Enables parallel consumption
- 3 partitions = 3 consumers can read simultaneously
- Events with same key go to same partition (ordering guaranteed per partition)

#### 3. **Producer**
Application that writes/publishes events to Kafka
```
Producer → Kafka Topic → Partitions
```

#### 4. **Consumer**
Application that reads events from Kafka
```
Kafka Topic → Partitions → Consumer Group → Consumers
```

#### 5. **Broker**
Kafka server that stores data
```
Kafka Cluster:
├── Broker 1 (stores some partitions)
├── Broker 2 (stores some partitions)
└── Broker 3 (stores some partitions)
```

#### 6. **Consumer Group**
Multiple consumers working together to process same topic
```
Topic: "orders" (3 partitions)

Consumer Group "order-processors":
├── Consumer A → reads Partition 0
├── Consumer B → reads Partition 1
└── Consumer C → reads Partition 2
```

**Rule:** Each partition read by only ONE consumer in a group (prevents duplicate work)

---

## 3. Key Concepts

### Offset
Sequential number identifying each message within a partition

```
Partition 0:
Offset 0: "User logged in"
Offset 1: "User viewed product"
Offset 2: "User added to cart"
Offset 3: "User checked out"
```

**Think:** Offset = Bookmark in a book

**How consumers use it:**
- Consumer reads offset 0, 1, 2...
- Consumer crashes at offset 2
- Consumer restarts → continues from offset 3

### Retention
How long Kafka keeps messages before deleting

**Default:** 7 days (168 hours)

**Two types:**
- **Time-based:** `retention.ms = 604800000` (7 days)
- **Size-based:** `retention.bytes = 1GB` (delete oldest when exceeds)

### Replication
Each partition copied across multiple brokers for fault tolerance

**Replication factor = 3** (common)
```
Partition 0 data:
├── Broker 1 (Leader) - handles reads/writes
├── Broker 2 (Follower) - syncs from leader
└── Broker 3 (Follower) - syncs from leader
```

**What happens when broker crashes:**
- Leader dies → Follower promoted to Leader automatically
- System continues without downtime

### Partitioning Strategy
How Kafka decides which partition to send message to

**1. Key-based (most common):**
```python
send(key="user_123", value="data")
→ hash("user_123") % num_partitions = partition number
```
- Same key → same partition (ordering guaranteed)

**2. Round-robin (no key):**
```python
send(value="data")  # no key
→ distributes evenly: P0, P1, P2, P0, P1, P2...
```

---

## 4. Producer - Writing Messages

### Basic Producer Setup

```python
from kafka import KafkaProducer
import json

# Initialize producer
producer = KafkaProducer(
    bootstrap_servers=['localhost:9092'],  # Kafka broker address
    
    # Serialize data to bytes (Kafka requires bytes)
    value_serializer=lambda v: json.dumps(v).encode('utf-8'),
    
    # Acknowledgment level
    acks='all',  # Wait for all replicas (safest)
    
    # Retry settings
    retries=3,
    
    # Batch settings for performance
    batch_size=16384,
    linger_ms=10
)
```

### Sending Messages

**Simple send:**
```python
# Send message
producer.send(
    topic='user-events',
    key=b'user_123',  # Must be bytes (b prefix)
    value={'action': 'login', 'timestamp': '2026-02-08'}
)

producer.flush()  # Ensure all messages sent
producer.close()  # Close connection
```

**With callback (check if sent successfully):**
```python
def on_success(metadata):
    print(f"Message sent to {metadata.topic} partition {metadata.partition} at offset {metadata.offset}")

def on_error(exception):
    print(f"Error sending message: {exception}")

# Send with callback
future = producer.send(
    topic='user-events',
    key=b'user_123',
    value={'action': 'login'}
)

# Add callbacks
future.add_callback(on_success)
future.add_errback(on_error)

# Wait for result (blocks until sent)
record_metadata = future.get(timeout=10)
```

### Acknowledgment Levels (acks)

```python
# acks=0 (Fire and forget - fastest, may lose data)
producer = KafkaProducer(acks=0)
# Producer doesn't wait for broker confirmation
# Use: Low-priority logs, metrics

# acks=1 (Leader acknowledgment - default)
producer = KafkaProducer(acks=1)
# Producer waits for leader to write, but not followers
# Use: Most use cases (balance of speed and reliability)

# acks='all' (All replicas - safest, slowest)
producer = KafkaProducer(acks='all')
# Producer waits for leader + all followers to write
# Use: Critical financial transactions, orders
```

### Key Serialization

```python
# Why b prefix?
key = 'user_123'        # String (won't work)
key = b'user_123'       # Bytes (works!)
key = 'user_123'.encode('utf-8')  # Also works (converts string to bytes)

# Value serialization (complex objects)
value_serializer = lambda v: json.dumps(v).encode('utf-8')
# Step 1: json.dumps(dict) → JSON string
# Step 2: .encode('utf-8') → bytes
```

---

## 5. Consumer - Reading Messages

### Basic Consumer Setup

```python
from kafka import KafkaConsumer
import json

# Initialize consumer
consumer = KafkaConsumer(
    'user-events',  # Topic to subscribe
    
    bootstrap_servers=['localhost:9092'],
    
    # Consumer group (for parallel processing)
    group_id='analytics-service',
    
    # Where to start reading if no previous offset
    auto_offset_reset='earliest',  # 'earliest' or 'latest'
    
    # Offset commit strategy
    enable_auto_commit=False,  # Manual commit (safer)
    
    # Deserialize data from bytes
    value_deserializer=lambda m: json.loads(m.decode('utf-8'))
)
```

### Reading Messages

**Basic consumption loop:**
```python
for message in consumer:
    print(f"Topic: {message.topic}")
    print(f"Partition: {message.partition}")
    print(f"Offset: {message.offset}")
    print(f"Key: {message.key}")
    print(f"Value: {message.value}")
    print(f"Timestamp: {message.timestamp}")
    
    # Process the message
    process_event(message.value)
    
    # Manually commit offset after successful processing
    consumer.commit()
```

**Batch processing:**
```python
# Poll for messages (non-blocking)
messages = consumer.poll(timeout_ms=1000, max_records=100)

for topic_partition, records in messages.items():
    for message in records:
        process_event(message.value)
    
    # Commit after batch
    consumer.commit()
```

### Auto Offset Reset

```python
# auto_offset_reset='earliest'
# Start from beginning (offset 0) if no previous offset exists
consumer = KafkaConsumer(
    'user-events',
    auto_offset_reset='earliest'
)
# Use case: New consumer needs all historical data

# auto_offset_reset='latest'
# Start from newest messages (skip old ones)
consumer = KafkaConsumer(
    'user-events',
    auto_offset_reset='latest'
)
# Use case: Only care about new events going forward

# auto_offset_reset='none'
# Fail if no previous offset found
consumer = KafkaConsumer(
    'user-events',
    auto_offset_reset='none'
)
# Use case: Strict control, don't want accidental data loss
```

---

## 6. Offset Management

### Why Offset Management Matters

```
Without proper offset management:
- Consumer crashes → loses track of position
- Restarts from beginning → duplicate processing
- Or skips messages → data loss
```

### Auto-Commit (Easy but Risky)

```python
consumer = KafkaConsumer(
    'orders',
    enable_auto_commit=True,      # Kafka commits automatically
    auto_commit_interval_ms=5000  # Every 5 seconds
)

for message in consumer:
    # Kafka commits offset in background every 5 seconds
    process(message)
    
    # RISK: If crash happens after commit but before processing
    # → Offset saved, but message not processed (data loss!)
```

**Timeline of what happens:**
```
0s:  Read offset 100
2s:  Processing...
5s:  Auto-commit → offset 101 saved
6s:  CRASH before processing complete
     Restart → continues from offset 101
     Message 100 never processed! (LOST)
```

### Manual Commit (Safer)

```python
consumer = KafkaConsumer(
    'orders',
    enable_auto_commit=False  # Manual control
)

for message in consumer:
    try:
        # Process message first
        result = process(message)
        save_to_database(result)
        
        # ONLY commit if processing succeeded
        consumer.commit()
        
    except Exception as e:
        print(f"Processing failed: {e}")
        # Don't commit → will reprocess this message after restart
        # This ensures at-least-once delivery
        break
```

### Commit Strategies

**1. Commit after each message (safest, slowest):**
```python
for message in consumer:
    process(message)
    consumer.commit()  # Commit immediately
```

**2. Commit after batch (faster, small risk):**
```python
batch = []
for message in consumer:
    batch.append(message)
    
    if len(batch) >= 100:
        process_batch(batch)
        consumer.commit()  # Commit once per 100 messages
        batch = []
```

**3. Commit specific offset:**
```python
from kafka import TopicPartition

for message in consumer:
    process(message)
    
    # Commit specific partition/offset
    tp = TopicPartition(message.topic, message.partition)
    consumer.commit({tp: message.offset + 1})
```

### Handling Duplicate Messages (Idempotency)

```python
# Because Kafka guarantees at-least-once delivery,
# same message might be processed twice

processed_ids = set()  # Track processed message IDs

for message in consumer:
    message_id = message.value['id']
    
    # Check if already processed
    if message_id in processed_ids:
        print(f"Duplicate message {message_id}, skipping")
        consumer.commit()
        continue
    
    # Process message
    process(message)
    processed_ids.add(message_id)
    
    consumer.commit()
```

---

## 7. Key & Partitioning Strategy

### How Keys Work

**Key determines which partition message goes to:**

```python
# Messages with same key → same partition
producer.send('orders', key=b'user_123', value={'order': 1})
producer.send('orders', key=b'user_123', value={'order': 2})
producer.send('orders', key=b'user_123', value={'order': 3})

# All 3 messages go to SAME partition
# Ordering guaranteed for user_123
```

### Key-Based Partitioning Logic

```python
# Kafka's internal logic:
partition = hash(key) % number_of_partitions

# Example with 3 partitions:
hash("user_123") % 3 = 0  → Partition 0
hash("user_456") % 3 = 1  → Partition 1
hash("user_789") % 3 = 2  → Partition 2
hash("user_123") % 3 = 0  → Partition 0 (same user, same partition!)
```

### Choosing the Right Key

**User-based events:**
```python
# Key = user_id
producer.send(
    'user-events',
    key=f'user_{user_id}'.encode(),
    value={'action': 'login', 'user_id': user_id}
)
# Benefit: All events for same user in order
```

**Order processing:**
```python
# Key = order_id
producer.send(
    'order-events',
    key=f'order_{order_id}'.encode(),
    value={'status': 'created', 'order_id': order_id}
)
# Benefit: All events for same order in order
# Created → Paid → Shipped → Delivered (sequence maintained)
```

**No key (load balancing):**
```python
# No key = round-robin distribution
producer.send(
    'logs',
    value={'level': 'INFO', 'message': 'System started'}
)
# Benefit: Evenly distributed across partitions
# Use case: Logs, metrics where order doesn't matter
```

### Custom Partitioner

```python
from kafka.partitioner import DefaultPartitioner

class CustomPartitioner:
    def __call__(self, key, all_partitions, available_partitions):
        # Premium users → Partition 0 (dedicated)
        if key.startswith(b'premium_'):
            return 0
        
        # Regular users → Other partitions
        return hash(key) % (len(all_partitions) - 1) + 1

producer = KafkaProducer(
    partitioner=CustomPartitioner()
)
```

---

## 8. Error Handling & Cleanup

### Producer Error Handling

```python
from kafka import KafkaProducer
from kafka.errors import KafkaError
import time

producer = KafkaProducer(
    bootstrap_servers=['localhost:9092'],
    retries=3,  # Retry 3 times on failure
    retry_backoff_ms=1000  # Wait 1 second between retries
)

def send_with_retry(topic, key, value, max_attempts=3):
    """Send message with error handling"""
    for attempt in range(max_attempts):
        try:
            future = producer.send(topic, key=key, value=value)
            
            # Wait for result
            record_metadata = future.get(timeout=10)
            
            print(f"✅ Sent to partition {record_metadata.partition} at offset {record_metadata.offset}")
            return True
            
        except KafkaError as e:
            print(f"❌ Attempt {attempt + 1} failed: {e}")
            
            if attempt < max_attempts - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
            else:
                print(f"❌ Failed after {max_attempts} attempts")
                return False
        
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
            return False

# Usage
send_with_retry('orders', b'order_123', {'status': 'created'})
```

### Consumer Error Handling

```python
from kafka import KafkaConsumer
from kafka.errors import KafkaError
import time

consumer = KafkaConsumer(
    'orders',
    bootstrap_servers=['localhost:9092'],
    group_id='order-processor',
    enable_auto_commit=False,
    auto_offset_reset='earliest'
)

def consume_safely():
    """Consume with error handling"""
    retry_count = {}
    
    try:
        for message in consumer:
            message_id = message.value.get('id')
            
            try:
                # Process message
                process_message(message.value)
                
                # Success → commit offset
                consumer.commit()
                
                # Reset retry count
                if message_id in retry_count:
                    del retry_count[message_id]
                
                print(f"✅ Processed message {message_id}")
                
            except TemporaryError as e:
                # Temporary error (network timeout, etc.)
                print(f"⚠️ Temporary error for {message_id}: {e}")
                
                # Track retries
                retry_count[message_id] = retry_count.get(message_id, 0) + 1
                
                if retry_count[message_id] < 3:
                    # Don't commit → will retry
                    time.sleep(5)
                else:
                    # Too many retries → send to DLQ
                    send_to_dead_letter_queue(message)
                    consumer.commit()  # Skip this message
                    print(f"❌ Moved to DLQ after 3 retries")
            
            except PermanentError as e:
                # Permanent error (invalid data, business rule violation)
                print(f"❌ Permanent error for {message_id}: {e}")
                
                # Send to DLQ
                send_to_dead_letter_queue(message)
                
                # Commit to skip this bad message
                consumer.commit()
                
    except KeyboardInterrupt:
        print("Shutting down gracefully...")
    
    finally:
        # Always close consumer
        consumer.close()
        print("Consumer closed")

# Custom exceptions
class TemporaryError(Exception):
    pass

class PermanentError(Exception):
    pass

def process_message(data):
    # Your processing logic
    if not data.get('id'):
        raise PermanentError("Missing ID")
    
    if external_api_call_failed():
        raise TemporaryError("API timeout")
    
    # Process...

def send_to_dead_letter_queue(message):
    # Send to separate topic for manual inspection
    dlq_producer = KafkaProducer(
        bootstrap_servers=['localhost:9092']
    )
    dlq_producer.send('orders-dlq', value=message.value)
    dlq_producer.flush()
    dlq_producer.close()

# Run consumer
consume_safely()
```

### Graceful Shutdown

```python
import signal
import sys

consumer = KafkaConsumer('orders')
running = True

def signal_handler(sig, frame):
    """Handle Ctrl+C gracefully"""
    global running
    print("\nShutting down gracefully...")
    running = False

# Register signal handler
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Consume with graceful shutdown
while running:
    messages = consumer.poll(timeout_ms=1000)
    
    for topic_partition, records in messages.items():
        for message in records:
            if not running:
                break
            
            process(message)
            consumer.commit()

# Clean shutdown
consumer.close()
print("Consumer closed successfully")
sys.exit(0)
```

### Connection Resilience

```python
from kafka import KafkaConsumer
from kafka.errors import NoBrokersAvailable
import time

def create_consumer_with_retry(max_retries=5):
    """Create consumer with connection retry"""
    for attempt in range(max_retries):
        try:
            consumer = KafkaConsumer(
                'orders',
                bootstrap_servers=['localhost:9092'],
                request_timeout_ms=30000,
                session_timeout_ms=10000,
                heartbeat_interval_ms=3000
            )
            print("✅ Connected to Kafka")
            return consumer
            
        except NoBrokersAvailable:
            print(f"⚠️ No brokers available, attempt {attempt + 1}/{max_retries}")
            if attempt < max_retries - 1:
                time.sleep(5)
            else:
                raise Exception("Failed to connect to Kafka after retries")
    
    return None

# Usage
consumer = create_consumer_with_retry()
```

---

## 9. ZooKeeper & KRaft

### What is ZooKeeper?

**ZooKeeper = Distributed coordination service used by older Kafka versions**

**What it managed (in old Kafka):**
- Broker membership (which brokers are alive)
- Leader election (which broker is leader for each partition)
- Configuration management
- Consumer group coordination

### Architecture (Old Kafka with ZooKeeper)

```
                    ZooKeeper Ensemble
                   ┌──────────────────┐
                   │  ZK Node 1       │
                   │  ZK Node 2       │
                   │  ZK Node 3       │
                   └──────────────────┘
                           ↓
              Manages cluster metadata
                           ↓
    ┌──────────────────────────────────────┐
    │         Kafka Cluster                │
    ├──────────────────────────────────────┤
    │  Broker 1  │  Broker 2  │  Broker 3  │
    └──────────────────────────────────────┘
```

**Problems with ZooKeeper:**
- Extra infrastructure to manage
- Additional complexity
- Separate monitoring and ops
- Scalability bottleneck

### KRaft Mode (Modern Kafka)

**KRaft = Kafka Raft (Kafka 2.8+)**

**What changed:**
- Kafka manages itself (no external ZooKeeper needed)
- Uses Raft consensus algorithm
- Some brokers become "controllers" (handle coordination)
- Simpler architecture

### Architecture (Modern Kafka with KRaft)

```
         Kafka Cluster (Self-managed)
    ┌──────────────────────────────────────┐
    │  Controller 1  (Leader)              │
    │  Controller 2  (Follower)            │
    │  Controller 3  (Follower)            │
    ├──────────────────────────────────────┤
    │  Broker 1      │  Broker 2           │
    └──────────────────────────────────────┘
    
    Controllers handle metadata (no ZooKeeper needed!)
```

### Interview Answers

**"What is ZooKeeper in Kafka?"**

"ZooKeeper was used in older Kafka versions for distributed coordination - managing broker membership, leader election, and storing cluster metadata. However, since Kafka 2.8, we have KRaft mode where Kafka manages itself using the Raft consensus algorithm, eliminating the need for ZooKeeper. This simplifies operations and reduces infrastructure overhead."

**"Do you need to know ZooKeeper details?"**

For 3.3 YOE: **No deep knowledge needed**, just know:
- Old Kafka used ZooKeeper for coordination
- New Kafka (KRaft mode) doesn't need it
- Modern deployments prefer KRaft

---

## 10. Kafka vs Service Bus

### Feature Comparison

| Feature | Kafka | Azure Service Bus |
|---------|-------|-------------------|
| **Type** | Distributed log | Message broker |
| **Throughput** | Millions/sec | Thousands/sec |
| **Message retention** | Configurable (days) | Deleted after consumption |
| **Replay capability** | ✅ Yes | ❌ No |
| **Ordering** | Per partition | Per session/queue |
| **Scalability** | Horizontal (partitions) | Vertical (upgrade tier) |
| **Dead-letter queue** | Manual | ✅ Built-in |
| **Transactions** | Basic | ✅ Full ACID |
| **Duplicate detection** | Manual | ✅ Built-in |
| **Message scheduling** | No | ✅ Yes |

### When to Choose Kafka

✅ High-volume streaming (>10K msg/sec)  
✅ Need event replay  
✅ Multiple consumers need same data  
✅ Real-time analytics pipelines  
✅ Event sourcing architecture  
✅ Long-term event storage  

**Examples:**
- Log aggregation from thousands of servers
- Real-time analytics dashboards
- IoT sensor data streaming
- Change data capture (CDC)
- Audit trail systems

### When to Choose Service Bus

✅ Enterprise messaging (<10K msg/sec)  
✅ Need ACID transactions  
✅ Request-reply patterns  
✅ Scheduled message delivery  
✅ Azure-native integration  
✅ Complex routing with filters  

**Examples:**
- Order processing workflows
- Payment transactions
- Background job queues
- Microservice commands
- Email/notification queues

### Hybrid Pattern (Common in Enterprise)

```
Service Bus → Inter-service commands (transactional)
Kafka → Event streaming for analytics

Example:
OrderService → Service Bus → PaymentService (transactional)
                     ↓
            All events → Kafka → Analytics/ML pipelines
```

---

## Quick Reference - Interview Answers

### "Explain Kafka in 30 seconds"
"Kafka is a distributed event streaming platform that stores events permanently in an append-only log with configurable retention. Unlike traditional message queues where messages are deleted after consumption, Kafka allows multiple consumers to read events at their own pace and replay past events. It uses partitions for horizontal scalability and can handle millions of messages per second."

### "What are partitions?"
"Partitions divide a topic into multiple ordered logs for parallel processing. Messages with the same key go to the same partition, maintaining ordering for that key. Each partition can be consumed by one consumer in a group, enabling throughput to scale linearly with partition count."

### "What is offset?"
"Offset is a sequential ID for each message within a partition, starting from 0. Consumers track their position using offsets, either manually committing after successful processing or using auto-commit. This enables at-least-once delivery and allows replay by resetting to earlier offsets."

### "Kafka vs Service Bus?"
"Choose Kafka for high-throughput streaming where you need replay capability and multiple independent consumers - like real-time analytics or event sourcing. Choose Service Bus for enterprise messaging needing transactional guarantees, dead-letter queues, and message scheduling - like order processing or payment workflows. Many systems use both - Service Bus for inter-service commands and Kafka for event streaming to analytics."

---

## End of Guide

**You're now ready for Kafka questions in your NTT Data interview! 🚀**

Key things to remember:
- Kafka = Streaming platform with replay
- Partitions = Parallel processing
- Offset = Message position tracking
- Producer writes, Consumer reads
- Manual commit for safety
- Keys maintain ordering per partition
- Grace shutdowns prevent data loss
