# Azure Service Bus & GCP Pub/Sub - Interview Cheat Sheet

## 1. Event-Driven Architecture (EDA) Fundamentals

### **What is EDA?**
Services communicate via **events** (messages), not direct calls. Loose coupling, async processing.

### **Synchronous vs Asynchronous**

| Synchronous | Asynchronous |
|-------------|--------------|
| Caller waits for response | Fire and forget |
| Blocking | Non-blocking |
| `response = api.call()` | `publish_event()` |
| Immediate result | Eventual result |

### **When to Use Messaging (Async)**
✅ Background tasks (reports, emails)  
✅ Multiple services need same data  
✅ Long-running operations  
✅ Decoupled microservices  

### **When NOT to Use Messaging**
❌ User waiting for response (use HTTP)  
❌ Need immediate confirmation  
❌ Transactional operations requiring rollback  

---

## 2. Queue vs Pub/Sub Pattern

### **Queue (Point-to-Point)**
**One sender → One receiver** (first come, first served)

```
Producer → [Queue] → Consumer1 picks up (others don't see it)
                  → Consumer2 (waiting)
                  → Consumer3 (waiting)
```

**Use for:** Task distribution, load balancing

---

### **Pub/Sub (Publish-Subscribe)**
**One sender → ALL subscribers** (broadcast)

```
Publisher → [Topic]
                ↓
    ┌───────────┼───────────┐
    ↓           ↓           ↓
Sub1: Email  Sub2: DB   Sub3: Analytics
(all receive same message)
```

**Use for:** Event broadcasting, multiple reactions to same event

---

## 3. Azure Service Bus - Core Concepts

### **Components**
- **Namespace:** Container for queues/topics
- **Queue:** Point-to-point messaging
- **Topic:** Pub/sub messaging
- **Subscription:** Consumer endpoint on topic
- **Message:** Data + properties (metadata)

---

### **Publishing to Queue**

```python
from azure.servicebus import ServiceBusClient, ServiceBusMessage
import json

client = ServiceBusClient.from_connection_string("connection_string")
sender = client.get_queue_sender("order-queue")

message = ServiceBusMessage(
    body=json.dumps({"order_id": 123, "amount": 500})
)

sender.send_messages(message)
sender.close()
```

---

### **Publishing to Topic**

```python
sender = client.get_topic_sender("order-events")

message = ServiceBusMessage(
    body=json.dumps({"order_id": 123}),
    subject="OrderPlaced",
    application_properties={
        "priority": "high",
        "region": "US"
    }
)

sender.send_messages(message)
sender.close()
```

---

### **Consuming from Queue (Manual Loop)**

```python
receiver = client.get_queue_receiver("order-queue")

while True:
    messages = receiver.receive_messages(max_message_count=10, max_wait_time=5)
    
    for message in messages:
        try:
            process_order(json.loads(message.body))
            receiver.complete_message(message)  # Ack (delete)
        except:
            receiver.abandon_message(message)  # Retry
```

---

### **Consuming from Topic Subscription**

```python
receiver = client.get_subscription_receiver(
    topic_name="order-events",
    subscription_name="inventory-sub"
)

messages = receiver.receive_messages(max_message_count=10)

for message in messages:
    process(message.body)
    receiver.complete_message(message)
```

---

### **Iterator Pattern (SDK-Managed Loop)**

```python
receiver = client.get_queue_receiver("reports-queue")

# Iterator = while True inside
for message in receiver:
    process(message.body)
    receiver.complete_message(message)
```

---

## 4. Azure Service Bus - Key Features

### **Dead-Letter Queue (DLQ)**
**Failed messages go here automatically after max retries (10)**

```python
# Manual dead-letter
try:
    process(message)
    receiver.complete_message(message)
except ValidationError:
    receiver.dead_letter_message(message, reason="InvalidData")

# Read DLQ
dlq_receiver = client.get_queue_receiver(
    queue_name="order-queue",
    sub_queue=ServiceBusSubQueue.DEAD_LETTER
)
messages = dlq_receiver.receive_messages(max_message_count=10)
```

---

### **Message Properties & Filtering**

**Publish with properties:**
```python
message = ServiceBusMessage(
    body=data,
    application_properties={
        "priority": "high",
        "order_value": 250,
        "region": "US"
    }
)
```

**Create filtered subscription:**
```python
from azure.servicebus.management import ServiceBusAdministrationClient, SqlRuleFilter

admin_client = ServiceBusAdministrationClient.from_connection_string("conn")

# Only high priority messages
admin_client.create_rule(
    topic_name="order-events",
    subscription_name="urgent-sub",
    rule_name="HighPriorityOnly",
    filter=SqlRuleFilter("priority = 'high'")
)

# Complex filter
admin_client.create_rule(
    topic_name="order-events",
    subscription_name="premium-sub",
    rule_name="PremiumFilter",
    filter=SqlRuleFilter("priority = 'high' AND order_value > 100")
)
```

---

### **Sessions (FIFO Guarantee)**
**Messages with same session_id processed in order by one consumer**

```python
# Publish with session
message = ServiceBusMessage(
    body="Step 1",
    session_id="ORDER-123"
)
sender.send_messages(message)

# Consume with session
session_receiver = client.get_queue_receiver(
    queue_name="orders",
    session_id="ORDER-123"
)

for message in session_receiver:
    process(message)
    session_receiver.complete_message(message)
```

**Use case:** Multi-turn conversations, ordered workflows

---

### **Scheduled Messages (Delayed Delivery)**

```python
from datetime import datetime, timedelta

scheduled_time = datetime.utcnow() + timedelta(hours=1)

message = ServiceBusMessage(
    body=json.dumps({"reminder": "Follow up"}),
    scheduled_enqueue_time_utc=scheduled_time
)

sender.send_messages(message)
```

**Use case:** Reminders, delayed retries, timeout escalation

---

### **AutoLockRenewer (Long Tasks)**
**Keeps message locked during long processing**

```python
from azure.servicebus import AutoLockRenewer

renewer = AutoLockRenewer()

for message in receiver:
    # Register for auto-renewal (up to 20 mins)
    renewer.register(receiver, message, max_lock_renewal_duration=1200)
    
    # Long task (15 minutes)
    generate_report(message.body)
    
    receiver.complete_message(message)

renewer.close()
```

**Without renewer:** Lock expires after 60s → duplicate processing

---

## 5. Azure Functions (Serverless - NO Loop!)

```python
import azure.functions as func

app = func.FunctionApp()

@app.service_bus_queue_trigger(
    arg_name="msg",
    queue_name="order-queue",
    connection="ServiceBusConnection"
)
def process_order(msg: func.ServiceBusMessage):
    order = json.loads(msg.get_body().decode())
    process(order)
    # Auto-acked on success
    # Auto-retried on exception
```

**Benefits:**
- No while loop needed
- Auto-scaling
- Auto message lifecycle (complete/abandon/DLQ)
- Timeout: 10 min max (default 5 min)

---

## 6. Azure Container Apps (Long Tasks)

### **Background Worker (With Loop)**

```python
# worker.py
from azure.servicebus import ServiceBusClient, AutoLockRenewer

client = ServiceBusClient.from_connection_string("CONN_STR")
receiver = client.get_queue_receiver("reports-queue")
renewer = AutoLockRenewer()

while True:
    messages = receiver.receive_messages(max_message_count=10)
    
    for message in messages:
        renewer.register(receiver, message, max_lock_renewal_duration=1200)
        generate_report(message.body)  # 15 minutes - no timeout!
        receiver.complete_message(message)
```

**Deploy:**
```bash
az containerapp create \
  --name report-worker \
  --image myregistry.azurecr.io/worker:v1 \
  --scale-rule-type azure-servicebus \
  --scale-rule-metadata queueName=reports-queue messageCount=5 \
  --min-replicas 0 \
  --max-replicas 10
```

**Auto-scales:** More messages → more containers

---

### **Container Apps Jobs (One Message = One Container)**

```python
# Same code, NO while loop
messages = receiver.receive_messages(max_message_count=1)
for message in messages:
    process(message)
    receiver.complete_message(message)
# Script exits, container terminates
```

**Deploy:**
```bash
az containerapp job create \
  --name report-job \
  --image myregistry.azurecr.io/worker:v1 \
  --trigger-type Event \
  --scale-rule-type azure-servicebus
```

**Difference:** Fresh container per message (good for memory isolation)

---

### **Graceful Shutdown**

```python
import signal

shutdown = False

def shutdown_handler(signum, frame):
    global shutdown
    print("Shutdown signal received, finishing current message...")
    shutdown = True

signal.signal(signal.SIGTERM, shutdown_handler)  # Docker/K8s
signal.signal(signal.SIGINT, shutdown_handler)   # Ctrl+C

for message in receiver:
    if shutdown:
        receiver.abandon_message(message)
        break
    
    process(message)  # Current message completes
    receiver.complete_message(message)

print("Exited gracefully")
```

**Why needed:**
- Complete current work before shutdown
- Prevent duplicate processing
- Avoid wasted compute

**Docker config:**
```bash
docker run --stop-timeout 1200 myimage  # Wait 20 mins before SIGKILL
```

---

## 7. GCP Pub/Sub - Core Concepts

### **Components**
- **Topic:** Named channel (like Azure topic)
- **Subscription:** Consumer endpoint
- **Message:** Data + attributes
- **NO QUEUES** - Use topic + single subscription for queue-like behavior

---

### **Publishing**

```python
from google.cloud import pubsub_v1
import json

publisher = pubsub_v1.PublisherClient()
topic_path = publisher.topic_path("my-project", "order-events")

message_data = json.dumps({"order_id": 123, "amount": 500})

publisher.publish(
    topic_path,
    data=message_data.encode("utf-8"),  # Must be bytes
    priority="high",  # Custom attribute
    region="US"
)
```

---

### **Consuming - Pull (Manual)**

```python
subscriber = pubsub_v1.SubscriberClient()
subscription_path = subscriber.subscription_path("my-project", "order-sub")

# Synchronous pull
response = subscriber.pull(
    request={
        "subscription": subscription_path,
        "max_messages": 10
    },
    timeout=5.0
)

for received_message in response.received_messages:
    message = received_message.message
    
    process(message.data.decode('utf-8'))
    
    # Acknowledge
    subscriber.acknowledge(
        request={
            "subscription": subscription_path,
            "ack_ids": [received_message.ack_id]
        }
    )
```

---

### **Consuming - Streaming Pull (Callback)**

```python
def callback(message):
    """Called automatically for each message"""
    print(f"Received: {message.data.decode('utf-8')}")
    
    try:
        process(message.data)
        message.ack()  # Success
    except:
        message.nack()  # Retry

# Start streaming (non-blocking, background threads)
streaming_pull_future = subscriber.subscribe(subscription_path, callback=callback)

print("Listening...")
streaming_pull_future.result()  # Blocks forever (keeps program alive)
```

**Key:** `.result()` blocks forever to keep background threads running

---

### **Push Subscriptions**

**Pub/Sub makes HTTP POST to your endpoint:**

```python
from fastapi import FastAPI, Request
import base64

app = FastAPI()

@app.post("/pubsub-webhook")
async def handle_pubsub(request: Request):
    envelope = await request.json()
    message_data = base64.b64decode(envelope['message']['data'])
    
    process(message_data)
    
    return {"status": "success"}  # 200 = ack
```

**Configure:**
```bash
gcloud pubsub subscriptions create order-push-sub \
  --topic=order-events \
  --push-endpoint=https://myapp.com/pubsub-webhook
```

---

### **Subscription Filters**

```bash
# Only high priority
gcloud pubsub subscriptions create high-priority-sub \
  --topic=order-events \
  --message-filter='attributes.priority="high"'

# Complex filter
gcloud pubsub subscriptions create premium-sub \
  --topic=order-events \
  --message-filter='attributes.priority="high" AND attributes.amount > 100'
```

---

### **Dead-Letter Topic**

```bash
# Create DLT
gcloud pubsub topics create order-events-dlq

# Create subscription with DLT
gcloud pubsub subscriptions create order-sub \
  --topic=order-events \
  --dead-letter-topic=order-events-dlq \
  --max-delivery-attempts=5
```

**Difference from Azure:** Separate topic, not sub-queue

---

### **Ordering Keys (FIFO)**

```python
# Enable ordering
publisher = pubsub_v1.PublisherClient(
    publisher_options=pubsub_v1.types.PublisherOptions(
        enable_message_ordering=True
    )
)

# Messages with same key processed in order
publisher.publish(topic_path, b"Step 1", ordering_key="ORDER-123")
publisher.publish(topic_path, b"Step 2", ordering_key="ORDER-123")
```

---

### **Long Tasks - Extend Ack Deadline**

```python
def callback(message):
    # Extend ack deadline (default 10 seconds)
    message.modify_ack_deadline(600)  # 10 minutes
    
    generate_report(message.data)  # Long task
    
    message.ack()
```

---

## 8. GCP Cloud Functions (Serverless)

```python
import functions_framework
import base64

@functions_framework.cloud_event
def process_order(cloud_event):
    """Called automatically when message arrives"""
    message_data = base64.b64decode(cloud_event.data["message"]["data"])
    
    process(message_data)
    
    # Auto-acked on success
    # Auto-retried on exception
```

**Deploy:**
```bash
gcloud functions deploy process_order \
  --trigger-topic=order-events \
  --runtime=python311
```

---

## 9. GCP Cloud Run Jobs

```python
# worker.py - No while loop
from google.cloud import pubsub_v1

subscriber = pubsub_v1.SubscriberClient()
subscription_path = subscriber.subscription_path("project", "reports-sub")

# Pull ONE message
response = subscriber.pull(
    request={"subscription": subscription_path, "max_messages": 1}
)

for msg in response.received_messages:
    generate_report(msg.message.data)  # 15 minutes
    
    subscriber.acknowledge(
        request={"subscription": subscription_path, "ack_ids": [msg.ack_id]}
    )

# Script exits, container terminates
```

**Deploy:**
```bash
gcloud run jobs create report-job \
  --image gcr.io/myproject/worker \
  --task-timeout 20m \
  --max-retries 3
```

---

## 10. Azure vs GCP Comparison

| Feature | Azure Service Bus | GCP Pub/Sub |
|---------|------------------|-------------|
| **Queue support** | ✅ Native | ❌ Use topic + 1 sub |
| **Pub/Sub support** | ✅ Topics | ✅ Native |
| **Message size** | 256 KB (1 MB premium) | 10 MB |
| **Message TTL** | 14 days (configurable) | 7 days (fixed) |
| **FIFO ordering** | Sessions | Ordering keys |
| **Filtering** | SQL filters | Attribute filters |
| **Dead-letter** | Sub-queue | Separate topic |
| **Push delivery** | ❌ No | ✅ Yes |
| **Ack mechanism** | `complete_message()` | `message.ack()` |
| **Default ack timeout** | 60 seconds | 10 seconds |
| **Transactions** | ✅ Yes | ❌ No |
| **Callback pattern** | ⚠️ Weak support | ✅ Built-in |

---

### **Code Comparison**

| Action | Azure | GCP |
|--------|-------|-----|
| **Publish** | `sender.send_messages(message)` | `publisher.publish(topic, data)` |
| **Subscribe** | `receiver.receive_messages()` | `subscriber.pull()` or callback |
| **Ack** | `receiver.complete_message(msg)` | `message.ack()` |
| **Nack** | `receiver.abandon_message(msg)` | `message.nack()` |
| **DLQ** | `sub_queue=DEAD_LETTER` | `--dead-letter-topic` |
| **Filter** | SQL filter rules | Attribute filter expressions |
| **Ordering** | `session_id` | `ordering_key` |

---

### **When to Use Which**

**Azure Service Bus:**
- Need traditional queues (point-to-point)
- Enterprise features (transactions, deferral)
- .NET ecosystem
- Already on Azure

**GCP Pub/Sub:**
- Pure event streaming
- Large messages (up to 10 MB)
- Push delivery needed
- Simple pub/sub
- Already on GCP

---

## 11. Serverless vs Containers

| Component | Timeout | When to Use |
|-----------|---------|-------------|
| **Azure Functions** | 10 min max | Quick tasks < 10 min |
| **Cloud Functions** | 60 min max | Quick tasks < 60 min |
| **Azure Container Apps** | Unlimited | Long tasks, need control |
| **Cloud Run** | Unlimited | Long tasks, need control |
| **Container Apps Jobs** | Unlimited | One-shot per message, memory isolation |
| **Cloud Run Jobs** | Unlimited | One-shot per message, memory isolation |

---

## 12. Key Interview Talking Points

### **EDA Benefits**
*"Event-driven architecture decouples services through asynchronous messaging. Instead of Service A calling Service B directly, Service A publishes an event that Service B subscribes to. This improves scalability since services can scale independently, and resilience since one service being down doesn't affect others."*

### **Queue vs Pub/Sub**
*"Queues are for task distribution - one message goes to one consumer (load balancing). Pub/Sub is for event broadcasting - one message goes to all subscribers. For example, order processing uses a queue to distribute work, while order events use pub/sub to notify inventory, email, and analytics services simultaneously."*

### **Azure vs GCP**
*"Azure Service Bus supports both queues and topics, making it suitable for traditional enterprise patterns. GCP Pub/Sub is purely pub/sub focused and better for high-throughput event streaming. Azure has richer features like transactions and sessions, while GCP allows larger messages (10 MB vs 256 KB) and native push delivery."*

### **Serverless vs Containers**
*"For short tasks under 10 minutes, Azure Functions are ideal - no infrastructure management, auto-scaling, pay per execution. For longer tasks like 15-minute report generation, we use Azure Container Apps with background workers. The container processes messages continuously with no timeout limit and auto-scales based on queue depth."*

### **Graceful Shutdown**
*"Graceful shutdown ensures in-progress work completes before container termination. When Kubernetes scales down, it sends SIGTERM. Our signal handler sets a flag. The current message finishes processing (could take 15 minutes), then we abandon the next message and exit cleanly. This prevents wasted compute and duplicate processing. We configure terminationGracePeriodSeconds longer than max task duration."*

### **Lock Renewal**
*"For tasks exceeding the default 60-second lock, we use AutoLockRenewer in Azure or modify_ack_deadline in GCP. It automatically extends the message lock every 30 seconds, telling the broker 'still working'. Without this, locks expire during processing and other consumers pick up the same message, causing duplicate processing."*

### **DLQ Monitoring**
*"In production, we monitor dead-letter queues for failed messages. Common reasons include validation errors, external API timeouts, and malformed data. We alert on DLQ depth and have a separate process to analyze patterns and reprocess or dead-letter permanently based on failure reason."*

---

## 13. Request/Response Pattern (When You Need Reply)

### **Problem:** Sender doesn't know if message was processed

### **Solution: Correlation ID + Reply Queue**

**Sender:**
```python
correlation_id = str(uuid.uuid4())

message = ServiceBusMessage(
    body=json.dumps({"order_id": 123}),
    correlation_id=correlation_id,
    reply_to="response-queue"
)

sender.send_messages(message)

# Listen for response
response_receiver = client.get_queue_receiver("response-queue")
for msg in response_receiver.receive_messages(max_wait_time=30):
    if msg.correlation_id == correlation_id:
        print(f"Response: {msg.body}")
        break
```

**Receiver:**
```python
for message in receiver:
    result = process(message)
    
    # Send response back
    if message.reply_to:
        response = ServiceBusMessage(
            body=json.dumps({"status": "success", "result": result}),
            correlation_id=message.correlation_id
        )
        response_sender = client.get_queue_sender(message.reply_to)
        response_sender.send_messages(response)
    
    receiver.complete_message(message)
```

**When to use:** API-like operations over messaging (but HTTP is better!)

---

## 14. Production Code Template

```python
import signal
import json
import logging
from azure.servicebus import ServiceBusClient, AutoLockRenewer
from concurrent.futures import ThreadPoolExecutor, TimeoutError

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Config
MAX_PROCESSING_TIME = 900  # 15 minutes
MAX_LOCK_RENEWAL = 1200    # 20 minutes

# Graceful shutdown
shutdown = False

def shutdown_handler(signum, frame):
    global shutdown
    logger.info("Shutdown signal received")
    shutdown = True

signal.signal(signal.SIGTERM, shutdown_handler)
signal.signal(signal.SIGINT, shutdown_handler)

# Main worker
def main():
    client = ServiceBusClient.from_connection_string("CONN_STR")
    receiver = client.get_queue_receiver("reports-queue")
    renewer = AutoLockRenewer()
    executor = ThreadPoolExecutor(max_workers=1)
    
    logger.info("Worker started")
    
    try:
        for message in receiver:
            if shutdown:
                logger.info("Abandoning message for shutdown")
                receiver.abandon_message(message)
                break
            
            renewer.register(receiver, message, max_lock_renewal_duration=MAX_LOCK_RENEWAL)
            
            body = json.loads(message.body)
            associate_id = body['associate_id']
            
            try:
                logger.info(f"Processing {associate_id}")
                
                # Process with timeout
                future = executor.submit(generate_report, body)
                result = future.result(timeout=MAX_PROCESSING_TIME)
                
                receiver.complete_message(message)
                logger.info(f"✅ {associate_id} completed")
                
            except TimeoutError:
                logger.warning(f"⏱️ {associate_id} timeout")
                receiver.abandon_message(message)
                
            except json.JSONDecodeError:
                logger.error(f"❌ Invalid JSON")
                receiver.dead_letter_message(message, reason="InvalidJSON")
                
            except Exception as e:
                logger.error(f"❌ {associate_id} failed: {e}")
                receiver.abandon_message(message)
                
    finally:
        executor.shutdown(wait=False)
        renewer.close()
        receiver.close()
        client.close()
        logger.info("Worker stopped")

if __name__ == "__main__":
    main()
```

---

## 15. Quick Command Reference

### **Azure**
```bash
# Create namespace
az servicebus namespace create --name myns --resource-group mygroup

# Create queue
az servicebus queue create --namespace-name myns --name myqueue

# Create topic
az servicebus topic create --namespace-name myns --name mytopic

# Create subscription
az servicebus topic subscription create --namespace-name myns --topic-name mytopic --name mysub

# Deploy Container App
az containerapp create --name worker --image myimage --scale-rule-type azure-servicebus
```

### **GCP**
```bash
# Create topic
gcloud pubsub topics create order-events

# Create subscription
gcloud pubsub subscriptions create order-sub --topic=order-events

# Create push subscription
gcloud pubsub subscriptions create push-sub --topic=order-events --push-endpoint=https://myapp.com/webhook

# Deploy Cloud Function
gcloud functions deploy my-function --trigger-topic=order-events --runtime=python311

# Deploy Cloud Run Job
gcloud run jobs create my-job --image gcr.io/project/image --task-timeout=20m
```

---

## END OF CHEAT SHEET

**Key Takeaways:**
1. **EDA** = Async messaging for loose coupling
2. **Queue** = One-to-one (load balance), **Pub/Sub** = One-to-many (broadcast)
3. **Azure** = Queues + Topics, **GCP** = Topics only
4. **Functions** = Short tasks (< 10 min), **Containers** = Long tasks (unlimited)
5. **Graceful shutdown** = Finish current work before exit
6. **Lock renewal** = Keep message locked during long processing
7. **Use HTTP for request/response**, messaging for async events
