import json
import httpx

# API endpoint
API_URL = "https://packagesales-backend-797525040891.us-central1.run.app/analyze"

# Path to the test Excel file
EXCEL_FILE_PATH = "test file.xlsx"

print("=" * 60)
print("🚀 Testing API Endpoint")
print("=" * 60)
print(f"📍 Endpoint: {API_URL}")
print(f"📁 File: {EXCEL_FILE_PATH}")
print("-" * 60)

try:
    # Open and send the Excel file
    with open(EXCEL_FILE_PATH, "rb") as f:
        files = {
            "file": (
                EXCEL_FILE_PATH,
                f,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        }

        print("📤 Sending POST request...")

        response = httpx.post(API_URL, files=files, timeout=60.0)

    # Check response status
    print(f"✅ Status Code: {response.status_code}")
    print("-" * 60)

    if response.status_code == 200:
        # Parse JSON response
        data = response.json()

        print("📊 Response Data:")
        print(json.dumps(data, indent=2))
        print("-" * 60)

        # Show summary
        if "AgentTeamInsights" in data:
            print(f"👥 Total Agents: {len(data['AgentTeamInsights'])}")
            print("\n📋 Agent List:")
            for idx, agent in enumerate(data["AgentTeamInsights"], 1):
                print(
                    f"  {idx}. {agent['Agent']} - Team: {agent['Team']} - Status: {agent['SalesStatus']}"
                )

        if "ReasonCatalogue" in data:
            print(f"\n📌 Total Reason Categories: {len(data['ReasonCatalogue'])}")

        print("=" * 60)
        print("✅ API Test Successful!")
        print("=" * 60)

    else:
        print(f"❌ Error: {response.status_code}")
        print(f"Response: {response.text}")

except FileNotFoundError:
    print(f"❌ File not found: {EXCEL_FILE_PATH}")
    print("Make sure the Excel file is in the same directory as this script!")

except httpx.RequestError as e:
    print(f"❌ Request failed: {e}")

except Exception as e:
    print(f"❌ Unexpected error: {e}")
