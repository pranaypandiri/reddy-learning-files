import streamlit as st
import json
import pandas as pd
from io import BytesIO
from datetime import datetime
import pytz
import openpyxl
from openai import AzureOpenAI
from pydantic import BaseModel, Field
from langchain.memory import ConversationBufferMemory
from langchain.schema import HumanMessage, AIMessage, SystemMessage
import httpx
from time import time
from typing import Optional


# Pydantic model for structured LLM output
class SupervisorResponse(BaseModel):
    """Structured response from supervisor with completion tracking"""

    response: str = Field(
        description="Casual, friendly message to the agent (2-3 sentences max)"
    )
    reasons_complete: bool = Field(
        description="True if ALL reasons have been REVEALED to agent OR agent identified them all. False if still in reasons phase."
    )
    improvements_complete: bool = Field(
        description="True if ALL improvements have been REVEALED to agent OR agent identified them all. False if still in improvements phase."
    )
    profanity_statement: Optional[str] = Field(
        default=None,
        description="If agent's message contains profanity, vulgar language, slurs, or inappropriate language, return the EXACT statement. Otherwise return None.",
    )


# Page Configuration
st.set_page_config(
    page_title="HICVy AI Supervisor Coaching", page_icon="🎯", layout="wide"
)

# Add custom CSS styling
st.markdown(
    """
    <style>
    /* Download button only */
    .stDownloadButton > button {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%) !important;
        color: white !important;
        border: none !important;
        font-weight: bold !important;
    }
    .stDownloadButton > button:hover {
        background: linear-gradient(90deg, #5a67d8 0%, #6b3fa0 100%) !important;
        transform: scale(1.02) !important;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Initialize Azure OpenAI Client
client = AzureOpenAI(
    api_key="92dc252cdb0c4079b4712a9ead4179ca",
    api_version="2024-12-01-preview",
    azure_endpoint="https://azureaitest4641590782.openai.azure.com/",
)


# Initialize session state
if "conversation_started" not in st.session_state:
    st.session_state.conversation_started = False

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

if "session_data" not in st.session_state:
    st.session_state.session_data = None

if "file_uploaded" not in st.session_state:
    st.session_state.file_uploaded = False

if "agent_name" not in st.session_state:
    st.session_state.agent_name = ""

if "agent_email" not in st.session_state:
    st.session_state.agent_email = ""

if "chat_start_time" not in st.session_state:
    st.session_state.chat_start_time = None

if "profanity_log" not in st.session_state:
    st.session_state.profanity_log = []

if "agent_dont_know_reasons" not in st.session_state:
    st.session_state.agent_dont_know_reasons = 0

if "agent_dont_know_improvements" not in st.session_state:
    st.session_state.agent_dont_know_improvements = 0


def parse_transcript(transcript_text):
    """Parse pasted transcript to extract metadata and conversations"""
    try:
        lines = transcript_text.strip().split("\n")

        # Extract metadata
        team = ""
        conversation_time = ""

        # Parse metadata section - handle both formats
        for line in lines:
            line_stripped = line.strip()

            # Handle "Team: value" format
            if line_stripped.startswith("Team:"):
                team = line_stripped.split("Team:", 1)[1].strip()
            # Handle "Conversation Time: value" format
            elif line_stripped.startswith("Conversation Time:"):
                conversation_time = line_stripped.split("Conversation Time:", 1)[
                    1
                ].strip()

        # Extract agent and customer conversations
        agent_lines = []
        customer_lines = []

        in_transcript = False
        for line in lines:
            line_stripped = line.strip()

            # Start capturing after "Transcript:" line
            if line_stripped.startswith("Transcript:"):
                in_transcript = True
                continue

            if in_transcript and line_stripped:  # Only process non-empty lines
                # Check if line starts with AGENT or VISITOR/CUSTOMER
                if line_stripped.startswith("AGENT"):
                    # Extract text after timestamp bracket: "AGENT [2:43:32 AM] Text here"
                    if "]" in line_stripped:
                        # Split by "]" and take everything after it, then strip whitespace
                        text = line_stripped.split("]", 1)[1].strip()
                        if text:  # Only add non-empty text
                            agent_lines.append(text)
                elif line_stripped.startswith("VISITOR") or line_stripped.startswith(
                    "CUSTOMER"
                ):
                    # Extract text after timestamp bracket
                    if "]" in line_stripped:
                        text = line_stripped.split("]", 1)[1].strip()
                        if text:  # Only add non-empty text
                            customer_lines.append(text)

        # Join with newlines to preserve conversation structure
        agent_conversation = "\n".join(agent_lines)
        customer_conversation = "\n".join(customer_lines)

        # Debug: Print parsed data
        print("\n" + "=" * 60)
        print("📋 PARSED TRANSCRIPT DATA")
        print("=" * 60)
        print(f"Team: {team}")
        print(f"Conversation Time: {conversation_time}")
        print(f"Agent Lines Count: {len(agent_lines)}")
        print(f"Customer Lines Count: {len(customer_lines)}")
        print(f"\nAgent Conversation (first 200 chars):\n{agent_conversation[:200]}...")
        print(
            f"\nCustomer Conversation (first 200 chars):\n{customer_conversation[:200]}..."
        )
        print("=" * 60 + "\n")

        return {
            "team": team,
            "conversation_time": conversation_time,
            "agent_conversation": agent_conversation,
            "customer_conversation": customer_conversation,
            "sale_status": "NO-SALE",
        }

    except Exception as e:
        st.error(f"❌ Error parsing transcript: {str(e)}")
        return None


def create_excel_from_transcript(parsed_data):
    """Create Excel file from parsed transcript data"""
    try:
        # Create workbook
        wb = openpyxl.Workbook()
        ws = wb.active

        # Add headers (Row 1)
        ws["B1"] = "Team"
        ws["C1"] = "Conversation Time"
        ws["D1"] = "Agent Conversation"
        ws["E1"] = "Customer Conversation"
        ws["F1"] = "Sale Status"

        # Add data (Row 2)
        ws["B2"] = parsed_data["team"]
        ws["C2"] = parsed_data["conversation_time"]
        ws["D2"] = parsed_data["agent_conversation"]
        ws["E2"] = parsed_data["customer_conversation"]
        ws["F2"] = parsed_data["sale_status"]

        # Save to BytesIO
        output = BytesIO()
        wb.save(output)
        output.seek(0)

        return output

    except Exception as e:
        st.error(f"❌ Error creating Excel: {str(e)}")
        return None


def process_transcript_text(transcript_text):
    """Process transcript text, create Excel, and send to API"""
    try:
        # Parse transcript
        parsed_data = parse_transcript(transcript_text)
        if not parsed_data:
            return False

        # Create Excel file
        excel_file = create_excel_from_transcript(parsed_data)
        if not excel_file:
            return False

        # Now send to API
        API_URL = "https://packagesale-new-797525040891.us-central1.run.app/analyzechat"

        files = {
            "file": (
                "transcript.xlsx",
                excel_file.getvalue(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        }

        # Call API
        response = httpx.post(API_URL, files=files, timeout=60.0)
        response.raise_for_status()

        # Parse response
        data = response.json()

        # Extract ReasonCatalogue
        if "ReasonCatalogue" not in data:
            st.error("❌ No ReasonCatalogue found in API response")
            return False

        reason_catalogue = data["ReasonCatalogue"]

        # Debug: Print ReasonCatalogue
        print("\n" + "=" * 60)
        print("📋 REASON CATALOGUE")
        print("=" * 60)
        print(json.dumps(reason_catalogue, indent=2))
        print("=" * 60 + "\n")

        # Extract reasons and improvements
        reasons = [item["Reason"] for item in reason_catalogue if "Reason" in item]
        improvements = [
            item["Suggestions"] for item in reason_catalogue if "Suggestions" in item
        ]

        # Debug: Print extracted data
        print("\n" + "=" * 60)
        print("✅ EXTRACTED REASONS & IMPROVEMENTS")
        print("=" * 60)
        print(f"Reasons found: {len(reasons)}")
        for i, reason in enumerate(reasons, 1):
            print(f"  {i}. {reason}")
        print(f"\nImprovements found: {len(improvements)}")
        for i, improvement in enumerate(improvements, 1):
            print(f"  {i}. {improvement}")
        print("=" * 60 + "\n")

        if not reasons or not improvements:
            st.error("❌ No reasons or improvements found in response")
            return False

        # Build transcription for chat context
        transcription = [
            {"speaker": "Agent", "message": parsed_data["agent_conversation"]},
            {"speaker": "Customer", "message": parsed_data["customer_conversation"]},
        ]

        # Store in session state
        st.session_state.session_data = {
            "mistakes": reasons,
            "improvements": improvements,
            "transcription": transcription,
        }

        st.session_state.file_uploaded = True
        return True

    except httpx.HTTPStatusError as e:
        st.error(f"❌ API Error: {e.response.status_code}")
        return False
    except httpx.RequestError as e:
        st.error(f"❌ Request failed: {str(e)}")
        return False
    except Exception as e:
        st.error(f"❌ Unexpected error: {str(e)}")
        return False


def upload_and_analyze_file(uploaded_file):
    """Upload file to backend API and extract reasons/improvements"""
    try:
        # API endpoint
        API_URL = (
            "https://packagesales-backend-797525040891.us-central1.run.app/analyze"
        )

        # Prepare file for upload
        files = {
            "file": (
                uploaded_file.name,
                uploaded_file.getvalue(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        }

        # Call API
        response = httpx.post(API_URL, files=files, timeout=60.0)
        response.raise_for_status()

        # Parse response
        data = response.json()

        # Debug: Print the API response
        print("\n" + "=" * 60)
        print("🔍 API RESPONSE DEBUG")
        print("=" * 60)
        print(json.dumps(data, indent=2))
        print("=" * 60 + "\n")

        # Extract ReasonCatalogue
        if "ReasonCatalogue" not in data:
            st.error("❌ No ReasonCatalogue found in API response")
            return False

        reason_catalogue = data["ReasonCatalogue"]

        # Debug: Print ReasonCatalogue
        print("\n" + "=" * 60)
        print("📋 REASON CATALOGUE")
        print("=" * 60)
        print(json.dumps(reason_catalogue, indent=2))
        print("=" * 60 + "\n")

        # Extract reasons and improvements
        reasons = [item["Reason"] for item in reason_catalogue if "Reason" in item]
        improvements = [
            item["Suggestions"] for item in reason_catalogue if "Suggestions" in item
        ]

        # Debug: Print extracted data
        print("\n" + "=" * 60)
        print("✅ EXTRACTED DATA")
        print("=" * 60)
        print(f"Reasons found: {len(reasons)}")
        print(f"Reasons: {reasons}")
        print(f"Improvements found: {len(improvements)}")
        print(f"Improvements: {improvements}")
        print("=" * 60 + "\n")

        if not reasons or not improvements:
            st.error("❌ No reasons or improvements found in response")
            return False

        # Extract transcription from Excel file (columns D & E)
        transcription = []
        try:
            df = pd.read_excel(uploaded_file)
            # Column D (index 3) = Agent Conversation
            # Column E (index 4) = Customer Conversation
            if len(df.columns) > 4:
                agent_text = str(df.iloc[0, 3]) if pd.notna(df.iloc[0, 3]) else ""
                customer_text = str(df.iloc[0, 4]) if pd.notna(df.iloc[0, 4]) else ""

                if agent_text:
                    transcription.append({"speaker": "Agent", "message": agent_text})
                if customer_text:
                    transcription.append(
                        {"speaker": "Customer", "message": customer_text}
                    )
        except Exception as e:
            # If transcription extraction fails, continue with empty transcription
            pass

        # Store in session state
        st.session_state.session_data = {
            "mistakes": reasons,
            "improvements": improvements,
            "transcription": transcription,
        }

        st.session_state.file_uploaded = True
        return True

    except httpx.HTTPStatusError as e:
        st.error(f"❌ API Error: {e.response.status_code}")
        return False
    except httpx.RequestError as e:
        st.error(f"❌ Request failed: {str(e)}")
        return False
    except Exception as e:
        st.error(f"❌ Unexpected error: {str(e)}")
        return False


def load_session_data(file_path="session_data.json"):
    """Load session data from JSON file"""
    try:
        with open(file_path, "r") as f:
            data = json.load(f)
        return data
    except FileNotFoundError:
        st.error(f"❌ File not found: {file_path}")
        return None
    except json.JSONDecodeError:
        st.error("❌ Invalid JSON format")
        return None


def reset_conversation():
    """Reset conversation to start fresh"""
    st.session_state.conversation_started = False
    st.session_state.chat_history = []
    st.session_state.session_data = None  # Clear cached session data
    st.session_state.file_uploaded = False  # Clear file upload status
    st.session_state.chat_start_time = None  # Reset start time
    st.session_state.profanity_log = []  # Clear profanity tracking
    st.session_state.agent_dont_know_reasons = 0  # Reset don't know counters
    st.session_state.agent_dont_know_improvements = 0
    if "llm_instance" in st.session_state:
        del st.session_state.llm_instance  # Clear LLM instance to reset memory
    st.success("✅ Conversation reset! Ready to paste a new transcript.")


def export_conversation_to_excel():
    """Export chat history to Excel file"""
    if not st.session_state.chat_history:
        st.warning("⚠️ No conversation to export")
        return None

    # Create workbook
    wb = openpyxl.Workbook()

    # Sheet 1: Chat History
    ws1 = wb.active
    ws1.title = "Chat History"
    ws1.append(["Role", "Message", "Timestamp"])

    for msg in st.session_state.chat_history:
        ws1.append(
            [msg.get("role", ""), msg.get("content", ""), msg.get("timestamp", "")]
        )

    # Sheet 2: Session Metadata
    ws2 = wb.create_sheet(title="Session Metadata")
    ws2.append(["Field", "Value"])
    central = pytz.timezone("America/Chicago")
    ws2.append(["Session Date", datetime.now(central).strftime("%Y-%m-%d %H:%M:%S %Z")])
    ws2.append(["Total Messages", len(st.session_state.chat_history)])

    if st.session_state.session_data:
        ws2.append(
            ["Mistakes Count", len(st.session_state.session_data.get("mistakes", []))]
        )
        ws2.append(
            [
                "Improvements Count",
                len(st.session_state.session_data.get("improvements", [])),
            ]
        )

    # Save to BytesIO
    output = BytesIO()
    wb.save(output)
    output.seek(0)

    return output


class ConversationLLM:

    GOODBYE_KEYWORDS = [
        "bye",
        "goodbye",
        "have a nice day",
        "talk to you later",
        "thanks again",
        "see you",
        "take care",
        "alright thanks for your help",
    ]

    SUMMARIZE_KEYWORDS = [
        "summarize",
        "summary",
        "sum up",
        "recap",
        "overview",
    ]

    def __init__(self):
        self.memory = ConversationBufferMemory(
            memory_key="chat_history", return_messages=True
        )
        self.reasons_revealed = False
        self.improvements_revealed = False

    def detect_summarize(self, message):
        """Check if user is requesting a summary"""
        return any(kw in message.lower() for kw in self.SUMMARIZE_KEYWORDS)

    def count_coaching_attempts(self, user_input):
        """Check if current user input has 'don't know' and update global counters"""

        # Check if user's CURRENT message has "don't know" keywords
        user_said_dont_know = any(
            keyword in user_input.lower()
            for keyword in [
                "don't know",
                "tell me",
                "please tell",
                "unable to think",
                "can't think",
                "not able to find",
                "can't find",
                "no idea",
                "not sure",
                "can't figure",
                "help me",
                "stuck",
                "don't see",
                "can't see",
                "confused",
                "not getting it",
            ]
        )

        # If yes, increment the appropriate global counter
        if user_said_dont_know:
            if not self.reasons_revealed:
                st.session_state.agent_dont_know_reasons += 1
            elif not self.improvements_revealed:
                st.session_state.agent_dont_know_improvements += 1

        # Decision logic for REASONS: hint at 1, reveal at 2+
        should_give_hint_reasons = (
            st.session_state.agent_dont_know_reasons == 1 and not self.reasons_revealed
        )
        should_reveal_reasons = (
            st.session_state.agent_dont_know_reasons >= 2 and not self.reasons_revealed
        )

        # Decision logic for IMPROVEMENTS: reveal immediately on first "don't know"
        should_reveal_improvements = (
            st.session_state.agent_dont_know_improvements >= 1
            and not self.improvements_revealed
        )

        return {
            "agent_dont_know_reasons": st.session_state.agent_dont_know_reasons,
            "should_reveal_reasons": should_reveal_reasons,
            "should_give_hint_reasons": should_give_hint_reasons,
            "agent_dont_know_improvements": st.session_state.agent_dont_know_improvements,
            "should_reveal_improvements": should_reveal_improvements,
            "should_give_hint_improvements": False,  # No hints for improvements
        }

    def convllm(self, user_input, session_data, is_summarize=False):

        # Build conversation history
        history_text = ""
        for message in self.memory.chat_memory.messages:
            if isinstance(message, HumanMessage):
                history_text += f"Agent: {message.content}\n"
            elif isinstance(message, AIMessage):
                history_text += f"Supervisor: {message.content}\n"

        # Build transcription context
        transcription_text = ""
        if session_data and "transcription" in session_data:
            for turn in session_data["transcription"]:
                transcription_text += f"{turn['speaker']}: {turn['message']}\n\n"

        # Get reasons and improvements
        reasons = (
            session_data.get("mistakes", []) if session_data else []
        )  # Backend still uses 'mistakes' key
        improvements = session_data.get("improvements", []) if session_data else []

        # Format reasons and improvements
        reasons_text = "\n".join(f"{i+1}. {r}" for i, r in enumerate(reasons))
        improvements_text = "\n".join(
            f"{i+1}. {imp}" for i, imp in enumerate(improvements)
        )

        # COUNT ATTEMPTS FIRST (Python logic - no LLM guessing)
        attempt_info = self.count_coaching_attempts(user_input)

        print("\n" + "=" * 60)
        print(f"🔢 COACHING ATTEMPT INFO : {attempt_info}")
        print("=" * 60 + "\n")

        # Check if both reasons and improvements have been revealed
        all_revealed = self.reasons_revealed and self.improvements_revealed

        # Get agent name from session state
        agent_name = st.session_state.get("agent_name", "")

        # Build your supervisor prompt here
        Customer_prompt = f"""
        You are AI Supervisor HICVy, a friendly and supportive AI supervisor coaching an agent about a customer service call.
        
        === AGENT INFORMATION ===
        Agent Name: {agent_name if agent_name else "Not provided"}
        
        === CALL TRANSCRIPTION (Must be used for the guiding questions and for giving out hints) ===
        {transcription_text}
        
        === REASONS THE CALL DIDN'T GO WELL ({len(reasons)} total) ===
        {reasons_text}
        
        === SUGGESTED IMPROVEMENTS ({len(improvements)} total) ===
        {improvements_text}
        
        === CONVERSATION HISTORY ===
        {history_text}
        
        === AGENT JUST SAID ===
        {user_input}
        
        === SYSTEM TRACKING (Calculated by Python) ===
        - Agent said "don't know" about reasons: {attempt_info['agent_dont_know_reasons']} times
        - Agent said "don't know" about improvements: {attempt_info['agent_dont_know_improvements']} times
        - Should give hint for reasons: {attempt_info['should_give_hint_reasons']}
        - Should reveal reasons now: {attempt_info['should_reveal_reasons']}
        - Should give hint for improvements: {attempt_info['should_give_hint_improvements']}
        - Should reveal improvements now: {attempt_info['should_reveal_improvements']}
        - Reasons already revealed: {self.reasons_revealed}
        - Improvements already revealed: {self.improvements_revealed}
        - All content revealed: {all_revealed}
        - Is summarize request: {is_summarize}
        
        === YOUR COACHING LOGIC ===
        
        **CORE COACHING PRINCIPLES (APPLY TO ALL RESPONSES):**
        ✓ CONCISE & CRISPY: Max 2-3 sentences per response (except summaries)
        ✓ TURNING POINT FOCUS: Always ask about the EXACT MOMENT things went wrong, not generic "what went wrong"
        ✓ TRANSCRIPT-BASED: Reference SPECIFIC quotes/moments from TRANSCRIPTION in every hint, reveal, or feedback
        ✓ GUIDING QUESTIONS: Use questions that make agent THINK and REFLECT on specific call moments
        ✓ BE DIRECT: Practice what we preach - efficient, punchy, no fluff
        
        GREETING (If this is the FIRST message in CONVERSATION HISTORY):
        → Start with warm, casual greeting ONLY: "Hi there! I'm HICVy. How's it going on your side?" or "Hey! I'm HICVy. How are things going with you?"
        → DO NOT mention the call yet
        → DO NOT ask about reasons yet
        → Just be friendly and casual - wait for their response
        → Keep it 1-2 sentences max
        
        SECOND INTERACTION (After agent responds to greeting):
        → If agent shared something casual (how they're doing, etc.):
          → Acknowledge it briefly: "Good to hear!" or "Nice!" or respond appropriately to what they said
          → Then set context joyfully: "Alright! So we're going to dive into your call today and figure out why it went NO-SALE, what reasons led to that, and how we can flip it from NO-SALE to SALE next time. Sound good?"
          → Wait for their response before asking about reasons
        → If agent responds positively/ready (like "yes", "sure", "okay", "let's do it"):
          → Jump to asking: "Perfect! So what was the EXACT MOMENT this call went south? Where did you lose the customer?"
        → If agent asks about the call or feedback directly:
          → Set context: "Great! So we're going to figure out why this call went NO-SALE and how to flip it. What was the turning point - the moment you felt the customer slip away?"
        → Be conversational, supportive, and energetic

         === PROFANITY & INAPPROPRIATE LANGUAGE DETECTION ===
        - Analyze the agent's message ("{user_input}") for profanity, vulgar language, slurs, or inappropriate expressions
        - If detected, populate profanity_statement field with the EXACT statement from the agent
        - If profanity is detected, Please say something like: "Let's keep it professional. Please avoid using inappropriate language."
        - If NO profanity detected, set profanity_statement to None
        - Important: If the user mention any situation or context from the customer CALL TRANSCRIPTION, do NOT flag that as profanity - only flag direct agent language
        
        
        PHASE 1 - REASONS IDENTIFICATION:
        
        **IMPORTANT: Check if agent already identified all {len(reasons)} reasons in CONVERSATION HISTORY**
        → Look through the CONVERSATION HISTORY and see if the agent has already mentioned ALL {len(reasons)} reasons
        → If YES (all {len(reasons)} reasons found in agent's previous messages):
          → Skip hint/reveal mechanism
          → Acknowledge: "Nice work! You nailed all the reasons the call was tricky."
          → Move directly to PHASE 2 (ask for improvements)
        
        If reasons NOT revealed yet ({self.reasons_revealed} is False) AND agent hasn't identified all reasons:
          
          If should_reveal_reasons is True ({attempt_info['should_reveal_reasons']}):
            → Agent said "don't know" TWICE - time to reveal
            → Be casual and supportive: "No worries! Here's what I spotted."
            → Reveal all {len(reasons)} reasons WITH TRANSCRIPT EVIDENCE
            → Format for EACH reason: "[Reason number]. [Exact reason text] → [Quote from TRANSCRIPTION showing where this happened]"
            → Example: "1. Agent didn't build rapport → Customer said 'Let's get to the point' but you kept pushing small talk\n2. Pricing objection not handled → Customer: 'That's expensive' You: 'Well, that's our price' - this shut them down"
            → After all reasons: "So, what improvements would help fix these issues?"
            → Keep it SHORT and PUNCHY
          
          Else if should_give_hint_reasons is True ({attempt_info['should_give_hint_reasons']}):
            → Agent needs guidance - provide a TRANSCRIPT-BASED guiding question
            → MUST include an EXACT QUOTE from TRANSCRIPTION related to one of the {len(reasons)} reasons
            → Format: Quote the moment + Ask a guiding question
            → Example: "Look at this - Customer said: '[exact quote]' and you replied: '[exact quote].' What happened to the conversation right after that?"
            → Or: "At [specific moment], Customer: '[exact quote].' What does their response tell you about how they felt?"
            → Keep it SHORT (2 sentences max) and make them THINK about that specific moment
          
          Else:
            → First time asking or agent is trying
            → Focus on TURNING POINT: "So what was the exact moment this call went sideways? I spotted {len(reasons)} key moments."
            → Or: "Where did you feel the customer disconnect? There are {len(reasons)} turning points I noticed."
            → Keep it SHORT - 1 sentence only
        
        PHASE 2 - IMPROVEMENTS SUGGESTION:
        
        **IMPORTANT: Check if agent already identified improvements in CONVERSATION HISTORY**
        → Count how many improvements the agent mentioned in their previous messages
        → If agent identified ALL {len(improvements)} improvements:
          → Skip hint/reveal mechanism
          → Acknowledge: "Awesome! You got all the improvements."
          → Move directly to PHASE 3
        → If agent identified SOME improvements (1 out of {len(improvements)}):
          → Acknowledge what they got: "Great job! That's spot on."
          → Ask for the remaining ones: "There's {len(improvements) - 1} more improvement(s) I noticed. Can you think of what it might be?"
          → Give them a chance to answer - DO NOT reveal yet
          → Wait for their next response
        
        If reasons ARE revealed ({self.reasons_revealed} is True) AND improvements NOT revealed yet:
          
          If should_reveal_improvements is True ({attempt_info['should_reveal_improvements']}):
            → Agent said "don't know" about improvements - time to reveal
            → Be supportive: "Here's what could flip this to a sale:"
            → Reveal all {len(improvements)} improvements WITH TRANSCRIPT CONTEXT
            → Format for EACH improvement: "[Number]. [Exact improvement text] → Instead of: '[what agent actually said in transcript]', try: '[better approach]'"
            → Example: "1. Handle objections smoothly → Instead of 'That's our price', try 'I get it, let me show you the value'"
            → After all improvements: "Hope this helps you!"
            → Keep it SHORT and ACTIONABLE
          
          Else:
            → First time asking for improvements
            → Be conversational: "So now that we've talked about what went wrong, what do you think could've been done differently?"
            → Or: "What improvements would you make if you could redo this call?"
            → Keep it natural and engaging
        
        PHASE 3 - CLOSURE (FINAL PHASE):
        
        **CRITICAL: SUMMARY REQUEST (MUST FOLLOW EXACTLY) **
        If is_summarize is True ({is_summarize}):
          → Agent requested a summary - THIS IS MANDATORY TO PROVIDE
          → Generate a story-style summary in 4-6 sentences following this flow:
          
          **Story Format:**
          1. What happened: Briefly describe the no-sale call situation (1 sentence)
          2. Why it didn't work: State the {len(reasons)} reasons using EXACT text from REASONS list (1-2 sentences)
          3. What to do differently: State the {len(improvements)} improvements using EXACT text from IMPROVEMENTS list (1-2 sentences)
          4. Expected result: How these changes turn no-sale into successful sales (1 sentence)
          
          → Write as a natural flowing story, NOT bullet points
          → Example: "In this call, the customer wasn't interested in the product. This happened because [exact reason 1 text], [exact reason 2 text], and [exact reason 3 text]. To turn this around, the agent should [exact improvement 1 text], [exact improvement 2 text], and [exact improvement 3 text]. With these changes, the next similar call can become a successful sale."
          → DO NOT ask follow-up questions after summary - just provide it and STOP
          → This takes priority over ALL other logic when is_summarize is True
        
        If all content revealed ({all_revealed} is True) AND is_summarize is False:
          
          **FIRST TIME ALL REVEALED - Give motivational completion message**
          → Check CONVERSATION HISTORY to see if this is the FIRST message after both reasons and improvements were revealed
          → If this is the first time all_revealed is True (no previous supervisor message after full reveal):
            → Give a strong motivational closing statement: "Awesome work! With these insights on the reasons and improvements, you're now equipped to turn no-sale calls into successful sales. Keep practicing and applying what we discussed!"
            → Keep it positive, energetic, 2-3 sentences max
            → NO questions yet - just acknowledge and motivate
            → This should happen ONLY ONCE when both phases complete
          
          **AFTER COMPLETION MESSAGE - Handle follow-up**
          
          **CRITICAL: NO MORE HINTS OR QUESTIONS - Just acknowledge and summarize**
          
          If agent is asking for MORE recommendations, suggestions, or additional advice:
            → FIRST: Acknowledge their question warmly: "Great question!" or "Good thinking!"
            → Then refer to what was already discussed: "The improvements I mentioned earlier are more than enough to make this a sale call next time."
            → End with: "What are your key takeaways from what we discussed?"
            → DO NOT give new recommendations
            → Keep it brief and redirect to closure
          
          Else if agent is asking to ELABORATE or explain a SPECIFIC improvement in detail:
            → FIRST: Acknowledge: "Sure, let me break that down!"
            → Then explain that specific improvement in detail using context from the TRANSCRIPTION
            → Connect it to the specific moment in the call where it applies
            → After elaborating, ask: "Does that make sense? Any other improvements you want me to explain?"
            → Be helpful and detailed - this is valid learning
          
          Else if agent is sharing their own ideas/suggestions (not from our list):
            → FIRST: Acknowledge their idea positively: "That's a solid idea!" or "Good thinking!" or "Nice approach!"
            → Then gently redirect: "Those are the main improvements I wanted to highlight. What are your key takeaways from our discussion?"
            → Be supportive of their creativity but steer to closure
          
          Else if agent is sharing takeaways/how they'll use them (any response - good or minimal):
            → If they shared meaningful takeaways:
              → Acknowledge warmly: "Great insights!" or "Love that!" or "Exactly!"
            → If they say "nothing", "don't know", "not sure", or give minimal response:
              → Be supportive: "No problem!" or "That's okay!"
            → Then ALWAYS say: "Spend some time going through the reasons and improvements we discussed - you'll understand them better."
            → End with casual goodbye: "Good luck with your next call!" or "Talk to you later!"
            → Format: "[Acknowledgment]. Spend some time going through the reasons and improvements we discussed - you'll understand them better. [Goodbye]"
            → Example: "No problem! Spend some time going through the reasons and improvements we discussed - you'll understand them better. Good luck!"
            → This is the TRUE END - conversation should close here
          
          Else:
            → Ask for their takeaways: "So, what are your main takeaways from this? How will you use these in your next call?"
            → Keep it casual and conversational
            → Maximum 1-2 sentences
        
        === OUTPUT RULES ===
        - CRISPY & CONCISE: Maximum 2-3 sentences (EXCEPT summaries) - be BRIEF and DIRECT
        - TRANSCRIPT-BASED: ALWAYS reference EXACT QUOTES from TRANSCRIPTION when giving hints/reveals/feedback
        - TURNING POINT FOCUS: Ask about SPECIFIC MOMENTS, not generic "what went wrong"
        - GUIDING QUESTIONS: Make agent THINK with questions tied to specific transcript moments
        - ALWAYS acknowledge agent's points first before responding (1 quick phrase)
        - Be casual and punchy - like a direct coach, not a lecturer
        - Use agent's name SPARINGLY (once every 4-5 messages at most)
        - NO repetition - each response should progress the conversation
        - NEVER create new reasons/improvements beyond the provided lists - ALWAYS use EXACT text from lists
        - Follow the phase logic EXACTLY based on the boolean values above
        - After all content revealed: NO MORE HINTS - just acknowledge and move to closure
        
        === OFF-TOPIC HANDLING ===
        - If agent talks about something COMPLETELY unrelated to the call (weather, sports, random topics):
        - Politely redirect: "Hey, let's stick to the call feedback for now. I'd like to wrap this up with your takeaways, cool?"
        - Keep it friendly but firm - bring them back to the coaching session
        
       
        === YOUR RESPONSE === 
        """

        # Use structured output with Pydantic - PRODUCTION READY! 🦇
        response = client.beta.chat.completions.parse(
            model="gpt-4.1",
            messages=[
                {"role": "system", "content": ""},
                {"role": "user", "content": Customer_prompt},
            ],
            response_format=SupervisorResponse,
            temperature=0.7,
            max_tokens=1000,
        )

        # Extract structured data - type-safe!
        parsed_response = response.choices[0].message.parsed
        response_content = parsed_response.response

        # 📊 Track token usage from Azure OpenAI response

        # Update flags based on LLM's intelligent detection
        if parsed_response.reasons_complete:
            self.reasons_revealed = True

        if parsed_response.improvements_complete:
            self.improvements_revealed = True

        # Capture profanity if detected
        if parsed_response.profanity_statement:
            st.session_state.profanity_log.append(parsed_response.profanity_statement)
            print(f"\n⚠️ PROFANITY DETECTED: {parsed_response.profanity_statement}")
            print(f"Total profanity instances: {len(st.session_state.profanity_log)}\n")

        # Save to memory (only the text response, not the flags)
        self.memory.save_context({"input": user_input}, {"output": response_content})

        return response_content

    def detect_goodbye(self, message):
        """Check if conversation should end based on goodbye keywords"""
        return any(kw in message.lower() for kw in self.GOODBYE_KEYWORDS)


def main():
    # Title and Header
    st.markdown(
        "<h1 style='text-align: center; margin-bottom: 30px;'>🎯 HICVy AI Supervisor Coaching</h1>",
        unsafe_allow_html=True,
    )

    # Initialize LLM instance after class definition
    if "llm_instance" not in st.session_state:
        st.session_state.llm_instance = ConversationLLM()

    # Sidebar controls
    with st.sidebar:
        st.header("🎛️ Session Controls")

        # Start Session Button (only enabled after transcript analysis)
        if st.session_state.file_uploaded and not st.session_state.conversation_started:
            st.markdown("---")
            if st.button(
                "🚀 Start AI Supervisor Guidance",
                type="primary",
                use_container_width=True,
                key="start_btn",
            ):
                st.session_state.conversation_started = True
                st.session_state.chat_start_time = time()  # Track start time
                st.success("✅ Session started! Supervisor is ready to chat.")
                st.rerun()
        elif st.session_state.conversation_started:
            st.markdown("---")
            st.success("✅ Session Active")

        st.markdown("---")

        # Reset Button
        if st.button(
            "🔄 Reset Conversation", use_container_width=True, key="reset_btn"
        ):
            reset_conversation()
            st.rerun()

        st.markdown("---")

        # Pro Tips Section
        st.markdown("### 💡 Pro Tips")
        st.markdown(
            """

         **⚠️ Important Notes:**
        
        📋 **NO-SALE Transcripts Only**  
        Please paste only unsuccessful call transcripts
        
        📊 **No Compliance Scoring feature**
        Please focus on coaching for reasons & improvements only.
        
        🎯 **Hint & Reveal Mechanism**  
        • **Reasons Phase**: 1st "don't know" → Hint, 2nd "don't know" → Full reveal  
        • **Improvements Phase**: 1st "don't know" → Full reveal immediately  
        • Try to discover insights yourself first!
    
        **Quick Commands:**
        
        🟢 **"HI" / "HELLO" / Hi HICVy**  
        Start The Conversation
        
        🔴 **"BYE" / "GOODBYE"**  
        End The Session
        
        📝 **"SUMMARIZE"**  
        Get A Summary Of Reasons & Improvements
        
        ❓ **"I DON'T KNOW"**  
        Get Hints When Stuck (1st time = hint, 2nd time = reveal)
        
        ---
        
       
        """
        )

        st.markdown("---")

        # Download Chat History Button
        if st.session_state.chat_history:
            excel_output = export_conversation_to_excel()
            if excel_output:
                st.download_button(
                    label="📥 Download Conversation",
                    data=excel_output,
                    file_name=f"coaching_session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                )

    # Main Content Area
    if not st.session_state.file_uploaded:
        # Transcript Input Screen - Center of UI
        st.markdown("---")
        st.markdown("### 📝 Enter Agent Details & Paste Transcript")

        # Agent Name Input
        agent_name = st.text_input(
            "Agent Name *",
            placeholder="Enter your full name",
            value=st.session_state.agent_name,
            key="agent_name_input",
        )

        # Agent Email Input
        agent_email = st.text_input(
            "Agent Email *",
            placeholder="Enter your email address",
            value=st.session_state.agent_email,
            key="agent_email_input",
        )

        st.markdown("**Paste Your Call Transcript:**")
        st.markdown(
            "Paste the complete transcript including metadata (Conversation ID, Team, Conversation Time, etc.) and the conversation."
        )

        transcript_input = st.text_area(
            "Transcript",
            height=400,
            placeholder="""Metadata: 

Conversation ID: 688366911347 
Conversation Time: 11/22/2025, 2:43 AM - 11/22/2025, 2:52 AM (Asia/Shanghai) 
Agent Full Name: Sherwin Winston Lequit 
Team: Team Joshua Alfafara 
Use Case: transfers-voice 

Transcript: 

AGENT [2:43:32 AM] Good afternoon, and thank you for transferring...
VISITOR [2:43:37 AM] Hello?
...""",
            label_visibility="collapsed",
        )

        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            # Check if all fields are filled
            all_fields_filled = (
                agent_name.strip() != ""
                and agent_email.strip() != ""
                and transcript_input.strip() != ""
            )

            if st.button(
                "🚀 Submit",
                type="primary",
                use_container_width=True,
                disabled=not all_fields_filled,
            ):
                # Validate email format
                if "@" not in agent_email or "." not in agent_email:
                    st.error("⚠️ Please enter a valid email address")
                else:
                    # Save agent details to session state
                    st.session_state.agent_name = agent_name
                    st.session_state.agent_email = agent_email

                    with st.spinner("Analyzing transcript..."):
                        success = process_transcript_text(transcript_input)
                        if success:
                            st.success("✅ Transcript analyzed successfully!")
                            st.rerun()

            # Show warning if fields are empty
            if not all_fields_filled:
                st.caption("⚠️ Please fill all fields to continue")

    elif st.session_state.file_uploaded and not st.session_state.conversation_started:
        # Transcript analyzed but session not started
        st.markdown("---")
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.success(
                "✅ **Transcript Analyzed Successfully!**\n\n"
                f"**Reasons Found:** {len(st.session_state.session_data.get('mistakes', []))}\n\n"
                f"**Improvements Suggested:** {len(st.session_state.session_data.get('improvements', []))}\n\n"
                "Click **'Start AI Supervisor Guidance'** in the sidebar to begin coaching."
            )

    else:
        # Chat Interface (Active Session)
        st.markdown("---")

        # Display chat history
        for msg in st.session_state.chat_history:
            role = msg.get("role", "")
            content = msg.get("content", "")

            if role == "supervisor":
                with st.chat_message("assistant", avatar="👔"):
                    st.markdown(content)
            elif role == "agent":
                with st.chat_message("user", avatar="👤"):
                    st.markdown(content)

        # Chat input
        user_input = st.chat_input("Type your response here...")

        if user_input:
            # Add user message to history
            central = pytz.timezone("America/Chicago")
            st.session_state.chat_history.append(
                {
                    "role": "agent",
                    "content": user_input,
                    "timestamp": datetime.now(central).strftime("%Y-%m-%d %H:%M:%S %Z"),
                }
            )

            # Display user message
            with st.chat_message("user", avatar="👤"):
                st.markdown(user_input)

            # Check for goodbye keywords to end conversation
            if st.session_state.llm_instance.detect_goodbye(user_input):
                goodbye_message = "Thank you for this coaching session! Feel free to start a new one anytime. Click 'Reset Conversation' to begin fresh."

                central = pytz.timezone("America/Chicago")
                st.session_state.chat_history.append(
                    {
                        "role": "supervisor",
                        "content": goodbye_message,
                        "timestamp": datetime.now(central).strftime(
                            "%Y-%m-%d %H:%M:%S %Z"
                        ),
                    }
                )

                with st.chat_message("assistant", avatar="👔"):
                    st.markdown(goodbye_message)

                # Save conversation to database with spinner
                if st.session_state.chat_start_time:
                    duration_seconds = int(time() - st.session_state.chat_start_time)

                    with st.spinner("💾 Saving conversation to database..."):
                        try:
                            filtered_profanity = list(
                                filter(None, st.session_state.profanity_log)
                            )
                            response = httpx.post(
                                "https://packagesale-new-797525040891.us-central1.run.app/addconvlogs",
                                json={
                                    "agent_name": st.session_state.agent_name
                                    or "Unknown Agent",
                                    "agent_email": st.session_state.agent_email
                                    or "unknown@company.com",
                                    "conversation_data": {
                                        "messages": st.session_state.chat_history,
                                        "session_info": "AI Coaching Session",
                                    },
                                    "duration_seconds": duration_seconds,
                                    "compliance_words": filtered_profanity,
                                },
                                timeout=10.0,
                            )

                            if response.status_code == 200:
                                st.success(
                                    f"✅ Conversation saved! Duration: {duration_seconds // 60} min {duration_seconds % 60} sec"
                                )
                            else:
                                st.warning(f"⚠️ Failed to save: {response.text}")
                        except Exception as e:
                            st.error(f"❌ Error saving conversation: {str(e)}")

                st.session_state.conversation_started = False
                st.session_state.chat_start_time = None
                st.info("✅ Session ended. Click 'Reset Conversation' to start fresh.")
                st.stop()

            # Check if user is requesting a summary
            is_summarize = st.session_state.llm_instance.detect_summarize(user_input)

            # Generate supervisor response using LLM
            supervisor_response = st.session_state.llm_instance.convllm(
                user_input, st.session_state.session_data, is_summarize=is_summarize
            )

            # Add supervisor response to history
            central = pytz.timezone("America/Chicago")
            st.session_state.chat_history.append(
                {
                    "role": "supervisor",
                    "content": supervisor_response,
                    "timestamp": datetime.now(central).strftime("%Y-%m-%d %H:%M:%S %Z"),
                }
            )

            # Display supervisor response
            with st.chat_message("assistant", avatar="👔"):
                st.markdown(supervisor_response)

            st.rerun()


if __name__ == "__main__":
    main()
