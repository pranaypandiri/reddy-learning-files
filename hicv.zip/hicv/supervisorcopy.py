import streamlit as st
import json
import pandas as pd
from io import BytesIO
from datetime import datetime
import openpyxl
from openai import AzureOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.schema import HumanMessage, AIMessage, SystemMessage

# Page Configuration
st.set_page_config(
    page_title="HICVy AI Supervisor Coaching", page_icon="🎯", layout="wide"
)

# Initialize Azure OpenAI Client
client = AzureOpenAI(
    api_key="92dc252cdb0c4079b4712a9ead4179ca",
    api_version="2024-12-01-preview",
    azure_endpoint="https://azureaitest4641590782.openai.azure.com/",
)


# Initialize session state
if "conversation_started" not in st.session_state:
    st.session_state.conversation_started = False

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

if "session_data" not in st.session_state:
    st.session_state.session_data = None

if "file_uploaded" not in st.session_state:
    st.session_state.file_uploaded = False


def parse_transcript(transcript_text):
    """Parse pasted transcript to extract metadata and conversations"""
    try:
        lines = transcript_text.strip().split("\n")

        # Extract metadata
        team = ""
        conversation_time = ""

        # Parse metadata section - handle both formats
        for line in lines:
            line_stripped = line.strip()

            # Handle "Team: value" format
            if line_stripped.startswith("Team:"):
                team = line_stripped.split("Team:", 1)[1].strip()
            # Handle "Conversation Time: value" format
            elif line_stripped.startswith("Conversation Time:"):
                conversation_time = line_stripped.split("Conversation Time:", 1)[
                    1
                ].strip()

        # Extract agent and customer conversations
        agent_lines = []
        customer_lines = []

        in_transcript = False
        for line in lines:
            line_stripped = line.strip()

            # Start capturing after "Transcript:" line
            if line_stripped.startswith("Transcript:"):
                in_transcript = True
                continue

            if in_transcript and line_stripped:  # Only process non-empty lines
                # Check if line starts with AGENT or VISITOR/CUSTOMER
                if line_stripped.startswith("AGENT"):
                    # Extract text after timestamp bracket: "AGENT [2:43:32 AM] Text here"
                    if "]" in line_stripped:
                        # Split by "]" and take everything after it, then strip whitespace
                        text = line_stripped.split("]", 1)[1].strip()
                        if text:  # Only add non-empty text
                            agent_lines.append(text)
                elif line_stripped.startswith("VISITOR") or line_stripped.startswith(
                    "CUSTOMER"
                ):
                    # Extract text after timestamp bracket
                    if "]" in line_stripped:
                        text = line_stripped.split("]", 1)[1].strip()
                        if text:  # Only add non-empty text
                            customer_lines.append(text)

        # Join with newlines to preserve conversation structure
        agent_conversation = "\n".join(agent_lines)
        customer_conversation = "\n".join(customer_lines)

        # Debug: Print parsed data
        print("\n" + "=" * 60)
        print("📋 PARSED TRANSCRIPT DATA")
        print("=" * 60)
        print(f"Team: {team}")
        print(f"Conversation Time: {conversation_time}")
        print(f"Agent Lines Count: {len(agent_lines)}")
        print(f"Customer Lines Count: {len(customer_lines)}")
        print(f"\nAgent Conversation (first 200 chars):\n{agent_conversation[:200]}...")
        print(
            f"\nCustomer Conversation (first 200 chars):\n{customer_conversation[:200]}..."
        )
        print("=" * 60 + "\n")

        return {
            "team": team,
            "conversation_time": conversation_time,
            "agent_conversation": agent_conversation,
            "customer_conversation": customer_conversation,
            "sale_status": "NO-SALE",
        }

    except Exception as e:
        st.error(f"❌ Error parsing transcript: {str(e)}")
        return None


def create_excel_from_transcript(parsed_data):
    """Create Excel file from parsed transcript data"""
    try:
        # Create workbook
        wb = openpyxl.Workbook()
        ws = wb.active

        # Add headers (Row 1)
        ws["B1"] = "Team"
        ws["C1"] = "Conversation Time"
        ws["D1"] = "Agent Conversation"
        ws["E1"] = "Customer Conversation"
        ws["F1"] = "Sale Status"

        # Add data (Row 2)
        ws["B2"] = parsed_data["team"]
        ws["C2"] = parsed_data["conversation_time"]
        ws["D2"] = parsed_data["agent_conversation"]
        ws["E2"] = parsed_data["customer_conversation"]
        ws["F2"] = parsed_data["sale_status"]

        # Save to BytesIO
        output = BytesIO()
        wb.save(output)
        output.seek(0)

        return output

    except Exception as e:
        st.error(f"❌ Error creating Excel: {str(e)}")
        return None


def process_transcript_text(transcript_text):
    """Process transcript text, create Excel, and send to API"""
    import httpx

    try:
        # Parse transcript
        parsed_data = parse_transcript(transcript_text)
        if not parsed_data:
            return False

        # Create Excel file
        excel_file = create_excel_from_transcript(parsed_data)
        if not excel_file:
            return False

        # Now send to API
        API_URL = "https://packagesale-new-797525040891.us-central1.run.app/analyzechat"

        files = {
            "file": (
                "transcript.xlsx",
                excel_file.getvalue(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        }

        # Call API
        response = httpx.post(API_URL, files=files, timeout=60.0)
        response.raise_for_status()

        # Parse response
        data = response.json()

        # Debug: Print API response
        print("\n" + "=" * 60)
        print("🔍 API RESPONSE DEBUG")
        print("=" * 60)
        print(json.dumps(data, indent=2))
        print("=" * 60 + "\n")

        # Extract ReasonCatalogue
        if "ReasonCatalogue" not in data:
            st.error("❌ No ReasonCatalogue found in API response")
            return False

        reason_catalogue = data["ReasonCatalogue"]

        # Debug: Print ReasonCatalogue
        print("\n" + "=" * 60)
        print("📋 REASON CATALOGUE")
        print("=" * 60)
        print(json.dumps(reason_catalogue, indent=2))
        print("=" * 60 + "\n")

        # Extract reasons and improvements
        reasons = [item["Reason"] for item in reason_catalogue if "Reason" in item]
        improvements = [
            item["Suggestions"] for item in reason_catalogue if "Suggestions" in item
        ]

        # Debug: Print extracted data
        print("\n" + "=" * 60)
        print("✅ EXTRACTED REASONS & IMPROVEMENTS")
        print("=" * 60)
        print(f"Reasons found: {len(reasons)}")
        for i, reason in enumerate(reasons, 1):
            print(f"  {i}. {reason}")
        print(f"\nImprovements found: {len(improvements)}")
        for i, improvement in enumerate(improvements, 1):
            print(f"  {i}. {improvement}")
        print("=" * 60 + "\n")

        if not reasons or not improvements:
            st.error("❌ No reasons or improvements found in response")
            return False

        # Build transcription for chat context
        transcription = [
            {"speaker": "Agent", "message": parsed_data["agent_conversation"]},
            {"speaker": "Customer", "message": parsed_data["customer_conversation"]},
        ]

        # Store in session state
        st.session_state.session_data = {
            "mistakes": reasons,
            "improvements": improvements,
            "transcription": transcription,
        }

        st.session_state.file_uploaded = True
        return True

    except httpx.HTTPStatusError as e:
        st.error(f"❌ API Error: {e.response.status_code}")
        return False
    except httpx.RequestError as e:
        st.error(f"❌ Request failed: {str(e)}")
        return False
    except Exception as e:
        st.error(f"❌ Unexpected error: {str(e)}")
        return False


def load_session_data(file_path="session_data.json"):
    """Load session data from JSON file"""
    try:
        with open(file_path, "r") as f:
            data = json.load(f)
        return data
    except FileNotFoundError:
        st.error(f"❌ File not found: {file_path}")
        return None
    except json.JSONDecodeError:
        st.error("❌ Invalid JSON format")
        return None


def reset_conversation():
    """Reset conversation to start fresh"""
    st.session_state.conversation_started = False
    st.session_state.chat_history = []
    st.session_state.session_data = None  # Clear cached session data
    st.session_state.file_uploaded = False  # Clear file upload status
    if "llm_instance" in st.session_state:
        del st.session_state.llm_instance  # Clear LLM instance to reset memory
    st.success("✅ Conversation reset! Ready to paste a new transcript.")


def export_conversation_to_excel():
    """Export chat history to Excel file"""
    if not st.session_state.chat_history:
        st.warning("⚠️ No conversation to export")
        return None

    # Create workbook
    wb = openpyxl.Workbook()

    # Sheet 1: Chat History
    ws1 = wb.active
    ws1.title = "Chat History"
    ws1.append(["Role", "Message", "Timestamp"])

    for msg in st.session_state.chat_history:
        ws1.append(
            [msg.get("role", ""), msg.get("content", ""), msg.get("timestamp", "")]
        )

    # Sheet 2: Session Metadata
    ws2 = wb.create_sheet(title="Session Metadata")
    ws2.append(["Field", "Value"])
    ws2.append(["Session Date", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
    ws2.append(["Total Messages", len(st.session_state.chat_history)])

    if st.session_state.session_data:
        ws2.append(
            ["Mistakes Count", len(st.session_state.session_data.get("mistakes", []))]
        )
        ws2.append(
            [
                "Improvements Count",
                len(st.session_state.session_data.get("improvements", [])),
            ]
        )

    # Save to BytesIO
    output = BytesIO()
    wb.save(output)
    output.seek(0)

    return output


class ConversationLLM:

    GOODBYE_KEYWORDS = [
        "bye",
        "goodbye",
        "have a nice day",
        "talk to you later",
        "thanks again",
        "see you",
        "take care",
    ]

    def __init__(self):
        self.memory = ConversationBufferMemory(
            memory_key="chat_history", return_messages=True
        )

    def convllm(self, user_input, session_data):

        # Build conversation history
        history_text = ""
        for message in self.memory.chat_memory.messages:
            if isinstance(message, HumanMessage):
                history_text += f"Agent: {message.content}\n"
            elif isinstance(message, AIMessage):
                history_text += f"Supervisor: {message.content}\n"

        # Build transcription context
        transcription_text = ""
        if session_data and "transcription" in session_data:
            for turn in session_data["transcription"]:
                transcription_text += f"{turn['speaker']}: {turn['message']}\n\n"

        # Get mistakes and improvements
        mistakes = session_data.get("mistakes", []) if session_data else []
        improvements = session_data.get("improvements", []) if session_data else []

        # Format mistakes and improvements
        mistakes_text = "\n".join(f"{i+1}. {m}" for i, m in enumerate(mistakes))
        improvements_text = "\n".join(
            f"{i+1}. {imp}" for i, imp in enumerate(improvements)
        )

        # TODO: Build your supervisor prompt here
        Customer_prompt = f"""
        You are an AI supervisor coach "HICVy" coaching an agent who heard a voice call  between a customer and a support agent.
        
        ORIGINAL CALL TRANSCRIPTION:
        {transcription_text}
        
        IDENTIFIED MISTAKES ({len(mistakes)} total):
        {mistakes_text}
        
        SUGGESTED IMPROVEMENTS ({len(improvements)} total):
        {improvements_text}
        
        CONVERSATION SO FAR:
        {history_text}
        
        AGENT JUST SAID: {user_input}
        
        ---- Goal -------
        YOUR TASK: Guide the agent to identify the mistakes and ask them what are the improvement which will make the call better and guide him if he is unable to find the mistakes and improvements by himself.


        ==== CONVERSATION TRACKING (CHECK THIS FIRST) ====

        COUNT SUPERVISOR ATTEMPTS:

        1. Review the CONVERSATION HISTORY above carefully
        2. Count how many times YOU (supervisor) have already asked the agent to identify mistakes
           - Look for your messages asking: "What mistakes do you think happened?"
           - Look for your messages with hints or probing questions
           - Count EACH time you tried to guide them to find mistakes

        3. Check agent's responses:
           - Did agent say "I don't know" or ask you to tell them directly?
           - Did agent try but get it wrong or incomplete?
           - Did agent show frustration (profanity, "fuck", "bro", etc.)?

        GREETING (If this is the FIRST message in CONVERSATION HISTORY):
        → Start with warm, casual greeting ONLY: "Hi there! I'm HICVy. How's it going on your side?" or "Hey! I'm HICVy. How are things going with you?"
        → DO NOT mention the call yet
        → DO NOT ask about mistakes yet
        → Just be friendly and casual - wait for their response
        → Keep it 1-2 sentences max
        
        SECOND INTERACTION (After agent responds to greeting):
        → If agent shared something casual (how they're doing, etc.):
          → Acknowledge it briefly: "Good to hear!" or "Nice!" or respond appropriately to what they said
          → Then transition: "So I listened to your call and wanted to chat about it. What mistakes do you think happened?"
        → If agent asks about the call or feedback directly:
          → Jump straight to: "I listened to your call and wanted to chat about it. What mistakes do you think happened?"
        
        DECISION LOGIC FOR MISTAKES:

        If this is attempt 1 (first time asking about mistakes - after greeting):
          → Ask agent: "What mistakes do you think happened in this call?"
          → Mention there are {len(mistakes)} key issues to find

        If this is attempt 2 OR agent explicitly asks you to reveal OR shows frustration:
          → STOP asking hints
          → Reveal ALL {len(mistakes)} mistakes directly as a numbered list
          → Format: "Here are the {len(mistakes)} mistakes: 1. [mistake 1], 2. [mistake 2], 3. [mistake 3]"
          → Then ask: "What improvements would you suggest for these?"

        DECISION LOGIC FOR IMPROVEMENTS:

        After revealing mistakes, count improvement attempts:
        
        If agent tries but doesn't know improvements (attempt 1):
          → Give ONE hint about what could be better
        
        If agent still doesn't know (attempt 2) OR asks you to tell OR shows frustration:
          → STOP hinting
          → Reveal ALL {len(improvements)} improvements directly as a numbered list
          → Format: "Here are the {len(improvements)} improvements: 1. [improvement 1], 2. [improvement 2], 3. [improvement 3]"
          → Then ask: "Which one would make the biggest difference?"

        CRITICAL RULES:
        - Maximum 1 attempt before revealing answers (only 1 chance to guess)
        - If agent says "I don't know, tell me" → Reveal immediately
        - If agent shows frustration (profanity, multiple "I don't know") → Reveal immediately with supportive tone
        - NEVER ask more than 1 time without revealing


        ====  THINK STEP BY STEP ====

        STEP 0 - HANDLE SPECIAL CASES:
        - Is the agent asking about the transcript? → Answer briefly, then redirect to identifying mistakes
        - Does the agent seem frustrated? → Be extra supportive, offer to show mistakes directly
        - Is the agent going off-topic? → Gently redirect: "Let's focus on the call mistakes first"

        STEP 1 - WHERE ARE WE IN THE CONVERSATION?
        
        Is this the first message (conversation history is empty)?
          → Greet the agent warmly and ask: "What mistakes do you think happened in this call?"
          → Mention there are {len(mistakes)} key issues to find
        
        Is the agent currently listing mistakes?
          → Count: How many of the {len(mistakes)} mistakes has the agent mentioned?
          → If mentioned all {len(mistakes)}: All found! → Validate strongly and ask "What improvements would you suggest?"
          → If mentioned some but not all: Missing some → Give gentle probe ("Good start! What else stood out?")
          → If mentioned 0: Not started yet → Ask what stood out as wrong in the call
        
        Is the agent suggesting improvements?
          → Check: Do the suggestions align with our {len(improvements)} recommended improvements?
          → If aligned: Validate and ask tactical follow-up ("How would you phrase that differently?")
          → If not aligned: Guide toward actual improvements with transcript references
        
        Has the agent stuck after multiple attempts?
          → This is now handled by CONVERSATION TRACKING section above
          → Follow the 1-attempt rule before revealing

        STEP 2 - CRAFT APPROPRIATE HINTS (if agent needs help):
        - Reference specific transcript moments: "What happened when the customer said [quote]?"
        - Ask probing questions: "How did the customer react to that approach?"
        - Don't name the mistake directly - guide discovery through questions

        STEP 3 - CHECK FOR COMPLETION:
        - Has the agent identified all {len(mistakes)} mistakes? ✓
        - Has the agent suggested improvements aligned with {len(improvements)} recommendations? ✓
        - If both complete → Ask: "What are your key takeaways from this call?"
        - If not complete → Continue coaching based on STEP 1

        ---- Response Guidelines ----
        - Keep responses concise, clear, and supportive.
        - Maintain a professional and encouraging tone throughout the conversation.
        - Ensure that the agent feels motivated to improve their customer service skills.


        ----  Critical ----
        - Maximum 1 attempt before revealing (follow CONVERSATION TRACKING logic above)
        - If agent says "I don't know" or asks you to tell them → Reveal immediately
        - If agent shows frustration → Reveal with supportive tone
        - Dont create any new mistake and improvments that we are not in the above data provided.
        - Keep responses to 1-2 sentences maximum
        





        
          
        """

        response = client.chat.completions.create(
            model="gpt-4.1",
            messages=[
                {"role": "system", "content": ""},
                {"role": "user", "content": Customer_prompt},
            ],
            temperature=0.7,
            max_tokens=1000,
        )

        response = response.choices[0].message.content
        self.memory.save_context({"input": user_input}, {"output": response})
        return response

    def detect_goodbye(self, message):
        """Check if conversation should end based on goodbye keywords"""
        return any(kw in message.lower() for kw in self.GOODBYE_KEYWORDS)


def main():
    # Title and Header
    st.markdown(
        "<h1 style='text-align: center; margin-bottom: 30px;'>🎯 HICVy AI Supervisor Coaching</h1>",
        unsafe_allow_html=True,
    )

    # Initialize LLM instance after class definition
    if "llm_instance" not in st.session_state:
        st.session_state.llm_instance = ConversationLLM()

    # Sidebar controls
    with st.sidebar:
        st.header("🎛️ Session Controls")

        # Start Session Button (only enabled after transcript analysis)
        if st.session_state.file_uploaded and not st.session_state.conversation_started:
            if st.button(
                "🚀 Start AI Supervisor Guidance",
                type="primary",
                use_container_width=True,
                key="start_btn",
            ):
                st.session_state.conversation_started = True
                st.success("✅ Session started! Supervisor is ready to chat.")
                st.rerun()
        elif st.session_state.conversation_started:
            st.success("✅ Session Active")

        st.markdown("---")

        # Reset Button
        if st.button("🔄 Reset Conversation", use_container_width=True):
            reset_conversation()
            st.rerun()

        st.markdown("---")

        # Download Chat History Button
        if st.session_state.chat_history:
            excel_output = export_conversation_to_excel()
            if excel_output:
                st.download_button(
                    label="📥 Download Conversation",
                    data=excel_output,
                    file_name=f"coaching_session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                )

        st.markdown("---")

        # Session Info
        if st.session_state.session_data:
            st.markdown("### 📊 Session Info")
            st.markdown(
                f"**Mistakes:** {len(st.session_state.session_data.get('mistakes', []))}"
            )
            st.markdown(
                f"**Improvements:** {len(st.session_state.session_data.get('improvements', []))}"
            )
            st.markdown(f"**Messages:** {len(st.session_state.chat_history)}")

    # Main Content Area
    if not st.session_state.file_uploaded:
        # Transcript Input Screen - Center of UI
        st.markdown("---")
        st.markdown("### 📝 Paste Your Call Transcript")
        st.markdown(
            "Paste the complete transcript including metadata (Conversation ID, Team, Conversation Time, etc.) and the conversation."
        )

        transcript_input = st.text_area(
            "Transcript",
            height=400,
            placeholder="""Metadata: 

Conversation ID: 688366911347 
Conversation Time: 11/22/2025, 2:43 AM - 11/22/2025, 2:52 AM (Asia/Shanghai) 
Agent Full Name: Sherwin Winston Lequit 
Team: Team Joshua Alfafara 
Use Case: transfers-voice 

Transcript: 

AGENT [2:43:32 AM] Good afternoon, and thank you for transferring...
VISITOR [2:43:37 AM] Hello?
...""",
            label_visibility="collapsed",
        )

        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            if st.button(
                "🚀 Analyze Transcript", type="primary", use_container_width=True
            ):
                if transcript_input.strip():
                    with st.spinner("Analyzing transcript..."):
                        success = process_transcript_text(transcript_input)
                        if success:
                            st.success("✅ Transcript analyzed successfully!")
                            st.rerun()
                else:
                    st.warning("⚠️ Please paste a transcript first")

    elif st.session_state.file_uploaded and not st.session_state.conversation_started:
        # Transcript analyzed but session not started
        st.markdown("---")
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.success(
                "✅ **Transcript Analyzed Successfully!**\n\n"
                f"**Mistakes Found:** {len(st.session_state.session_data.get('mistakes', []))}\n\n"
                f"**Improvements Suggested:** {len(st.session_state.session_data.get('improvements', []))}\n\n"
                "Click **'Start AI Supervisor Guidance'** in the sidebar to begin coaching."
            )

    else:
        # Chat Interface (Active Session)
        st.markdown("---")

        # Display chat history
        for msg in st.session_state.chat_history:
            role = msg.get("role", "")
            content = msg.get("content", "")

            if role == "supervisor":
                with st.chat_message("assistant", avatar="👔"):
                    st.markdown(content)
            elif role == "agent":
                with st.chat_message("user", avatar="👤"):
                    st.markdown(content)

        # Chat input
        user_input = st.chat_input("Type your response here...")

        if user_input:
            # Add user message to history
            st.session_state.chat_history.append(
                {
                    "role": "agent",
                    "content": user_input,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
            )

            # Display user message
            with st.chat_message("user", avatar="👤"):
                st.markdown(user_input)

            # Check for goodbye keywords to end conversation
            if st.session_state.llm_instance.detect_goodbye(user_input):
                goodbye_message = "Thank you for this coaching session! Feel free to start a new one anytime. Click 'Reset Conversation' to begin fresh."

                st.session_state.chat_history.append(
                    {
                        "role": "supervisor",
                        "content": goodbye_message,
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    }
                )

                with st.chat_message("assistant", avatar="👔"):
                    st.markdown(goodbye_message)

                st.session_state.conversation_started = False
                st.info("✅ Session ended. Click 'Reset Conversation' to start fresh.")
                st.stop()

            # Generate supervisor response using LLM
            supervisor_response = st.session_state.llm_instance.convllm(
                user_input, st.session_state.session_data
            )

            # Add supervisor response to history
            st.session_state.chat_history.append(
                {
                    "role": "supervisor",
                    "content": supervisor_response,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
            )

            # Display supervisor response
            with st.chat_message("assistant", avatar="👔"):
                st.markdown(supervisor_response)

            st.rerun()


if __name__ == "__main__":
    main()
