"""
ORM Models - Database Entity Classes
Similar to Spring Boot's @Entity classes
"""

from sqlalchemy import Column, String, Integer, JSON, TIMESTAMP
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

# Base class for ORM models
Base = declarative_base()


class ConversationLog(Base):
    """
    ConversationLog Entity
    Maps to 'conversationlogs' table in PostgreSQL

    Similar to Spring Boot:
    @Entity
    @Table(name = "conversationlogs")
    public class ConversationLog { ... }
    """

    __tablename__ = "conversationlogs"

    # Primary Key
    id = Column(String(255), primary_key=True, nullable=False)

    # Agent Information
    agent_name = Column(String(100), nullable=False)
    agent_email = Column(String(100), nullable=False)

    # Conversation Data (JSON field stores the entire chat history)
    conversation_data = Column(JSON, nullable=False)

    # Compliance words (optional - added to match hicvfastapi schema)
    compliance_words = Column(JSON, nullable=True)

    # Duration in seconds
    duration_seconds = Column(Integer, nullable=False)

    # Timestamps (auto-managed)
    created_at = Column(
        TIMESTAMP(timezone=True),
        nullable=True,
        server_default=func.now(),  # Automatically set to current timestamp
    )
    updated_at = Column(
        TIMESTAMP(timezone=True),
        nullable=True,
        onupdate=func.now(),  # Automatically update on record update
    )

    def __repr__(self):
        """String representation for debugging"""
        return f"<ConversationLog(id={self.id}, agent={self.agent_name}, duration={self.duration_seconds}s)>"

    def to_dict(self):
        """Convert model to dictionary (useful for JSON responses)"""
        return {
            "id": self.id,
            "agent_name": self.agent_name,
            "agent_email": self.agent_email,
            "conversation_data": self.conversation_data,
            "duration_seconds": self.duration_seconds,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
