import psycopg2
from psycopg2 import sql

# Database credentials
DB_USER = "postgres"
DB_PASSWORD = "packagesales_Wipro122"
DB_NAME = "postgres"
DB_HOST = "35.222.253.106"
DB_PORT = "5432"


def check_table_structure():
    """Check if conversationlogs table exists and show its structure"""
    try:
        # Connect to the database
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
        )
        cursor = conn.cursor()

        print("✅ Successfully connected to PostgreSQL database!")
        print(f"📍 Host: {DB_HOST}")
        print(f"📍 Database: {DB_NAME}\n")

        # Check if table exists
        cursor.execute(
            """
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'conversationlogs'
            );
        """
        )
        table_exists = cursor.fetchone()[0]

        if table_exists:
            print("✅ Table 'conversationlogs' EXISTS!\n")

            # Get table structure
            cursor.execute(
                """
                SELECT 
                    column_name, 
                    data_type, 
                    character_maximum_length,
                    is_nullable,
                    column_default
                FROM information_schema.columns
                WHERE table_name = 'conversationlogs'
                ORDER BY ordinal_position;
            """
            )

            columns = cursor.fetchall()

            print("📋 TABLE STRUCTURE:")
            print("=" * 80)
            print(
                f"{'Column Name':<25} {'Data Type':<20} {'Nullable':<10} {'Default':<20}"
            )
            print("=" * 80)

            for col in columns:
                col_name = col[0]
                data_type = col[1]
                max_length = col[2]
                is_nullable = col[3]
                default_val = col[4] if col[4] else "None"

                # Add max length to varchar types
                if max_length:
                    data_type = f"{data_type}({max_length})"

                print(
                    f"{col_name:<25} {data_type:<20} {is_nullable:<10} {default_val:<20}"
                )

            print("=" * 80)

            # Count existing records
            cursor.execute("SELECT COUNT(*) FROM conversationlogs;")
            count = cursor.fetchone()[0]
            print(f"\n📊 Total records in table: {count}")

        cursor.close()
        conn.close()

    except Exception as e:
        print(f"❌ Error connecting to database: {str(e)}")


if __name__ == "__main__":
    check_table_structure()
