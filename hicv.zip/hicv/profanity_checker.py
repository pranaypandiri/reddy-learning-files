"""
Profanity Detection Module using Detoxify
Analyzes conversation history for toxic/profane language in agent messages
"""

from detoxify import Detoxify
from typing import List, Dict, Any
import json


class ProfanityChecker:

    def __init__(self, threshold: float = 0.65):
        self.threshold = threshold
        self.model = Detoxify("original")

    def check_message(self, message: str) -> Dict[str, Any]:

        scores = self.model.predict(message)

        # Check if any category exceeds threshold
        is_flagged = (
            scores["toxicity"] > self.threshold
            or scores["obscene"] > self.threshold
            or scores["insult"] > self.threshold
        )

        return {
            "text": message,
            "is_flagged": is_flagged,
            "toxicity_score": round(float(scores["toxicity"]), 3),
            "obscene_score": round(float(scores["obscene"]), 3),
            "insult_score": round(float(scores["insult"]), 3),
            "threat_score": round(float(scores["threat"]), 3),
            "severity": self._get_severity(float(scores["toxicity"])),
        }

    def _get_severity(self, toxicity_score: float) -> str:
        if toxicity_score > 0.8:
            return "high"
        elif toxicity_score > 0.65:
            return "medium"
        else:
            return "low"

    def check_conversation_history(
        self, conversation_history: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        flagged_messages = []
        total_agent_messages = 0

        # Check each agent message
        for msg in conversation_history:
            if msg.get("role") == "agent":
                total_agent_messages += 1
                content = msg.get("content", "")
                timestamp = msg.get("timestamp", "")

                # Analyze message
                result = self.check_message(content)

                # If flagged, add to results
                if result["is_flagged"]:
                    flagged_messages.append(
                        {
                            "message": content,
                            "timestamp": timestamp,
                            "toxicity_score": result["toxicity_score"],
                            "obscene_score": result["obscene_score"],
                            "insult_score": result["insult_score"],
                            "severity": result["severity"],
                        }
                    )

        # Build summary
        has_profanity = len(flagged_messages) > 0

        return {
            "profanity_detected": has_profanity,
            "total_agent_messages": total_agent_messages,
            "flagged_count": len(flagged_messages),
            "flagged_messages": flagged_messages,
            "threshold_used": self.threshold,
            "summary": self._generate_summary(flagged_messages, total_agent_messages),
        }

    def _generate_summary(
        self, flagged_messages: List[Dict], total_messages: int
    ) -> str:
        """
        Generate human-readable summary

        Args:
            flagged_messages: List of flagged message dicts
            total_messages: Total number of agent messages analyzed

        Returns:
            Summary string
        """
        if not flagged_messages:
            return f"No profanity detected in {total_messages} agent messages."

        count = len(flagged_messages)
        severity_counts = {}
        for msg in flagged_messages:
            severity = msg["severity"]
            severity_counts[severity] = severity_counts.get(severity, 0) + 1

        severity_text = ", ".join(
            f"{count} {severity}" for severity, count in severity_counts.items()
        )

        return (
            f"Profanity detected in {count}/{total_messages} agent messages. "
            f"Severity breakdown: {severity_text}."
        )


def check_conversation_profanity(
    conversation_history: List[Dict[str, str]], threshold: float = 0.65
) -> Dict[str, Any]:
    """
    Convenience function to check conversation for profanity

    Args:
        conversation_history: List of message dicts (role, content, timestamp)
        threshold: Toxicity threshold (default 0.65)

    Returns:
        Profanity analysis results as dict
    """
    checker = ProfanityChecker(threshold=threshold)
    return checker.check_conversation_history(conversation_history)


def check_conversation_profanity_json(
    conversation_history: List[Dict[str, str]], threshold: float = 0.65
) -> str:
    """
    Check conversation and return results as JSON string

    Args:
        conversation_history: List of message dicts (role, content, timestamp)
        threshold: Toxicity threshold (default 0.65)

    Returns:
        JSON string of profanity analysis results
    """
    result = check_conversation_profanity(conversation_history, threshold)
    return json.dumps(result, indent=2)


# Example usage
if __name__ == "__main__":
    # Test with sample conversation
    sample_conversation = [
        {
            "role": "agent",
            "content": "Hi there, how can I help you?",
            "timestamp": "2025-12-05 10:00:00 CST",
        },
        {
            "role": "supervisor",
            "content": "Great start!",
            "timestamp": "2025-12-05 10:00:05 CST",
        },
        {
            "role": "agent",
            "content": "yeah the customer said  fuck me to me but thats okay maybe he is frastured",
            "timestamp": "2025-12-05 10:01:00 CST",
        },
        {
            "role": "agent",
            "content": "I think the customer is being unreasonable",
            "timestamp": "2025-12-05 10:02:00 CST",
        },
    ]

    # Run profanity check
    result = check_conversation_profanity(sample_conversation, threshold=0.65)

    # Print results
    print("=" * 60)
    print("PROFANITY CHECK RESULTS")
    print("=" * 60)
    print(json.dumps(result, indent=2))
    print("=" * 60)
