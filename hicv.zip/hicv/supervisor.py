import streamlit as st
import json
import pandas as pd
from io import BytesIO
from datetime import datetime
import openpyxl
from openai import AzureOpenAI
from pydantic import BaseModel, Field
from langchain.memory import ConversationBufferMemory
from langchain.schema import HumanMessage, AIMessage, SystemMessage
import httpx


# Pydantic model for structured LLM output
class SupervisorResponse(BaseModel):
    """Structured response from supervisor with completion tracking"""

    response: str = Field(
        description="Casual, friendly message to the agent (2-3 sentences max)"
    )
    reasons_complete: bool = Field(
        description="True if ALL reasons have been REVEALED to agent OR agent identified them all. False if still in reasons phase."
    )
    improvements_complete: bool = Field(
        description="True if ALL improvements have been REVEALED to agent OR agent identified them all. False if still in improvements phase."
    )


# Page Configuration
st.set_page_config(
    page_title="HICVy AI Supervisor Coaching", page_icon="🎯", layout="wide"
)

# Add custom CSS styling
st.markdown(
    """
    <style>
    /* Download button only */
    .stDownloadButton > button {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%) !important;
        color: white !important;
        border: none !important;
        font-weight: bold !important;
    }
    .stDownloadButton > button:hover {
        background: linear-gradient(90deg, #5a67d8 0%, #6b3fa0 100%) !important;
        transform: scale(1.02) !important;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Initialize Azure OpenAI Client
client = AzureOpenAI(
    api_key="92dc252cdb0c4079b4712a9ead4179ca",
    api_version="2024-12-01-preview",
    azure_endpoint="https://azureaitest4641590782.openai.azure.com/",
)


# Initialize session state
if "conversation_started" not in st.session_state:
    st.session_state.conversation_started = False

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

if "session_data" not in st.session_state:
    st.session_state.session_data = None

if "file_uploaded" not in st.session_state:
    st.session_state.file_uploaded = False


def upload_and_analyze_file(uploaded_file):
    """Upload file to backend API and extract reasons/improvements"""
    try:
        # API endpoint
        API_URL = (
            "https://packagesales-backend-797525040891.us-central1.run.app/analyze"
        )

        # Prepare file for upload
        files = {
            "file": (
                uploaded_file.name,
                uploaded_file.getvalue(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        }

        # Call API
        response = httpx.post(API_URL, files=files, timeout=60.0)
        response.raise_for_status()

        # Parse response
        data = response.json()

        # Debug: Print the API response
        print("\n" + "=" * 60)
        print("🔍 API RESPONSE DEBUG")
        print("=" * 60)
        print(json.dumps(data, indent=2))
        print("=" * 60 + "\n")

        # Extract ReasonCatalogue
        if "ReasonCatalogue" not in data:
            st.error("❌ No ReasonCatalogue found in API response")
            return False

        reason_catalogue = data["ReasonCatalogue"]

        # Debug: Print ReasonCatalogue
        print("\n" + "=" * 60)
        print("📋 REASON CATALOGUE")
        print("=" * 60)
        print(json.dumps(reason_catalogue, indent=2))
        print("=" * 60 + "\n")

        # Extract reasons and improvements
        reasons = [item["Reason"] for item in reason_catalogue if "Reason" in item]
        improvements = [
            item["Suggestions"] for item in reason_catalogue if "Suggestions" in item
        ]

        # Debug: Print extracted data
        print("\n" + "=" * 60)
        print("✅ EXTRACTED DATA")
        print("=" * 60)
        print(f"Reasons found: {len(reasons)}")
        print(f"Reasons: {reasons}")
        print(f"Improvements found: {len(improvements)}")
        print(f"Improvements: {improvements}")
        print("=" * 60 + "\n")

        if not reasons or not improvements:
            st.error("❌ No reasons or improvements found in response")
            return False

        # Extract transcription from Excel file (columns D & E)
        transcription = []
        try:
            df = pd.read_excel(uploaded_file)
            # Column D (index 3) = Agent Conversation
            # Column E (index 4) = Customer Conversation
            if len(df.columns) > 4:
                agent_text = str(df.iloc[0, 3]) if pd.notna(df.iloc[0, 3]) else ""
                customer_text = str(df.iloc[0, 4]) if pd.notna(df.iloc[0, 4]) else ""

                if agent_text:
                    transcription.append({"speaker": "Agent", "message": agent_text})
                if customer_text:
                    transcription.append(
                        {"speaker": "Customer", "message": customer_text}
                    )
        except Exception as e:
            # If transcription extraction fails, continue with empty transcription
            pass

        # Store in session state
        st.session_state.session_data = {
            "mistakes": reasons,
            "improvements": improvements,
            "transcription": transcription,
        }

        st.session_state.file_uploaded = True
        return True

    except httpx.HTTPStatusError as e:
        st.error(f"❌ API Error: {e.response.status_code}")
        return False
    except httpx.RequestError as e:
        st.error(f"❌ Request failed: {str(e)}")
        return False
    except Exception as e:
        st.error(f"❌ Unexpected error: {str(e)}")
        return False


def load_session_data(file_path="session_data.json"):
    """Load session data from JSON file"""
    try:
        with open(file_path, "r") as f:
            data = json.load(f)
        return data
    except FileNotFoundError:
        st.error(f"❌ File not found: {file_path}")
        return None
    except json.JSONDecodeError:
        st.error("❌ Invalid JSON format")
        return None


def reset_conversation():
    """Reset conversation to start fresh"""
    st.session_state.conversation_started = False
    st.session_state.chat_history = []
    st.session_state.session_data = None  # Clear cached session data
    st.session_state.file_uploaded = False  # Clear file upload status
    if "llm_instance" in st.session_state:
        del st.session_state.llm_instance  # Clear LLM instance to reset memory
    st.success("✅ Conversation reset! Ready to upload a new file.")


def export_conversation_to_excel():
    """Export chat history to Excel file"""
    if not st.session_state.chat_history:
        st.warning("⚠️ No conversation to export")
        return None

    # Create workbook
    wb = openpyxl.Workbook()

    # Sheet 1: Chat History
    ws1 = wb.active
    ws1.title = "Chat History"
    ws1.append(["Role", "Message", "Timestamp"])

    for msg in st.session_state.chat_history:
        ws1.append(
            [msg.get("role", ""), msg.get("content", ""), msg.get("timestamp", "")]
        )

    # Sheet 2: Session Metadata
    ws2 = wb.create_sheet(title="Session Metadata")
    ws2.append(["Field", "Value"])
    ws2.append(["Session Date", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
    ws2.append(["Total Messages", len(st.session_state.chat_history)])

    if st.session_state.session_data:
        ws2.append(
            ["Mistakes Count", len(st.session_state.session_data.get("mistakes", []))]
        )
        ws2.append(
            [
                "Improvements Count",
                len(st.session_state.session_data.get("improvements", [])),
            ]
        )

    # Save to BytesIO
    output = BytesIO()
    wb.save(output)
    output.seek(0)

    return output


class ConversationLLM:

    GOODBYE_KEYWORDS = [
        "bye",
        "goodbye",
        "have a nice day",
        "alright, thanks for your help.",
        "resolved",
        "issue fixed",
        "problem solved",
        "Thanks again!",
    ]

    def __init__(self):
        self.memory = ConversationBufferMemory(
            memory_key="chat_history", return_messages=True
        )
        self.reasons_revealed = False
        self.improvements_revealed = False

    def count_coaching_attempts(self, chat_history):
        """Count supervisor attempts and agent responses - Pure Python logic"""
        supervisor_reason_attempts = 0
        supervisor_improvement_attempts = 0
        agent_dont_know_reasons = 0
        agent_dont_know_improvements = 0
        agent_frustrated = False

        for msg in chat_history:
            role = msg.get("role", "")
            content = msg.get("content", "").lower()

            if role == "supervisor":
                # Count reason-related questions
                if any(
                    keyword in content
                    for keyword in [
                        "what reasons",
                        "why did",
                        "what went wrong",
                        "what do you think went wrong",
                        "what stood out",
                        "can you spot",
                    ]
                ):
                    if not self.reasons_revealed:
                        supervisor_reason_attempts += 1

                # Count improvement-related questions
                if any(
                    keyword in content
                    for keyword in [
                        "what improvements",
                        "how would you",
                        "what could be better",
                        "what would you do differently",
                        "if you could redo",
                    ]
                ):
                    if not self.improvements_revealed:
                        supervisor_improvement_attempts += 1

            elif role == "agent":
                # Check for "I don't know" responses and variations
                if any(
                    keyword in content
                    for keyword in [
                        "don't know",
                        "tell me",
                        "please tell",
                        "unable to think",
                        "can't think",
                        "not able to find",
                        "can't find",
                        "no idea",
                        "not sure",
                        "can't figure",
                        "help me",
                        "stuck",
                        "don't see",
                        "can't see",
                        "confused",
                        "not getting it",
                    ]
                ):
                    # Now this works correctly because self.reasons_revealed is updated by Pydantic!
                    if not self.reasons_revealed:
                        agent_dont_know_reasons += 1
                    elif not self.improvements_revealed:
                        agent_dont_know_improvements += 1

                # Check for frustration
                if any(
                    keyword in content
                    for keyword in ["fuck", "shit", "damn", "bro please"]
                ):
                    agent_frustrated = True  # Decision logic: reveal after 2 "don't know" responses (1 ask + 1 hint + still don't know)
        should_reveal_reasons = (
            agent_dont_know_reasons >= 2  # Agent said "don't know" at least TWICE
            or agent_frustrated  # OR agent is cursing
        ) and not self.reasons_revealed

        should_reveal_improvements = (
            agent_dont_know_improvements >= 2  # Agent said "don't know" at least TWICE
            or agent_frustrated
        ) and not self.improvements_revealed

        # Determine if we should give a hint (after 1 "don't know" but before revealing)
        should_give_hint_reasons = (
            agent_dont_know_reasons == 1  # Agent said "don't know" ONCE
            and supervisor_reason_attempts >= 1  # We already asked once
            and not self.reasons_revealed  # Haven't revealed yet
        )

        should_give_hint_improvements = (
            agent_dont_know_improvements == 1
            and supervisor_improvement_attempts >= 1
            and not self.improvements_revealed
        )

        return {
            "supervisor_reason_attempts": supervisor_reason_attempts,
            "agent_dont_know_reasons": agent_dont_know_reasons,
            "should_reveal_reasons": should_reveal_reasons,
            "should_give_hint_reasons": should_give_hint_reasons,
            "should_reveal_improvements": should_reveal_improvements,
            "should_give_hint_improvements": should_give_hint_improvements,
            "agent_frustrated": agent_frustrated,
        }

    def convllm(self, user_input, session_data):

        # Build conversation history
        history_text = ""
        for message in self.memory.chat_memory.messages:
            if isinstance(message, HumanMessage):
                history_text += f"Agent: {message.content}\n"
            elif isinstance(message, AIMessage):
                history_text += f"Supervisor: {message.content}\n"

        # Build transcription context
        transcription_text = ""
        if session_data and "transcription" in session_data:
            for turn in session_data["transcription"]:
                transcription_text += f"{turn['speaker']}: {turn['message']}\n\n"

        # Get reasons and improvements
        reasons = (
            session_data.get("mistakes", []) if session_data else []
        )  # Backend still uses 'mistakes' key
        improvements = session_data.get("improvements", []) if session_data else []

        # Format reasons and improvements
        reasons_text = "\n".join(f"{i+1}. {r}" for i, r in enumerate(reasons))
        improvements_text = "\n".join(
            f"{i+1}. {imp}" for i, imp in enumerate(improvements)
        )

        # COUNT ATTEMPTS FIRST (Python logic - no LLM guessing)
        attempt_info = self.count_coaching_attempts(st.session_state.chat_history)

        # Check if both reasons and improvements have been revealed
        all_revealed = self.reasons_revealed and self.improvements_revealed

        # Build your supervisor prompt here
        Customer_prompt = f"""
        You are Mike, a friendly and supportive AI supervisor coaching an agent about a customer service call.
        
        === CALL TRANSCRIPTION ===
        {transcription_text}
        
        === REASONS THE CALL DIDN'T GO WELL ({len(reasons)} total) ===
        {reasons_text}
        
        === SUGGESTED IMPROVEMENTS ({len(improvements)} total) ===
        {improvements_text}
        
        === CONVERSATION HISTORY ===
        {history_text}
        
        === AGENT JUST SAID ===
        {user_input}
        
        === SYSTEM TRACKING (Calculated by Python) ===
        - Supervisor asked about reasons: {attempt_info['supervisor_reason_attempts']} times
        - Agent said "don't know" about reasons: {attempt_info['agent_dont_know_reasons']} times
        - Should give hint for reasons: {attempt_info['should_give_hint_reasons']}
        - Should reveal reasons now: {attempt_info['should_reveal_reasons']}
        - Should give hint for improvements: {attempt_info['should_give_hint_improvements']}
        - Should reveal improvements now: {attempt_info['should_reveal_improvements']}
        - Reasons already revealed: {self.reasons_revealed}
        - Improvements already revealed: {self.improvements_revealed}
        - All content revealed: {all_revealed}
        
        === YOUR COACHING LOGIC ===
        
        GREETING (If this is the FIRST message in CONVERSATION HISTORY):
        → Start with warm, casual greeting ONLY: "Hi there! I'm HICVy. How's it going on your side?" or "Hey! I'm HICVy. How are things going with you?"
        → DO NOT mention the call yet
        → DO NOT ask about reasons yet
        → Just be friendly and casual - wait for their response
        → Keep it 1-2 sentences max
        
        SECOND INTERACTION (After agent responds to greeting):
        → If agent shared something casual (how they're doing, etc.):
          → Acknowledge it briefly: "Good to hear!" or "Nice!" or respond appropriately to what they said
          → Then transition: "So I listened to your call and wanted to chat about it. What reasons do you think the call didn't go as well as it could have?"
        → If agent asks about the call or feedback directly:
          → Jump straight to: "I listened to your call and wanted to chat about it. What reasons do you think the call didn't go as well as it could have?"
        → Be conversational and supportive
        
        PHASE 1 - REASONS IDENTIFICATION:
        
        **IMPORTANT: Check if agent already identified all {len(reasons)} reasons in CONVERSATION HISTORY**
        → Look through the CONVERSATION HISTORY and see if the agent has already mentioned ALL {len(reasons)} reasons
        → If YES (all {len(reasons)} reasons found in agent's previous messages):
          → Skip hint/reveal mechanism
          → Acknowledge: "Nice work! You nailed all three reasons the call was tricky."
          → Move directly to PHASE 2 (ask for improvements)
        
        If reasons NOT revealed yet ({self.reasons_revealed} is False) AND agent hasn't identified all reasons:
          
          If should_reveal_reasons is True ({attempt_info['should_reveal_reasons']}):
            → Agent said "don't know" TWICE - time to reveal
            → Be casual and supportive: "No worries! Let me share what I noticed."
            → Reveal all {len(reasons)} reasons as a numbered list
            → Format: "Here are the {len(reasons)} reasons things didn't go so well: 1. [reason], 2. [reason], 3. [reason]. So, what do you think could've been done differently?"
            → Keep it conversational, like chatting with a friend
            → Use phrases like "So here's the thing..." or "What I noticed was..."
          
          Else if should_give_hint_reasons is True ({attempt_info['should_give_hint_reasons']}):
            → Agent said "don't know" ONCE - give them ONE helpful hint
            → Be encouraging: "That's okay! Let me give you a hint."
            → Use the FIRST reason from the list as context: "{reasons[0] if reasons else ''}"
            → Find a relevant moment from the TRANSCRIPTION that relates to this reason
            → Format: "Think about [specific moment from transcript related to first reason]. What do you notice there?"
            → Keep it friendly and interactive, like you're helping a colleague
          
          Else:
            → First time asking or agent is trying
            → Be casual and curious: "So, what reasons do you think the call didn't go as smoothly as it could have? There are {len(reasons)} things I spotted."
            → Or: "Hey, what stood out to you about why this call was tricky? I noticed {len(reasons)} key reasons."
            → Keep it conversational, not formal
        
        PHASE 2 - IMPROVEMENTS SUGGESTION:
        
        **IMPORTANT: Check if agent already identified all {len(improvements)} improvements in CONVERSATION HISTORY**
        → Look through the CONVERSATION HISTORY and see if the agent has already mentioned ALL {len(improvements)} improvements
        → If YES (all {len(improvements)} improvements found in agent's previous messages):
          → Skip hint/reveal mechanism
          → Acknowledge: "Awesome! You got all the improvements."
          → Move directly to PHASE 3 (ask for takeaways)
        
        If reasons ARE revealed ({self.reasons_revealed} is True) AND improvements NOT revealed yet AND agent hasn't identified all improvements:
          
          If should_reveal_improvements is True ({attempt_info['should_reveal_improvements']}):
            → Agent said "don't know" TWICE about improvements - time to reveal
            → Be supportive: "Alright, let me share some ideas that could help!"
            → Reveal all {len(improvements)} improvements as a numbered list
            → Format: "Here's what could work better next time: 1. [improvement], 2. [improvement], 3. [improvement]. What do you think? What are your main takeaways here?"
            → Keep it conversational and encouraging
          
          Else if should_give_hint_improvements is True ({attempt_info['should_give_hint_improvements']}):
            → Agent said "don't know" ONCE about improvements - give ONE hint
            → Be helpful: "Let me give you a hint!"
            → Use the FIRST improvement from the list: "{improvements[0] if improvements else ''}"
            → Connect it to the FIRST reason we already discussed: "{reasons[0] if reasons else ''}"
            → Format: "Think about [first improvement] - how could that help with [first reason we found]?"
            → Keep it like friendly advice
          
          Else:
            → First time asking for improvements
            → Be conversational: "So now that we've talked about what went wrong, what do you think could've been done differently?"
            → Or: "What improvements would you make if you could redo this call?"
            → Keep it natural and engaging
        
        PHASE 3 - CLOSURE (FINAL PHASE):
        
        If all content revealed ({all_revealed} is True):
          
          If agent is asking for suggestions or more advice:
            → Provide brief, actionable suggestions based on the improvements we discussed
            → Keep it to 2-3 practical tips
            → Then ask: "So, what are your key takeaways? How will you use these in your next call?"
          
          Else if agent is sharing takeaways/how they'll use them (any response - good or minimal):
            → If they shared meaningful takeaways:
              → Acknowledge warmly: "Great insights!" or "Love that!"
            → If they say "nothing", "don't know", "not sure", or give minimal response:
              → Be supportive: "No problem!" or "That's okay!"
            → Then ALWAYS say: "Spend some time going through the reasons and improvements we discussed - you'll understand them better."
            → End with casual goodbye: "Good luck with your next call!" or "Talk to you later!"
            → Format: "[Acknowledgment]. Spend some time going through the reasons and improvements we discussed - you'll understand them better. [Goodbye]"
            → Example: "No problem! Spend some time going through the reasons and improvements we discussed - you'll understand them better. Good luck!"
            → This is the TRUE END - conversation should close here
          
          Else:
            → Ask for their takeaways: "So, what are your main takeaways from this? How will you use these in your next call?"
            → Keep it casual and conversational
            → Maximum 1-2 sentences
            → Keep it casual and conversational
            → Maximum 1-2 sentences
        
        === OUTPUT RULES ===
        - Maximum 2-3 sentences
        - Be casual, friendly, and conversational - like talking to a colleague over coffee
        - Use casual phrases: "So here's the thing...", "What I noticed was...", "Let me ask you this..."
        - Be interactive and engaging - ask questions naturally
        - Use agent's name occasionally if appropriate
        - NO repetition - each response should progress the conversation
        - If agent is frustrated, be extra supportive and understanding
        - NEVER create new reasons/improvements beyond the provided lists
        - Follow the phase logic EXACTLY based on the boolean values above
        - Avoid formal language - keep it relaxed and supportive
        
        === OFF-TOPIC HANDLING ===
        - If agent talks about something COMPLETELY unrelated to the call (weather, sports, random topics):
        - Politely redirect: "Hey, let's stick to the call feedback for now. I'd like to wrap this up with your takeaways, cool?"
        - Keep it friendly but firm - bring them back to the coaching session
        
        === YOUR RESPONSE ===
        





        
          
        """

        # Use structured output with Pydantic - PRODUCTION READY! 🦇
        response = client.beta.chat.completions.parse(
            model="gpt-4.1",
            messages=[
                {"role": "system", "content": ""},
                {"role": "user", "content": Customer_prompt},
            ],
            response_format=SupervisorResponse,
            temperature=0.7,
            max_tokens=1000,
        )

        # Extract structured data - type-safe!
        parsed_response = response.choices[0].message.parsed
        response_content = parsed_response.response

        # 🔍 DEBUG LOGGING - Print flags and Pydantic output
        print("\n" + "=" * 60)
        print("🦇 DEBUG: LLM RESPONSE")
        print("=" * 60)
        print(f"📝 Response Text: {response_content[:100]}...")
        print(f"✅ reasons_complete: {parsed_response.reasons_complete}")
        print(f"✅ improvements_complete: {parsed_response.improvements_complete}")
        print(f"🚩 BEFORE UPDATE:")
        print(f"   - self.reasons_revealed: {self.reasons_revealed}")
        print(f"   - self.improvements_revealed: {self.improvements_revealed}")

        # Update flags based on LLM's intelligent detection
        if parsed_response.reasons_complete:
            self.reasons_revealed = True

        if parsed_response.improvements_complete:
            self.improvements_revealed = True

        print(f"🚩 AFTER UPDATE:")
        print(f"   - self.reasons_revealed: {self.reasons_revealed}")
        print(f"   - self.improvements_revealed: {self.improvements_revealed}")
        print(
            f"🎯 all_revealed: {self.reasons_revealed and self.improvements_revealed}"
        )
        print("=" * 60 + "\n")

        # Save to memory (only the text response, not the flags)
        self.memory.save_context({"input": user_input}, {"output": response_content})

        return response_content

    def detect_goodbye(self, message):
        """Check if conversation should end based on goodbye keywords"""
        return any(kw in message.lower() for kw in self.GOODBYE_KEYWORDS)


def main():
    # Title and Header
    st.markdown(
        "<h1 style='text-align: center; margin-bottom: 30px;'>🎯 HICVy AI Supervisor Coaching</h1>",
        unsafe_allow_html=True,
    )

    # Initialize LLM instance after class definition
    if "llm_instance" not in st.session_state:
        st.session_state.llm_instance = ConversationLLM()

    # Sidebar controls
    with st.sidebar:
        st.header("🎛️ Session Controls")

        # File Upload Section
        if not st.session_state.file_uploaded:
            st.markdown("### 📁 Upload Transcript")
            uploaded_file = st.file_uploader(
                "Upload Excel file",
                type=["xlsx", "xls"],
                help="Upload your call transcript Excel file to analyze",
            )

            if uploaded_file is not None:
                with st.spinner("Analyzing file..."):
                    success = upload_and_analyze_file(uploaded_file)
                    if success:
                        st.success("✅ File analyzed successfully!")
                        st.rerun()

        # Start Session Button (only enabled after file upload)
        if st.session_state.file_uploaded and not st.session_state.conversation_started:
            st.markdown("---")
            if st.button(
                "🚀 Start AI Supervisor Guidance",
                type="primary",
                use_container_width=True,
                key="start_btn",
            ):
                st.session_state.conversation_started = True
                st.success("✅ Session started! Supervisor is ready to chat.")
                st.rerun()
        elif st.session_state.conversation_started:
            st.markdown("---")
            st.success("✅ Session Active")

        st.markdown("---")

        # Reset Button
        if st.button(
            "🔄 Reset Conversation", use_container_width=True, key="reset_btn"
        ):
            reset_conversation()
            st.rerun()

        st.markdown("---")

        # Download Chat History Button
        if st.session_state.chat_history:
            excel_output = export_conversation_to_excel()
            if excel_output:
                st.download_button(
                    label="📥 Download Conversation",
                    data=excel_output,
                    file_name=f"coaching_session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                )

    # Main Content Area
    if not st.session_state.file_uploaded:
        # Welcome Screen - File Upload Required
        st.markdown("---")
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.info(
                "👋 **Welcome to HICVy Coaching!**\n\n"
                "Please upload your call transcript Excel file from the sidebar to begin.\n\n"
                "The AI supervisor will analyze your call and provide coaching feedback."
            )

    elif st.session_state.file_uploaded and not st.session_state.conversation_started:
        # File uploaded but session not started
        st.markdown("---")
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.success(
                "✅ **File Analyzed Successfully!**\n\n"
                f"**Reasons Found:** {len(st.session_state.session_data.get('mistakes', []))}\n\n"
                f"**Improvements Suggested:** {len(st.session_state.session_data.get('improvements', []))}\n\n"
                "Click **'Start AI Supervisor Guidance'** in the sidebar to begin coaching."
            )

    else:
        # Chat Interface (Active Session)
        st.markdown("---")

        # Display chat history
        for msg in st.session_state.chat_history:
            role = msg.get("role", "")
            content = msg.get("content", "")

            if role == "supervisor":
                with st.chat_message("assistant", avatar="👔"):
                    st.markdown(content)
            elif role == "agent":
                with st.chat_message("user", avatar="👤"):
                    st.markdown(content)

        # Chat input
        user_input = st.chat_input("Type your response here...")

        if user_input:
            # Add user message to history
            st.session_state.chat_history.append(
                {
                    "role": "agent",
                    "content": user_input,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
            )

            # Display user message
            with st.chat_message("user", avatar="👤"):
                st.markdown(user_input)

            # Check for goodbye keywords to end conversation
            if st.session_state.llm_instance.detect_goodbye(user_input):
                goodbye_message = "Thank you for this coaching session! Feel free to start a new one anytime. Click 'Reset Conversation' to begin fresh."

                st.session_state.chat_history.append(
                    {
                        "role": "supervisor",
                        "content": goodbye_message,
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    }
                )

                with st.chat_message("assistant", avatar="👔"):
                    st.markdown(goodbye_message)

                st.session_state.conversation_started = False
                st.info("✅ Session ended. Click 'Reset Conversation' to start fresh.")
                st.stop()

            # Generate supervisor response using LLM
            supervisor_response = st.session_state.llm_instance.convllm(
                user_input, st.session_state.session_data
            )

            # Add supervisor response to history
            st.session_state.chat_history.append(
                {
                    "role": "supervisor",
                    "content": supervisor_response,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
            )

            # Display supervisor response
            with st.chat_message("assistant", avatar="👔"):
                st.markdown(supervisor_response)

            st.rerun()


if __name__ == "__main__":
    main()
