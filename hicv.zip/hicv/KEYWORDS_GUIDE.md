# 🎯 HICVy AI Supervisor - Keywords Guide

This document explains the keywords and phrases that trigger specific behaviors in the HICVy AI Supervisor coaching application.

---

## 🛑 GOODBYE KEYWORDS (Conversation End Triggers)

When the agent uses any of these phrases, the conversation will automatically end:

| Keyword | Purpose |
|---------|---------|
| `bye` | Standard goodbye |
| `goodbye` | Formal farewell |
| `have a nice day` | Polite closing |
| `talk to you later` | Casual goodbye |
| `thanks again` | Gratitude + closing |
| `see you` | Informal goodbye |
| `take care` | Caring farewell |
| `alright thanks for your help` | Acknowledgment + thanks |

### 📌 **Usage Example:**
```
Agent: "Okay, I understand now. Thanks again!"
System: ✅ Conversation ends automatically
```

---

## ❓ "I DON'T KNOW" KEYWORDS (Hint/Reveal Triggers)

When the agent uses any of these phrases, it indicates they need help identifying reasons or improvements:

### **Primary Keywords:**
- `don't know`
- `tell me`
- `please tell`
- `no idea`
- `not sure`

### **Inability to Think/Find:**
- `unable to think`
- `can't think`
- `not able to find`
- `can't find`
- `can't figure`
- `don't see`
- `can't see`

### **Confusion/Stuck:**
- `help me`
- `stuck`
- `confused`
- `not getting it`

---

## 🔄 HOW THE HINT SYSTEM WORKS

The supervisor uses a **progressive hint system** based on how many times the agent says "I don't know":

### **First Time - Agent Says "Don't Know":**
```
Agent: "I don't know what went wrong..."
Supervisor: 💡 Gives ONE helpful HINT
```

### **Second Time - Agent Says "Don't Know" Again:**
```
Agent: "I still don't know..."
Supervisor: 📋 REVEALS all reasons/improvements
```

---

## 📊 BEHAVIOR FLOWCHART

```
┌─────────────────────────────────┐
│ Agent Response                  │
└──────────┬──────────────────────┘
           │
           ├─── Contains "don't know" keyword?
           │    │
           │    ├─ First time → Give HINT
           │    └─ Second time → REVEAL all
           │
           ├─── Contains goodbye keyword?
           │    └─ END conversation
           │
           └─── Normal response
                └─ Continue coaching
```

---

## 🎯 TIPS FOR AGENTS

### **✅ DO:**
- Try to identify reasons/improvements before asking for help
- Use "don't know" phrases if genuinely stuck (you'll get hints)
- Use goodbye phrases when ready to end the session

### **❌ DON'T:**
- Say goodbye phrases mid-conversation (conversation will end!)
- Overuse "don't know" - try thinking first
- Use confusion phrases when you actually understand

---

## 📝 EXAMPLE CONVERSATION FLOW

### **Scenario 1: Agent Needs Help**
```
Supervisor: "What reasons do you think the call didn't go well?"
Agent: "Hmm, I'm not sure..."
         ↓
Supervisor: 💡 "Let me give you a hint! Think about when the customer mentioned..."
Agent: "Oh! The customer had a bad experience before!"
         ↓
Supervisor: ✅ "Exactly! Good catch!"
```

### **Scenario 2: Agent Ready to Leave**
```
Agent: "I understand everything now. Thanks again!"
         ↓
System: ✅ Conversation ends
Message: "Thank you for this coaching session! Feel free to start a new one anytime."
```

---

## 🔧 TECHNICAL DETAILS

### **Keyword Detection:**
- All keywords are **case-insensitive** (works with uppercase/lowercase)
- Partial matches work (e.g., "I don't know anything" triggers "don't know")
- System checks **agent messages only**, not supervisor messages

### **Counters:**
- `agent_dont_know_reasons`: Tracks "don't know" for reasons phase
- `agent_dont_know_improvements`: Tracks "don't know" for improvements phase
- Counters reset when conversation restarts

---

## 📞 SUPPORT

If you have questions about these keywords or need to add/remove any, contact the development team.

**Last Updated:** November 28, 2025  
**Version:** 1.0
