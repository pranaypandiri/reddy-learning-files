"""
Script to check all available models in Vertex AI Model Garden
"""

import vertexai
from vertexai.generative_models import GenerativeModel
from google.cloud import aiplatform

# Initialize Vertex AI
PROJECT_ID = "ai-practice-388514"
LOCATION = "us-central1"

vertexai.init(project=PROJECT_ID, location=LOCATION)

print("=" * 60)
print("🔍 CHECKING VERTEX AI MODEL GARDEN")
print("=" * 60)
print(f"Project: {PROJECT_ID}")
print(f"Location: {LOCATION}")
print("=" * 60)

# Method 1: List Gemini models (most common)
print("\n📦 GEMINI MODELS AVAILABLE:")
print("-" * 60)

gemini_models = [
    "gemini-2.0-flash-exp",
    "gemini-1.5-flash",
    "gemini-1.5-flash-8b",
    "gemini-1.5-pro",
    "gemini-1.0-pro",
    "gemini-pro",
    "gemini-pro-vision",
]

for model_name in gemini_models:
    try:
        model = GenerativeModel(model_name)
        print(f"✅ {model_name} - AVAILABLE")
    except Exception as e:
        print(f"❌ {model_name} - NOT AVAILABLE ({str(e)[:50]})")

# Method 2: List all published models in Model Garden
print("\n\n📚 ALL MODELS IN MODEL GARDEN:")
print("-" * 60)

try:
    aiplatform.init(project=PROJECT_ID, location=LOCATION)

    # List all models
    models = aiplatform.Model.list()

    if models:
        for model in models[:10]:  # Show first 10
            print(f"Model: {model.display_name}")
            print(f"  Resource Name: {model.resource_name}")
            print(f"  Created: {model.create_time}")
            print("-" * 40)
    else:
        print("No custom models found in your project")

except Exception as e:
    print(f"Error listing models: {e}")

# Method 3: Test specific model with a simple prompt
print("\n\n🧪 TESTING GEMINI 2.0 FLASH:")
print("-" * 60)

try:
    test_model = GenerativeModel("gemini-2.0-flash-exp")
    response = test_model.generate_content(
        "Say 'Hello from Vertex AI!' in one sentence"
    )
    print(f"✅ Model Response: {response.text}")
    print(f"✅ Model is working!")
except Exception as e:
    print(f"❌ Error: {e}")

print("\n" + "=" * 60)
print("✅ Model Garden Check Complete!")
print("=" * 60)
