"""
Agent 1: IT Support Triage Agent
Handles issue categorization, ticket creation, and session management
"""

from langchain_google_vertexai import ChatVertexAI
from langchain.tools import tool
from langgraph.prebuilt import create_react_agent
from google.cloud import firestore
from sqlalchemy import create_engine, text
import os
from datetime import datetime

# Initialize Vertex AI LLM
llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    project="ai-practice-388514",
    location="us-central1",
    temperature=0.3,
)

# Initialize Firestore (using existing database)
db = firestore.Client(project="ai-practice-388514", database="customer-support-db")

# TODO: Initialize Cloud SQL connection
# cloud_sql_connection_name = "PROJECT_ID:REGION:INSTANCE_NAME"


# ============ TOOLS ============


@tool
def categorize_issue(issue_description: str) -> str:
    """
    Categorize the IT support issue into one of these categories:
    - VPN_ACCESS
    - PASSWORD_RESET
    - NETWORK_CONNECTIVITY
    - SOFTWARE_INSTALLATION
    - HARDWARE_ISSUE
    - OTHER

    Args:
        issue_description: The user's description of their IT problem

    Returns:
        The category as a string
    """
    # TODO: Use LLM to categorize the issue
    pass


@tool
def create_ticket(user_id: str, issue: str, category: str) -> str:
    """
    Create a support ticket in Cloud SQL database.

    Args:
        user_id: The user's employee ID
        issue: Description of the issue
        category: The categorized issue type

    Returns:
        ticket_id as string
    """
    # TODO: Insert ticket into Cloud SQL
    pass


@tool
def save_session(session_id: str, ticket_id: str, category: str, messages: list) -> str:
    """
    Save conversation session to Firestore for crash recovery.

    Args:
        session_id: Unique session identifier
        ticket_id: Associated ticket ID
        category: Issue category
        messages: List of conversation messages

    Returns:
        Success message
    """
    # TODO: Save to Firestore sessions collection
    pass


@tool
def load_session(session_id: str) -> dict:
    """
    Load existing session from Firestore if user returns.

    Args:
        session_id: The session identifier to retrieve

    Returns:
        Session data dictionary or empty dict if not found
    """
    # TODO: Retrieve from Firestore
    pass


# ============ AGENT DECLARATION ============

# System prompt for Agent 1
system_prompt = """You are an IT Support Triage Agent for Google GTE employees.

Your responsibilities:
1. Greet users and understand their IT issues
2. Categorize issues into the correct category
3. Create support tickets in the database
4. Save conversation sessions for crash recovery
5. Load existing sessions if users return

Be professional, empathetic, and efficient. Ask clarifying questions if needed.
Always confirm the category with the user before creating a ticket."""

# Create Agent 1 with tools
from langchain_core.messages import SystemMessage

agent1_triage = create_react_agent(
    model=llm,
    tools=[categorize_issue, create_ticket, save_session, load_session],
    prompt=SystemMessage(content=system_prompt),
)


# ============ TEST FUNCTION ============


def test_agent1():
    """
    Test Agent 1 standalone
    """
    # TODO: Test the agent with sample inputs
    pass


if __name__ == "__main__":
    print("✅ Agent 1 Triage loaded successfully!")
    print(f"Agent type: {type(agent1_triage).__name__}")
    print(f"Tools: categorize_issue, create_ticket, save_session, load_session")
