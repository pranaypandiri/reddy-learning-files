#!/usr/bin/env python3
"""
GCS Storage Manager - Handle evaluation file operations with Google Cloud Storage
For ImageToQueryLLM application
"""

import os
from datetime import datetime
from google.cloud import storage
import streamlit as st


class GCSStorageManager:
    """
    Manages evaluation file storage and retrieval from Google Cloud Storage
    Replaces local file system operations with cloud storage
    """

    def __init__(
        self, project_id="ai-practice-388514", bucket_name="ai-virtual-customer-poc"
    ):
        self.project_id = project_id
        self.bucket_name = bucket_name

        try:
            # Using Application Default Credentials
            self.client = storage.Client(project=project_id)
            self.bucket = self.client.bucket(bucket_name)
            # GCS Storage Manager initialized successfully
        except Exception as e:
            print(f"[ERROR] ❌ Failed to initialize GCS client: {str(e)}")
            self.client = None
            self.bucket = None

    def is_connected(self):
        """Check if GCS client is properly initialized"""
        return self.client is not None and self.bucket is not None

    def save_evaluation_to_gcs(self, eval_data):
        """
        Save evaluation Excel file to GCS bucket

        Args:
            eval_data (dict): Contains evaluation information:
                - username: str
                - timestamp: str
                - excel_bytes: bytes
                - department: str (optional)
                - issue_type: str (optional)
                - tone: str (optional)
                - eval_score: str (optional)

        Returns:
            tuple: (success: bool, message: str)
        """

        if not self.is_connected():
            return False, "⚠️ Cloud storage connection not available"

        try:
            username = eval_data.get("username", "unknown")
            timestamp = eval_data.get(
                "timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            )
            excel_bytes = eval_data.get("excel_bytes", b"")

            if not excel_bytes:
                return False, "❌ No evaluation data to save"

            # Create filename with same naming convention
            safe_timestamp = timestamp.replace(":", "-").replace(" ", "_")

            # Generate eval number (simple incrementing number)
            # For now, use timestamp-based approach, can be improved later
            eval_number = self._get_next_eval_number(username)
            filename = f"eval_{eval_number}_{safe_timestamp}.xlsx"

            # Create GCS path: evaluations/{username}/{filename}
            gcs_path = f"evaluations/{username}/{filename}"

            # Create blob object
            blob = self.bucket.blob(gcs_path)

            # Add metadata for better tracking
            blob.metadata = {
                "username": eval_data.get("username", ""),
                "department": eval_data.get("department", ""),
                "issue_type": eval_data.get("issue_type", ""),
                "tone": eval_data.get("tone", ""),
                "eval_score": eval_data.get("eval_score", ""),
                "created_at": timestamp,
                "file_type": "evaluation_excel",
                "saved_by": "streamlit_app",
                "eval_number": str(eval_number),
            }

            # Upload the Excel file
            blob.upload_from_string(
                excel_bytes,
                content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

            success_msg = f"✅ Evaluation saved to cloud storage"

            return True, success_msg

        except Exception as e:
            error_msg = f"❌ Failed to save to cloud storage: {str(e)}"
            print(f"[ERROR] {error_msg}")
            return False, error_msg

    def _get_next_eval_number(self, username):
        """
        Get the next evaluation number for a user
        Simple approach: count existing files + 1
        """
        try:
            prefix = f"evaluations/{username}/"
            blobs = list(self.client.list_blobs(self.bucket, prefix=prefix))

            # Count evaluation files
            eval_count = len([blob for blob in blobs if blob.name.endswith(".xlsx")])

            return eval_count + 1

        except Exception as e:
            print(f"[WARNING] Could not determine eval number: {e}")
            # Fallback to timestamp-based number
            return int(datetime.now().timestamp() % 10000)

    def load_user_evaluations(self, username):
        """
        Load all evaluation files for a specific user from GCS

        Args:
            username (str): Username to load evaluations for

        Returns:
            list: List of evaluation dictionaries with excel_bytes included
        """

        if not self.is_connected():
            print("[ERROR] GCS not connected for loading evaluations")
            return []

        try:
            evaluations = []
            prefix = f"evaluations/{username}/"

            # List all blobs with the user's prefix
            blobs = list(self.client.list_blobs(self.bucket, prefix=prefix))

            for blob in blobs:
                if blob.name.endswith(".xlsx"):
                    try:
                        # Extract filename first (needed for error messages)
                        filename = blob.name.split("/")[-1]  # Get just the filename

                        # Download the Excel file bytes
                        excel_bytes = blob.download_as_bytes()

                        # Extract metadata from GCS blob
                        metadata = blob.metadata or {}

                        # 🔧 FALLBACK: If metadata is missing, try to read from Excel file itself
                        if not metadata.get("department") or not metadata.get(
                            "issue_type"
                        ):
                            try:
                                metadata = self._extract_metadata_from_excel_bytes(
                                    excel_bytes, metadata
                                )
                            except Exception as e:
                                print(
                                    f"[WARNING] Could not extract Excel metadata for {filename}: {e}"
                                )

                        # Try to extract timestamp from filename if not in metadata
                        timestamp_from_filename = self._extract_timestamp_from_filename(
                            filename
                        )

                        evaluation = {
                            "username": metadata.get("username", username),
                            "department": metadata.get("department", ""),
                            "issue_type": metadata.get("issue_type", ""),
                            "tone": metadata.get("tone", ""),
                            "timestamp": metadata.get(
                                "created_at", timestamp_from_filename
                            ),
                            "eval_score": metadata.get("eval_score", ""),
                            "excel_bytes": excel_bytes,
                            "gcs_path": blob.name,
                            "filename": filename,
                        }

                        evaluations.append(evaluation)

                    except Exception as e:
                        print(
                            f"[ERROR] Failed to load evaluation {blob.name}: {str(e)}"
                        )
                        continue

            # Sort by timestamp (newest first)
            evaluations.sort(key=lambda x: x.get("timestamp", ""), reverse=True)

            # Summary: evaluations loaded
            return evaluations

        except Exception as e:
            error_msg = f"Failed to load evaluations from cloud storage: {str(e)}"
            print(f"[ERROR] {error_msg}")
            return []

    def _extract_timestamp_from_filename(self, filename):
        """Extract timestamp from filename like eval_1_2025-08-25_14-30-25.xlsx"""
        try:
            if "eval_" in filename:
                # Remove eval_ prefix and .xlsx suffix
                parts = filename.replace("eval_", "").replace(".xlsx", "")
                # Split by underscore and take everything after the first part (eval number)
                timestamp_parts = parts.split("_", 1)
                if len(timestamp_parts) > 1:
                    timestamp_str = (
                        timestamp_parts[1].replace("_", " ").replace("-", ":")
                    )
                    return timestamp_str
        except Exception as e:
            print(
                f"[WARNING] Could not extract timestamp from filename {filename}: {e}"
            )

        return ""

    def _extract_metadata_from_excel_bytes(self, excel_bytes, existing_metadata):
        """
        Extract metadata from Excel file's Metadata sheet if GCS metadata is missing

        Args:
            excel_bytes: Excel file bytes
            existing_metadata: Current GCS metadata (to preserve what we have)

        Returns:
            dict: Updated metadata dictionary
        """
        import openpyxl
        from io import BytesIO

        try:
            with BytesIO(excel_bytes) as excel_io:
                wb = openpyxl.load_workbook(excel_io, data_only=True)

                if "Metadata" in wb.sheetnames:
                    meta_sheet = wb["Metadata"]

                    # Read metadata row (assuming row 2 has the data)
                    meta_row = list(
                        meta_sheet.iter_rows(min_row=2, max_row=2, values_only=True)
                    )
                    if meta_row and len(meta_row[0]) >= 6:
                        username_xl, dept_xl, issue_xl, tone_xl, ts_xl, score_xl = (
                            meta_row[0][:6]
                        )

                        # Update metadata with Excel data if GCS metadata is missing
                        updated_metadata = existing_metadata.copy()
                        if not updated_metadata.get("department") and dept_xl:
                            updated_metadata["department"] = str(dept_xl)
                        if not updated_metadata.get("issue_type") and issue_xl:
                            updated_metadata["issue_type"] = str(issue_xl)
                        if not updated_metadata.get("tone") and tone_xl:
                            updated_metadata["tone"] = str(tone_xl)
                        if not updated_metadata.get("eval_score") and score_xl:
                            updated_metadata["eval_score"] = str(score_xl)
                        if not updated_metadata.get("created_at") and ts_xl:
                            updated_metadata["created_at"] = str(ts_xl)
                        if not updated_metadata.get("username") and username_xl:
                            updated_metadata["username"] = str(username_xl)

                        return updated_metadata

        except Exception as e:
            print(f"[WARNING] Error extracting metadata from Excel: {e}")

        return existing_metadata

    def test_connection(self):
        """Test GCS connection and bucket access"""
        try:
            if not self.is_connected():
                return False, "❌ GCS client not initialized"

            # Simple test - try to list bucket contents (limit 1)
            list(self.client.list_blobs(self.bucket, max_results=1))
            return True, "✅ Cloud storage connection successful"

        except Exception as e:
            return False, f"❌ Cloud storage connection failed: {str(e)}"

    def load_all_evaluations_for_analytics(self):
        """
        Load ALL evaluations from ALL users for trainer/supervisor analytics

        Returns:
            list: List of all evaluation dictionaries from all users
        """
        if not self.is_connected():
            print("[ERROR] GCS not connected for analytics")
            return []

        try:
            all_evaluations = []
            prefix = "evaluations/"

            blobs = list(self.client.list_blobs(self.bucket, prefix=prefix))

            # List all blobs in evaluations folder

            for blob in blobs:
                if blob.name.endswith(".xlsx"):
                    try:
                        # Extract username from path (evaluations/Associate1/file.xlsx -> Associate1)
                        path_parts = blob.name.split("/")
                        username = path_parts[1] if len(path_parts) > 1 else "unknown"

                        # Skip trainer/supervisor data
                        if username.lower() in ["trainer", "supervisor"]:
                            continue

                        # Extract filename first (needed for error messages)
                        path_parts = blob.name.split("/")
                        username = path_parts[1] if len(path_parts) > 1 else "unknown"
                        filename = path_parts[-1] if path_parts else ""

                        # Download Excel bytes
                        excel_bytes = blob.download_as_bytes()

                        # Extract metadata from GCS blob
                        metadata = blob.metadata or {}

                        # 🔧 FALLBACK: If metadata is missing, try to read from Excel file itself
                        if not metadata.get("department") or not metadata.get(
                            "issue_type"
                        ):
                            try:
                                metadata = self._extract_metadata_from_excel_bytes(
                                    excel_bytes, metadata
                                )
                                # Successfully parsed Excel metadata
                            except Exception as e:
                                print(
                                    f"[WARNING] Could not extract Excel metadata for analytics {filename}: {e}"
                                )

                        evaluation = {
                            "username": metadata.get("username", username),
                            "department": metadata.get("department", ""),
                            "issue_type": metadata.get("issue_type", ""),
                            "tone": metadata.get("tone", ""),
                            "timestamp": metadata.get("created_at", ""),
                            "eval_score": self._parse_eval_score(
                                metadata.get("eval_score", "0")
                            ),
                            "excel_bytes": excel_bytes,
                            "filename": filename,
                            "gcs_path": blob.name,
                        }

                        all_evaluations.append(evaluation)

                    except Exception as e:
                        print(f"[ERROR] Failed to load analytics file {blob.name}: {e}")
                        continue

            # Sort by timestamp (newest first)
            all_evaluations.sort(key=lambda x: x.get("timestamp", ""), reverse=True)

            return all_evaluations

        except Exception as e:
            print(f"[ERROR] Failed to load analytics data from GCS: {e}")
            return []

    def _parse_eval_score(self, score_str):
        """Parse evaluation score string to float"""
        try:
            if isinstance(score_str, (int, float)):
                return float(score_str)
            if isinstance(score_str, str):
                # Remove % sign if present
                clean_score = score_str.replace("%", "").strip()
                return float(clean_score) if clean_score else 0.0
        except (ValueError, AttributeError):
            pass
        return 0.0

    # === USER AND SIMULATION MANAGEMENT METHODS ===

    def get_user_management_bucket(self):
        """Get the user management bucket instance"""
        try:
            user_bucket = self.client.bucket("user-management-ai-trainer")
            return user_bucket
        except Exception as e:
            print(f"[ERROR] Failed to get user management bucket: {e}")
            return None

    def save_json_file(self, filename, data):
        """Save JSON data to user management bucket"""
        import json

        try:
            user_bucket = self.get_user_management_bucket()
            if not user_bucket:
                return False, "Failed to access user management bucket"

            blob = user_bucket.blob(filename)
            json_string = json.dumps(data, indent=2)
            blob.upload_from_string(json_string, content_type="application/json")

            # File saved successfully to user management bucket
            return True, f"Successfully saved {filename}"

        except Exception as e:
            print(f"[ERROR] Failed to save {filename}: {e}")
            return False, str(e)

    def load_json_file(self, filename):
        """Load JSON data from user management bucket"""
        import json

        try:
            user_bucket = self.get_user_management_bucket()
            if not user_bucket:
                print(f"[ERROR] Failed to access user management bucket")
                return None

            blob = user_bucket.blob(filename)
            if not blob.exists():
                print(f"[DEBUG] {filename} does not exist in bucket, returning None")
                return None

            json_string = blob.download_as_text()
            data = json.loads(json_string)

            # File loaded successfully from user management bucket
            return data

        except Exception as e:
            print(f"[ERROR] Failed to load {filename}: {e}")
            return None


# Singleton instance for use in main application
@st.cache_resource
def get_gcs_storage_manager():
    """Get cached GCS storage manager instance"""
    return GCSStorageManager()
