from google.cloud import storage


def delete_bucket_completely(project_id, bucket_name):
    """Delete all objects in bucket, then delete the bucket itself"""
    print(f"🗑️ Starting cleanup of bucket: {bucket_name}")

    client = storage.Client(project=project_id)
    bucket = client.bucket(bucket_name)

    try:
        # Step 1: Delete all objects first
        print("📁 Deleting all objects...")
        blobs = list(bucket.list_blobs())

        if blobs:
            print(f"   Found {len(blobs)} objects to delete")
            for blob in blobs:
                blob.delete()
                print(f"   ✅ Deleted: {blob.name}")
        else:
            print("   📭 No objects found")

        # Step 2: Delete the bucket itself
        print("🗑️ Deleting bucket...")
        bucket.delete()
        print(f"✅ Bucket '{bucket_name}' deleted successfully!")

    except Exception as e:
        print(f"❌ Error deleting bucket: {e}")


if __name__ == "__main__":
    project_id = "ai-practice-388514"
    bucket_name = "testingpractice-20250830"

    # Confirm before deletion
    confirm = input(
        f"⚠️ Are you sure you want to delete bucket '{bucket_name}'? (yes/no): "
    )
    if confirm.lower() == "yes":
        delete_bucket_completely(project_id, bucket_name)
    else:
        print("❌ Deletion cancelled")
