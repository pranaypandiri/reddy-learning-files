from google.cloud import storage
import json
import pandas as pd
from datetime import datetime
import io
import os
import concurrent.futures
import threading

import streamlit as st

project_id = "ai-practice-388514"
bucketname = "testingpractice-20250830"

client = storage.Client(project=project_id)

## when have a service account
# client = storage.Client.from_service_account_json("path/to/service_account.json")

bucket = client.bucket(bucketname)

print(f"bucket {bucket.name}")


class Testing:
    def __init__(self, client, bucket):
        self.client = client
        self.bucket = bucket

    def list_blobs(self):
        blobs = self.client.list_blobs(self.bucket.name)
        for blob in blobs:
            print(blob.name)

    def create_data(self):
        root = "data/"
        employee_data = {
            "empid": [1, 2, 3],
            "name": ["Alice", "Bob", "Charlie"],
            "age": [25, 30, 35],
        }
        df = pd.DataFrame(employee_data)

        emp_dept = {"dept": ["HR", "Finance", "IT"]}

        df_dept = pd.DataFrame(emp_dept)
        ## used to create the in-memory
        excelbuffer = io.BytesIO()
        ## like an object writer which helpful to write the pandas data to the excel
        with pd.ExcelWriter(excelbuffer, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name="Employees")
            df_dept.to_excel(writer, sheet_name="Departments")
        ## makes the file data from in-memory to the byte which is the format need for the gcs
        excel_bytes = excelbuffer.getvalue()

        """
        create the json object 
        convert as json string --> bytes again aas it is the format gcs bucket needed 
        """
        json_data = {"key": "testing values bro"}

        json_str = json.dumps(json_data)
        json_str_bytes = json_str.encode("utf-8")

        return json_str_bytes, excel_bytes

    def add_data(self):
        json_str_bytes, excel_bytes = self.create_data()
        root = "data/"

        try:
            excelobj = self.bucket.blob(root + "excelfile")
            excelobj.upload_from_string(
                excel_bytes,
                content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

            jsonobj = self.bucket.blob(root + "metadata.json")
            jsonobj.upload_from_string(json_str_bytes, content_type="application/json")

            blobs = self.bucket.list_blobs(prefix=root)

            for x in blobs:
                print(x.name)
                print(x.path)

        except Exception as e:
            raise e

    def upload_parallel_different_data(self):
        # Create different format data
        # Data 1: Customer CSV format
        customer_data = {
            "customer_id": [101, 102, 103, 104],
            "name": ["John Smith", "Sarah Wilson", "Mike Johnson", "Lisa Brown"],
            "email": [
                "john@email.com",
                "sarah@email.com",
                "mike@email.com",
                "lisa@email.com",
            ],
            "subscription": ["Premium", "Basic", "Premium", "Standard"],
        }
        df_customers = pd.DataFrame(customer_data)

        # Convert to CSV bytes
        csv_buffer = io.StringIO()
        df_customers.to_csv(csv_buffer, index=False)
        csv_bytes = csv_buffer.getvalue().encode("utf-8")

        # Data 2: Configuration JSON format
        config_data = {
            "app_settings": {
                "version": "2.1.0",
                "environment": "production",
                "features": ["analytics", "notifications", "backup"],
            },
            "database": {"host": "localhost", "port": 5432, "timeout": 30},
            "created_at": datetime.now().isoformat(),
        }
        config_json_bytes = json.dumps(config_data, indent=2).encode("utf-8")

        def upload_csv():
            try:
                csv_blob = self.bucket.blob(
                    f"parallel_data/customers_{datetime.now().strftime('%H%M%S')}.csv"
                )
                csv_blob.upload_from_string(csv_bytes, content_type="text/csv")
                print(f"✅ CSV uploaded by thread: {threading.current_thread().name}")
                return "CSV Success"
            except Exception as e:
                print(
                    f"❌ CSV failed by thread: {threading.current_thread().name} - {e}"
                )
                return f"CSV Failed: {e}"

        def upload_config():
            try:
                config_blob = self.bucket.blob(
                    f"parallel_data/config_{datetime.now().strftime('%H%M%S')}.json"
                )
                config_blob.upload_from_string(
                    config_json_bytes, content_type="application/json"
                )
                print(
                    f"✅ Config uploaded by thread: {threading.current_thread().name}"
                )
                return "Config Success"
            except Exception as e:
                print(
                    f"❌ Config failed by thread: {threading.current_thread().name} - {e}"
                )
                return f"Config Failed: {e}"

        # Execute in parallel
        print("🚀 Starting parallel uploads...")
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            future1 = executor.submit(upload_csv)
            future2 = executor.submit(upload_config)

            # Wait for both to complete and get results
            print("⏳ Waiting for all uploads to complete...")
            done, not_done = concurrent.futures.wait(
                [future1, future2], return_when=concurrent.futures.ALL_COMPLETED
            )

            # Get results
            results = []
            for future in done:
                result = future.result()
                results.append(result)

            print(f"🎉 All uploads completed! Results: {results}")
            return results

    def delete(self):
        root = "data/"
        try:
            self.bucket.blob(root + "metadata.json").delete()
            print("✅ Metadata deleted successfully.")
        except Exception as e:
            print(f"❌ Metadata deletion failed - {e}")

    def del_bulk_upload(self):
        root = "parallel_data/"
        try:

            def deleteblob(blob):
                try:
                    blob.delete()
                    return f"✅ {blob.name} deleted"
                except Exception as e:
                    print(f"❌ Failed to delete {blob.name}: {e}")
                    return f"❌ {blob.name}: {e}"

            ## difference multiple threads 
            with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
                results = list(
                    executor.map(deleteblob, list(self.bucket.list_blobs(prefix=root)))
                )
                print(*results)
        except Exception as e:
            raise e

    def delete_old_files(self, days_old=7):
        """Delete files older than specified days"""
        from datetime import timedelta

        try:
            cutoff_date = datetime.now() - timedelta(days=days_old)
            blobs = list(self.bucket.list_blobs())
            deleted_count = 0

            for blob in blobs:
                if blob.time_created.replace(tzinfo=None) < cutoff_date:
                    try:
                        blob.delete()
                        print(
                            f"✅ Deleted old file: {blob.name} (created: {blob.time_created})"
                        )
                        deleted_count += 1
                    except Exception as e:
                        print(f"❌ Failed to delete old file {blob.name}: {e}")

            print(f"🎉 Deleted {deleted_count} files older than {days_old} days")
            return deleted_count

        except Exception as e:
            print(f"❌ Old files deletion failed: {e}")
            return 0

    def verify_deletion(self, file_path):
        """Check if file was actually deleted"""
        try:
            blob = self.bucket.blob(file_path)
            exists = blob.exists()

            if exists:
                print(f"⚠️ File still exists: {file_path}")
                return False
            else:
                print(f"✅ File successfully deleted: {file_path}")
                return True

        except Exception as e:
            print(f"❌ Error checking file deletion: {e}")
            return False

    def bulk_upload_generated_excel_with_transfer_manager(self):
        """Upload runtime-generated Excel files using Transfer Manager"""
        import tempfile
        import os
        from google.cloud.storage import transfer_manager

        # Step 1: Generate Excel files in memory
        excel_files_data = []

        for i in range(3):
            # Create Excel data
            employee_data = {
                "EmpID": [100 + i, 200 + i, 300 + i],
                "Name": [f"Alice_{i}", f"Bob_{i}", f"Charlie_{i}"],
                "Salary": [50000 + i * 1000, 60000 + i * 1000, 70000 + i * 1000],
            }
            df = pd.DataFrame(employee_data)

            # Convert to bytes (in memory)
            excel_buffer = io.BytesIO()
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                df.to_excel(writer, sheet_name=f"Data_{i}", index=False)
            excel_bytes = excel_buffer.getvalue()

            excel_files_data.append(
                {
                    "filename": f"transfer_excel_{i}.xlsx",
                    "data": excel_bytes,
                    "gcs_path": f"data/transfer_excel_{i}.xlsx",
                }
            )

        # Step 2: Save to temporary files
        temp_files = []
        temp_dir = tempfile.mkdtemp()

        try:
            for excel_info in excel_files_data:
                # Create temp file
                temp_file_path = os.path.join(temp_dir, excel_info["filename"])

                # Write Excel bytes to temp file
                with open(temp_file_path, "wb") as f:
                    f.write(excel_info["data"])

                temp_files.append(
                    {"temp_path": temp_file_path, "gcs_path": excel_info["gcs_path"]}
                )

            # Step 3: Use Transfer Manager for bulk upload (Official API)
            print(f"🚀 Transfer Manager uploading {len(temp_files)} Excel files...")

            # Correct API: List of (source_file_path, destination_blob) tuples
            source_destination_pairs = []
            for temp_info in temp_files:
                destination_blob = self.bucket.blob(temp_info["gcs_path"])
                source_destination_pairs.append(
                    (temp_info["temp_path"], destination_blob)
                )

            results = transfer_manager.upload_many(
                source_destination_pairs, max_workers=3, deadline=300
            )

            print("✅ Transfer Manager upload completed!")

            # Transfer Manager returns None for successful uploads
            # Let's verify uploads and create meaningful results
            upload_results = []
            for temp_info in temp_files:
                gcs_path = temp_info["gcs_path"]
                blob = self.bucket.blob(gcs_path)

                if blob.exists():
                    print(f"📁 Successfully uploaded: {gcs_path}")
                    upload_results.append(f"✅ {gcs_path}")
                else:
                    print(f"❌ Upload failed: {gcs_path}")
                    upload_results.append(f"❌ {gcs_path}")

            return upload_results

        except Exception as e:
            print(f"❌ Transfer Manager upload failed: {e}")
            return []

        finally:
            # Step 4: Cleanup temp files
            for temp_info in temp_files:
                try:
                    os.remove(temp_info["temp_path"])
                    print(f"🗑️ Cleaned temp file: {temp_info['temp_path']}")
                except:
                    pass
            try:
                os.rmdir(temp_dir)
                print(f"🗑️ Cleaned temp directory: {temp_dir}")
            except:
                pass

    def demonstrate_blob_data_loading(self):
        """Demonstrate the difference between blob metadata and actual data loading"""
        print("\n" + "=" * 60)
        print("🔍 BLOB DATA LOADING DEMONSTRATION")
        print("=" * 60)

        # First, let's create a test file
        test_content = "Hello! This is test content for demonstrating blob loading."
        blob_name = "demo/data_loading_test.txt"

        try:
            # 1. Upload test file
            blob = self.bucket.blob(blob_name)
            blob.upload_from_string(test_content)
            print(f"✅ Created test file: {blob_name}")

            # 2. Create a NEW blob reference (no data loaded)
            print("\n📝 Step 1: Creating blob reference...")
            fresh_blob = self.bucket.blob(blob_name)  # Just a reference!
            print(f"   Blob name: {fresh_blob.name}")
            print(f"   Blob size: {fresh_blob.size}")  # This will be None!
            print(f"   Blob etag: {fresh_blob.etag}")  # This will be None!
            print(f"   ⚠️  No metadata loaded yet - everything is None!")

            # 3. Use reload() to get metadata (NOT content)
            print("\n🔄 Step 2: Using reload() to fetch metadata...")
            fresh_blob.reload()  # Fetches metadata only
            print(f"   Blob size: {fresh_blob.size} bytes")
            print(f"   Blob etag: {fresh_blob.etag}")
            print(f"   Generation: {fresh_blob.generation}")
            print(f"   ✅ Metadata loaded, but still NO file content!")

            # 4. Now actually download the content
            print("\n📥 Step 3: Actually downloading file content...")
            actual_content = fresh_blob.download_as_text()
            print(f"   Downloaded content: '{actual_content}'")
            print(f"   Content length: {len(actual_content)} characters")
            print(f"   ✅ NOW we have the actual file data!")

            # 5. Alternative: get_blob() loads metadata automatically
            print("\n🔍 Step 4: Using get_blob() (loads metadata automatically)...")
            auto_loaded_blob = self.bucket.get_blob(blob_name)
            if auto_loaded_blob:
                print(f"   Size (already loaded): {auto_loaded_blob.size} bytes")
                print(f"   ETag (already loaded): {auto_loaded_blob.etag}")
                print(f"   ✅ get_blob() automatically loaded metadata!")

                # But still need to download for content
                content_via_get_blob = auto_loaded_blob.download_as_text()
                print(f"   Content: '{content_via_get_blob}'")

            # Cleanup
            blob.delete()
            print(f"\n🗑️  Cleaned up test file: {blob_name}")

        except Exception as e:
            print(f"❌ Error in demonstration: {e}")

        print("\n" + "=" * 60)
        print("📚 SUMMARY:")
        print("• bucket.blob(name) → Just creates reference, no data")
        print("• blob.reload() → Fetches metadata only (size, etag, etc.)")
        print("• blob.download_as_text() → Actually downloads file content")
        print("• bucket.get_blob(name) → Creates reference + loads metadata")
        print("=" * 60)

    def comprehensive_update_example(self):
        """Comprehensive UPDATE operations with backup, atomic updates, and safety checks"""
        print("\n" + "=" * 70)
        print("🔄 COMPREHENSIVE UPDATE OPERATIONS WITH BACKUP")
        print("=" * 70)

        # Test file setup
        original_file = "updates/customer_data.json"
        backup_file = "updates/backups/customer_data_backup.json"

        try:
            # Step 1: Create initial data
            print("📝 Step 1: Creating initial customer data...")
            initial_data = {
                "customers": [
                    {"id": 1, "name": "Alice", "orders": 5},
                    {"id": 2, "name": "Bob", "orders": 3},
                ],
                "last_updated": "2024-08-30T10:00:00Z",
                "version": 1,
            }

            original_blob = self.bucket.blob(original_file)
            original_blob.upload_from_string(
                json.dumps(initial_data, indent=2), content_type="application/json"
            )
            print(f"✅ Created: {original_file}")

            # Step 2: Load current data and metadata
            print(f"\n🔄 Step 2: Loading current data and metadata...")
            original_blob.reload()  # Get fresh metadata!
            current_generation = original_blob.generation
            current_etag = original_blob.etag
            current_size = original_blob.size

            print(f"   Current generation: {current_generation}")
            print(f"   Current ETag: {current_etag}")
            print(f"   Current size: {current_size} bytes")

            # Download current content
            current_content = original_blob.download_as_text()
            current_data = json.loads(current_content)
            print(f"   Current data: {current_data['customers']}")

            # Step 3: CREATE BACKUP BEFORE UPDATING
            print(f"\n💾 Step 3: Creating backup before update...")
            backup_blob = self.bucket.blob(backup_file)

            # This is the backup concept you asked about!
            backup_blob.upload_from_string(
                original_blob.download_as_bytes(),  # Get original content as bytes
                content_type=original_blob.content_type,  # Preserve content type
            )

            print(f"✅ Backup created: {backup_file}")
            print(f"   Backup preserves content-type: {backup_blob.content_type}")

            # Step 4: Prepare updated data
            print(f"\n📝 Step 4: Preparing updated data...")
            updated_data = current_data.copy()
            updated_data["customers"].append({"id": 3, "name": "Charlie", "orders": 7})
            updated_data["last_updated"] = "2024-08-30T14:30:00Z"
            updated_data["version"] = 2

            print(f"   Adding new customer: Charlie")
            print(f"   New version: {updated_data['version']}")

            # Step 5: ATOMIC UPDATE with generation matching
            print(f"\n🔒 Step 5: Performing atomic update with generation matching...")
            try:
                original_blob.upload_from_string(
                    json.dumps(updated_data, indent=2),
                    content_type="application/json",
                    if_generation_match=current_generation,  # Only if no one else changed it!
                )
                print("✅ Atomic update succeeded!")

                # Reload to get new metadata
                original_blob.reload()
                new_generation = original_blob.generation
                print(f"   New generation: {new_generation}")

            except Exception as e:
                print(f"❌ Atomic update failed: {e}")
                print("   Someone else modified the file! Need to reload and retry...")
                return

            # Step 6: Update metadata using patch()
            print(f"\n🏷️  Step 6: Updating metadata using patch()...")
            original_blob.reload()  # Always reload before patch!

            # patch() updates metadata without changing content
            original_blob.patch()  # This would update metadata if we set any

            # You can set custom metadata like this:
            original_blob.metadata = {
                "department": "customer_service",
                "backup_location": backup_file,
                "last_backup": datetime.now().isoformat(),
            }
            original_blob.patch()  # Apply metadata changes
            print("✅ Metadata updated with patch()")

            # Step 7: Verify the update
            print(f"\n✅ Step 7: Verifying the update...")
            original_blob.reload()  # Get latest state

            # Download and verify content
            updated_content = original_blob.download_as_text()
            verified_data = json.loads(updated_content)

            print(f"   Updated customers: {len(verified_data['customers'])}")
            print(f"   Latest customer: {verified_data['customers'][-1]}")
            print(f"   File generation: {original_blob.generation}")
            print(f"   Custom metadata: {original_blob.metadata}")

            # Step 8: Demonstrate recovery from backup
            print(f"\n🔄 Step 8: Demonstrating recovery from backup...")
            print("   Simulating recovery scenario...")

            # Restore from backup
            backup_content = backup_blob.download_as_bytes()
            recovery_blob = self.bucket.blob("updates/recovered_data.json")
            recovery_blob.upload_from_string(
                backup_content, content_type="application/json"
            )
            print(f"✅ Recovered data to: updates/recovered_data.json")

            # Verify recovery
            recovered_content = recovery_blob.download_as_text()
            recovered_data = json.loads(recovered_content)
            print(f"   Recovered customers: {len(recovered_data['customers'])}")
            print(f"   Recovered version: {recovered_data['version']}")

            # Cleanup
            print(f"\n🗑️  Cleaning up test files...")
            for cleanup_file in [
                original_file,
                backup_file,
                "updates/recovered_data.json",
            ]:
                cleanup_blob = self.bucket.blob(cleanup_file)
                if cleanup_blob.exists():
                    cleanup_blob.delete()
                    print(f"   Deleted: {cleanup_file}")

        except Exception as e:
            print(f"❌ Error in comprehensive update: {e}")

        print("\n" + "=" * 70)
        print("🎯 UPDATE OPERATIONS SUMMARY:")
        print("1. reload() → Get fresh metadata before operations")
        print("2. download_as_bytes() → Backup original content with type")
        print("3. if_generation_match → Atomic updates (prevent conflicts)")
        print("4. patch() → Update metadata without changing content")
        print("5. metadata → Add custom properties to files")
        print("6. Backup strategy → Always backup before risky operations")
        print("\n💡 BACKUP PATTERN:")
        print("backup_blob.upload_from_string(")
        print("    original_blob.download_as_bytes(),")
        print("    content_type=original_blob.content_type")
        print(")")
        print("=" * 70)

    def loaddata_with_cache_invalidation(self, blob_name=None):
        """Smart cache with ETag-based invalidation"""
        print("🔄 Checking cache validity...")

        # Initialize cache if not exists
        if not hasattr(st, "cache") or not hasattr(st, "cache_etags"):
            print("📝 No cache found, loading fresh data...")
            return self.loaddata_with_cache()

        if not st.cache:
            print("📝 Empty cache, loading fresh data...")
            return self.loaddata_with_cache()

        # Get a blob to check (first one if not specified)
        check_blob_name = blob_name or next(iter(st.cache.keys()))
        print(f"🔍 Checking ETag for: {check_blob_name}")

        # Get fresh ETag from GCS
        blob = self.bucket.blob(check_blob_name)
        blob.reload()  # Get fresh metadata
        current_etag = blob.etag

        # Compare with cached ETag
        cached_etag = st.cache_etags.get(check_blob_name)

        print(f"   Current ETag: {current_etag}")
        print(f"   Cached ETag:  {cached_etag}")

        if current_etag != cached_etag:
            print("🚨 Cache INVALID - ETag changed! Refreshing...")
            st.cache.clear()
            st.cache_etags.clear()
            return self.loaddata_with_cache()

        print("✅ Cache VALID - using cached data")
        return st.cache

    def loaddata_with_cache(self):
        """Load all blob data with ETag tracking for cache invalidation"""
        print("📥 Loading fresh data from GCS...")

        # Initialize cache structures
        if not hasattr(st, "cache"):
            st.cache = {}
        if not hasattr(st, "cache_etags"):
            st.cache_etags = {}

        blobs = self.client.list_blobs(self.bucket.name)
        loaded_count = 0

        for blob in blobs:
            if blob.name not in st.cache:
                try:
                    blob.reload()  # Get fresh metadata including ETag

                    # Download content and store ETag
                    st.cache[blob.name] = blob.download_as_text()
                    st.cache_etags[blob.name] = blob.etag

                    loaded_count += 1
                    print(f"   ✅ Loaded: {blob.name} (ETag: {blob.etag})")

                except Exception as e:
                    print(f"   ❌ Failed to load {blob.name}: {e}")

        print(f"📊 Cache loaded: {loaded_count} new files, {len(st.cache)} total")
        return st.cache


if __name__ == "__main__":
    test = Testing()
    test.list_blobs
