import os
from google.cloud import speech
from io import BytesIO


class SimpleSTTService:
    def __init__(self):
        self.client = speech.SpeechClient()

    def transcribe_audio_bytes(self, audio_input, language_code="en-US"):
        try:
            # Handle both AudioSegment and bytes input
            audio_bytes = self._convert_to_bytes(audio_input)

            # Configure recognition settings for short audio (up to 1 minute)
            # Optimized for audiorecorder which provides various formats
            config = speech.RecognitionConfig(
                encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
                sample_rate_hertz=16000,  # Fixed 16kHz for Google Cloud Speech
                audio_channel_count=1,  # Mono audio for Google Cloud Speech
                language_code=language_code,
                model="latest_short",
                enable_automatic_punctuation=True,
            )

            # Create audio object from bytes
            audio = speech.RecognitionAudio(content=audio_bytes)

            # Perform speech recognition
            response = self.client.recognize(config=config, audio=audio)

            # Extract transcription
            if response.results:
                transcript = response.results[0].alternatives[0].transcript
                return transcript.strip()
            else:
                return ""

        except Exception as e:
            print(f"STT Error: {str(e)}")
            return ""

    def _convert_to_bytes(self, audio_input):
        """
        Convert various audio input types to bytes suitable for Google Cloud Speech API.
        Handles: AudioSegment objects, bytes, file-like objects
        """
        try:
            # Check if input is already bytes
            if isinstance(audio_input, bytes):
                print("[STT DEBUG] Input is already bytes")
                return audio_input

            # Check if input is a pydub AudioSegment
            try:
                from pydub import AudioSegment

                if isinstance(audio_input, AudioSegment):
                    print("[STT DEBUG] Converting AudioSegment to bytes")

                    # Ensure audio is in the correct format for Google Cloud Speech
                    audio_segment = audio_input

                    # Convert to 16kHz, mono, 16-bit PCM
                    audio_segment = audio_segment.set_frame_rate(
                        16000
                    )  # 16kHz sample rate
                    audio_segment = audio_segment.set_channels(1)  # Mono
                    audio_segment = audio_segment.set_sample_width(
                        2
                    )  # 16-bit (2 bytes per sample)

                    print(
                        f"[STT DEBUG] Audio format - Rate: {audio_segment.frame_rate}Hz, Channels: {audio_segment.channels}, Sample Width: {audio_segment.sample_width} bytes"
                    )

                    # Export as WAV bytes
                    wav_io = BytesIO()
                    audio_segment.export(wav_io, format="wav")
                    wav_bytes = wav_io.getvalue()

                    print(f"[STT DEBUG] Converted to WAV bytes: {len(wav_bytes)} bytes")
                    return wav_bytes

            except ImportError:
                print("[STT DEBUG] Pydub not available, treating as bytes")

            # If it's a file-like object, read it
            if hasattr(audio_input, "read"):
                print("[STT DEBUG] Reading from file-like object")
                return audio_input.read()

            # Try to convert to bytes if it's another type
            print(f"[STT DEBUG] Attempting to convert {type(audio_input)} to bytes")
            return bytes(audio_input)

        except Exception as e:
            print(f"[STT ERROR] Failed to convert audio input: {e}")
            print(f"[STT ERROR] Input type: {type(audio_input)}")
            # Return empty bytes as fallback
            return b""


stt_service = SimpleSTTService()


def transcribe_audio(audio_input, language_code="en-US"):
    """
    Transcribe audio to text using Google Cloud Speech API.

    Args:
        audio_input: Can be AudioSegment object, bytes, or file-like object
        language_code: Language code for transcription (default: "en-US")

    Returns:
        str: Transcribed text or empty string if transcription fails
    """
    return stt_service.transcribe_audio_bytes(audio_input, language_code)
