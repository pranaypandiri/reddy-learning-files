#!/usr/bin/env python3
"""
Supervisor Dashboard Module
Handles supervisor-specific UI components for user management and simulation assignment
"""

import streamlit as st
import pandas as pd
from user_simulation_manager import UserSimulationManager


@st.cache_resource
def get_user_manager():
    return UserSimulationManager()


# Cache user and assignment data to avoid repeated network calls on widget
# interactions which trigger Streamlit reruns.
@st.cache_data
def cached_users():
    manager = get_user_manager()
    return manager.load_users()


@st.cache_data
def cached_assignments():
    manager = get_user_manager()
    return manager.get_all_simulation_assignments()


def render_user_management_tab():
    """Render the User Management tab for supervisors"""
    st.markdown("### 👤 Add New Associate")

    user_manager = get_user_manager()

    # Reset counter for clearing form inputs safely
    if "add_user_form_reset" not in st.session_state:
        st.session_state["add_user_form_reset"] = 0

    with st.form("add_user_form"):
        col1, col2 = st.columns(2)

        with col1:
            new_username = st.text_input(
                "Associate Name",
                placeholder="Enter associate name",
                help="Enter the full name of the new associate",
                key=f"new_username_{st.session_state['add_user_form_reset']}",
            )

        with col2:
            new_password = st.text_input(
                "Password",
                type="password",
                placeholder="Enter password",
                help="Set a secure password for the associate",
                key=f"new_password_{st.session_state['add_user_form_reset']}",
            )

        submitted = st.form_submit_button("➕ Add Associate", type="primary")

    if submitted:
        if new_username and new_password:
            success, message = user_manager.add_new_user(new_username, new_password)
            if success:
                # Invalidate cached users so UI updates without stale data
                try:
                    cached_users.clear()
                except Exception:
                    pass
                st.success(f"✅ {message}")
                # Bump reset counter to clear inputs on next render
                st.session_state["add_user_form_reset"] += 1
                st.rerun()  # Refresh to show updated table
            else:
                st.error(f"❌ {message}")
        else:
            st.error("⚠️ Please fill in both username and password")

    st.markdown("---")
    st.markdown("### 📋 Current Associates")

    # Display current users
    users = cached_users()
    associates = {k: v for k, v in users.items() if v.get("role") == "trainee"}

    if associates:
        associates_df = pd.DataFrame(
            [
                {
                    "Associate Name": username,
                    "Role": data["role"].title(),
                    "Status": "Active",
                }
                for username, data in associates.items()
            ]
        )

        st.dataframe(associates_df, use_container_width=True, hide_index=True)

        st.info(f"📊 Total Associates: {len(associates)}")
    else:
        st.info("👥 No associates found. Add your first associate above!")


def render_simulation_assignment_tab():
    """Render the Simulation Assignment tab for supervisors"""
    st.markdown("### 📋 Assign Simulation to Associate")

    # Cache user manager to avoid recreating

    user_manager = get_user_manager()

    # Reset counter for clearing assignment dropdowns safely
    if "assign_form_reset" not in st.session_state:
        st.session_state["assign_form_reset"] = 0

    # Load associates for dropdown
    users = cached_users()
    associates = [
        username for username, data in users.items() if data.get("role") == "trainee"
    ]

    if not associates:
        st.warning(
            "⚠️ No associates found. Please add associates first in the User Management tab."
        )
        return

    # Static mapping - no FAISS loading needed for simple filtering
    dept_theme_map = {
        "Airlines": [
            "buy miles",
            "earn credit",
            "account changes",
            "premier status",
            "missing credit",
            "upgrades",
            "use miles",
        ],
    }

    all_departments = ["Airlines"]

    # Simple fast filtering - no complex loading
    col1, col2 = st.columns(2)
    with col1:
        selected_associate = st.selectbox(
            "Select Associate:",
            [""] + associates,
            key=f"associate_select_{st.session_state['assign_form_reset']}",
        )

        selected_industry = st.selectbox(
            "Select Industry:",
            [""] + all_departments,
            key=f"industry_select_{st.session_state['assign_form_reset']}",
        )

    with col2:
        # Simple filter: show themes based on selected industry
        if selected_industry and selected_industry in dept_theme_map:
            available_themes = dept_theme_map[selected_industry]
        else:
            available_themes = []

        selected_theme = st.selectbox(
            "Select Reason for Contact:",
            [""] + available_themes,
            key=f"theme_select_{st.session_state['assign_form_reset']}",
        )

        selected_tone = st.selectbox(
            "Select Customer Tone:",
            ["", "General", "Angry"],
            key=f"tone_select_{st.session_state['assign_form_reset']}",
        )

    # Submit button outside form for immediate response
    assign_submitted = st.button("📋 Assign Simulation", type="primary")

    if assign_submitted:
        if all([selected_associate, selected_industry, selected_theme, selected_tone]):
            success, message = user_manager.assign_simulation(
                selected_associate, selected_industry, selected_theme, selected_tone
            )
            if success:
                # Invalidate cached assignments so table refreshes quickly
                try:
                    cached_assignments.clear()
                except Exception:
                    pass
                st.success(f"✅ {message}")
                # Bump reset counter to clear selects on next render
                st.session_state["assign_form_reset"] += 1
                st.rerun()  # Refresh to show updated table
            else:
                st.error(f"❌ {message}")
        else:
            st.error("⚠️ Please fill in all fields")

    st.markdown("---")
    st.markdown("### 📊 Associate Simulation Assignments")

    # Display simulation assignments in a table (cached)
    assignments = cached_assignments()

    if assignments:
        assignments_df = pd.DataFrame(assignments)

        # Style the dataframe
        st.dataframe(assignments_df, use_container_width=True, hide_index=True)

        st.info(f"📈 Total Simulations Assigned: {len(assignments)}")

        # Show summary by associate
        if len(assignments) > 0:
            summary = (
                assignments_df.groupby("Associate")
                .size()
                .reset_index(name="Simulations Assigned")
            )

            with st.expander("📊 Assignment Summary by Associate"):
                st.dataframe(summary, use_container_width=True, hide_index=True)
    else:
        st.info("📝 No simulations assigned yet. Assign your first simulation above!")


def render_supervisor_dashboard():
    """Main supervisor dashboard with all tabs"""
    st.title("📊 Supervisor Dashboard")
    st.markdown("Monitor trainee performance and manage simulations")

    # Main dashboard tabs
    tab1, tab2, tab3, tab4, tab5 = st.tabs(
        [
            "👤 User Management",
            "📋 Simulation Assignment",
            "👥 Individual Performance",
            "📊 Comparative Analysis",
            "📋 Detailed Reports",
        ]
    )

    with tab1:
        render_user_management_tab()

    with tab2:
        render_simulation_assignment_tab()

    with tab3:
        st.info("Individual Performance tab - existing functionality will be preserved")

    with tab4:
        st.info("Comparative Analysis tab - existing functionality will be preserved")

    with tab5:
        st.info("Detailed Reports tab - existing functionality will be preserved")
