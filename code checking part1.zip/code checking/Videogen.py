import requests
import streamlit as st
import json
from typing import List, Dict


class ContentSearcher:
    def __init__(self):
        self.cse_id = "22deb800308eb4603"
        self.api_key = "AIzaSyBl2h-JKCGiq63SA2YOvSTo3MwYSQoPNNA"
        self.base_url = "https://www.googleapis.com/customsearch/v1"

        self.keywords = {
            "Danger Content": "Harmful content",
            "Child Abuse": "child abuse",
        }

    def search_google_cse(self, query: str, num_results: int = 10) -> List[Dict]:
        params = {
            "key": self.api_key,
            "cx": self.cse_id,
            "q": query,
            "num": num_results,
        }

        try:
            response = requests.get(self.base_url, params=params)
            response.raise_for_status()

            data = response.json()

            results = []
            print(data)
            if "items" in data:
                for item in data["items"]:
                    results.append(
                        {
                            "title": item.get("title", ""),
                            "url": item.get("link", ""),
                            "snippet": item.get("snippet", ""),
                        }
                    )

            return results

        except requests.exceptions.RequestException as e:
            st.error(f"Error making API request: {e}")
            return []
        except json.JSONDecodeError as e:
            st.error(f"Error parsing response: {e}")
            return []
        except Exception as e:
            st.error(f"Unexpected error: {e}")
            return []


def main():
    st.set_page_config(page_title="Content Search Tool", page_icon="🔍", layout="wide")

    st.title("🔍 Content Search Tool")
    st.markdown("Search for YouTube URLs based on selected content categories")

    # Initialize the searcher
    searcher = ContentSearcher()

    # Create dropdown for category selection
    st.subheader("Category Selection")
    category = st.selectbox(
        "Select Content Category:",
        ["", "Danger Content", "Child Abuse"],
        help="Choose the type of content you want to search for",
    )

    # Search button and results
    if category:
        st.markdown("---")

        if st.button(
            "🔍 Search for YouTube URLs", type="primary", use_container_width=True
        ):
            keyword = searcher.keywords[category]
            with st.spinner(f"Searching for '{keyword}' videos..."):
                results = searcher.search_google_cse(keyword)

            if results:
                st.success(f"Found {len(results)} YouTube results for '{keyword}'")

                # Display results
                st.subheader("📋 YouTube Search Results")

                for i, result in enumerate(results, 1):
                    with st.expander(f"Result {i}: {result['title'][:60]}..."):
                        st.markdown(f"**Title:** {result['title']}")
                        st.markdown(f"**URL:** [{result['url']}]({result['url']})")
                        if result["snippet"]:
                            st.markdown(f"**Description:** {result['snippet']}")

                        # Copy URL button
                        st.code(result["url"], language=None)
            else:
                st.warning("No YouTube results found. Please try again later.")
    else:
        st.info("Please select a category to get started.")

    # Footer
    st.markdown("---")
    st.markdown(
        "*This tool uses Google Custom Search Engine to find YouTube URLs based on your category selection.*"
    )


if __name__ == "__main__":
    main()
