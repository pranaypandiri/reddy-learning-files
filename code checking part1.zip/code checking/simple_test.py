#!/usr/bin/env python3
"""
Simple test script to print Associate21 behavior analysis
"""

import sys
import os
import json
import base64
from io import BytesIO
import openpyxl


def analyze_associate21():
    """Simple analysis for Associate21 - just print results"""

    print("\n🔍 ASSOCIATE21 BEHAVIOR ANALYSIS")
    print("=" * 50)

    # For now, let's create a simple mock analysis
    # In a real scenario, you'd load from your actual data source

    print("📊 Mock Analysis Results:")
    print("-" * 30)

    # Mock session data
    sessions = [
        {
            "session": 1,
            "date": "2024-01-15",
            "overall_score": "75%",
            "behaviors": [
                {"name": "Active Listening", "score": 6.5, "max": 8.0, "percent": 81.3},
                {"name": "Problem Solving", "score": 4.2, "max": 7.0, "percent": 60.0},
                {"name": "Communication", "score": 3.1, "max": 6.0, "percent": 51.7},
                {"name": "Empathy", "score": 7.2, "max": 9.0, "percent": 80.0},
            ],
        },
        {
            "session": 2,
            "date": "2024-01-20",
            "overall_score": "68%",
            "behaviors": [
                {"name": "Active Listening", "score": 5.8, "max": 8.0, "percent": 72.5},
                {"name": "Problem Solving", "score": 3.9, "max": 7.0, "percent": 55.7},
                {"name": "Communication", "score": 2.8, "max": 6.0, "percent": 46.7},
                {"name": "Empathy", "score": 6.9, "max": 9.0, "percent": 76.7},
            ],
        },
    ]

    # Print session-by-session analysis
    for session in sessions:
        print(f"\n📋 SESSION {session['session']}")
        print(f"Date: {session['date']}")
        print(f"Overall Score: {session['overall_score']}")
        print(f"\n🎯 Behavior Breakdown:")
        print(f"{'Behavior':<20} {'Score':<8} {'Max':<6} {'%':<8} {'Status'}")
        print("-" * 50)

        for behavior in session["behaviors"]:
            # Categorize
            if behavior["percent"] < 60:
                status = "🔴 Weak"
            elif behavior["percent"] >= 80:
                status = "🟢 Good"
            else:
                status = "🟡 Moderate"

            print(
                f"{behavior['name']:<20} {behavior['score']:<8.1f} {behavior['max']:<6.1f} {behavior['percent']:<8.1f} {status}"
            )

    # Summary across all sessions
    print(f"\n📈 SUMMARY ACROSS {len(sessions)} SESSIONS")
    print("=" * 50)

    # Calculate averages
    all_behaviors = {}
    for session in sessions:
        for behavior in session["behaviors"]:
            name = behavior["name"]
            if name not in all_behaviors:
                all_behaviors[name] = {"scores": [], "maxes": []}
            all_behaviors[name]["scores"].append(behavior["score"])
            all_behaviors[name]["maxes"].append(behavior["max"])

    print(f"\n🎯 Average Performance per Behavior:")
    print(f"{'Behavior':<20} {'Avg Score':<12} {'Avg Max':<10} {'Avg %':<8} {'Status'}")
    print("-" * 60)

    total_percentage = 0
    behavior_count = 0
    weak_count = 0
    moderate_count = 0
    good_count = 0

    for name, data in all_behaviors.items():
        avg_score = sum(data["scores"]) / len(data["scores"])
        avg_max = sum(data["maxes"]) / len(data["maxes"])
        avg_percentage = (avg_score / avg_max) * 100 if avg_max > 0 else 0

        # Categorize
        if avg_percentage < 60:
            status = "🔴 Weak"
            weak_count += 1
        elif avg_percentage >= 80:
            status = "🟢 Good"
            good_count += 1
        else:
            status = "🟡 Moderate"
            moderate_count += 1

        print(
            f"{name:<20} {avg_score:<12.1f} {avg_max:<10.1f} {avg_percentage:<8.1f} {status}"
        )

        total_percentage += avg_percentage
        behavior_count += 1

    overall_avg = total_percentage / behavior_count if behavior_count > 0 else 0
    print(f"\n🎯 Overall Average Performance: {overall_avg:.1f}%")

    print(f"\n📊 Category Distribution:")
    print(f"🟢 Good (≥80%): {good_count} behaviors")
    print(f"🟡 Moderate (60-79%): {moderate_count} behaviors")
    print(f"🔴 Weak (<60%): {weak_count} behaviors")

    print(f"\n✅ Analysis Complete!")


if __name__ == "__main__":
    analyze_associate21()
