#!/usr/bin/env python3
"""
User and Simulation Management Module
Handles user creation, simulation assignment, and management for AI Cus        success, message = self.save_simulations(simulations)

        if success:
            return True, f"Simulation assigned successfully to {username}" Support Trainer
"""

import json
from datetime import datetime
from gcsstorageunited import get_gcs_storage_manager


class UserSimulationManager:
    """
    Manages user accounts and simulation assignments using GCS bucket storage
    """

    def __init__(self):
        self.gcs_manager = get_gcs_storage_manager()

    def load_users(self):
        """Load users from GCS bucket"""
        try:
            if self.gcs_manager.is_connected():
                users_data = self.gcs_manager.load_json_file("users.json")
                if users_data:
                    return users_data

            return self._get_fallback_users()
        except Exception as e:
            print(f"[ERROR] Failed to load users: {e}")
            # Return fallback users even on error
            return self._get_fallback_users()

    def _get_fallback_users(self):
        """Get fallback users when GCS is unavailable"""
        return {
            "Associate1": {"password": "pass1", "role": "trainee"},
            "Associate2": {"password": "pass2", "role": "trainee"},
            "Associate3": {"password": "pass3", "role": "trainee"},
            "Associate4": {"password": "pass4", "role": "trainee"},
            "Associate5": {"password": "pass5", "role": "trainee"},
            "Supervisor": {"password": "admin", "role": "trainer"},
        }

    def save_users(self, users_data):
        """Save users to GCS bucket"""
        try:
            if self.gcs_manager.is_connected():
                success, message = self.gcs_manager.save_json_file(
                    "users.json", users_data
                )
                if success:
                    return success, message
            return False, "GCS not connected"
        except Exception as e:
            print(f"[ERROR] Failed to save users: {e}")
            return False, str(e)

    def load_simulations(self):
        """Load simulation assignments from GCS bucket"""
        try:
            if self.gcs_manager.is_connected():
                sims_data = self.gcs_manager.load_json_file("simulations.json")
                if sims_data:
                    return sims_data
            return {}
        except Exception as e:
            print(f"[ERROR] Failed to load simulations: {e}")
            return {}

    def save_simulations(self, simulations_data):
        """Save simulation assignments to GCS bucket"""
        try:
            if self.gcs_manager.is_connected():
                success, message = self.gcs_manager.save_json_file(
                    "simulations.json", simulations_data
                )
                return success, message
            return False, "GCS not connected"
        except Exception as e:
            print(f"[ERROR] Failed to save simulations: {e}")
            return False, str(e)

    def add_new_user(self, username, password):
        """Add a new user to the system"""
        if not username or not password:
            return False, "Username and password are required"

        users = self.load_users()
        if username in users:
            return False, "User already exists"

        users[username] = {"password": password, "role": "trainee"}
        success, message = self.save_users(users)

        if success:
            return True, f"User {username} added successfully"
        else:
            return False, f"Failed to save user: {message}"

    def assign_simulation(self, username, industry, theme, tone):
        """Assign a simulation to a user"""
        if not all([username, industry, theme, tone]):
            return False, "All fields are required"

        simulations = self.load_simulations()

        if username not in simulations:
            simulations[username] = []

        # Normalize for duplicate comparison (remove extra spaces, lowercase)
        def _norm(s: str) -> str:
            return " ".join(str(s).lower().split())

        # Generate unique simulation ID
        sim_id = f"sim_{len(simulations[username]) + 1:03d}"

        # Create simulation string in format: "Industry - Theme - Tone"
        simulation_string = f"{industry} - {theme} - {tone}"

        # Block duplicates: if same Industry-Theme-Tone already assigned to this user
        existing = simulations.get(username, [])
        if any(
            _norm(entry.get("simulation", "")) == _norm(simulation_string)
            for entry in existing
        ):
            return False, f"Simulation already assigned to {username}"

        new_simulation = {
            "id": sim_id,
            "simulation": simulation_string,
            "industry": industry,
            "theme": theme,
            "tone": tone,
            # Use numeric sessions_completed counter starting at 0
            "sessions_completed": 0,
            "assigned_date": datetime.now().strftime("%Y-%m-%d"),
        }

        simulations[username].append(new_simulation)
        success, message = self.save_simulations(simulations)

        if success:
            return True, f"Simulation assigned to {username}"
        else:
            return False, f"Failed to assign simulation: {message}"

    def get_user_simulations(self, username):
        """Get all simulations assigned to a user"""
        simulations = self.load_simulations()
        user_sims = simulations.get(username, [])
        return user_sims

    def get_all_simulation_assignments(self):
        """Get all simulation assignments for supervisor dashboard table"""
        simulations = self.load_simulations()
        assignments = []

        for username, user_sims in simulations.items():
            for sim in user_sims:
                assignments.append(
                    {
                        "Associate": username,
                        "Simulation": sim[
                            "simulation"
                        ],  # Format: "Industry - Theme - Tone"
                        "Sessions Completed": int(sim.get("sessions_completed", 0)),
                        "Assigned Date": sim["assigned_date"],
                    }
                )

        return assignments

    def get_user_simulation_assignments(self, username):
        """Get simulation assignments for a specific user"""
        simulations = self.load_simulations()
        user_assignments = []

        if username in simulations:
            for sim in simulations[username]:
                user_assignments.append(
                    {
                        "simulation": sim["simulation"],
                        "sessions_completed": int(sim.get("sessions_completed", 0)),
                        "assigned_date": sim["assigned_date"],
                    }
                )

        return user_assignments

    def parse_simulation_string(self, simulation_string):
        """Parse simulation string format: 'Industry - Theme - Tone' back to components"""
        try:
            parts = simulation_string.split(" - ")
            if len(parts) == 3:
                return {
                    "industry": parts[0].strip(),
                    "theme": parts[1].strip(),
                    "tone": parts[2].strip(),
                }
            else:
                print(f"[ERROR] Invalid simulation format: {simulation_string}")
                return None
        except Exception as e:
            print(f"[ERROR] Failed to parse simulation string: {e}")
            return None

    def mark_assignment_completed(
        self, username: str, simulation_identifier: str
    ) -> bool:

        try:
            simulations = self.load_simulations() or {}
            user_entries = simulations.get(username, [])
            if not user_entries:
                print(f"[WARN] No assignments found for {username}")
                return False

            target = str(simulation_identifier).strip()

            def _norm(s: str) -> str:
                return " ".join(str(s).lower().split())

            updated = False
            for entry in user_entries:
                id_match = str(entry.get("id", "")).strip() == target
                sim_match = _norm(entry.get("simulation", "")) == _norm(target)
                if id_match or sim_match:
                    current = int(entry.get("sessions_completed", 0) or 0)
                    entry["sessions_completed"] = current + 1
                    updated = True
                    break

            if not updated:
                print(
                    f"[WARN] No matching assignment for {username} using '{simulation_identifier}'"
                )
                return False

            simulations[username] = user_entries
            success, message = self.save_simulations(simulations)
            return success
        except Exception as e:
            print(f"[ERROR] mark_assignment_completed failed: {e}")
            return False
