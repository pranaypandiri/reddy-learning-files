#!/usr/bin/env python3
"""
Simple test script to analyze associate behavior results
Just prints the results in terminal logs
"""

import sys
import os
import json
from io import BytesIO
import openpyxl
from google.cloud import storage


def get_gcs_client():
    """Get GCS client"""
    try:
        return storage.Client()
    except Exception as e:
        print(f"❌ Error connecting to GCS: {e}")
        return None


def load_evaluations_from_gcs():
    """Load evaluation data directly from GCS"""
    try:
        client = get_gcs_client()
        if not client:
            return []

        bucket = client.bucket("evaluations-data-bucket")
        blobs = bucket.list_blobs(prefix="evaluations/")

        evaluations = []
        for blob in blobs:
            if blob.name.endswith(".json"):
                try:
                    content = blob.download_as_text()
                    eval_data = json.loads(content)
                    evaluations.append(eval_data)
                except Exception:
                    continue

        return evaluations
    except Exception as e:
        print(f"❌ Error loading from GCS: {e}")
        return []


def analyze_associate_sessions(associate_name):
    """Analyze behavior results for an associate across all sessions"""

    print(f"\n🔍 Analyzing behavior results for Associate: {associate_name}")
    print("=" * 60)

    # Get GCS manager and load data
    gcs_manager = get_gcs_storage_manager()
    all_evaluations = gcs_manager.load_all_evaluations_for_analytics()

    if not all_evaluations:
        print("❌ No evaluation data found!")
        return

    # Filter data for the specific associate
    associate_data = [
        eval_data
        for eval_data in all_evaluations
        if eval_data.get("username") == associate_name
    ]

    if not associate_data:
        print(f"❌ No evaluation data found for associate '{associate_name}'")
        print(
            f"Available associates: {list(set([d.get('username', 'Unknown') for d in all_evaluations]))}"
        )
        return

    print(f"📊 Found {len(associate_data)} evaluation sessions")
    print("-" * 60)

    # Analyze each session
    for i, session in enumerate(associate_data, 1):
        print(f"\n📋 SESSION {i}")
        print(f"Date: {session.get('timestamp', 'N/A')}")
        print(f"Department: {session.get('department', 'N/A')}")
        print(f"Issue Type: {session.get('issue_type', 'N/A')}")
        print(f"Tone: {session.get('tone', 'N/A')}")
        print(f"Overall Score: {session.get('eval_score', 'N/A')}%")

        # Analyze behavior details from Excel
        excel_bytes = session.get("excel_bytes")
        if excel_bytes:
            try:
                with BytesIO(excel_bytes) as io:
                    wb = openpyxl.load_workbook(io, data_only=True)
                    if "Evaluation Table" in wb.sheetnames:
                        ws = wb["Evaluation Table"]

                        print("\n🎯 Behavior Breakdown:")
                        print(
                            f"{'Behavior':<30} {'Score':<8} {'Max':<6} {'%':<8} {'Status'}"
                        )
                        print("-" * 60)

                        for row in ws.iter_rows(min_row=2, values_only=True):
                            if len(row) >= 4:
                                behavior, _, max_score, score = row[:4]
                                try:
                                    score = float(score)
                                    max_score = float(max_score)
                                    percentage = (
                                        (score / max_score) * 100
                                        if max_score > 0
                                        else 0
                                    )

                                    # Categorize
                                    if percentage < 60:
                                        status = "🔴 Weak"
                                    elif percentage >= 80:
                                        status = "🟢 Good"
                                    else:
                                        status = "🟡 Moderate"

                                    print(
                                        f"{behavior[:29]:<30} {score:<8.1f} {max_score:<6.1f} {percentage:<8.1f} {status}"
                                    )

                                except (ValueError, TypeError):
                                    continue
                    else:
                        print("❌ No 'Evaluation Table' sheet found in Excel file")

            except Exception as e:
                print(f"❌ Error reading Excel data: {str(e)}")
        else:
            print("❌ No Excel data found for this session")

    # Summary across all sessions
    print(f"\n📈 SUMMARY ACROSS ALL {len(associate_data)} SESSIONS")
    print("=" * 60)

    # Aggregate behavior data
    behavior_totals = {}
    behavior_counts = {}
    behavior_max_totals = {}

    for session in associate_data:
        excel_bytes = session.get("excel_bytes")
        if excel_bytes:
            try:
                with BytesIO(excel_bytes) as io:
                    wb = openpyxl.load_workbook(io, data_only=True)
                    if "Evaluation Table" in wb.sheetnames:
                        ws = wb["Evaluation Table"]
                        for row in ws.iter_rows(min_row=2, values_only=True):
                            if len(row) >= 4:
                                behavior, _, max_score, score = row[:4]
                                try:
                                    score = float(score)
                                    max_score = float(max_score)
                                    if behavior:
                                        behavior_totals[behavior] = (
                                            behavior_totals.get(behavior, 0) + score
                                        )
                                        behavior_counts[behavior] = (
                                            behavior_counts.get(behavior, 0) + 1
                                        )
                                        behavior_max_totals[behavior] = (
                                            behavior_max_totals.get(behavior, 0)
                                            + max_score
                                        )
                                except (ValueError, TypeError):
                                    continue
            except Exception:
                continue

    if behavior_totals:
        print(f"\n🎯 Average Performance per Behavior:")
        print(
            f"{'Behavior':<30} {'Avg Score':<12} {'Avg Max':<10} {'Avg %':<8} {'Sessions':<8} {'Status'}"
        )
        print("-" * 80)

        total_percentage = 0
        behavior_count = 0

        for behavior in behavior_totals.keys():
            avg_score = behavior_totals[behavior] / behavior_counts[behavior]
            avg_max = behavior_max_totals[behavior] / behavior_counts[behavior]
            avg_percentage = (avg_score / avg_max) * 100 if avg_max > 0 else 0
            sessions = behavior_counts[behavior]

            # Categorize
            if avg_percentage < 60:
                status = "🔴 Weak"
            elif avg_percentage >= 80:
                status = "🟢 Good"
            else:
                status = "🟡 Moderate"

            print(
                f"{behavior[:29]:<30} {avg_score:<12.1f} {avg_max:<10.1f} {avg_percentage:<8.1f} {sessions:<8} {status}"
            )

            total_percentage += avg_percentage
            behavior_count += 1

        overall_avg = total_percentage / behavior_count if behavior_count > 0 else 0
        print(f"\n🎯 Overall Average Performance: {overall_avg:.1f}%")

        # Count categories
        weak_count = sum(
            1
            for behavior in behavior_totals.keys()
            if (behavior_totals[behavior] / behavior_counts[behavior])
            / (behavior_max_totals[behavior] / behavior_counts[behavior])
            * 100
            < 60
        )

        good_count = sum(
            1
            for behavior in behavior_totals.keys()
            if (behavior_totals[behavior] / behavior_counts[behavior])
            / (behavior_max_totals[behavior] / behavior_counts[behavior])
            * 100
            >= 80
        )

        moderate_count = behavior_count - weak_count - good_count

        print(f"\n📊 Category Distribution:")
        print(f"🟢 Good (≥80%): {good_count} behaviors")
        print(f"🟡 Moderate (60-79%): {moderate_count} behaviors")
        print(f"🔴 Weak (<60%): {weak_count} behaviors")


def main():
    if len(sys.argv) != 2:
        print("Usage: python test_associate_behavior.py <associate_name>")
        print('Example: python test_associate_behavior.py "21"')
        return

    associate_name = sys.argv[1]
    analyze_associate_sessions(associate_name)


if __name__ == "__main__":
    main()
