


# import pandas as pd
# from io import BytesIO
# import seaborn as sns
# from collections import defaultdict
# import matplotlib.pyplot as plt
# import numpy as np
# import openpyxl
# import streamlit as st
# import os
# from langchain.memory import ConversationBufferMemory
# from langchain.schema import HumanMessage, AIMessage, SystemMessage
# from langchain_community.vectorstores import FAISS
# from langchain_core.runnables import chain
# from langchain_openai import AzureOpenAIEmbeddings
# from langchain_core.documents import Document
# from openai import AzureOpenAI as OpenAIAzureClient
# from langchain_community.vectorstores import FAISS as EvalFAISS
# from langchain_openai import AzureOpenAIEmbeddings as EvalEmbeddings
# import re
# from datetime import datetime
# from gcs_storage_manager import get_gcs_storage_manager
# import tiktoken


# # Simple token counting for GPT-4.1


# # Import our new modules
# from user_simulation_manager import UserSimulationManager
# from supervisor_dashboard import (
#     render_user_management_tab,
#     render_simulation_assignment_tab,
# )


# # Helper function to format eval scores consistently
# def format_eval_score(score):
#     """Format eval score to ensure consistent display without double %"""
#     if isinstance(score, str):
#         # Remove existing % if present and convert to float
#         clean_score = score.replace("%", "").strip()
#         try:
#             return float(clean_score)
#         except ValueError:
#             return 0.0
#     elif isinstance(score, (int, float)):
#         return float(score)
#     else:
#         return 0.0


# # Initialize the user simulation manager
# user_sim_manager = UserSimulationManager()


# # --- SUPERVISOR ASSIGNMENTS CACHING ---
# @st.cache_data
# def cached_supervisor_assignments(username):
#     """Return supervisor assignments for a specific user (cached)."""
#     if not username:
#         return []
#     try:
#         assignments = user_sim_manager.get_user_simulation_assignments(username)
#         return [assignment["simulation"] for assignment in assignments]
#     except Exception:
#         return []


# # --- FAISS DB Caching ---
# @st.cache_resource
# def get_faiss_db():
#     embeddings = CustomerSupportTrainer.OAI_embedder()
#     db = FAISS.load_local(
#         "/Users/ge20425940/Downloads/ImageToQueryLLM/code checking/faiss_store_hierarchical_new",
#         embeddings,
#         allow_dangerous_deserialization=True,
#     )

#     # 🔍 DEBUG: Show ALL available examples in vector store
#     print(f"[DEBUG] " + "=" * 80)
#     print(f"[DEBUG] 📚 TOTAL EXAMPLES IN VECTOR STORE: {len(db.docstore._dict)}")
#     print(f"[DEBUG] " + "=" * 80)

#     # Show ALL examples with full content and metadata
#     for i, (doc_id, doc) in enumerate(db.docstore._dict.items(), 1):
#         print(f"[DEBUG] 📄 EXAMPLE {i} (ID: {doc_id}):")
#         print(f"[DEBUG] Metadata: {doc.metadata}")
#         print(f"[DEBUG] FULL CONTENT:")
#         print(f"[DEBUG] {doc.page_content}")
#         print(f"[DEBUG] " + "-" * 80)

#     # Show unique metadata combinations
#     departments = set()
#     themes = set()
#     tones = set()

#     for doc_id, doc in db.docstore._dict.items():
#         if "department" in doc.metadata:
#             departments.add(doc.metadata["department"])
#         if "theme" in doc.metadata:
#             themes.add(doc.metadata["theme"])
#         if "tone" in doc.metadata:
#             tones.add(doc.metadata["tone"])

#     print(f"[DEBUG] 🏢 AVAILABLE DEPARTMENTS: {sorted(departments)}")
#     print(f"[DEBUG] 🎯 AVAILABLE THEMES: {sorted(themes)}")
#     print(f"[DEBUG] 😊 AVAILABLE TONES: {sorted(tones)}")
#     print(f"[DEBUG] " + "=" * 80)

#     return db


# # --- POLICY DOCUMENTS FAISS DB Caching ---
# @st.cache_resource
# def get_policy_faiss_db():
#     """Load the policy documents vector store created by EmbeddingSequentialChunking.py"""
#     embeddings = CustomerSupportTrainer.OAI_embedder()
#     try:
#         policy_db = FAISS.load_local(
#             "faiss_store_policy_chunks_clean_version2",
#             embeddings,
#             allow_dangerous_deserialization=True,
#         )
#         print(
#             f"[DEBUG] Loaded policy documents vector store with {len(policy_db.docstore._dict)} documents"
#         )

#         # Debug: Show available themes in the policy database
#         available_themes = set()
#         for doc_id, doc in policy_db.docstore._dict.items():
#             theme = doc.metadata.get("theme", "Unknown")
#             available_themes.add(theme)
#         print(
#             f"[DEBUG] Available themes in policy database: {sorted(available_themes)}"
#         )

#         return policy_db
#     except Exception as e:
#         print(f"[ERROR] Could not load policy documents vector store: {e}")
#         print("[INFO] Using fallback - regular conversation examples database")
#         return get_faiss_db()  # Fallback to regular database


# # Azure OpenAI Configuration
# client = OpenAIAzureClient(
#     api_key="92dc252cdb0c4079b4712a9ead4179ca",
#     api_version="2024-12-01-preview",
#     azure_endpoint="https://azureaitest4641590782.openai.azure.com/",
# )

# os.environ["OPENAI_API_KEY"] = "92dc252cdb0c4079b4712a9ead4179ca"


# class CustomerSupportTrainer:
#     GOODBYE_KEYWORDS = [
#         "bye",
#         "goodbye",
#         "have a nice day",
#         "alright, thanks for your help.",
#         "resolved",
#         "issue fixed",
#         "problem solved",
#         "Thanks again!",
#     ]

#     def __init__(self):
#         # Use buffer memory for context management
#         self.memory = ConversationBufferMemory(
#             memory_key="chat_history", return_messages=True
#         )
#         # Static first message - Banking fraud scenario
#         # self.initial_customer_message = """
#         # Hi, I need help. After the latest Windows update, my store computer has become very slow and it's affecting checkout. Can you help me fix this?
#         # """
#         self.examples = []
#         # Conversation started flag
#         self.phase_switched = False
#         self.conversation_started = False

#     def load_examples_from_excels(self, excel_paths, group_size=15):

#         examples = []
#         for path in excel_paths:
#             df = pd.read_excel(path, header=None)
#             rows = df.values.tolist()
#             for i in range(0, len(rows), group_size):
#                 group = rows[i : i + group_size]
#                 convo = ""
#                 for agent, customer in group:
#                     if agent and customer:
#                         convo += f"Support Rep: {str(agent).strip()}\nCustomer: {str(customer).strip()}\n"
#                 if convo.strip():
#                     examples.append(convo.strip())
#         self.examples = examples

#     def retrieve_examples(self, db, query, department, theme, tone, k=5):

#         # Normalize filter values
#         norm_department = (
#             department.strip().lower()
#             if isinstance(department, str) and department
#             else ""
#         )
#         # norm_theme = theme.strip().lower() if isinstance(theme, str) and theme else ""
#         norm_tone = tone.strip().lower() if isinstance(tone, str) and tone else ""

#         # 🔧 FIX: Handle database inconsistencies and typos
#         # Map common variations to database values
#         # theme_mapping = {
#         #     "cancel flight": "cancelfilght",  # Fix typo in database
#         #     "flight booking": "flight booking",  # Keep as is
#         #     "rebooking": "rebooking",  # Keep as is
#         #     "re-booking": "rebooking",  # Map variation
#         # }

#         # # Apply theme mapping if found
#         # if norm_theme in theme_mapping:
#         #     mapped_theme = theme_mapping[norm_theme]
#         #     norm_theme = mapped_theme

#         filters = {
#             "department": norm_department,
#             "theme": theme,
#             "tone": norm_tone,
#         }

#         print(f"[DEBUG] 🔎 FILTER VALUES PASSED TO similarity_search: {filters}")

#         docs = db.similarity_search(query, k=k, filter=filters)

#         # Fallback: If no exact matches, try broader search
#         if len(docs) == 0:
#             # Try without theme filter (department + tone only)
#             return []
#         else:
#             examples = [doc.page_content for doc in docs]
#         return examples

#     @staticmethod
#     def get_department_theme_map(db):
#         dept_theme_map = {}
#         for doc in db.docstore._dict.values():
#             dept = doc.metadata.get("department")
#             theme = doc.metadata.get("theme")
#             if dept and theme:
#                 dept_theme_map.setdefault(dept, set()).add(theme)
#         # Convert sets to sorted lists
#         for dept in dept_theme_map:
#             dept_theme_map[dept] = sorted(list(dept_theme_map[dept]))
#         return dept_theme_map

#     @staticmethod
#     def OAI_embedder():
#         embedding_model = AzureOpenAIEmbeddings(
#             model="text-embedding-3-large",
#             api_key="83265f364fe844f298b2d4f8a5a39426",
#             openai_api_type="azure",
#             azure_endpoint="https://genai-demos.openai.azure.com/",
#             api_version="2024-02-15-preview",
#         )
#         return embedding_model

#     # Add this method to CustomerSupportTrainer class

#     def gen_query_cont(
#         self, support_rep_message, examples, customer_tone, theme, all_matching_docs
#     ):
#         """
#         Generate policy-based customer questions when support rep offers additional assistance
#         Uses random sampling of 4 policy chunks to create scenarios, stored in session to avoid re-creation
#         """
#         try:
#             # Get conversation history up to this point
#             memory_vars = self.memory.load_memory_variables({})
#             chat_history = memory_vars.get("chat_history", [])

#             # Build conversation history text for context
#             history_text = ""
#             for message in chat_history:
#                 if isinstance(message, HumanMessage):
#                     history_text += f"Support Rep: {message.content}\n"
#                 elif isinstance(message, AIMessage):
#                     history_text += f"Customer: {message.content}\n"

#             # Check if we already have a policy scenario stored in session for this switch
#             if "policy_switch_scenario" not in st.session_state:
#                 # Random sampling of 4 policy chunks
#                 if all_matching_docs and len(all_matching_docs) >= 4:
#                     import random

#                     selected_chunks = random.sample(all_matching_docs, 4)
#                 elif all_matching_docs:
#                     selected_chunks = all_matching_docs  # Use all if less than 4
#                 else:
#                     return "I think that covers everything I needed to know. Thank you for your help!"

#                 # Create policy context from selected chunks
#                 policy_context = ""
#                 for i, doc in enumerate(selected_chunks, 1):
#                     policy_intent = doc.metadata.get("policy_intent", "General policy")
#                     chunk_id = doc.metadata.get("chunk_id", f"chunk_{i}")
#                     policy_context += f"POLICY CHUNK {i} - {policy_intent}:\n"
#                     policy_context += f"Chunk ID: {chunk_id}\n"
#                     policy_context += f"Content: {doc.page_content}\n"
#                     policy_context += "=" * 60 + "\n"

#                 # Generate scenario based on selected policy chunks
#                 scenario_prompt = f"""
# You are tasked with creating a realistic customer question scenario based on company policy documents.

# CONTEXT:
# - Theme: {theme}
# - Customer has been offered additional assistance by support rep
# - The conversation history shows what has already been discussed and resolved

# EXISTING CONVERSATION HISTORY:
# {history_text}

# AVAILABLE POLICY CHUNKS FOR NEW SCENARIO:
# {policy_context}

# INSTRUCTIONS:
# 1. Create ONE realistic customer question/scenario based on the policy chunks above
# 2. The question must be DIFFERENT from what's already been discussed in the conversation history
# 3. Base the question on specific policy situations, rules, or procedures from the chunks
# 4. Make it something a real customer would ask about after being offered additional help
# 5. Keep it focused on the theme domain
# 6. Don't repeat or rephrase anything already resolved in the conversation

# Generate ONLY the customer scenario/question (1-2 sentences max) that would naturally come up based on the policies.
# """

#                 # Call LLM to generate scenario
#                 messages = [
#                     {
#                         "role": "system",
#                         "content": "You are an expert at creating realistic customer service scenarios based on company policies.",
#                     },
#                     {"role": "user", "content": scenario_prompt},
#                 ]

#                 # Print token count before LLM call
#                 print_token_count(messages)

#                 response = client.chat.completions.create(
#                     model="gpt-4.1",
#                     messages=messages,
#                     max_tokens=150,
#                     temperature=0.5,
#                 )

#                 generated_scenario = response.choices[0].message.content.strip()

#                 # Store in session state to avoid regeneration on streamlit reruns
#                 st.session_state.policy_switch_scenario = {
#                     "scenario": generated_scenario,
#                     "selected_chunks": selected_chunks,
#                     "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#                 }

#                 # Also update current policy session similar to gen_cus_policy_response for evaluation
#                 chunk_mapping = {}
#                 for i, doc in enumerate(selected_chunks, 1):
#                     chunk_id = doc.metadata.get("chunk_id", f"CHUNK_{i}")
#                     chunk_mapping[1] = chunk_mapping.get(1, "") + f"{chunk_id}, "

#                 # Clean up the chunk mapping (remove trailing comma)
#                 if 1 in chunk_mapping:
#                     chunk_mapping[1] = chunk_mapping[1].rstrip(", ")

#                 st.session_state.current_policy_session = {
#                     "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#                     "department": "Policy Inquiry",
#                     "theme": theme,
#                     "selected_policies": selected_chunks,
#                     "scenarios": [generated_scenario],
#                     "scenario_chunks": chunk_mapping,
#                 }

#             else:
#                 # Use existing scenario from session state
#                 generated_scenario = st.session_state.policy_switch_scenario["scenario"]
#                 selected_chunks = st.session_state.policy_switch_scenario[
#                     "selected_chunks"
#                 ]

#             # Now generate customer response using the scenario and current support rep message
#             policy_context_for_response = ""
#             for i, doc in enumerate(selected_chunks, 1):
#                 policy_intent = doc.metadata.get("policy_intent", "General policy")
#                 chunk_id = doc.metadata.get("chunk_id", f"chunk_{i}")
#                 policy_context_for_response += f"POLICY CHUNK {i} - {policy_intent}:\n"
#                 policy_context_for_response += f"Chunk ID: {chunk_id}\n"
#                 policy_context_for_response += f"Content: {doc.page_content}\n"
#                 policy_context_for_response += "=" * 60 + "\n"

#             # Generate actual customer response
#             customer_prompt = f"""
# You are an AI Assistant mimicking a customer in a support chat. Your tone should match the specified customer tone: {customer_tone}.

# SCENARIO CONTEXT:
# - Theme: {theme}
# - Customer Tone: {customer_tone}
# - Current Scenario: {generated_scenario}

# CONVERSATION HISTORY:
# {history_text}

# SUPPORT REP JUST SAID: {support_rep_message}

# POLICY CONTEXT FOR RESOLUTION ANALYSIS:
# {policy_context_for_response}

# Generate only the customer's next message (1-2 short sentences) that fits the scenario and tone.
# """

#             messages = [
#                 {
#                     "role": "system",
#                     "content": "You are a customer asking about company policies after being offered additional help.",
#                 },
#                 {"role": "user", "content": customer_prompt},
#             ]

#             # Count input tokens and print to console
#             tokens = get_token_count(messages)
#             # ...existing code...
#             print(
#                 f"Token count values: {tokens} tokens for customer response generation LLM call"
#             )

#             response = client.chat.completions.create(
#                 model="gpt-4.1",
#                 messages=messages,
#                 max_tokens=100,
#                 temperature=0.4,
#             )

#             customer_response = response.choices[0].message.content.strip()

#             return customer_response

#         except Exception as e:
#             print(f"[ERROR] Error in gen_query_cont: {str(e)}")
#             return f"Actually, I think I'm all set. Thank you for your help!"

#     def generate_customer_response(
#         self,
#         support_rep_message,
#         examples,
#         customer_tone,
#         department,
#         theme,
#         all_matching_docs,
#     ):
#         try:
#             # Get conversation history
#             memory_vars = self.memory.load_memory_variables({})
#             chat_history = memory_vars.get("chat_history", [])

#             # Modular goodbye detection
#             if self.has_conversation_ended(chat_history, support_rep_message):
#                 # Conversation ended - skip generation
#                 self.memory.save_context({"input": support_rep_message}, {"output": ""})
#                 self.conversation_started = False
#                 return None

#             history_text = ""
#             for message in chat_history:
#                 if isinstance(message, HumanMessage):
#                     history_text += f"Support Rep: {message.content}\n"
#                 elif isinstance(message, AIMessage):
#                     history_text += f"Customer: {message.content}\n"
#             examples_text = ""
#             for idx, ex in enumerate(examples, 1):
#                 examples_text += f"EXAMPLE {idx}:\n{ex}\n\n"

#             prompt = f"""
#             You are a AI Assistant in a support chat mimicking the customer.Your tone should be: {customer_tone}

#             SCENARIO:
#                 Department: {department}
#                 Theme: {theme}
#                 Customer Tone: {customer_tone}

#             EXAMPLE CONVERSATIONS (Try to follow the patterns in the generation of customer question):
#             {examples_text}

#             CONVERSATION HISTORY:
#             {history_text}

#             SUPPORT REP JUST SAID: {support_rep_message}

#             INSTRUCTIONS:
#              - Respond as a real customer would in this scenario.
#              - Strictly follow the Example Conversations and the pattern, just generate the most likely question based on the example. Otherwise, it will fail the task.
#              - If your tone is 'angry', express your dissatisfaction, but do not repeat or exaggerate anger in every sentence. And follow the Examples how they react in the angry mode.
#              - CRITICAL: Keep responses to 1-2 short sentences maximum - match the brevity shown in example conversations.
#              - CRITICAL OVERRIDE: When the current situation matches the patterns shown in these examples, follow the EXACT response pattern from the examples, ignoring any conflicting general instructions.
#              - Do NOT repeat previous questions or answers.
#              - If there is any escalation stated in the examples, please follow the same pattern.
#              - Do NOT invent hypothetical scenarios or 'what if' questions.
#              - Do NOT end the conversation unless you have already thanked the support rep and agreed to follow up later.
#              - Keep your response concise, relevant, and natural.
#              - Use the selected customer tone in your reply.
#              - Only discuss issues relevant to the selected department and theme. Do not mention unrelated problems.
#              - If the support rep has resolved your issue, said goodbye, or used any closing phrase, DO NOT generate any further customer response. End the chat immediately.
#              - If your tone is 'angry' or 'confused', do NOT ask more than one question per message, and do not exaggerate or repeat the tone in every sentence.
#              - Only say goodbye or end the conversation once. If you have already said goodbye or thanked the support rep, do not respond further, even if the support rep says goodbye again.
#              - Wait for the support rep to fully address your current concern before introducing new issues.
#              - RESOLUTION PHRASES: When the support rep has fully resolved your issue, use one of these EXACT phrases to signal satisfaction and close the conversation:
#                • "thank you, that helps"
#                • "got it, thanks" 
#                • "that makes sense, thank you"
#                • "perfect, thank you"
#                • "understood, thanks"
#                • "that clears it up"
#                • "that answers my question"
#                • "that's exactly what I needed"
#                • "appreciate the clarification, that helps"
#                • "thanks for explaining, that's clear now"
#             """

#             messages = [
#                 {
#                     "role": "system",
#                     "content": "You are a customer generating the next message in support chat.",
#                 },
#                 {"role": "user", "content": prompt},
#             ]

#             # Print token count before LLM call
#             tokens = get_token_count(messages)
#             # ...existing code...

#             response = client.chat.completions.create(
#                 model="gpt-4.1",
#                 messages=messages,
#                 max_tokens=200,
#                 temperature=0.2,
#                 top_p=0.5,
#             )

#             customer_response = response.choices[0].message.content.strip()
#             # If customer response contains any goodbye/closing, end conversation
#             if any(kw in customer_response.lower() for kw in self.GOODBYE_KEYWORDS):
#                 self.conversation_started = False

#             # Save to memory
#             self.memory.save_context(
#                 {"input": support_rep_message}, {"output": customer_response}
#             )

#             return customer_response

#         except Exception as e:
#             return f"Error generating response: {str(e)}"

#     def reset_conversation(self):
#         """Reset conversation memory and policy scenarios"""
#         # Clear LangChain memory
#         self.memory.clear()

#         # Reset all instance flags to initial state
#         self.conversation_started = False
#         self.phase_switched = False

#         # Clear all policy-related session state variables
#         if "policy_scenarios" in st.session_state:
#             st.session_state.policy_scenarios = []
#         if "current_policy_session" in st.session_state:
#             st.session_state.current_policy_session = None
#         if "policy_switch_scenario" in st.session_state:
#             del st.session_state.policy_switch_scenario

#         # Additional safety check - clear any other potential session state variables
#         session_keys_to_clear = [
#             "selected_policies",
#             "scenario_chunks",
#             "policy_context",
#             "current_scenario",
#         ]

#         for key in session_keys_to_clear:
#             if key in st.session_state:
#                 del st.session_state[key]

#         print("✅ Conversation reset complete")
#         print(
#             f"[DEBUG]   - current_policy_session: {'CLEARED' if 'current_policy_session' not in st.session_state or st.session_state.current_policy_session is None else 'NOT CLEARED'}"
#         )
#         print(
#             f"[DEBUG]   - policy_switch_scenario: {'CLEARED' if 'policy_switch_scenario' not in st.session_state else 'NOT CLEARED'}"
#         )

#     def get_conversation_history(self):
#         """Get formatted conversation history"""
#         memory_vars = self.memory.load_memory_variables({})
#         return memory_vars.get("chat_history", [])

#     def debug_memory(self):
#         """Debug method to check if summarization is happening"""
#         # Check if memory has a moving_summary_buffer attribute
#         if (
#             hasattr(self.memory, "moving_summary_buffer")
#             and self.memory.moving_summary_buffer
#         ):
#             return f"SUMMARY CREATED: {self.memory.moving_summary_buffer}"
#         else:
#             return "No summary yet"

#     def has_conversation_ended(self, chat_history, support_rep_message):
#         """Check if the conversation has ended based on goodbye keywords"""
#         # Check if support rep message contains goodbye keywords
#         if any(kw in support_rep_message.lower() for kw in self.GOODBYE_KEYWORDS):
#             return True

#         # Check if the last customer message contained goodbye keywords
#         if chat_history:
#             last_message = chat_history[-1]
#             if isinstance(last_message, AIMessage):  # Customer's last message
#                 if any(
#                     kw in last_message.content.lower() for kw in self.GOODBYE_KEYWORDS
#                 ):
#                     return True

#         return False

#     def gen_cus_policy_response(
#         self, support_rep_message, policy_docs, customer_tone, department, theme
#     ):

#         try:
#             # Get conversation history
#             memory_vars = self.memory.load_memory_variables({})
#             chat_history = memory_vars.get("chat_history", [])

#             # Modular goodbye detection
#             if self.has_conversation_ended(chat_history, support_rep_message):
#                 # Conversation ended - skip generation
#                 self.memory.save_context({"input": support_rep_message}, {"output": ""})
#                 self.conversation_started = False
#                 return None

#             # Initialize session tracking for policy scenarios if not exists
#             if "policy_scenarios" not in st.session_state:
#                 st.session_state.policy_scenarios = []
#             if "current_policy_session" not in st.session_state:
#                 st.session_state.current_policy_session = None

#             # Check if this is the first customer interaction (no scenarios exist yet)
#             # OR if we need to create scenarios for a new department/theme combination
#             need_new_scenarios = (
#                 len(st.session_state.policy_scenarios) == 0
#                 or st.session_state.current_policy_session is None
#                 or st.session_state.current_policy_session.get("department")
#                 != department
#                 or st.session_state.current_policy_session.get("theme") != theme
#             )

#             selected_policies = []
#             scenarios = []

#             if need_new_scenarios:
#                 # Creating new scenarios (logging reduced)

#                 # Select 4 random policy documents from available ones
#                 if policy_docs and len(policy_docs) > 0:
#                     import random

#                     # Pick up to 4 policies (or all if less than 4)
#                     num_to_select = min(4, len(policy_docs))
#                     selected_policies = random.sample(policy_docs, num_to_select)

#                     # Selected policies logged (reduced verbosity)

#                     # Create 2 scenario-based queries from the selected policies
#                     scenarios, scenario_chunks = self.create_policy_scenarios(
#                         selected_policies, department, theme
#                     )

#                     # Create new policy session entry
#                     st.session_state.current_policy_session = {
#                         "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#                         "department": department,
#                         "theme": theme,
#                         "selected_policies": selected_policies,  # Store full policy documents
#                         "scenarios": scenarios,
#                         "scenario_chunks": scenario_chunks,  # Store chunk mappings
#                     }

#                     # Also store in the policy_scenarios list for tracking
#                     scenario_entry = {
#                         "timestamp": st.session_state.current_policy_session[
#                             "timestamp"
#                         ],
#                         "department": department,
#                         "theme": theme,
#                         "selected_policies": [
#                             {
#                                 "content": doc.page_content[:200]
#                                 + "...",  # Truncate for storage
#                                 "theme": doc.metadata.get("theme", ""),
#                                 "policy_intent": doc.metadata.get("policy_intent", ""),
#                             }
#                             for doc in selected_policies
#                         ],
#                         "scenarios": scenarios,
#                         "scenario_chunks": scenario_chunks,  # Store chunk mappings
#                     }
#                     st.session_state.policy_scenarios.append(scenario_entry)

#                     # Created and stored scenarios (logging reduced)
#             else:
#                 # Reuse existing scenarios and policies from current session
#                 selected_policies = st.session_state.current_policy_session[
#                     "selected_policies"
#                 ]
#                 scenarios = st.session_state.current_policy_session["scenarios"]
#                 scenario_chunks = st.session_state.current_policy_session.get(
#                     "scenario_chunks", {}
#                 )

#                 # Reusing scenarios (logging reduced)
#                 for i, doc in enumerate(selected_policies, 1):
#                     policy_intent = doc.metadata.get("policy_intent", "General policy")
#                     policy_theme = doc.metadata.get("theme", "Unknown")
#                     source_doc = doc.metadata.get("source_document", "Unknown")
#                     print(f"\n🔄 REUSED POLICY CHUNK {i}:")
#                     print(f"   📌 Intent: {policy_intent}")
#                     print(f"   🏢 Theme: {policy_theme}")
#                     print(f"   📄 Source: {source_doc}")
#                     print("-" * 60)
#                 print("🔄" * 80 + "\n")
#                 print("🚨 FINISHED: Reusing existing policy chunks complete!")

#             # Build conversation history for context
#             history_text = ""
#             for message in chat_history:
#                 if isinstance(message, HumanMessage):
#                     history_text += f"Support Rep: {message.content}\n"
#                 elif isinstance(message, AIMessage):
#                     history_text += f"Customer: {message.content}\n"

#             # Create policy context from selected documents
#             policy_context = ""
#             if selected_policies:
#                 policy_context = "RELEVANT POLICY INFORMATION:\n"
#                 policy_context += "=" * 60 + "\n"

#                 # Get all required chunks from scenario_chunks
#                 required_chunks = []
#                 if "scenario_chunks" in st.session_state.current_policy_session:
#                     scenario_chunks = st.session_state.current_policy_session[
#                         "scenario_chunks"
#                     ]
#                     for chunk_list in scenario_chunks.values():
#                         # Handle cases like "CHUNK_24" or "CHUNK_23, CHUNK_25"
#                         chunks = [chunk.strip() for chunk in chunk_list.split(",")]
#                         required_chunks.extend(chunks)

#                 print(f"[DEBUG] Required chunks from scenarios: {required_chunks}")

#                 # Normalize required chunks to handle case variations (CHUNK_X vs chunk_x)
#                 normalized_required_chunks = set()
#                 for chunk in required_chunks:
#                     # Extract the number from patterns like "CHUNK_18" or "chunk_18"
#                     chunk_num = (
#                         chunk.replace("CHUNK_", "").replace("chunk_", "").strip()
#                     )
#                     normalized_required_chunks.add(chunk_num)

#                 print(
#                     f"[DEBUG] Normalized required chunk numbers: {sorted(normalized_required_chunks)}"
#                 )

#                 for i, doc in enumerate(selected_policies, 1):
#                     doc_chunk_id = doc.metadata.get("chunk_id", f"CHUNK_{i}")
#                     print(f"[DEBUG] Checking policy document chunk_id: {doc_chunk_id}")

#                     # Extract chunk number from document chunk_id (e.g., "chunk_10" -> "10")
#                     doc_chunk_num = (
#                         doc_chunk_id.replace("CHUNK_", "").replace("chunk_", "").strip()
#                     )

#                     # Check if this document's chunk number is in the required chunks
#                     if doc_chunk_num in normalized_required_chunks:
#                         policy_intent = doc.metadata.get(
#                             "policy_intent", "General policy"
#                         )
#                         policy_context += (
#                             f"POLICY CHUNK {i} - {policy_intent.upper()}:\n"
#                         )
#                         policy_context += f"Chunk ID: {doc_chunk_id}\n"
#                         policy_context += f"{doc.page_content}\n"
#                         policy_context += "=" * 60 + "\n"
#                         print(
#                             f"[DEBUG] ✅ Added policy chunk {doc_chunk_id} to context"
#                         )
#                     else:
#                         print(
#                             f"[DEBUG] ❌ Skipped policy chunk {doc_chunk_id} - not in required chunks"
#                         )

#                 # 🌟 POLICY CONTEXT LOGGING 🌟
#                 # Essential policy context logging
#                 print(f"📋 Using {len(selected_policies)} policy chunks for response")

#             # Get the single scenario (no need for indexing since we only have one)
#             current_scenario = ""
#             current_scenario_chunks = ""
#             if scenarios and len(scenarios) > 0:
#                 current_scenario = scenarios[
#                     0
#                 ]  # Always use the first (and only) scenario
#                 # Get chunk information for the scenario
#                 if "scenario_chunks" in st.session_state.current_policy_session:
#                     scenario_chunks = st.session_state.current_policy_session[
#                         "scenario_chunks"
#                     ]
#                     current_scenario_chunks = scenario_chunks.get(1, "Not specified")

#                 print(
#                     f"[DEBUG] Using single multi-question scenario: {current_scenario}"
#                 )
#                 print(f"[DEBUG] Required chunks: {current_scenario_chunks}")

#                 # 🎯 SCENARIO USAGE LOGGING 🎯
#                 print("\n" + "🎯" * 80)
#                 print("🎯 SINGLE MULTI-QUESTION SCENARIO IN USE 🎯")
#                 print("🎯" * 80)
#                 print(f"🎭 Active Scenario: {current_scenario}")
#                 print(f"📋 Required Chunks: {current_scenario_chunks}")
#                 print("🎯" * 80 + "\n")

#             # Create customer response prompt with scenario and policy context
#             customer_prompt = f"""
#             You are an AI Assistant mimicking a **customer** in a support chat. Your tone should match the specified customer tone: {customer_tone}.
            
#             SCENARIO CONTEXT:
#             - Department: {department}
#             - Theme: {theme} 
#             - Customer Tone: {customer_tone}
#             - Current Scenario: {current_scenario}
#             - Required Policy Chunks: {current_scenario_chunks}
            
#             CONVERSATION HISTORY:
#             {history_text}
            
#             SUPPORT REP JUST SAID: {support_rep_message}
            
#             POLICY CONTEXT FOR RESOLUTION ANALYSIS:
#             {policy_context}
            
#             YOUR TASK (strictly follow all points):

#             CRITICAL INSTRUCTIONS:
#             1. **MULTI-QUESTION SCENARIO FOCUS**: You are working on this ONE scenario with multiple questions: "{current_scenario}"
#                 - This scenario contains multiple related questions - address them one by one
#                 - Do NOT ask multiple questions in one response
#                 - Focus on the first unresolved question, then move to the next after it's answered
#                 - Do NOT combine different topics
#                 - Stay focused on this specific scenario until all questions are fully resolved
#             2. **Don't create new scenarios or queries based on the policy context you have - stick to the scenario: {current_scenario}.**
#             3. **Use the given policy context only as background awareness, not to challenge or correct the support rep’s answers.
#             4. **If the rep asks about the policy, respond briefly (2–3 sentences) to acknowledge it, but don't argue.
#             5. **When your tone is angry, express your dissatisfaction briefly at the start, but do not repeat or exaggerate anger in every sentence.

#             Guide for your response:
#             1. **If the Support Rep's message asks for patience or says they are checking/waiting/processing (e.g., "I'll check," "wait please," "one moment"),** do NOT move the scenario forward or repeat any earlier query. Instead, respond naturally and briefly with patience or acknowledgment (e.g., "Sure, take your time.", "Thanks, I'll wait for your update.").

#             2. **If asked for personal details (such as a MileagePlus account number), reply with a plausible, randomly-generated 8–10 digit number (e.g., "My account number is 387459263.")**. Generate a new realistic number every time unless you have already shared one earlier in this conversation (then re-use it if asked again).

#             3. **Ask just one new question or make one comment per turn related only to the current policy scenario — never more than one. Make all responses concise (1–2 sentences max) and do NOT repeat previous queries unless specifically requested by the Support Rep. Avoid re-phrasing or restating the same question if it's already pending.**

#             4. **Resolution Check:**  
#                -  Is the resolution provided by the support rep,
#                  - If YES: Respond with acknowledgment or brief gratitude using one of these EXACT phrases to signal resolution:
#                    • "thank you, that helps"
#                    • "got it, thanks" 
#                    • "that makes sense, thank you"
#                    • "perfect, thank you"
#                    • "understood, thanks"
#                    • "that clears it up"
#                    • "that answers my question"
#                    • "that's exactly what I needed"
#                    • "appreciate the clarification, that helps"
#                    • "thanks for explaining, that's clear now"
#                    Then do NOT ask further questions on this topic.
#                  - If support rep mentioned anything unable to resolve the issue: 
#                    - After 2 unresolved attempts, escalate politely ("Could you please escalate this issue to a supervisor?").
#                    - If escalation is denied, end with disappointment and polite goodbye ("I'm disappointed this can't be resolved, but thanks for your time. Goodbye.").
#                - If rep signals the end ("goodbye", "let us know if you need anything else"), do NOT respond further.

#             5. **When moving between questions (once current one is resolved), connect smoothly using natural conversational transitions like:**  
#                 - Example: "Thank you for your help with that. I have another question about [next topic]…"
#                 - Example: "Alright, that clears it up. Now, regarding [next topic]…"
#               - Do NOT abruptly switch topics without acknowledgment of the previous resolution.
#               - Smoothly transition to the next one, with humanic-like flow.

#             6. **Style and Etiquette:**  
#                - Do not invent unrelated hypothetical problems.
#                - Use polite, natural, and human-like language. Vary your interjections subtly ("Thanks!", "I appreciate it.", "Alright, I'll wait.").
#                - Always maintain the specified customer tone, especially if told to be "angry" or "confused": express those emotions briefly once at the start of the query, but never repeat or exaggerate in each sentence.

#             7. **NEVER repeat previous questions or answers verbatim, even if the rep is slow to answer. If stuck (repeated 'wait'), indicate patience. Do NOT ask new policy questions until the prior one is fully resolved.**

#             8. **Do NOT end the conversation (say goodbye/thanks) unless your issue is resolved, escalation is denied, or the rep has already ended the chat.**

#             -----
#             **Generate only the customer's next message based on all of the above.**
#             Keep your reply natural, concise, and maximally relevant to the current scenario and flow of the conversation.
#             """

#             messages = [
#                 {
#                     "role": "system",
#                     "content": "You are a customer with a specific concern asking for help in a support chat.",
#                 },
#                 {"role": "user", "content": customer_prompt},
#             ]

#             # Count input tokens and add to list
#             tokens = get_token_count(messages)
#             # ...existing code...
#             st.session_state.token_usage.append(tokens)

#             response = client.chat.completions.create(
#                 model="gpt-4.1",
#                 messages=messages,
#                 max_tokens=200,
#                 temperature=0.3,
#                 top_p=0.7,
#             )

#             customer_response = response.choices[0].message.content.strip()

#             # Check if customer response contains goodbye/closing
#             if any(kw in customer_response.lower() for kw in self.GOODBYE_KEYWORDS):
#                 self.conversation_started = False

#             # Save to memory
#             self.memory.save_context(
#                 {"input": support_rep_message}, {"output": customer_response}
#             )

#             return customer_response

#         except Exception as e:
#             print(f"[ERROR] Error in gen_cus_policy_response: {str(e)}")
#             return f"Error generating response: {str(e)}"

#     def create_policy_scenarios(self, selected_policies, department, theme):
#         """
#         Create 1 multi-question scenario from the selected policy documents
#         """
#         try:
#             print(f"🎬 Generating scenarios for {department} - {theme}")
#             policy_summaries = []
#             for i, doc in enumerate(selected_policies, 1):
#                 policy_intent = doc.metadata.get("policy_intent", "General policy")
#                 content_summary = doc.page_content
#                 policy_id = doc.metadata.get("chunk_id", f"Policy-{i}")
#                 print(f"  Chunk {i}: {policy_id} - {content_summary}")

#                 policy_summaries.append(
#                     f"Policy Intent: {policy_intent}\nContent: {content_summary} \nID: {policy_id}"
#                 )

#             combined_policies = "\n\n".join(policy_summaries)

#             scenario_prompt = f"""
#             Based on the following company policy documents, create 1 realistic customer service scenario 
#             that would require knowledge of these policies to resolve properly.
            
#             Department: {department}
#             Theme: {theme}
            
#             POLICY DOCUMENTS:
#             {combined_policies}
            
#             Generate 1 customer scenario that includes at least 2 related questions.
#             The scenario should:
#             1. Be a realistic customer problem with multiple related questions
#             2. Require multiple policy documents from the provided policies to resolve
#             3. Be specific to the {department} department and {theme} theme
#             4. Include at least 2 questions that a customer would naturally ask in sequence
#             5. **IMPORTANT: Mention which CHUNK numbers from ALL available chunks are needed to answer the scenario**

            
#             Format EXACTLY like this:
        
#             Scenario 1:
#                 Questions: [First question about the topic] Also, [second related question about the same topic]
#                 Required Chunks: CHUNK_1, CHUNK_2, CHUNK_3, CHUNK_4
        
#             """

#             messages = [
#                 {
#                     "role": "system",
#                     "content": "You are an expert at creating realistic customer service scenarios based on company policies.",
#                 },
#                 {"role": "user", "content": scenario_prompt},
#             ]

#             # Count input tokens and add to list
#         tokens = get_token_count(messages)
#         # ...existing code...
#             st.session_state.token_usage.append(tokens)

#             response = client.chat.completions.create(
#                 model="gpt-4.1",
#                 messages=messages,
#                 max_tokens=300,
#                 temperature=0.5,
#             )

#             scenario_text = response.choices[0].message.content.strip()

#             # Parse scenarios from response
#             scenarios = []
#             scenario_chunks = {}  # Track which chunks each scenario needs
#             lines = scenario_text.split("\n")
#             current_scenario_num = 0

#             for line in lines:
#                 line = line.strip()

#                 # Track which scenario we're currently parsing
#                 if line.startswith("Scenario 1:"):
#                     current_scenario_num = 1

#                 # Look for lines that start with "Questions:" (multiple questions in one scenario)
#                 elif line.startswith("Questions:"):
#                     questions = line.replace("Questions:", "").strip()
#                     if questions:  # Only add non-empty questions
#                         scenarios.append(questions)

#                 # Look for lines that start with "Required Chunks:"
#                 elif line.startswith("Required Chunks:") and current_scenario_num > 0:
#                     chunks = line.replace("Required Chunks:", "").strip()
#                     scenario_chunks[current_scenario_num] = chunks

#             # Essential results logging
#             print(f"✅ CREATED {len(scenarios)} SCENARIOS")
#             for i, scenario in enumerate(scenarios, 1):
#                 chunks_needed = scenario_chunks.get(i, "Not specified")
#                 print(f"📝 Scenario {i}: {scenario}")
#                 print(f"📋 Required Chunks: {chunks_needed}")

#             return scenarios, scenario_chunks

#         except Exception as e:
#             print(f"[ERROR] Error creating policy scenarios: {str(e)}")
#             return [
#                 f"General {theme} inquiry for {department} with multiple questions about policies"
#             ], {1: "ALL_CHUNKS"}


# def fetch_policy_documents(db, department, issue_type, support_input):
#     """
#     Fetch relevant policy documents from vector database based on department, issue type, and support input
#     Enhanced with policy_intent metadata analysis
#     """
#     try:
#         # Step 1: Analyze the support input to understand what type of policy help is needed
#         policy_need_analysis = analyze_support_query_intent(
#             support_input, department, issue_type
#         )

#         # Step 2: Create an intelligent query that targets policy_intent metadata
#         enhanced_policy_query = f"""
#         Customer Support Situation Analysis:
#         Department: {department}
#         Issue Category: {issue_type}
#         Support Representative Query: {support_input}
        
#         Policy Guidance Needed For: {policy_need_analysis}
        
#         Find policy documents that can help resolve customer issues related to: {policy_need_analysis}
#         """

#         # Step 3: Search for relevant policy documents using enhanced query
#         policy_docs = db.similarity_search(
#             enhanced_policy_query,
#             k=5,  # Get top 5 most relevant policy documents
#         )

#         # Step 4: Filter and rank documents based on policy_intent metadata relevance
#         relevant_docs = filter_by_policy_intent(
#             policy_docs, policy_need_analysis, support_input
#         )

#         # Step 5: Build enhanced policy context with metadata
#         policy_context = ""
#         if relevant_docs:
#             policy_context = "\n\n--- RELEVANT POLICY DOCUMENTS ---\n"
#             for i, doc_info in enumerate(relevant_docs, 1):
#                 doc = doc_info["document"]
#                 relevance_score = doc_info["relevance_score"]
#                 policy_intent = doc.metadata.get(
#                     "policy_intent", "General policy guidance"
#                 )
#                 source_doc = doc.metadata.get("source_document", "Unknown")

#                 policy_context += f"\n=== Policy Document {i} (Relevance: {relevance_score:.2f}) ===\n"
#                 policy_context += f"Policy Intent: {policy_intent}\n"
#                 policy_context += f"Source Document: {source_doc}\n"
#                 policy_context += f"Content: {doc.page_content}\n"
#                 policy_context += f"{'='*60}\n"

#             policy_context += "\n--- END POLICY DOCUMENTS ---\n"
#         else:
#             policy_context = "\n\n--- NO RELEVANT POLICY DOCUMENTS FOUND ---\n"
#             policy_context += f"Search Query: {enhanced_policy_query}\n"
#             policy_context += f"Total Documents in Database: {len(db.docstore._dict) if hasattr(db, 'docstore') else 'Unknown'}\n"
#             policy_context += "--- END ---\n"

#         print(f"[DEBUG] Final result: {len(relevant_docs)} relevant policy documents")
#         return policy_context

#     except Exception as e:
#         print(f"[ERROR] Error fetching policy documents: {str(e)}")
#         return f"\n\n--- ERROR FETCHING POLICY DOCUMENTS ---\nError: {str(e)}\n--- END ---\n"


# def analyze_support_query_intent(support_input, department, issue_type):
#     """
#     Analyze the support representative's query to understand what kind of policy guidance they need
#     """
#     try:
#         analysis_prompt = f"""
#         Analyze this customer support situation and determine what specific policy guidance is needed.
        
#         Department: {department}
#         Issue Type: {issue_type}
#         Support Rep Query: {support_input}
        
#         Based on this context, what specific customer service policy areas would be most helpful? 
#         Consider things like:
#         - Refund and return policies
#         - Booking modification policies  
#         - Cancellation policies
#         - Upgrade and seating policies
#         - Special circumstances policies
#         - Compensation policies
#         - Customer escalation policies
        
#         Respond with 1-2 sentences describing the specific policy guidance needed.
#         """

#         messages = [
#             {
#                 "role": "system",
#                 "content": "You are an expert at analyzing customer support scenarios and identifying relevant policy needs.",
#             },
#             {"role": "user", "content": analysis_prompt},
#         ]

#         # Count input tokens and add to list
#     tokens = get_token_count(messages)
#     # ...existing code...
#         st.session_state.token_usage.append(tokens)

#         response = client.chat.completions.create(
#             model="gpt-4.1",
#             messages=messages,
#             max_tokens=200,
#             temperature=0.2,
#         )

#         policy_need = response.choices[0].message.content.strip()
#         return policy_need

#     except Exception as e:
#         print(f"[ERROR] Error analyzing support query intent: {str(e)}")
#         return f"General policy guidance for {department} {issue_type} issues"


# def filter_by_policy_intent(policy_docs, policy_need_analysis, support_input):
#     """
#     Filter and rank policy documents based on how well their policy_intent matches the support query
#     """
#     try:
#         relevant_docs = []

#         for doc in policy_docs:
#             # Get the policy_intent from metadata
#             policy_intent = doc.metadata.get("policy_intent", "")

#             # Calculate relevance score using GPT-4.1
#             relevance_score = calculate_policy_relevance(
#                 policy_intent, policy_need_analysis, support_input
#             )

#             # Only include documents with relevance score > 0.3
#             if relevance_score > 0.3:
#                 relevant_docs.append(
#                     {
#                         "document": doc,
#                         "relevance_score": relevance_score,
#                         "policy_intent": policy_intent,
#                     }
#                 )

#         # Sort by relevance score (highest first)
#         relevant_docs.sort(key=lambda x: x["relevance_score"], reverse=True)

#         # Return top 3 most relevant documents
#         return relevant_docs[:3]

#     except Exception as e:
#         print(f"[ERROR] Error filtering by policy intent: {str(e)}")
#         return [
#             {"document": doc, "relevance_score": 0.5, "policy_intent": "Unknown"}
#             for doc in policy_docs[:3]
#         ]


# def calculate_policy_relevance(policy_intent, policy_need_analysis, support_input):
#     """
#     Use GPT-4.1 to calculate how relevant a policy document is to the support query
#     """
#     try:
#         relevance_prompt = f"""
#         Rate the relevance of this policy document to the support representative's need.
        
#         Policy Document Intent: {policy_intent}
        
#         Support Rep's Policy Need: {policy_need_analysis}
        
#         Original Support Query: {support_input}
        
#         On a scale of 0.0 to 1.0, how relevant is this policy document to helping resolve the support representative's query?
        
#         Consider:
#         - Does the policy intent match the type of customer issue?
#         - Would this policy help the support rep provide accurate guidance?
#         - Is this policy applicable to the specific situation described?
        
#         Respond with only a decimal number between 0.0 and 1.0 (e.g., 0.85)
#         """

#         messages = [
#             {
#                 "role": "system",
#                 "content": "You are an expert at evaluating policy document relevance for customer support scenarios. Always respond with only a decimal number.",
#             },
#             {"role": "user", "content": relevance_prompt},
#         ]

#         # Count input tokens and add to list
#     tokens = get_token_count(messages)
#     # ...existing code...
#         st.session_state.token_usage.append(tokens)

#         response = client.chat.completions.create(
#             model="gpt-4.1",
#             messages=messages,
#             max_tokens=10,
#             temperature=0.1,
#         )

#         relevance_text = response.choices[0].message.content.strip()

#         # Extract the decimal number
#         import re

#         match = re.search(r"(\d+\.?\d*)", relevance_text)
#         if match:
#             relevance_score = float(match.group(1))
#             # Ensure it's between 0 and 1
#             return min(max(relevance_score, 0.0), 1.0)
#         else:
#             return 0.5  # Default score if parsing fails

#     except Exception as e:
#         print(f"[ERROR] Error calculating policy relevance: {str(e)}")
#         return 0.5  # Default score on error


# def generate_enhanced_support_response(
#     support_input, policy_context, department, issue_type, customer_tone
# ):
#     """
#     Generate enhanced support response using GPT-4.1 with policy context
#     """
#     try:
#         # Create prompt for GPT-4.1 with policy context
#         enhanced_prompt = f"""
#         You are an expert customer support AI assistant with access to company policy documents.
        
#         SCENARIO CONTEXT:
#         - Department: {department}
#         - Issue Type: {issue_type}  
#         - Customer Tone: {customer_tone}
        
#         SUPPORT REPRESENTATIVE INPUT:
#         {support_input}
        
#         RELEVANT POLICY CONTEXT:
#         {policy_context}
        
#         INSTRUCTIONS:
#         1. Analyze the support representative's input along with the relevant policy documents
#         2. Provide an enhanced, policy-compliant response that helps the support representative
#         3. Include specific policy references when applicable
#         4. Suggest the best course of action based on company policies
#         5. Keep the response professional and helpful
#         6. If no relevant policy is found, provide general best practice guidance
        
#         Generate a comprehensive support response that incorporates policy guidance:
#         """

#         # Call GPT-4.1 to generate enhanced response
#         messages = [
#             {
#                 "role": "system",
#                 "content": "You are an expert customer support AI assistant with access to company policy documents. Provide helpful, policy-compliant guidance to support representatives.",
#             },
#             {"role": "user", "content": enhanced_prompt},
#         ]

#         # Count input tokens and add to list
#     print_token_count(messages)
#         st.session_state.token_usage.append(tokens)

#         response = client.chat.completions.create(
#             model="gpt-4.1",
#             messages=messages,
#             max_tokens=500,
#             temperature=0.3,
#             top_p=0.9,
#         )

#         enhanced_response = response.choices[0].message.content.strip()
#         print(f"[DEBUG] Generated enhanced response: {enhanced_response[:100]}...")

#         return enhanced_response

#     except Exception as e:
#         print(f"[ERROR] Error generating enhanced response: {str(e)}")
#         return f"Error generating enhanced response: {str(e)}"


# def display_fetched_policy_documents(
#     policy_context, department, issue_type, support_input
# ):
#     """
#     Display the fetched policy documents in a neat, organized way in the Streamlit UI
#     """
#     if not policy_context or "RELEVANT POLICY DOCUMENTS" not in policy_context:
#         st.info(
#             "🔍 **Policy Search Result:** No relevant policy documents found for this query."
#         )
#         return

#     # Custom CSS for better styling
#     st.markdown(
#         """
#     <style>
#     .policy-header {
#         background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
#         color: white;
#         padding: 1rem;
#         border-radius: 10px;
#         margin: 1rem 0;
#         text-align: center;
#         box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
#     }
#     .policy-document {
#         background: #f8fafc;
#         border-left: 4px solid #667eea;
#         padding: 1rem;
#         margin: 0.5rem 0;
#         border-radius: 0 8px 8px 0;
#         box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
#     }
#     .policy-intent {
#         background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
#         color: white;
#         padding: 0.5rem 1rem;
#         border-radius: 20px;
#         display: inline-block;
#         font-size: 0.9rem;
#         font-weight: 600;
#         margin: 0.5rem 0;
#     }
#     .relevance-score {
#         background: linear-gradient(135deg, #ed8936 0%, #dd6b20 100%);
#         color: white;
#         padding: 0.3rem 0.8rem;
#         border-radius: 15px;
#         display: inline-block;
#         font-size: 0.8rem;
#         font-weight: 600;
#         margin-left: 1rem;
#     }
#     .search-context {
#         background: #e6f3ff;
#         border: 1px solid #3182ce;
#         padding: 1rem;
#         border-radius: 8px;
#         margin: 1rem 0;
#     }
#     </style>
#     """,
#         unsafe_allow_html=True,
#     )

#     # Header showing search context
#     st.markdown(
#         f"""
#     <div class="policy-header">
#         <h3>📚 Policy Documents Retrieved</h3>
#         <p><strong>Industry:</strong> {department} | <strong>Reason for Contact:</strong> {issue_type}</p>
#     </div>
#     """,
#         unsafe_allow_html=True,
#     )

#     # Show search query
#     with st.expander("🔍 **View Search Context**", expanded=False):
#         st.markdown(
#             f"""
#         <div class="search-context">
#             <strong>🎯 Support Representative Query:</strong><br>
#             <em>"{support_input}"</em><br><br>
#             <strong>📋 Search Parameters:</strong><br>
#             • Industry: {department}<br>
#             • Reason for Contact: {issue_type}<br>
#             • Vector Database: Policy Documents Store
#         </div>
#         """,
#             unsafe_allow_html=True,
#         )

#     # Parse and display policy documents
#     try:
#         # Extract policy documents from the context
#         if "=== Policy Document" in policy_context:
#             policy_sections = policy_context.split("=== Policy Document")[
#                 1:
#             ]  # Skip the header part

#             st.markdown("### 📄 **Retrieved Policy Documents:**")

#             for i, section in enumerate(policy_sections, 1):
#                 if section.strip():
#                     # Parse the section
#                     lines = section.strip().split("\n")

#                     # Extract metadata
#                     relevance_score = "N/A"
#                     policy_intent = "General policy guidance"
#                     content = ""

#                     for line in lines:
#                         if "Relevance:" in line:
#                             relevance_score = (
#                                 line.split("Relevance:")[1]
#                                 .strip()
#                                 .replace("===", "")
#                                 .strip()
#                             )
#                         elif line.startswith("Policy Intent:"):
#                             policy_intent = line.replace("Policy Intent:", "").strip()
#                         elif line.startswith("Content:"):
#                             content_start = lines.index(line)
#                             content = (
#                                 "\n".join(lines[content_start + 1 :])
#                                 .replace("=" * 60, "")
#                                 .strip()
#                             )
#                             break

#                     # Display policy document
#                     st.markdown(
#                         f"""
#                     <div class="policy-document">
#                         <h4>📋 Policy Document #{i} <span class="relevance-score">Relevance: {relevance_score}</span></h4>
#                         <div class="policy-intent">🎯 {policy_intent}</div>
#                         <br>
#                         <strong>📝 Policy Content:</strong>
#                     </div>
#                     """,
#                         unsafe_allow_html=True,
#                     )

#                     # Display content in an expandable section
#                     with st.expander(
#                         f"📖 **View Policy Document #{i} Content**", expanded=False
#                     ):
#                         st.markdown(
#                             f"```\n{content[:500]}{'...' if len(content) > 500 else ''}\n```"
#                         )
#                         if len(content) > 500:
#                             st.markdown(f"**Full Content:**\n{content}")

#     except Exception as e:
#         st.error(f"❌ Error parsing policy documents: {str(e)}")

#         # Fallback: Show raw policy context
#         with st.expander("📄 **Raw Policy Context (Debug)**", expanded=False):
#             st.text(policy_context)


# def main():
#     # Function definitions first
#     def format_display_name(name):
#         """Convert camelCase or PascalCase to spaced words"""
#         import re

#         if not name:
#             return name

#         # Add space before uppercase letters that follow lowercase letters
#         formatted = re.sub(r"([a-z])([A-Z])", r"\1 \2", name)

#         # Handle specific cases - match the actual data
#         formatted = formatted.replace("Cancelfilght", "Cancel Flight")  # Fixed typo
#         formatted = formatted.replace(
#             "Flightbooking", "Flight Booking"
#         )  # Fixed capitalization
#         formatted = formatted.replace("FlightBooking", "Flight Booking")
#         formatted = formatted.replace("Rebooking", "Re-booking")

#         return formatted

#     if st.session_state.get("logged_in", False):
#         # Logout functionality moved to bottom of main sidebar
#         pass

#     # --- DYNAMIC LOGIN SYSTEM ---
#     if "logged_in" not in st.session_state:
#         st.session_state.logged_in = False
#         st.session_state.username = ""
#         st.session_state.role = ""
#         st.session_state.token_usage = []  # Simple list to track input tokens

#     if not st.session_state.logged_in:
#         st.title("🔐 Login to AI Customer Support Trainer")

#         # Load dynamic users from GCS
#         USERS = user_sim_manager.load_users()

#         with st.form("login_form"):
#             username = st.text_input("Username")
#             password = st.text_input("Password", type="password")
#             submitted = st.form_submit_button("Login")

#         if submitted:
#             user = USERS.get(username)
#             if user and user["password"] == password:
#                 st.session_state.logged_in = True
#                 st.session_state.username = username
#                 st.session_state.role = user["role"]
#                 # Restore user data if exists (from session and disk)
#                 if "user_data" not in st.session_state:
#                     st.session_state.user_data = {}
#                 user_data = st.session_state.user_data.get(username, {})
#                 # Try to load eval_summary and chat_history from disk if available
#                 user_dir = os.path.join("user_data", username)
#                 eval_summary = []
#                 chat_history = []
#                 if os.path.isdir(user_dir):
#                     # Load all Excel files in user_dir except chat_history.xlsx
#                     for fname in os.listdir(user_dir):
#                         if fname.endswith(".xlsx") and fname != "chat_history.xlsx":
#                             fpath = os.path.join(user_dir, fname)
#                             with open(fpath, "rb") as f:
#                                 excel_bytes = f.read()
#                             # Try to parse timestamp from filename
#                             ts_match = re.search(r"eval_\d+_(.*?)\.xlsx", fname)
#                             timestamp = (
#                                 ts_match.group(1).replace("_", " ").replace("-", ":")
#                                 if ts_match
#                                 else ""
#                             )
#                             # Read metadata from Excel file
#                             try:
#                                 wb = openpyxl.load_workbook(fpath, data_only=True)
#                                 meta = wb["Metadata"]
#                                 meta_row = list(
#                                     meta.iter_rows(
#                                         min_row=2, max_row=2, values_only=True
#                                     )
#                                 )[0]
#                                 (
#                                     username_xl,
#                                     dept_xl,
#                                     issue_xl,
#                                     tone_xl,
#                                     ts_xl,
#                                     score_xl,
#                                 ) = meta_row
#                             except Exception:
#                                 (
#                                     username_xl,
#                                     dept_xl,
#                                     issue_xl,
#                                     tone_xl,
#                                     ts_xl,
#                                     score_xl,
#                                 ) = (username, "", "", "", timestamp, "")
#                             eval_summary.append(
#                                 {
#                                     "username": username_xl or username,
#                                     "timestamp": ts_xl or timestamp,
#                                     "excel_bytes": excel_bytes,
#                                     "department": dept_xl or "",
#                                     "issue_type": issue_xl or "",
#                                     "tone": tone_xl or "",
#                                     "eval_score": score_xl or "",
#                                 }
#                             )
#                     # Note: chat_history.xlsx loading removed - using session state only
#                 else:
#                     eval_summary = user_data.get("eval_summary", [])
#                     chat_history = user_data.get("chat_history", [])
#                 st.session_state.eval_summary = eval_summary
#                 # NEW: Only restore chat_history if not cleared by Start New Training Session
#                 if st.session_state.get("clear_chat_on_login", False):
#                     st.session_state.chat_history = []
#                     st.session_state["clear_chat_on_login"] = False
#                 else:
#                     st.session_state.chat_history = chat_history
#                 st.success(f"Welcome, {username}!")
#                 st.rerun()
#             else:
#                 st.error("Invalid username or password.")
#         st.stop()

#     # --- EVAL SUMMARY & CHAT HISTORY PERSISTENCE ---
#     # Ensure eval_summary and chat_history exist in session
#     if "eval_summary" not in st.session_state:
#         st.session_state.eval_summary = []
#     if "chat_history" not in st.session_state:
#         st.session_state.chat_history = []

#     # --- ROLE-BASED UI ---
#     if st.session_state.role == "trainer":
#         st.title("📊 Supervisor(Trainer) Dashboard")
#         st.markdown("Monitor and analyze trainee performance across all sessions")

#         # 🚀 PERFORMANCE OPTIMIZATION: In-memory caching implemented
#         # - First load: Fetches from GCP bucket and caches in session state
#         # - Subsequent loads: Uses cached data for instant response
#         # - Manual refresh available to update cache with fresh data
#         # - Cache automatically cleared on logout to free memory

#         # Check for logout in sidebar FIRST (before any data loading)
#         logout_requested = False
#         refresh_requested = False
#         with st.sidebar:
#             st.header("🔍 Analytics Filters")

#             # Create a placeholder for filters that will be populated after data loading
#             filters_placeholder = st.empty()

#             # Cache management buttons
#             st.markdown("---")
#             st.markdown("**📊 Data Management**")

#             # Show cache status
#             cached_count = len(st.session_state.get("supervisor_all_trainee_data", []))
#             if cached_count > 0:
#                 st.success(f"✅ {cached_count} evaluations cached")
#             else:
#                 st.info("🔄 No data cached")

#             # Refresh data button
#             if st.button(
#                 "🔄 Refresh Data",
#                 key="supervisor_refresh_btn",
#                 help="Clear cache and reload fresh data from cloud storage",
#             ):
#                 refresh_requested = True

#             # Logout button at bottom of sidebar
#             st.markdown("---")
#             if st.button(
#                 "🚪 Logout", key="supervisor_sidebar_logout_btn", type="secondary"
#             ):
#                 logout_requested = True

#         # Handle refresh BEFORE loading data
#         if refresh_requested:
#             # Clear the cached supervisor data to force fresh load
#             if "supervisor_all_trainee_data" in st.session_state:
#                 del st.session_state["supervisor_all_trainee_data"]
#             # Clear cached function data safely (Streamlit cache)
#             try:
#                 from supervisor_dashboard import cached_users, cached_assignments

#                 cached_users.clear()
#                 cached_assignments.clear()
#             except Exception:
#                 pass
#             st.success("🔄 Cache cleared! Refreshing data...")
#             st.rerun()

#         # Handle logout BEFORE any data loading
#         if logout_requested:
#             # 🚀 COMPREHENSIVE SUPERVISOR LOGOUT CLEANUP:
#             # - Login credentials
#             # - Supervisor cached analytics data
#             # - Policy-related session data
#             # - Any trainee session data (in case supervisor used trainee features)
#             print(
#                 f"[DEBUG] Supervisor {st.session_state.get('username', '')} logging out"
#             )
#             st.session_state.logged_in = False
#             st.session_state.username = ""
#             st.session_state.role = ""

#             # 🚀 Clear supervisor cached data to free memory
#             if "supervisor_all_trainee_data" in st.session_state:
#                 cached_count = len(st.session_state["supervisor_all_trainee_data"])
#                 del st.session_state["supervisor_all_trainee_data"]
#             cached_supervisor_assignments.clear()

#             # 🚀 Clear supervisor dashboard caches too
#             try:
#                 from supervisor_dashboard import cached_users, cached_assignments

#                 cached_users.clear()
#                 cached_assignments.clear()
#             except Exception:
#                 pass

#             # 🚀 Clear policy-related session data (in case supervisor was also using trainee features)
#             policy_keys = [
#                 "policy_scenarios",
#                 "current_policy_session",
#                 "policy_switch_scenario",
#                 "selected_policies",
#                 "scenario_chunks",
#                 "policy_context",
#                 "current_scenario",
#                 "messages",
#                 "gcs_evaluations",
#             ]
#             for key in policy_keys:
#                 if key in st.session_state:
#                     if key == "policy_scenarios":
#                         st.session_state[key] = []  # Reset to empty list
#                     elif key == "current_policy_session":
#                         st.session_state[key] = None  # Reset to None
#                     else:
#                         del st.session_state[key]  # Delete completely
#                     print(f"[DEBUG] 💾 Cleared supervisor policy session key: {key}")

#             # 🗄️ Clear example and policy caches (in case supervisor used trainee features)
#             if "cached_examples" in st.session_state:
#                 del st.session_state.cached_examples
#                 print(f"[DEBUG] 💾 Cleared supervisor examples cache")
#             if "cached_policies" in st.session_state:
#                 del st.session_state.cached_policies
#                 print(f"[DEBUG] 💾 Cleared supervisor policies cache")

#             # 🚀 Clear GCS storage manager cache - FIXES THE ORIGINAL ISSUE!
#             # This ensures fresh data loading on next login
#             try:
#                 get_gcs_storage_manager.clear()
#                 print(f"[DEBUG] 💾 Cleared GCS storage manager cache")
#             except Exception as e:
#                 print(f"[DEBUG] ⚠️ Could not clear GCS cache: {e}")

#             st.success("✅ Logged out successfully!")
#             st.rerun()

#         # Function to load all trainee data from GCS with in-memory caching
#         def load_all_trainee_data_from_gcs():
#             """🚀 Load all trainee evaluation data from GCS bucket with caching"""
#             # Check if data is already cached in session state
#             if "supervisor_all_trainee_data" in st.session_state:
#                 cached_data = st.session_state["supervisor_all_trainee_data"]
#                 return cached_data

#             # If not cached, load from GCS
#             gcs_manager = get_gcs_storage_manager()
#             if not gcs_manager.is_connected():
#                 print("[ERROR] GCS not connected for trainer analytics")
#                 return []

#             all_trainee_data = gcs_manager.load_all_evaluations_for_analytics()

#             # Cache the data in session state for faster subsequent loads
#             st.session_state["supervisor_all_trainee_data"] = all_trainee_data

#             return all_trainee_data

#         # 🚀 Load all trainee data from GCS with caching (ONLY if not logging out)
#         with st.spinner("Loading analytics data from cloud storage..."):
#             all_trainee_data = load_all_trainee_data_from_gcs()

#         if not all_trainee_data:
#             st.info(
#                 "No trainee evaluation data found in cloud storage. Trainees need to complete evaluations first."
#             )
#             st.stop()
#         else:
#             # Show data source info
#             unique_trainees = len(set([d["username"] for d in all_trainee_data]))
#             st.success(
#                 f"📊 Loaded {len(all_trainee_data)} evaluations from {unique_trainees} trainee(s) from cloud storage"
#             )

#         # Now populate the sidebar filters with actual data
#         with filters_placeholder.container():
#             # Get unique values for filters
#             all_usernames = sorted(list(set([d["username"] for d in all_trainee_data])))
#             all_departments = sorted(
#                 list(
#                     set([d["department"] for d in all_trainee_data if d["department"]])
#                 )
#             )
#             all_tones = sorted(
#                 list(set([d["tone"] for d in all_trainee_data if d["tone"]]))
#             )

#             # Filter controls
#             selected_trainees = st.multiselect(
#                 "Select Trainees:", all_usernames, default=all_usernames
#             )
#             selected_departments = st.multiselect(
#                 "Select Departments:", all_departments, default=all_departments
#             )
#             selected_tones = st.multiselect(
#                 "Select Tones:", all_tones, default=all_tones
#             )

#             # Date range filter
#             st.markdown("**Date Range:**")
#             date_filter = st.selectbox(
#                 "Filter by:", ["All Time", "Last 7 Days", "Last 30 Days", "Today"]
#             )

#         # Apply filters
#         filtered_data = all_trainee_data
#         if selected_trainees:
#             filtered_data = [
#                 d for d in filtered_data if d["username"] in selected_trainees
#             ]
#         if selected_departments:
#             filtered_data = [
#                 d for d in filtered_data if d["department"] in selected_departments
#             ]
#         if selected_tones:
#             filtered_data = [d for d in filtered_data if d["tone"] in selected_tones]

#         # Main dashboard tabs
#         tab1, tab2, tab3, tab4, tab5 = st.tabs(
#             [
#                 "👤 User Management",
#                 "📋 Simulation Assignment",
#                 "👥 Individual Performance",
#                 "📊 Comparative Analysis",
#                 "📋 Detailed Reports",
#             ]
#         )

#         with tab1:  # User Management Tab
#             render_user_management_tab()

#         with tab2:  # Simulation Assignment Tab
#             render_simulation_assignment_tab()

#         with tab3:  # Individual Performance Tab
#             if filtered_data:
#                 # Trainee selector
#                 selected_trainee = st.selectbox(
#                     "Select Trainee for Detailed View:",
#                     sorted(list(set([d["username"] for d in filtered_data]))),
#                     key="tab1_trainee_selector",
#                 )
#                 if selected_trainee:
#                     trainee_data = [
#                         d for d in filtered_data if d["username"] == selected_trainee
#                     ]

#                     # Trainee metrics
#                     col1, col2, col3, col4 = st.columns(4)

#                     with col1:
#                         st.metric("Total Sessions", len(trainee_data))

#                     with col2:
#                         avg_score = np.mean(
#                             [format_eval_score(d["eval_score"]) for d in trainee_data]
#                         )
#                         st.metric("Average Score", f"{avg_score:.1f}%")

#                     with col3:
#                         best_score = max(
#                             [format_eval_score(d["eval_score"]) for d in trainee_data]
#                         )
#                         st.metric("Best Score", f"{best_score:.1f}%")

#                     with col4:
#                         latest_score = format_eval_score(
#                             trainee_data[0]["eval_score"]
#                         )  # Data is sorted by timestamp desc
#                         st.metric("Latest Score", f"{latest_score:.1f}%")

#                     # Show individual trainee progress
#                     st.markdown("### 📈 Progress Over Time")
#                     st.markdown("---")
#                     st.markdown("#### � Session Overview")
#                     trainee_df = pd.DataFrame(trainee_data)
#                     trainee_df["timestamp"] = pd.to_datetime(trainee_df["timestamp"])
#                     trainee_df = trainee_df.sort_values("timestamp")
#                     trainee_df["session_number"] = range(1, len(trainee_df) + 1)
#                     # Format eval_score to numeric values
#                     trainee_df["eval_score"] = trainee_df["eval_score"].apply(
#                         format_eval_score
#                     )

#                     fig, ax = plt.subplots(figsize=(12, 6))

#                     sns.lineplot(
#                         data=trainee_df,
#                         x="session_number",
#                         y="eval_score",
#                         marker="o",
#                         markersize=8,
#                         linewidth=3,
#                         color="#2E86AB",
#                         ax=ax,
#                     )

#                     # Fill area under curve
#                     ax.fill_between(
#                         trainee_df["session_number"],
#                         trainee_df["eval_score"],
#                         alpha=0.3,
#                         color="#2E86AB",
#                     )

#                     # Add value annotations
#                     for x, y in zip(
#                         trainee_df["session_number"], trainee_df["eval_score"]
#                     ):
#                         ax.annotate(
#                             f"{y:.1f}%",
#                             (x, y),
#                             textcoords="offset points",
#                             xytext=(0, 10),
#                             ha="center",
#                             fontweight="bold",
#                             bbox=dict(
#                                 boxstyle="round,pad=0.3", facecolor="white", alpha=0.8
#                             ),
#                         )

#                     ax.set_xlabel("Session Number", fontsize=12, fontweight="bold")
#                     ax.set_ylabel(
#                         "Evaluation Score (%)", fontsize=12, fontweight="bold"
#                     )
#                     ax.set_title(
#                         f"{selected_trainee}'s Performance Progress",
#                         fontsize=14,
#                         fontweight="bold",
#                         pad=20,
#                     )
#                     ax.set_ylim(0, 105)
#                     ax.grid(True, linestyle="--", alpha=0.7)

#                     # Add average line
#                     ax.axhline(
#                         y=avg_score, color="red", linestyle="--", alpha=0.7, linewidth=2
#                     )
#                     ax.text(
#                         len(trainee_df),
#                         avg_score,
#                         f"Avg: {avg_score:.1f}%",
#                         verticalalignment="bottom",
#                         color="red",
#                         fontweight="bold",
#                     )

#                     plt.tight_layout()
#                     st.pyplot(fig)
#                     plt.close()

#         with tab4:  # Comparative Analysis Tab
#             st.markdown("### 🆚 Comparative Analysis")

#             if filtered_data:
#                 # Trainee comparison
#                 st.markdown("### 👥 Trainee Performance Comparison")

#                 trainee_stats = {}
#                 for d in filtered_data:
#                     username = d["username"]
#                     if username not in trainee_stats:
#                         trainee_stats[username] = []
#                     trainee_stats[username].append(format_eval_score(d["eval_score"]))

#                 comparison_data = []
#                 for username, scores in trainee_stats.items():
#                     comparison_data.append(
#                         {
#                             "Trainee": username,
#                             "Sessions": len(scores),
#                             "Average Score": np.mean(scores),
#                             "Best Score": max(scores),
#                             "Latest Score": scores[0],  # Assuming first is latest
#                             "Improvement": (
#                                 scores[0] - scores[-1] if len(scores) > 1 else 0
#                             ),
#                         }
#                     )

#                 comparison_df = pd.DataFrame(comparison_data)
#                 comparison_df = comparison_df.sort_values(
#                     "Average Score", ascending=False
#                 )

#                 # Display comparison table
#                 st.dataframe(comparison_df, use_container_width=True)

#                 # Comparison chart
#                 fig, ax = plt.subplots(figsize=(12, 8))

#                 x_pos = np.arange(len(comparison_df))
#                 bars = ax.bar(
#                     x_pos, comparison_df["Average Score"], color="skyblue", alpha=0.7
#                 )

#                 # Add value labels on bars
#                 for i, (bar, score) in enumerate(
#                     zip(bars, comparison_df["Average Score"])
#                 ):
#                     ax.text(
#                         bar.get_x() + bar.get_width() / 2,
#                         bar.get_height() + 1,
#                         f"{score:.1f}%",
#                         ha="center",
#                         va="bottom",
#                         fontweight="bold",
#                     )

#                 ax.set_xlabel("Trainees", fontsize=12, fontweight="bold")
#                 ax.set_ylabel("Average Score (%)", fontsize=12, fontweight="bold")
#                 ax.set_title(
#                     "Trainee Performance Comparison",
#                     fontsize=14,
#                     fontweight="bold",
#                     pad=20,
#                 )
#                 ax.set_xticks(x_pos)
#                 ax.set_xticklabels(comparison_df["Trainee"], rotation=45, ha="right")
#                 ax.set_ylim(0, 105)
#                 ax.grid(True, axis="y", linestyle="--", alpha=0.7)

#                 plt.tight_layout()
#                 st.pyplot(fig)
#                 plt.close()

#                 st.markdown("---")
#                 st.markdown("### 🏢 Department Performance")

#                 dept_scores = defaultdict(list)
#                 for d in filtered_data:
#                     if d["department"]:
#                         dept_scores[d["department"]].append(
#                             format_eval_score(d["eval_score"])
#                         )

#                 if dept_scores:
#                     dept_avg = {
#                         dept: np.mean(scores) for dept, scores in dept_scores.items()
#                     }
#                     dept_df = pd.DataFrame(
#                         list(dept_avg.items()), columns=["Department", "Avg Score"]
#                     )
#                     dept_df = dept_df.sort_values("Avg Score", ascending=True)

#                     fig, ax = plt.subplots(figsize=(12, 6))
#                     sns.barplot(
#                         data=dept_df,
#                         y="Department",
#                         x="Avg Score",
#                         palette="viridis",
#                         ax=ax,
#                     )

#                     # Add value labels
#                     for i, v in enumerate(dept_df["Avg Score"]):
#                         ax.text(v + 1, i, f"{v:.1f}%", va="center", fontweight="bold")

#                     ax.set_xlabel("Average Score (%)", fontsize=12, fontweight="bold")
#                     ax.set_ylabel("Department", fontsize=12, fontweight="bold")
#                     ax.set_title(
#                         "Average Performance by Department",
#                         fontsize=14,
#                         fontweight="bold",
#                     )
#                     ax.set_xlim(0, 105)
#                     plt.tight_layout()
#                     st.pyplot(fig)
#                     plt.close()

#         with tab5:  # Detailed Reports Tab
#             # Check if we're in supervisor report view mode
#             if "view_supervisor_eval_idx" in st.session_state:
#                 st.markdown("### 📊 Detailed Evaluation Report")

#                 # Back button
#                 if st.button(
#                     "← Back to Overall Reports", key="back_to_supervisor_reports"
#                 ):
#                     st.session_state.pop("view_supervisor_eval_idx", None)
#                     st.session_state.pop("supervisor_eval_data", None)
#                     st.rerun()

#                 eval_data = st.session_state.get("supervisor_eval_data")
#                 if eval_data:
#                     # Enhanced CSS for the detailed view (same as trainee view)
#                     st.markdown(
#                         """
#                         <style>
#                         .detail-container {
#                             background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
#                             border-radius: 15px;
#                             padding: 2rem;
#                             margin: 1rem 0;
#                             box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
#                             border: 1px solid rgba(255, 255, 255, 0.2);
#                         }
#                         .detail-header {
#                             background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
#                             color: white;
#                             padding: 1.5rem;
#                             border-radius: 12px;
#                             text-align: center;
#                             margin-bottom: 2rem;
#                             box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
#                         }
#                         .sheet-container {
#                             background: white;
#                             padding: 1rem;
#                             margin: 0.5rem 0;
#                             border-left: 3px solid #667eea;
#                         }
#                         .sheet-title {
#                             color: #2d3748;
#                             font-size: 1.3rem;
#                             font-weight: 600;
#                             margin-bottom: 1rem;
#                             padding-bottom: 0.5rem;
#                             border-bottom: 2px solid #e2e8f0;
#                             display: flex;
#                             align-items: center;
#                             gap: 0.5rem;
#                         }
#                         .chat-message {
#                             background: #f8fafc;
#                             border-radius: 6px;
#                             padding: 0.6rem 0.8rem;
#                             margin: 0.3rem 0;
#                             border-left: 3px solid #4299e1;
#                             font-size: 0.9rem;
#                             line-height: 1.4;
#                         }
#                         .chat-message.user {
#                             background: #e6f3ff;
#                             border-left-color: #3182ce;
#                         }
#                         .chat-message.assistant {
#                             background: #f0f9ff;
#                             border-left-color: #0ea5e9;
#                         }
#                         .chat-role {
#                             font-weight: 600;
#                             font-size: 0.75rem;
#                             color: #4a5568;
#                             margin-bottom: 0.3rem;
#                             text-transform: uppercase;
#                             letter-spacing: 0.3px;
#                         }
#                         .behavior-score {
#                             display: inline-block;
#                             background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
#                             color: white;
#                             padding: 0.3rem 1rem;
#                             border-radius: 20px;
#                             font-weight: 600;
#                             font-size: 0.9rem;
#                             margin: 0.2rem;
#                             box-shadow: 0 2px 4px rgba(72, 187, 120, 0.3);
#                         }
#                         .behavior-item {
#                             background: #f9fafb;
#                             border-radius: 4px;
#                             padding: 0.4rem;
#                             margin: 0.2rem 0;
#                             border-left: 3px solid #e5e7eb;
#                             font-size: 0.85rem;
#                         }
#                         .behavior-item:hover {
#                             background: #f3f4f6;
#                             border-color: #d1d5db;
#                         }
#                         .metadata-card {
#                             background: linear-gradient(135deg, #fef5e7 0%, #fed7aa 100%);
#                             border-radius: 10px;
#                             padding: 1rem;
#                             margin: 1rem 0;
#                             border-left: 4px solid #f59e0b;
#                         }
#                         </style>
#                         """,
#                         unsafe_allow_html=True,
#                     )

#                     st.markdown(
#                         '<div class="detail-container">', unsafe_allow_html=True
#                     )
#                     st.markdown(
#                         f'<div class="detail-header"><h2>📊 Detailed Evaluation Report - {eval_data.get("username", "N/A")}</h2></div>',
#                         unsafe_allow_html=True,
#                     )

#                     # Display session metadata in a card
#                     st.markdown(
#                         f"""
#                         <div class="metadata-card">
#                             <strong>📝 Session Information:</strong><br>
#                             <strong>Trainee:</strong> {eval_data.get('username', 'N/A')} | 
#                             <strong>Department:</strong> {eval_data.get('department', 'N/A')} | 
#                             <strong>Issue Type:</strong> {eval_data.get('issue_type', 'N/A')}<br>
#                             <strong>Tone:</strong> {eval_data.get('tone', 'N/A')} | 
#                             <strong>Date:</strong> {eval_data.get('timestamp', 'N/A')} | 
#                             <strong>Score:</strong> <span class="behavior-score">{format_eval_score(eval_data.get('eval_score', 'N/A')):.1f}%</span>
#                         </div>
#                         """,
#                         unsafe_allow_html=True,
#                     )

#                     excel_bytes = eval_data["excel_bytes"]
#                     with BytesIO(excel_bytes) as excel_io:
#                         wb = openpyxl.load_workbook(excel_io)

#                         for sheet_name in wb.sheetnames:
#                             st.markdown(
#                                 '<div class="sheet-container">', unsafe_allow_html=True
#                             )

#                             # Determine sheet icon
#                             if (
#                                 "chat" in sheet_name.lower()
#                                 or "conversation" in sheet_name.lower()
#                             ):
#                                 icon = "💬"
#                             elif (
#                                 "evaluation" in sheet_name.lower()
#                                 or "behavior" in sheet_name.lower()
#                             ):
#                                 icon = "📊"
#                             elif "metadata" in sheet_name.lower():
#                                 icon = "📋"
#                             else:
#                                 icon = "📄"

#                             st.markdown(
#                                 f'<div class="sheet-title">{icon} {sheet_name}</div>',
#                                 unsafe_allow_html=True,
#                             )

#                             ws = wb[sheet_name]
#                             data = list(ws.values)

#                             if data:
#                                 df = pd.DataFrame(data[1:], columns=data[0])

#                                 # Special formatting for different sheet types
#                                 if (
#                                     "chat" in sheet_name.lower()
#                                     or "conversation" in sheet_name.lower()
#                                 ):
#                                     # Enhanced chat history display
#                                     st.markdown("📝 **Chat Conversation:**")

#                                     if df.empty:
#                                         st.info("No chat history found in this sheet.")
#                                     else:
#                                         for _, row in df.iterrows():
#                                             # Try different possible column names
#                                             role = ""
#                                             content = ""

#                                             # Common column names for role
#                                             for role_col in [
#                                                 "Role",
#                                                 "role",
#                                                 "Speaker",
#                                                 "speaker",
#                                                 "User",
#                                                 "user",
#                                             ]:
#                                                 if role_col in df.columns and pd.notna(
#                                                     row.get(role_col)
#                                                 ):
#                                                     role = str(row[role_col]).strip()
#                                                     break

#                                             # Common column names for content
#                                             for content_col in [
#                                                 "Message",
#                                                 "message",
#                                                 "Content",
#                                                 "content",
#                                                 "Text",
#                                                 "text",
#                                             ]:
#                                                 if (
#                                                     content_col in df.columns
#                                                     and pd.notna(row.get(content_col))
#                                                 ):
#                                                     content = str(
#                                                         row[content_col]
#                                                     ).strip()
#                                                     break

#                                             if (
#                                                 content
#                                             ):  # Only display if we have content
#                                                 role_display = (
#                                                     role if role else "Unknown"
#                                                 )
#                                                 message_class = (
#                                                     "user"
#                                                     if "user" in role.lower()
#                                                     or "customer" in role.lower()
#                                                     else "assistant"
#                                                 )

#                                                 st.markdown(
#                                                     f"""
#                                                     <div class="chat-message {message_class}">
#                                                         <div class="chat-role">{role_display}</div>
#                                                         {content}
#                                                     </div>
#                                                     """,
#                                                     unsafe_allow_html=True,
#                                                 )

#                                 elif (
#                                     "evaluation" in sheet_name.lower()
#                                     or "behavior" in sheet_name.lower()
#                                     or "table" in sheet_name.lower()
#                                 ):
#                                     # Enhanced evaluation table display - exact same as associates
#                                     st.markdown("📊 **Behavior Evaluation Scores:**")

#                                     if df.empty:
#                                         st.info(
#                                             "No evaluation data found in this sheet."
#                                         )
#                                     else:
#                                         # Add column headers for 4-column layout
#                                         st.markdown(
#                                             """
#                                             <div class="behavior-item" style="background: #667eea; color: white; margin-bottom: 0.5rem;">
#                                                 <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem; table-layout: fixed;">
#                                                     <tr>
#                                                         <th style="font-weight: 600; padding: 0.6rem 0.5rem; text-align: center; width: 20%; border-right: 1px solid rgba(255,255,255,0.3);">
#                                                             📋 Behavior
#                                                         </th>
#                                                         <th style="font-weight: 600; padding: 0.6rem 0.5rem; text-align: center; width: 15%; border-right: 1px solid rgba(255,255,255,0.3);">
#                                                             🎯 Score
#                                                         </th>
#                                                         <th style="font-weight: 600; padding: 0.6rem 0.5rem; text-align: center; width: 30%; border-right: 1px solid rgba(255,255,255,0.3);">
#                                                             💬 Citation
#                                                         </th>
#                                                         <th style="font-weight: 600; padding: 0.6rem 0.5rem; text-align: center; width: 35%;">
#                                                             📝 Feedback
#                                                         </th>
#                                                     </tr>
#                                                 </table>
#                                             </div>
#                                             """,
#                                             unsafe_allow_html=True,
#                                         )

#                                         for _, row in df.iterrows():
#                                             # Try different possible column names with more flexibility
#                                             behavior = ""
#                                             criteria = ""
#                                             max_score = ""
#                                             score = ""
#                                             feedback = ""
#                                             reasoning = ""
#                                             citation = ""

#                                             # More comprehensive column matching
#                                             for col in df.columns:
#                                                 col_str = str(col).strip()
#                                                 col_lower = col_str.lower()
#                                                 row_value = (
#                                                     str(row[col]).strip()
#                                                     if not pd.isna(row[col])
#                                                     else ""
#                                                 )

#                                                 # Check for behavior column
#                                                 if not behavior and (
#                                                     "behavior" in col_lower
#                                                     or "behaviour" in col_lower
#                                                 ):
#                                                     behavior = row_value

#                                                 # Check for criteria column
#                                                 elif not criteria and (
#                                                     "criteria" in col_lower
#                                                     or "criterion" in col_lower
#                                                 ):
#                                                     criteria = row_value

#                                                 # Check for max score column
#                                                 elif not max_score and (
#                                                     "max" in col_lower
#                                                     and "score" in col_lower
#                                                 ):
#                                                     max_score = row_value

#                                                 # Check for score column
#                                                 elif not score and (
#                                                     col_lower == "score"
#                                                     or (
#                                                         col_lower.endswith("score")
#                                                         and "max" not in col_lower
#                                                     )
#                                                 ):
#                                                     score = row_value

#                                                 # Check for feedback/reasoning column - prioritize "Reason" column
#                                                 elif not feedback and (
#                                                     col_lower == "reason"
#                                                     or col_lower == "reasons"
#                                                     or any(
#                                                         pattern in col_lower
#                                                         for pattern in [
#                                                             "feedback",
#                                                             "comment",
#                                                             "remarks",
#                                                             "notes",
#                                                             "suggestion",
#                                                             "improvement",
#                                                             "reasoning",
#                                                         ]
#                                                     )
#                                                 ):
#                                                     feedback = row_value

#                                                 # Check for citation column
#                                                 elif not citation and any(
#                                                     pattern in col_lower
#                                                     for pattern in [
#                                                         "citation",
#                                                         "cite",
#                                                         "reference",
#                                                         "quote",
#                                                         "example",
#                                                     ]
#                                                 ):
#                                                     citation = row_value

#                                             # Fallback logic
#                                             if not behavior and len(df.columns) > 0:
#                                                 behavior = (
#                                                     str(row[df.columns[0]]).strip()
#                                                     if not pd.isna(row[df.columns[0]])
#                                                     else ""
#                                                 )

#                                             # Try to find score in any numeric column
#                                             if not score:
#                                                 for col in df.columns:
#                                                     try:
#                                                         val = str(row[col]).strip()
#                                                         if (
#                                                             val
#                                                             and val != "nan"
#                                                             and val.replace(".", "")
#                                                             .replace(",", "")
#                                                             .isdigit()
#                                                         ):
#                                                             score = val
#                                                             break
#                                                     except:
#                                                         continue

#                                             # Try to find feedback/reasoning in longer text columns - prioritize "Reason" column
#                                             if not feedback or feedback in [
#                                                 "nan",
#                                                 "None",
#                                                 "",
#                                                 "No feedback provided",
#                                                 "Performance evaluation criteria",
#                                             ]:
#                                                 # First, specifically look for "Reason" column
#                                                 for col in df.columns:
#                                                     col_lower = str(col).lower()
#                                                     if (
#                                                         col_lower == "reason"
#                                                         or col_lower == "reasons"
#                                                     ):
#                                                         val = (
#                                                             str(row[col]).strip()
#                                                             if not pd.isna(row[col])
#                                                             else ""
#                                                         )
#                                                         if val and val != "nan":
#                                                             feedback = val
#                                                             break

#                                                 # If still no feedback, look for other text columns
#                                                 if not feedback or feedback in [
#                                                     "nan",
#                                                     "None",
#                                                     "",
#                                                 ]:
#                                                     for col in df.columns:
#                                                         col_lower = str(col).lower()
#                                                         if any(
#                                                             skip in col_lower
#                                                             for skip in [
#                                                                 "behavior",
#                                                                 "behaviour",
#                                                                 "criteria",
#                                                                 "score",
#                                                                 "max",
#                                                                 "citation",
#                                                             ]
#                                                         ):
#                                                             continue

#                                                         val = (
#                                                             str(row[col]).strip()
#                                                             if not pd.isna(row[col])
#                                                             else ""
#                                                         )
#                                                         if (
#                                                             val
#                                                             and val != "nan"
#                                                             and len(val) > 15
#                                                         ):  # Look for substantial text
#                                                             feedback = val
#                                                             break

#                                             # Skip completely empty rows
#                                             if not behavior or behavior in [
#                                                 "nan",
#                                                 "None",
#                                                 "",
#                                             ]:
#                                                 continue

#                                             # Clean up values
#                                             max_score = (
#                                                 max_score
#                                                 if max_score
#                                                 and max_score not in ["nan", "None", ""]
#                                                 else "5"
#                                             )
#                                             score = (
#                                                 score
#                                                 if score
#                                                 and score not in ["nan", "None", ""]
#                                                 else "0"
#                                             )
#                                             feedback = (
#                                                 feedback
#                                                 if feedback
#                                                 and feedback
#                                                 not in [
#                                                     "nan",
#                                                     "None",
#                                                     "",
#                                                     "Performance evaluation criteria",
#                                                 ]
#                                                 else ""
#                                             )
#                                             citation = (
#                                                 citation
#                                                 if citation
#                                                 and citation not in ["nan", "None", ""]
#                                                 else ""
#                                             )

#                                             # Create 4-column table layout with full text wrapping (no truncation)
#                                             # Function to clean and prepare text for display
#                                             def clean_text(text):
#                                                 if not text or text in [
#                                                     "nan",
#                                                     "None",
#                                                     "",
#                                                 ]:
#                                                     return "<em>No data provided</em>"
#                                                 return (
#                                                     str(text)
#                                                     .strip()
#                                                     .replace("\n", "<br>")
#                                                 )

#                                             clean_behavior = clean_text(behavior)
#                                             clean_citation = clean_text(citation)
#                                             clean_feedback = clean_text(feedback)

#                                             st.markdown(
#                                                 f"""
#                                                 <div class="behavior-item">
#                                                     <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem; table-layout: fixed;">
#                                                         <tr style="vertical-align: top;">
#                                                             <td style="font-weight: 600; color: #2d3748; padding: 0.6rem 0.5rem; border-right: 1px solid #e5e7eb; width: 20%; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; line-height: 1.4;">
#                                                                 🎯 {clean_behavior}
#                                                             </td>
#                                                             <td style="text-align: center; padding: 0.6rem 0.5rem; border-right: 1px solid #e5e7eb; width: 15%; word-wrap: break-word; vertical-align: middle;">
#                                                                 <span class="behavior-score">{score}/{max_score}</span>
#                                                             </td>
#                                                             <td style="padding: 0.6rem 0.5rem; border-right: 1px solid #e5e7eb; width: 30%; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; font-style: italic; color: #4a5568; line-height: 1.4;">
#                                                                 💬 {clean_citation}
#                                                             </td>
#                                                             <td style="padding: 0.6rem 0.5rem; width: 35%; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; line-height: 1.4;">
#                                                                 {clean_feedback}
#                                                             </td>
#                                                         </tr>
#                                                     </table>
#                                                 </div>
#                                                 """,
#                                                 unsafe_allow_html=True,
#                                             )

#                                 else:
#                                     # Display other sheets as regular dataframes
#                                     if df.empty:
#                                         st.info(f"No data found in {sheet_name}.")
#                                     else:
#                                         st.dataframe(df, use_container_width=True)

#                             st.markdown("</div>", unsafe_allow_html=True)

#                     st.markdown("</div>", unsafe_allow_html=True)

#                     # Add back button at the bottom
#                     st.markdown("---")
#                     if st.button(
#                         "← Back to Overall Reports",
#                         key="bottom_back_to_supervisor_reports",
#                         type="primary",
#                     ):
#                         st.session_state.pop("view_supervisor_eval_idx", None)
#                         st.session_state.pop("supervisor_eval_data", None)
#                         st.rerun()
#             else:
#                 # Regular detailed reports view
#                 st.markdown("### 📋 Detailed Evaluation Reports")

#                 if filtered_data:
#                     # Search and filter options
#                     col1, col2 = st.columns([2, 1])

#                     with col1:
#                         search_term = st.text_input(
#                             "Search evaluations:",
#                             placeholder="Enter trainee name, department, etc.",
#                         )

#                     with col2:
#                         sort_by = st.selectbox(
#                             "Sort by:",
#                             ["Timestamp (Latest)", "Score (Highest)", "Trainee Name"],
#                         )

#                     # Filter and sort data
#                     display_data = filtered_data

#                     if search_term:
#                         display_data = [
#                             d
#                             for d in display_data
#                             if search_term.lower() in d["username"].lower()
#                             or search_term.lower() in d["department"].lower()
#                             or search_term.lower() in d["issue_type"].lower()
#                         ]

#                     # Sort data
#                     if sort_by == "Score (Highest)":
#                         display_data = sorted(
#                             display_data, key=lambda x: x["eval_score"], reverse=True
#                         )
#                     elif sort_by == "Trainee Name":
#                         display_data = sorted(display_data, key=lambda x: x["username"])
#                     # Default is already timestamp sorted

#                     # Pagination
#                     items_per_page = 10
#                     total_items = len(display_data)
#                     total_pages = (
#                         (total_items - 1) // items_per_page + 1
#                         if total_items > 0
#                         else 1
#                     )

#                     col1, col2, col3 = st.columns([1, 2, 1])
#                     with col2:
#                         page = st.selectbox("Page:", range(1, total_pages + 1))

#                     start_idx = (page - 1) * items_per_page
#                     end_idx = start_idx + items_per_page
#                     page_data = display_data[start_idx:end_idx]

#                     # Display detailed table
#                     for idx, evaluation in enumerate(page_data, start_idx + 1):
#                         score_val = format_eval_score(evaluation["eval_score"])
#                         with st.expander(
#                             f"#{idx} - {evaluation['username']} | {evaluation['department']} | Score: {score_val:.1f}%"
#                         ):
#                             col1, col2 = st.columns(2)

#                             with col1:
#                                 st.write(f"**Trainee:** {evaluation['username']}")
#                                 st.write(f"**Industry:** {evaluation['department']}")
#                                 st.write(
#                                     f"**Reason for Contact:** {evaluation['issue_type']}"
#                                 )

#                             with col2:
#                                 st.write(f"**Tone:** {evaluation['tone']}")
#                                 st.write(f"**Timestamp:** {evaluation['timestamp']}")
#                                 st.write(f"**Score:** {score_val:.1f}%")

#                             # Action buttons for individual evaluation
#                             button_col1, button_col2 = st.columns(2)

#                             with button_col1:
#                                 st.download_button(
#                                     label="📄 Download Session Report",
#                                     data=evaluation["excel_bytes"],
#                                     file_name=f"{evaluation['username']}_{evaluation['filename']}",
#                                     mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
#                                     key=f"download_{idx}",
#                                 )

#                             with button_col2:
#                                 if st.button(
#                                     "👁️ View Report",
#                                     key=f"view_supervisor_eval_{idx}",
#                                     help="View detailed evaluation report",
#                                 ):
#                                     st.session_state["view_supervisor_eval_idx"] = idx
#                                     st.session_state["supervisor_eval_data"] = (
#                                         evaluation
#                                     )
#                                     st.rerun()

#                     # Summary at bottom
#                     st.markdown("---")
#                     st.markdown(
#                         f"Showing {len(page_data)} of {total_items} evaluations"
#                     )

#         st.stop()

#     # --- Trainee UI (original main UI) ---
#     # 🚀 PERFORMANCE OPTIMIZATION: In-memory caching implemented for trainee evaluations
#     # - Performance Evaluation button: Loads from GCP and caches in session state
#     # - Subsequent views: Uses cached data for instant response
#     # - Cache automatically cleared on logout to free memory
#     # - Clears both gcs_evaluations and related performance evaluation session keys

#     # --- Sidebar: Eval Summary Button ---
#     if "show_eval_summary" not in st.session_state:
#         st.session_state["show_eval_summary"] = False

#     if st.sidebar.button("Performance Evaluation"):
#         st.session_state["show_eval_summary"] = True
#         st.session_state.pop("view_eval_idx", None)

#         # 🚀 NEW: Load evaluations from GCS for current user
#         username = st.session_state.get("username", "")
#         if username:
#             with st.spinner("Loading evaluations from cloud storage..."):
#                 gcs_manager = get_gcs_storage_manager()

#                 if gcs_manager.is_connected():
#                     # Load all evaluations for this user from GCS
#                     gcs_evaluations = gcs_manager.load_user_evaluations(username)
#                     print(
#                         f"[DEBUG] 📊 Loaded {len(gcs_evaluations)} evaluations from GCS for {username}"
#                     )

#                     # Store in session state for the performance evaluation display
#                     st.session_state["gcs_evaluations"] = gcs_evaluations

#                     if gcs_evaluations:
#                         st.sidebar.success(
#                             f"✅ Loaded {len(gcs_evaluations)} evaluation(s)"
#                         )
#                     else:
#                         st.sidebar.info("ℹ️ No evaluations found")
#                 else:
#                     st.sidebar.error("⚠️ Cloud storage unavailable")
#                     st.session_state["gcs_evaluations"] = []
#         else:
#             st.sidebar.warning("⚠️ Please login first")
#             st.session_state["gcs_evaluations"] = []

#         st.rerun()

#     # Sidebar: Back to Chat button if in summary or preview mode
#     if (
#         st.session_state.get("show_eval_summary", False)
#         or "view_eval_idx" in st.session_state
#     ):
#         if st.sidebar.button("Back to Chat Session", key="sidebar_back_to_chat"):
#             st.session_state.pop("show_eval_summary", None)
#             st.session_state.pop("view_eval_idx", None)
#             st.rerun()

#     # --- Main area: Show Eval Summary Table or Excel preview if requested ---
#     if st.session_state.get("show_eval_summary", False):
#         # Only show summary table or Excel preview, hide chat UI
#         if "view_eval_idx" not in st.session_state:
#             st.title("Performance Evaluation Summary")

#             # 🚀 NEW: Use GCS-loaded evaluations instead of session state
#             username = st.session_state.get("username", "")
#             gcs_evaluations = st.session_state.get("gcs_evaluations", [])

#             if gcs_evaluations:
#                 st.info(
#                     f"📊 Showing {len(gcs_evaluations)} evaluation(s) for {username}"
#                 )

#                 # Convert GCS evaluation data to display format
#                 summary_rows = []
#                 for display_idx, entry in enumerate(gcs_evaluations, 1):
#                     summary_rows.append(
#                         {
#                             "S.No": display_idx,
#                             "Username": entry.get("username", ""),
#                             "Timestamp": entry.get("timestamp", ""),
#                             "Industry": entry.get("department", ""),
#                             "Reason for Contact": format_display_name(
#                                 entry.get("issue_type", "")
#                             ),
#                             "Tone": entry.get("tone", ""),
#                             "Eval Score (%)": format_eval_score(
#                                 entry.get("eval_score", "")
#                             ),
#                         }
#                     )
#                 columns = list(summary_rows[0].keys()) + ["Chat/Eval"]
#                 st.markdown(
#                     """
#                     <style>
#                     .eval-table-container {
#                         border-radius: 12px;
#                         overflow: hidden;
#                         box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
#                         margin: 1rem 0;
#                         border: 1px solid #e1e8ed;
#                     }
#                     .eval-header {
#                         background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
#                         color: white;
#                         font-weight: 600;
#                         font-size: 14px;
#                         padding: 1rem 0.8rem;
#                         text-align: center;
#                         border: none;
#                         text-transform: uppercase;
#                         letter-spacing: 0.5px;
#                         position: relative;
#                         overflow: hidden;
#                     }
#                     .eval-header::before {
#                         content: '';
#                         position: absolute;
#                         top: 0;
#                         left: -100%;
#                         width: 100%;
#                         height: 100%;
#                         background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
#                         transition: left 0.5s;
#                     }
#                     .eval-header:hover::before {
#                         left: 100%;
#                     }
#                     .eval-row {
#                         background: #ffffff;
#                         border-bottom: 1px solid #f0f4f8;
#                         padding: 0.8rem;
#                         transition: all 0.3s ease;
#                         position: relative;
#                         font-size: 14px;
#                         color: #2d3748;
#                     }
#                     .eval-row:nth-child(even) {
#                         background: #f8fafc;
#                     }
#                     .eval-row:hover {
#                         background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
#                         transform: translateY(-1px);
#                         box-shadow: 0 2px 8px rgba(102, 126, 234, 0.15);
#                         border-left: 4px solid #667eea;
#                         padding-left: 0.6rem;
#                     }
#                     .eval-row:last-child {
#                         border-bottom: none;
#                         border-radius: 0 0 12px 12px;
#                     }
#                     .eval-score {
#                         font-weight: 600;
#                         padding: 0.3rem 0.8rem;
#                         border-radius: 20px;
#                         background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
#                         color: white;
#                         display: inline-block;
#                         min-width: 60px;
#                         text-align: center;
#                         box-shadow: 0 2px 4px rgba(72, 187, 120, 0.3);
#                     }
#                     .eval-button {
#                         background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
#                         color: white;
#                         border: none;
#                         padding: 0.5rem 1rem;
#                         border-radius: 8px;
#                         font-weight: 500;
#                         cursor: pointer;
#                         transition: all 0.3s ease;
#                         box-shadow: 0 2px 4px rgba(66, 153, 225, 0.3);
#                     }
#                     .eval-button:hover {
#                         transform: translateY(-2px);
#                         box-shadow: 0 4px 12px rgba(66, 153, 225, 0.4);
#                         background: linear-gradient(135deg, #3182ce 0%, #2d70b3 100%);
#                     }
#                     </style>
#                 """,
#                     unsafe_allow_html=True,
#                 )
#                 # Create table with enhanced styling
#                 st.markdown(
#                     '<div class="eval-table-container">', unsafe_allow_html=True
#                 )

#                 header_cols = st.columns(len(columns))
#                 for i, col in enumerate(columns):
#                     header_cols[i].markdown(
#                         f'<div class="eval-header">{col}</div>', unsafe_allow_html=True
#                     )

#                 for row_idx, row in enumerate(summary_rows):
#                     row_cols = st.columns(len(columns))
#                     for i, col in enumerate(columns[:-1]):
#                         if col == "Eval Score (%)":
#                             # Special styling for score column
#                             score_value = row[col]
#                             row_cols[i].markdown(
#                                 f'<div class="eval-row"><span class="eval-score">{score_value:.1f}%</span></div>',
#                                 unsafe_allow_html=True,
#                             )
#                         else:
#                             row_cols[i].markdown(
#                                 f'<div class="eval-row">{row[col]}</div>',
#                                 unsafe_allow_html=True,
#                             )
#                     # View button with custom styling
#                     with row_cols[-1]:
#                         st.markdown('<div class="eval-row">', unsafe_allow_html=True)
#                         if st.button(
#                             "👁️ View",
#                             key=f"view_excel_{row_idx+1}",
#                             help="View detailed evaluation",
#                         ):
#                             st.session_state["view_eval_idx"] = (
#                                 row_idx  # Use the correct 0-based index
#                             )
#                             st.session_state["show_eval_summary"] = True
#                             st.rerun()
#                         st.markdown("</div>", unsafe_allow_html=True)

#                 st.markdown("</div>", unsafe_allow_html=True)
#                 st.markdown("---")
#             else:
#                 st.info("No evaluation records found for this user/session.")
#         else:
#             # Excel preview page with enhanced styling
#             idx = st.session_state["view_eval_idx"]
#             # 🚀 NEW: Use GCS-loaded evaluations instead of filtered session state
#             gcs_evaluations = st.session_state.get("gcs_evaluations", [])
#             if 0 <= idx < len(gcs_evaluations):
#                 # Enhanced CSS for the detailed view
#                 st.markdown(
#                     """
#                     <style>
#                     .detail-container {
#                         background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
#                         border-radius: 15px;
#                         padding: 2rem;
#                         margin: 1rem 0;
#                         box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
#                         border: 1px solid rgba(255, 255, 255, 0.2);
#                     }
#                     .detail-header {
#                         background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
#                         color: white;
#                         padding: 1.5rem;
#                         border-radius: 12px;
#                         text-align: center;
#                         margin-bottom: 2rem;
#                         box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
#                     }
#                     .sheet-container {
#                         background: white;
#                         padding: 1rem;
#                         margin: 0.5rem 0;
#                         border-left: 3px solid #667eea;
#                     }
#                     .sheet-title {
#                         color: #2d3748;
#                         font-size: 1.3rem;
#                         font-weight: 600;
#                         margin-bottom: 1rem;
#                         padding-bottom: 0.5rem;
#                         border-bottom: 2px solid #e2e8f0;
#                         display: flex;
#                         align-items: center;
#                         gap: 0.5rem;
#                     }
#                     .chat-message {
#                         background: #f8fafc;
#                         border-radius: 6px;
#                         padding: 0.6rem 0.8rem;
#                         margin: 0.3rem 0;
#                         border-left: 3px solid #4299e1;
#                         font-size: 0.9rem;
#                         line-height: 1.4;
#                     }
#                     .chat-message.user {
#                         background: #e6f3ff;
#                         border-left-color: #3182ce;
#                     }
#                     .chat-message.assistant {
#                         background: #f0f9ff;
#                         border-left-color: #0ea5e9;
#                     }
#                     .chat-role {
#                         font-weight: 600;
#                         font-size: 0.75rem;
#                         color: #4a5568;
#                         margin-bottom: 0.3rem;
#                         text-transform: uppercase;
#                         letter-spacing: 0.3px;
#                     }
#                     .behavior-score {
#                         display: inline-block;
#                         background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
#                         color: white;
#                         padding: 0.3rem 1rem;
#                         border-radius: 20px;
#                         font-weight: 600;
#                         font-size: 0.9rem;
#                         margin: 0.2rem;
#                         box-shadow: 0 2px 4px rgba(72, 187, 120, 0.3);
#                     }
#                     .behavior-item {
#                         background: #f9fafb;
#                         border-radius: 4px;
#                         padding: 0.4rem;
#                         margin: 0.2rem 0;
#                         border-left: 3px solid #e5e7eb;
#                         font-size: 0.85rem;
#                     }
#                     .behavior-item:hover {
#                         background: #f3f4f6;
#                         border-color: #d1d5db;
#                     }
#                     .back-button {
#                         background: linear-gradient(135deg, #ed8936 0%, #dd6b20 100%);
#                         color: white;
#                         border: none;
#                         padding: 0.8rem 2rem;
#                         border-radius: 25px;
#                         font-weight: 600;
#                         cursor: pointer;
#                         transition: all 0.3s ease;
#                         box-shadow: 0 4px 15px rgba(237, 137, 54, 0.3);
#                         margin: 2rem 0;
#                     }
#                     .back-button:hover {
#                         transform: translateY(-2px);
#                         box-shadow: 0 6px 20px rgba(237, 137, 54, 0.4);
#                     }
#                     .metadata-card {
#                         background: linear-gradient(135deg, #fef5e7 0%, #fed7aa 100%);
#                         border-radius: 10px;
#                         padding: 1rem;
#                         margin: 1rem 0;
#                         border-left: 4px solid #f59e0b;
#                     }
#                     </style>
#                     """,
#                     unsafe_allow_html=True,
#                 )

#                 st.markdown('<div class="detail-container">', unsafe_allow_html=True)
#                 st.markdown(
#                     f'<div class="detail-header"><h2>📊 Detailed Evaluation Report #{idx+1}</h2></div>',
#                     unsafe_allow_html=True,
#                 )

#                 # Display session metadata in a card
#                 eval_entry = gcs_evaluations[idx]
#                 st.markdown(
#                     f"""
#                     <div class="metadata-card">
#                         <strong>📝 Session Information:</strong><br>
#                         <strong>Trainee:</strong> {eval_entry.get('username', 'N/A')} | 
#                         <strong>Department:</strong> {eval_entry.get('department', 'N/A')} | 
#                         <strong>Issue Type:</strong> {eval_entry.get('issue_type', 'N/A')}<br>
#                         <strong>Tone:</strong> {eval_entry.get('tone', 'N/A')} | 
#                         <strong>Date:</strong> {eval_entry.get('timestamp', 'N/A')} | 
#                         <strong>Score:</strong> <span class="behavior-score">{format_eval_score(eval_entry.get('eval_score', 'N/A')):.1f}%</span>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )

#                 excel_bytes = gcs_evaluations[idx]["excel_bytes"]
#                 with BytesIO(excel_bytes) as excel_io:
#                     wb = openpyxl.load_workbook(excel_io)

#                     for sheet_name in wb.sheetnames:
#                         st.markdown(
#                             '<div class="sheet-container">', unsafe_allow_html=True
#                         )

#                         # Determine sheet icon
#                         if (
#                             "chat" in sheet_name.lower()
#                             or "conversation" in sheet_name.lower()
#                         ):
#                             icon = "💬"
#                         elif (
#                             "evaluation" in sheet_name.lower()
#                             or "behavior" in sheet_name.lower()
#                         ):
#                             icon = "📊"
#                         elif "metadata" in sheet_name.lower():
#                             icon = "📋"
#                         else:
#                             icon = "📄"

#                         st.markdown(
#                             f'<div class="sheet-title">{icon} {sheet_name}</div>',
#                             unsafe_allow_html=True,
#                         )

#                         ws = wb[sheet_name]
#                         data = list(ws.values)

#                         if data:
#                             df = pd.DataFrame(data[1:], columns=data[0])

#                             # Debug: Print sheet info
#                             print(
#                                 f"[DEBUG] Sheet: {sheet_name}, Columns: {list(df.columns)}"
#                             )
#                             print(f"[DEBUG] Data shape: {df.shape}")

#                             # Special formatting for different sheet types
#                             if (
#                                 "chat" in sheet_name.lower()
#                                 or "conversation" in sheet_name.lower()
#                             ):
#                                 # Enhanced chat history display
#                                 st.markdown("📝 **Chat Conversation:**")

#                                 if df.empty:
#                                     st.info("No chat history found in this sheet.")
#                                 else:
#                                     for _, row in df.iterrows():
#                                         # Try different possible column names
#                                         role = ""
#                                         content = ""

#                                         # Check for role column
#                                         for col in df.columns:
#                                             col_lower = str(col).lower()
#                                             if "role" in col_lower:
#                                                 role = (
#                                                     str(row[col]).lower()
#                                                     if not pd.isna(row[col])
#                                                     else ""
#                                                 )
#                                                 break

#                                         # Check for content column
#                                         for col in df.columns:
#                                             col_lower = str(col).lower()
#                                             if (
#                                                 "content" in col_lower
#                                                 or "message" in col_lower
#                                             ):
#                                                 content = (
#                                                     str(row[col])
#                                                     if not pd.isna(row[col])
#                                                     else ""
#                                                 )
#                                                 break

#                                         # Skip empty rows
#                                         if not content or content == "nan":
#                                             continue

#                                         role_icon = "👤" if role == "user" else "🤖"
#                                         role_label = (
#                                             "Support Representative"
#                                             if role == "user"
#                                             else "AI Customer"
#                                         )

#                                         st.markdown(
#                                             f"""
#                                             <div class="chat-message {role}">
#                                                 <div class="chat-role">{role_icon} {role_label}</div>
#                                                 <div>{content}</div>
#                                             </div>
#                                             """,
#                                             unsafe_allow_html=True,
#                                         )

#                             elif (
#                                 "evaluation" in sheet_name.lower()
#                                 or "behavior" in sheet_name.lower()
#                                 or "table" in sheet_name.lower()
#                             ):
#                                 # Enhanced evaluation table display
#                                 st.markdown("🎯 **Behavior Evaluation Scores:**")

#                                 if df.empty:
#                                     st.info("No evaluation data found in this sheet.")
#                                 else:
#                                     # Add column headers for 4-column layout
#                                     st.markdown(
#                                         """
#                                         <div class="behavior-item" style="background: #667eea; color: white; margin-bottom: 0.5rem;">
#                                             <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem; table-layout: fixed;">
#                                                 <tr>
#                                                     <th style="font-weight: 600; padding: 0.6rem 0.5rem; text-align: center; width: 20%; border-right: 1px solid rgba(255,255,255,0.3);">
#                                                         📋 Behavior
#                                                     </th>
#                                                     <th style="font-weight: 600; padding: 0.6rem 0.5rem; text-align: center; width: 15%; border-right: 1px solid rgba(255,255,255,0.3);">
#                                                         🎯 Score
#                                                     </th>
#                                                     <th style="font-weight: 600; padding: 0.6rem 0.5rem; text-align: center; width: 30%; border-right: 1px solid rgba(255,255,255,0.3);">
#                                                         💬 Citation
#                                                     </th>
#                                                     <th style="font-weight: 600; padding: 0.6rem 0.5rem; text-align: center; width: 35%;">
#                                                         📝 Feedback
#                                                     </th>
#                                                 </tr>
#                                             </table>
#                                         </div>
#                                         """,
#                                         unsafe_allow_html=True,
#                                     )

#                                     # Debug: Show all available columns
#                                     print(
#                                         f"[DEBUG] Available columns in {sheet_name}: {list(df.columns)}"
#                                     )
#                                     print(f"[DEBUG] First few rows: {df.head()}")

#                                     for _, row in df.iterrows():
#                                         # Try different possible column names with more flexibility
#                                         behavior = ""
#                                         criteria = ""
#                                         max_score = ""
#                                         score = ""
#                                         feedback = ""
#                                         reasoning = ""
#                                         citation = ""

#                                         # Print all row data for debugging
#                                         print(f"[DEBUG] Row data: {dict(row)}")

#                                         # More comprehensive column matching
#                                         for col in df.columns:
#                                             col_str = str(col).strip()
#                                             col_lower = col_str.lower()
#                                             row_value = (
#                                                 str(row[col]).strip()
#                                                 if not pd.isna(row[col])
#                                                 else ""
#                                             )

#                                             # Check for behavior column
#                                             if not behavior and (
#                                                 "behavior" in col_lower
#                                                 or "behaviour" in col_lower
#                                             ):
#                                                 behavior = row_value

#                                             # Check for criteria column
#                                             elif not criteria and (
#                                                 "criteria" in col_lower
#                                                 or "criterion" in col_lower
#                                             ):
#                                                 criteria = row_value

#                                             # Check for max score column
#                                             elif not max_score and (
#                                                 "max" in col_lower
#                                                 and "score" in col_lower
#                                             ):
#                                                 max_score = row_value

#                                             # Check for score column
#                                             elif not score and (
#                                                 col_lower == "score"
#                                                 or (
#                                                     col_lower.endswith("score")
#                                                     and "max" not in col_lower
#                                                 )
#                                             ):
#                                                 score = row_value

#                                             # Check for feedback/reasoning column - prioritize "Reason" column
#                                             elif not feedback and (
#                                                 col_lower == "reason"
#                                                 or col_lower == "reasons"
#                                                 or any(
#                                                     pattern in col_lower
#                                                     for pattern in [
#                                                         "feedback",
#                                                         "comment",
#                                                         "remarks",
#                                                         "notes",
#                                                         "suggestion",
#                                                         "improvement",
#                                                         "reasoning",
#                                                     ]
#                                                 )
#                                             ):
#                                                 feedback = row_value

#                                             # Check for citation column
#                                             elif not citation and any(
#                                                 pattern in col_lower
#                                                 for pattern in [
#                                                     "citation",
#                                                     "cite",
#                                                     "reference",
#                                                     "quote",
#                                                     "example",
#                                                 ]
#                                             ):
#                                                 citation = row_value

#                                         # Fallback logic
#                                         if not behavior and len(df.columns) > 0:
#                                             behavior = (
#                                                 str(row[df.columns[0]]).strip()
#                                                 if not pd.isna(row[df.columns[0]])
#                                                 else ""
#                                             )

#                                         # Try to find score in any numeric column
#                                         if not score:
#                                             for col in df.columns:
#                                                 try:
#                                                     val = str(row[col]).strip()
#                                                     if (
#                                                         val
#                                                         and val != "nan"
#                                                         and val.replace(".", "")
#                                                         .replace(",", "")
#                                                         .isdigit()
#                                                     ):
#                                                         score = val
#                                                         break
#                                                 except:
#                                                     continue

#                                         # Try to find feedback/reasoning in longer text columns - prioritize "Reason" column
#                                         if not feedback or feedback in [
#                                             "nan",
#                                             "None",
#                                             "",
#                                             "No feedback provided",
#                                             "Performance evaluation criteria",
#                                         ]:
#                                             # First, check specifically for "Reason" or "Reasons" columns
#                                             for col in df.columns:
#                                                 col_lower = str(col).lower()
#                                                 if (
#                                                     col_lower == "reason"
#                                                     or col_lower == "reasons"
#                                                 ):
#                                                     val = (
#                                                         str(row[col]).strip()
#                                                         if not pd.isna(row[col])
#                                                         else ""
#                                                     )
#                                                     if val and val != "nan":
#                                                         feedback = val
#                                                         break

#                                             # If still no feedback, try other text columns
#                                             if not feedback or feedback in [
#                                                 "nan",
#                                                 "None",
#                                                 "",
#                                             ]:
#                                                 for col in df.columns:
#                                                     col_lower = str(col).lower()
#                                                     if any(
#                                                         skip in col_lower
#                                                         for skip in [
#                                                             "behavior",
#                                                             "behaviour",
#                                                             "criteria",
#                                                             "score",
#                                                             "max",
#                                                         ]
#                                                     ):
#                                                         continue

#                                                     val = (
#                                                         str(row[col]).strip()
#                                                         if not pd.isna(row[col])
#                                                         else ""
#                                                     )
#                                                     if (
#                                                         val
#                                                         and val != "nan"
#                                                         and len(val) > 15
#                                                     ):  # Look for substantial text
#                                                         feedback = val
#                                                         break

#                                         # Skip completely empty rows
#                                         if not behavior or behavior in [
#                                             "nan",
#                                             "None",
#                                             "",
#                                         ]:
#                                             continue

#                                         # Clean up values
#                                         max_score = (
#                                             max_score
#                                             if max_score
#                                             and max_score not in ["nan", "None", ""]
#                                             else "5"
#                                         )
#                                         score = (
#                                             score
#                                             if score
#                                             and score not in ["nan", "None", ""]
#                                             else "0"
#                                         )
#                                         feedback = (
#                                             feedback
#                                             if feedback
#                                             and feedback
#                                             not in [
#                                                 "nan",
#                                                 "None",
#                                                 "",
#                                                 "Performance evaluation criteria",
#                                             ]
#                                             else ""
#                                         )
#                                         citation = (
#                                             citation
#                                             if citation
#                                             and citation not in ["nan", "None", ""]
#                                             else ""
#                                         )

#                                         # Debug print the extracted values
#                                         print(
#                                             f"[DEBUG] Extracted - Behavior: {behavior}, Score: {score}, Feedback: {feedback[:100]}..., Citation: {citation[:50]}..."
#                                         )

#                                         # Create 4-column table layout with full text wrapping (no truncation)
#                                         # Function to clean and prepare text for display
#                                         def clean_text(text):
#                                             if not text or text in ["nan", "None", ""]:
#                                                 return "<em>No data provided</em>"
#                                             return (
#                                                 str(text).strip().replace("\n", "<br>")
#                                             )

#                                         clean_behavior = clean_text(behavior)
#                                         clean_citation = clean_text(citation)
#                                         clean_feedback = clean_text(feedback)

#                                         st.markdown(
#                                             f"""
#                                             <div class="behavior-item">
#                                                 <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem; table-layout: fixed;">
#                                                     <tr style="vertical-align: top;">
#                                                         <td style="font-weight: 600; color: #2d3748; padding: 0.6rem 0.5rem; border-right: 1px solid #e5e7eb; width: 20%; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; line-height: 1.4;">
#                                                             🎯 {clean_behavior}
#                                                         </td>
#                                                         <td style="text-align: center; padding: 0.6rem 0.5rem; border-right: 1px solid #e5e7eb; width: 15%; word-wrap: break-word; vertical-align: middle;">
#                                                             <span class="behavior-score">{score}/{max_score}</span>
#                                                         </td>
#                                                         <td style="padding: 0.6rem 0.5rem; border-right: 1px solid #e5e7eb; width: 30%; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; font-style: italic; color: #4a5568; line-height: 1.4;">
#                                                             💬 {clean_citation}
#                                                         </td>
#                                                         <td style="padding: 0.6rem 0.5rem; width: 35%; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; line-height: 1.4;">
#                                                             {clean_feedback}
#                                                         </td>
#                                                     </tr>
#                                                 </table>
#                                             </div>
#                                             """,
#                                             unsafe_allow_html=True,
#                                         )
#                             else:
#                                 # Regular table display for other sheets
#                                 st.markdown(f"📋 **{sheet_name} Data:**")
#                                 st.dataframe(df, use_container_width=True)
#                         else:
#                             st.info("No data in this sheet.")

#                         st.markdown("</div>", unsafe_allow_html=True)

#                 st.markdown("</div>", unsafe_allow_html=True)

#                 # Enhanced back button
#                 st.markdown("---")
#                 col1, col2, col3 = st.columns([1, 1, 1])
#                 with col2:
#                     if st.button(
#                         "⬅️ Back to Summary",
#                         key="back_to_summary_btn",
#                         help="Return to evaluation summary",
#                     ):
#                         st.session_state.pop("view_eval_idx", None)
#                         st.session_state["show_eval_summary"] = True
#                         st.rerun()
#             st.stop()
#         # Do not show chat UI when summary is active
#         # --- Plots below summary table ---
#         st.markdown("---")
#         # ---- Eval Score Trend ----
#         st.markdown("### 📈 Evaluation Score Trend (Line Graph)")
#         # Reverse the order for chronological display (oldest to newest)
#         gcs_evaluations = st.session_state.get("gcs_evaluations", [])
#         scores = [
#             float(entry.get("eval_score", "0").replace("%", ""))
#             for entry in reversed(gcs_evaluations)
#         ]
#         if scores:
#             # Create a clean, modern line plot with seaborn
#             plot_df = pd.DataFrame(
#                 {"Trial": np.arange(1, len(scores) + 1), "Score": scores}
#             )

#             # Set the style and color palette
#             sns.set_style("whitegrid")
#             plt.style.use("seaborn-v0_8")

#             # Calculate dynamic figure size
#             fig_width = max(8, min(12, len(scores) * 1.2))
#             fig_height = 5

#             fig, ax = plt.subplots(figsize=(fig_width, fig_height))

#             # Create the line plot with enhanced styling
#             line_plot = sns.lineplot(
#                 data=plot_df,
#                 x="Trial",
#                 y="Score",
#                 marker="o",
#                 markersize=8,
#                 linewidth=3,
#                 color="#2E86AB",
#                 ax=ax,
#             )

#             # Fill area under the curve for better visual appeal
#             ax.fill_between(
#                 plot_df["Trial"], plot_df["Score"], alpha=0.3, color="#2E86AB"
#             )

#             # Add value annotations on each point
#             for x, y in zip(plot_df["Trial"], plot_df["Score"]):
#                 ax.annotate(
#                     f"{y:.1f}%",
#                     (x, y),
#                     textcoords="offset points",
#                     xytext=(0, 10),
#                     ha="center",
#                     fontsize=10,
#                     fontweight="bold",
#                     bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8),
#                 )

#             # Customize the plot
#             ax.set_xlabel("Training Session", fontsize=12, fontweight="bold")
#             ax.set_ylabel("Evaluation Score (%)", fontsize=12, fontweight="bold")
#             ax.set_title(
#                 "Performance Trend Across Training Sessions",
#                 fontsize=14,
#                 fontweight="bold",
#                 pad=20,
#             )

#             # Set axis limits and ticks
#             ax.set_xlim(0.5, len(scores) + 0.5)
#             ax.set_ylim(0, 105)
#             ax.set_xticks(plot_df["Trial"])
#             ax.set_yticks(np.arange(0, 101, 10))

#             # Customize grid
#             ax.grid(True, linestyle="--", alpha=0.7, color="gray")
#             ax.set_axisbelow(True)

#             # Add a horizontal line for average score
#             avg_score = np.mean(scores)
#             ax.axhline(y=avg_score, color="red", linestyle="--", alpha=0.7, linewidth=2)
#             ax.text(
#                 len(scores),
#                 avg_score,
#                 f"Avg: {avg_score:.1f}%",
#                 verticalalignment="bottom",
#                 fontsize=10,
#                 color="red",
#                 fontweight="bold",
#             )

#             # Improve tick labels
#             ax.tick_params(axis="both", which="major", labelsize=10)

#             plt.tight_layout()
#             st.pyplot(fig)
#             plt.close()
#         else:
#             st.info("No evaluation scores to plot.")

#         st.markdown("---")
#         # ---- Behavior Scores Histogram ----
#         st.markdown("### 🏆 Behavior Scores (Average)")

#         behavior_totals = {}
#         behavior_counts = {}
#         total_sessions = len(gcs_evaluations)

#         for entry in gcs_evaluations:
#             eb = entry.get("excel_bytes")
#             if eb:
#                 with BytesIO(eb) as io:
#                     wb = openpyxl.load_workbook(io, data_only=True)
#                     if "Evaluation Table" in wb.sheetnames:
#                         ws = wb["Evaluation Table"]
#                         for r in ws.iter_rows(min_row=2, values_only=True):
#                             b, _, mx, sc, *_ = r
#                             try:
#                                 sc = float(sc)
#                                 if b:
#                                     behavior_totals[b] = behavior_totals.get(b, 0) + sc
#                                     behavior_counts[b] = behavior_counts.get(b, 0) + 1
#                             except:
#                                 continue

#         # Display session summary before the graph
#         st.info(
#             f"📊 **Analysis Summary:** {total_sessions} total training sessions completed"
#         )

#         if behavior_totals:
#             behaviors = list(behavior_totals.keys())
#             # Calculate averages instead of totals
#             avg_scores = [behavior_totals[b] / behavior_counts[b] for b in behaviors]
#             session_counts = [behavior_counts[b] for b in behaviors]

#             plot_df = pd.DataFrame(
#                 {
#                     "Behavior": behaviors,
#                     "Average Score": avg_scores,
#                     "Sessions": session_counts,
#                 }
#             )

#             # Sort by average score for better visualization
#             plot_df = plot_df.sort_values("Average Score", ascending=True)

#             # Set the style
#             sns.set_style("whitegrid")
#             plt.style.use("seaborn-v0_8")

#             # Calculate dynamic figure size based on number of behaviors
#             fig_height = max(6, len(behaviors) * 0.6)
#             fig_width = 12

#             fig, ax = plt.subplots(figsize=(fig_width, fig_height))

#             # Create a beautiful horizontal bar plot
#             bars = sns.barplot(
#                 data=plot_df,
#                 y="Behavior",
#                 x="Average Score",
#                 ax=ax,
#                 palette="viridis",
#                 orient="h",
#             )

#             # Add value labels on the bars with session count
#             for i, (behavior, avg_score, session_count) in enumerate(
#                 zip(plot_df["Behavior"], plot_df["Average Score"], plot_df["Sessions"])
#             ):
#                 ax.text(
#                     avg_score + max(avg_scores) * 0.01,
#                     i,
#                     f"{avg_score:.1f} ({session_count} sessions)",
#                     va="center",
#                     ha="left",
#                     fontsize=10,
#                     fontweight="bold",
#                 )

#             # Customize the plot
#             ax.set_xlabel("Average Score", fontsize=12, fontweight="bold")
#             ax.set_ylabel("Behavior", fontsize=12, fontweight="bold")
#             ax.set_title(
#                 "Average Behavior Performance Scores",
#                 fontsize=14,
#                 fontweight="bold",
#                 pad=20,
#             )

#             # Improve the y-axis labels (behavior names)
#             ax.tick_params(axis="y", labelsize=10)
#             ax.tick_params(axis="x", labelsize=10)

#             # Set x-axis limits with some padding
#             ax.set_xlim(0, max(avg_scores) * 1.15)

#             # Customize grid
#             ax.grid(True, linestyle="--", alpha=0.7, color="gray", axis="x")
#             ax.set_axisbelow(True)

#             # Add a subtle background color gradient
#             for i, bar in enumerate(bars.patches):
#                 bar.set_edgecolor("white")
#                 bar.set_linewidth(1)

#             plt.tight_layout()
#             st.pyplot(fig)
#             plt.close()
#         else:
#             st.info("No behavior scores to plot.")

#         st.stop()
#     st.set_page_config(
#         page_title="AI Customer Support Trainer", page_icon="🎯", layout="wide"
#     )

#     st.title("🎯 AI Customer Support Trainer")
#     st.markdown(
#         "<h3 style='font-size: 24px; font-weight: 600; color: #2E86AB; margin-bottom: 30px;'>Practice your customer support skills with AI-powered customer training simulator</h3>",
#         unsafe_allow_html=True,
#     )

#     db = get_faiss_db()
#     dept_theme_map = CustomerSupportTrainer.get_department_theme_map(db)

#     # Remove duplicates and convert to camel case for departments
#     def normalize_key(s):
#         # Remove spaces and lowercase for uniqueness
#         return "".join(s.lower().split())

#     def to_title_case(s):
#         # Capitalize first letter of each word, rest lowercase
#         return " ".join(word.capitalize() for word in s.strip().split())

#     # Build a mapping from normalized department to original department
#     norm_to_original_dept = {}
#     for d in dept_theme_map.keys():
#         if d:
#             norm = normalize_key(d)
#             norm_to_original_dept[norm] = d
#     departments = [
#         to_title_case(norm_to_original_dept[n])
#         for n in sorted(norm_to_original_dept.keys())
#     ]
#     norm_dept_display_to_key = {
#         to_title_case(norm_to_original_dept[n]): n for n in norm_to_original_dept
#     }
#     # Initialize trainer in session state
#     # Initialize trainer in session state
#     if "trainer" not in st.session_state:
#         st.session_state.trainer = CustomerSupportTrainer()

#     # Sidebar controls
#     # Initialize reset counter for assigned simulation dropdown
#     if "assigned_dropdown_reset" not in st.session_state:
#         st.session_state["assigned_dropdown_reset"] = 0

#     with st.sidebar:
#         if st.button("🔄 Start New Session"):
#             st.session_state.trainer.reset_conversation()
#             st.session_state.messages = []
#             st.session_state.trainer.conversation_started = False

#             # 🚀 Reset token usage tracking for new session
#             st.session_state.token_usage = []

#             # Clear chat history for current user in user_data
#             username = st.session_state.get("username", "")
#             if username:
#                 if "user_data" not in st.session_state:
#                     st.session_state.user_data = {}
#                 if username not in st.session_state.user_data:
#                     st.session_state.user_data[username] = {}
#                 st.session_state.user_data[username]["chat_history"] = []
#                 st.session_state.chat_history = []
#             # NEW: Also clear chat_history from session state on next login
#             st.session_state["clear_chat_on_login"] = True
#             # Bump reset counter so dropdowns reset to defaults on rerender
#             st.session_state["assigned_dropdown_reset"] += 1
#             # Reset scenario dropdown-related session values to defaults
#             for k in ("scenario_type", "issue_type", "customer_tone"):
#                 if k in st.session_state:
#                     del st.session_state[k]

#             # 🚀 NEW: Clear all policy-related session data to prevent interference
#             policy_keys = [
#                 "policy_scenarios",
#                 "current_policy_session",
#                 "policy_switch_scenario",
#                 "selected_policies",
#                 "scenario_chunks",
#                 "policy_context",
#                 "current_scenario",
#             ]
#             for key in policy_keys:
#                 if key in st.session_state:
#                     if key == "policy_scenarios":
#                         st.session_state[key] = []  # Reset to empty list
#                     elif key == "current_policy_session":
#                         st.session_state[key] = None  # Reset to None
#                     else:
#                         del st.session_state[key]  # Delete completely

#             # 🗄️ Clear example and policy caches
#             if "cached_examples" in st.session_state:
#                 st.session_state.cached_examples = {}
#             if "cached_policies" in st.session_state:
#                 st.session_state.cached_policies = {}

#             st.success("New training session started!")

#         st.markdown("---")

#         # --- SUPERVISOR ASSIGNED SIMULATIONS DROPDOWN ---
#         username = st.session_state.get("username", "")
#         assign_list = cached_supervisor_assignments(username)

#         # Prepare dropdown options
#         assign_options = ["-- Select Assigned Simulation --"] + sorted(
#             set(s for s in assign_list if s)
#         )

#         selected_assignment = st.selectbox(
#             "Assigned Simulations (from Supervisor)",
#             assign_options,
#             key=f"assigned_simulation_dropdown_{st.session_state['assigned_dropdown_reset']}",
#         )

#         # Refresh button below the dropdown
#         if st.button("🔄 Refresh Assignments"):
#             cached_supervisor_assignments.clear()
#             st.rerun()

#         # Parse selected assignment into existing session variables (handle hyphens safely)
#         import re

#         if (
#             selected_assignment
#             and selected_assignment != "-- Select Assigned Simulation --"
#         ):
#             # Store the full simulation string for later use
#             st.session_state["assigned_simulation"] = selected_assignment
#             st.session_state["assigned_simulation_dropdown"] = selected_assignment

#             parts = [
#                 p.strip() for p in re.split(r"\s*-\s*", selected_assignment, maxsplit=2)
#             ]
#             if len(parts) >= 1 and parts[0]:
#                 st.session_state["scenario_type"] = parts[0]
#             if len(parts) >= 2 and parts[1]:
#                 st.session_state["issue_type"] = parts[1]
#             if len(parts) >= 3 and parts[2]:
#                 st.session_state["customer_tone"] = parts[2]

#         # Get values from session state (populated by assignment parsing above)
#         scenario_type = st.session_state.get("scenario_type", "")
#         issue_type = st.session_state.get("issue_type", "")
#         customer_tone = st.session_state.get("customer_tone", "")

#         st.markdown("---")
#         st.markdown(f"**Current Scenario:** {scenario_type}")
#         st.markdown(f"**Reason for Contact:** {issue_type}")
#         st.markdown(f"**Customer Tone:** {customer_tone}")

#         # Export chat to Excel download button using buffer memory
#         st.markdown("---")
#         chat_history = st.session_state.trainer.get_conversation_history()
#         rows = []
#         for msg in chat_history:
#             if isinstance(msg, HumanMessage):
#                 rows.append({"role": "user", "content": msg.content})
#             elif isinstance(msg, AIMessage):
#                 rows.append({"role": "assistant", "content": msg.content})
#         if rows:
#             df = pd.DataFrame(rows)
#             output = BytesIO()
#             df.to_excel(output, index=False, engine="openpyxl")
#             output.seek(0)
#         else:
#             st.info("No chat history to export.")

#         # Note: Chat history download removed - data is preserved in evaluation Excel files

#         # Logout button at bottom of sidebar
#         st.markdown("---")
#         if st.button("🚪 Logout", key="logout_btn", type="secondary"):
#             # 🚀 COMPREHENSIVE LOGOUT CLEANUP:
#             # - Login credentials
#             # - Cached evaluation data
#             # - Performance evaluation UI data
#             # - Policy-related session data (same as Start New Session)
#             # - Conversation memory and chat history
#             print(f"[DEBUG] User {st.session_state.get('username', '')} logging out")
#             st.session_state.logged_in = False
#             st.session_state.username = ""
#             st.session_state.role = ""

#             # 🚀 Clear trainee cached evaluation data to free memory
#             if "gcs_evaluations" in st.session_state:
#                 cached_count = len(st.session_state["gcs_evaluations"])
#                 del st.session_state["gcs_evaluations"]
#                 print(
#                     f"[DEBUG] 💾 Cleared {cached_count} cached evaluations from trainee memory"
#                 )

#             # Clear other performance evaluation session data
#             performance_keys = [
#                 "show_eval_summary",
#                 "view_eval_idx",
#                 "supervisor_eval_data",
#                 "view_supervisor_eval_idx",
#             ]
#             for key in performance_keys:
#                 if key in st.session_state:
#                     del st.session_state[key]
#                     print(f"[DEBUG] 💾 Cleared session key: {key}")

#             # 🚀 Clear policy-related session data (same as Start New Session)
#             policy_keys = [
#                 "policy_scenarios",
#                 "current_policy_session",
#                 "policy_switch_scenario",
#                 "selected_policies",
#                 "scenario_chunks",
#                 "policy_context",
#                 "current_scenario",
#                 "messages",
#             ]
#             for key in policy_keys:
#                 if key in st.session_state:
#                     if key == "policy_scenarios":
#                         st.session_state[key] = []  # Reset to empty list
#                     elif key == "current_policy_session":
#                         st.session_state[key] = None  # Reset to None
#                     else:
#                         del st.session_state[key]  # Delete completely
#                     print(f"[DEBUG] 💾 Cleared policy session key: {key}")

#             # 🗄️ Clear example and policy caches
#             if "cached_examples" in st.session_state:
#                 del st.session_state.cached_examples
#                 print(f"[DEBUG] 💾 Cleared examples cache")
#             if "cached_policies" in st.session_state:
#                 del st.session_state.cached_policies
#                 print(f"[DEBUG] 💾 Cleared policies cache")

#             # 🚀 Clear GCS storage manager cache - FIXES THE ORIGINAL ISSUE!
#             # This ensures fresh data loading on next login
#             try:
#                 get_gcs_storage_manager.clear()
#                 print(f"[DEBUG] 💾 Cleared GCS storage manager cache")
#             except Exception as e:
#                 print(f"[DEBUG] ⚠️ Could not clear GCS cache: {e}")

#             st.rerun()
#     # --- Main area: Show Excel preview if requested ---

#     # Main chat interface

#     # Display conversation history from buffer memory
#     # Use session chat_history for current user
#     chat_history = st.session_state.get("chat_history", [])
#     for msg in chat_history:
#         if isinstance(msg, HumanMessage):
#             with st.chat_message("user"):
#                 st.markdown(msg.content)
#         elif isinstance(msg, AIMessage):
#             with st.chat_message("assistant"):
#                 st.markdown(msg.content)

#     # Show initial customer message if conversation hasn't started
#     # NEW LOGIC: Require scenario, issue, and tone before starting chat
#     required_ready = all(
#         bool(str(st.session_state.get(k, "")).strip())
#         for k in ("scenario_type", "issue_type", "customer_tone")
#     )
#     if not st.session_state.trainer.conversation_started:
#         if not required_ready:
#             st.info(
#                 "Please select an assigned simulation (or set Scenario, Issue Type, and Customer Tone) in the sidebar before starting the conversation."
#             )
#         else:
#             st.info("Support Rep, please start the conversation.")
#     # Only set conversation_started after first support rep input

#     # Support rep input (only when required selections are ready)
#     support_input = None
#     if required_ready:
#         support_input = st.chat_input(
#             "Type your response as a support representative..."
#         )
#     if support_input:
#         # Always show support rep message in UI
#         with st.chat_message("user"):
#             st.markdown(support_input)

#         st.session_state.trainer.conversation_started = True

#         # 🚀 OPTIMIZATION: Cache examples and policies per session to avoid repeated loading
#         # Create a cache key based on scenario, issue, and tone
#         cache_key = f"{scenario_type}_{issue_type}_{customer_tone}"

#         # Initialize cache if not exists
#         if "cached_examples" not in st.session_state:
#             st.session_state.cached_examples = {}
#         if "cached_policies" not in st.session_state:
#             st.session_state.cached_policies = {}

#         # Get cached examples or load them
#         if cache_key in st.session_state.cached_examples:
#             examples = st.session_state.cached_examples[cache_key]
#             print(f"[DEBUG] 📦 Using CACHED examples for {cache_key}")
#         else:
#             examples = st.session_state.trainer.retrieve_examples(
#                 db, support_input, scenario_type, issue_type, customer_tone, k=5
#             )
#             st.session_state.cached_examples[cache_key] = examples
#             print(f"[DEBUG] 🔄 LOADED and cached examples for {cache_key}")

#         # Get cached policies or load them
#         policy_cache_key = f"policy_{issue_type}"
#         if policy_cache_key in st.session_state.cached_policies:
#             all_matching_docs = st.session_state.cached_policies[policy_cache_key][
#                 "docs"
#             ]
#             theme_for_filter = st.session_state.cached_policies[policy_cache_key][
#                 "theme"
#             ]
#             print(f"[DEBUG] 📦 Using CACHED policies for {policy_cache_key}")
#         else:
#             # Load policy documents
#             policy_db = get_policy_faiss_db()
#             all_matching_docs = []
#             theme_for_filter = "nothing"

#             if policy_db:
#                 # Map issue type to theme for FAISS filtering
#                 issue_lower = issue_type.lower()

#                 if (
#                     "seats" in issue_lower
#                     and "upgrade" in issue_lower
#                     and "without policies" not in issue_lower
#                 ):
#                     theme_for_filter = "seats and upgrades"
#                 elif (
#                     "service" in issue_lower
#                     and "animal" in issue_lower
#                     and "without policies" not in issue_lower
#                 ):
#                     theme_for_filter = "service animals"
#                 else:
#                     theme_for_filter = "nothing"
#                 if "Service Animals(without policies)" in issue_lower:
#                     theme_for_filter = "nothing"

#                 try:
#                     # Get ALL chunks that match the theme filter
#                     for doc_id, doc in policy_db.docstore._dict.items():
#                         if doc.metadata.get("theme") == theme_for_filter:
#                             all_matching_docs.append(doc)

#                     print(
#                         f"[DEBUG] 🔄 LOADED {len(all_matching_docs)} policy documents for theme: {theme_for_filter}"
#                     )

#                 except Exception as e:
#                     print(f"[DEBUG] Error retrieving policy documents: {e}")
#                     st.warning(f"Error retrieving policy documents: {str(e)}")

#             # Cache the policy data
#             st.session_state.cached_policies[policy_cache_key] = {
#                 "docs": all_matching_docs,
#                 "theme": theme_for_filter,
#             }

#         # 🔍 DEBUG: Show what examples were retrieved
#         print(f"[DEBUG] 📝 EXAMPLES FOUND: {len(examples) if examples else 0}")
#         if examples:
#             print(f"[DEBUG] " + "=" * 80)
#             print(f"[DEBUG] 📚 ALL {len(examples)} EXAMPLES CONTENT:")
#             print(f"[DEBUG] " + "=" * 80)
#             for i, example in enumerate(examples, 1):
#                 print(f"[DEBUG] 📄 EXAMPLE {i}:")
#                 print(f"[DEBUG] {example}")
#                 print(f"[DEBUG] " + "-" * 60)
#             print(f"[DEBUG] " + "=" * 80)

#         # Fixed routing logic: Use policies only when policies are found AND it's a policy-enabled scenario
#         if all_matching_docs and theme_for_filter != "nothing":
#             # Use policy-based response when policies are available
#             customer_response = st.session_state.trainer.gen_cus_policy_response(
#                 support_input,
#                 all_matching_docs,
#                 customer_tone,
#                 scenario_type,
#                 issue_type,
#             )
#         elif examples:
#             # Use example-based response when examples are available
#             customer_response = st.session_state.trainer.generate_customer_response(
#                 support_input,
#                 examples,
#                 customer_tone,
#                 scenario_type,
#                 issue_type,
#                 all_matching_docs,
#             )
#         else:
#             # Fallback: Use example-based response with empty examples
#             customer_response = st.session_state.trainer.generate_customer_response(
#                 support_input,
#                 [],
#                 customer_tone,
#                 scenario_type,
#                 issue_type,
#                 [],
#             )

#         # Always show AI customer response in UI
#         with st.chat_message("assistant"):
#             with st.spinner("Customer is typing..."):
#                 st.markdown(customer_response)

#         # Save chat history to session for current user
#         st.session_state.chat_history = (
#             st.session_state.trainer.get_conversation_history()
#         )

#         if not st.session_state.trainer.conversation_started and chat_history:
#             st.info("Conversation ended. You can start a new session from the sidebar.")

#     # Exit conversation button
#     if chat_history and len(chat_history) > 1:
#         st.markdown("---")
#         col1, col2, col3 = st.columns([1, 1, 1])
#         with col2:
#             if st.button("🚪 End Training Session", type="primary"):
#                 st.success(
#                     "Training session ended! Great job practicing your support skills."
#                 )
#                 st.markdown("**Session Summary:**")
#                 st.markdown(f"• Scenario: {scenario_type}")
#                 st.markdown(f"• Issue Type: {issue_type}")
#                 st.markdown(f"• Customer Tone: {customer_tone}")
#                 st.markdown(f"• Total exchanges: {len(chat_history)//2}")
#                 st.markdown("• You can start a new session from the sidebar")

#     # Show evaluation button when conversation ended and chat history exists
#     if not st.session_state.trainer.conversation_started and chat_history:
#         st.markdown("---")
#         if st.button("📝 Evaluate Session", type="primary"):
#             # 🚀 Initialize token usage tracking for this evaluation
#             if "token_usage" not in st.session_state:
#                 st.session_state.token_usage = []
#             else:
#                 st.session_state.token_usage = []  # Reset for new evaluation

#             with st.spinner("Evaluating session with LLM..."):
#                 # Load evaluation metrics vector store
#                 eval_vector_store_path = "./faiss_store_eval_metrics"
#                 eval_embedder = EvalEmbeddings(
#                     model="text-embedding-3-large",
#                     api_key="83265f364fe844f298b2d4f8a5a39426",
#                     openai_api_type="azure",
#                     azure_endpoint="https://genai-demos.openai.azure.com/",
#                     api_version="2024-02-15-preview",
#                 )
#                 eval_db = EvalFAISS.load_local(
#                     eval_vector_store_path,
#                     eval_embedder,
#                     allow_dangerous_deserialization=True,
#                 )
#                 selected_domain = st.session_state.get("scenario_type", None)

#                 # Get policy documents used for scenario creation from session state
#                 policy_documents_text = ""
#                 if (
#                     "current_policy_session" in st.session_state
#                     and st.session_state.current_policy_session is not None
#                 ):
#                     selected_policies = st.session_state.current_policy_session.get(
#                         "selected_policies", []
#                     )
#                     if selected_policies:
#                         policy_documents_text = (
#                             "\n\nPOLICY DOCUMENTS USED FOR SCENARIO:\n"
#                         )
#                         for i, doc in enumerate(selected_policies, 1):
#                             policy_documents_text += (
#                                 f"Policy Document {i}:\n{doc.page_content}\n\n"
#                             )
#                         print(
#                             f"[DEBUG] Found {len(selected_policies)} policy documents from session state"
#                         )
#                     else:
#                         print("[DEBUG] No policy documents found in session state")
#                 else:
#                     print("[DEBUG] No current_policy_session found in session state")

#                 # Mimic retail policy for airlines and retail ONLY for policy retrieval
#                 domain_for_policy = (
#                     str(selected_domain).lower() if selected_domain else ""
#                 )
#                 if "retail" in domain_for_policy or "air" in domain_for_policy:
#                     domain_for_policy = "retail"
#                 # Debug: print all available domains and selected_domain
#                 all_domains = set()
#                 for doc in eval_db.docstore._dict.values():
#                     dom = doc.metadata.get("Domain", "")
#                     all_domains.add(dom)
#                 print(f"[DEBUG] Available domains in eval_db: {sorted(all_domains)}")
#                 print(
#                     f"[DEBUG] Selected domain for policy: '{domain_for_policy}' (original: '{selected_domain}')"
#                 )
#                 eval_metrics = []
#                 for doc in eval_db.docstore._dict.values():
#                     if doc.metadata.get("Domain", "").lower() == domain_for_policy:
#                         eval_metrics.append(doc)
#                 if not eval_metrics:
#                     print(
#                         f"[WARNING] No metrics found for domain '{selected_domain}'. Check for case/whitespace mismatches."
#                     )
#                     st.warning(
#                         f"No evaluation metrics found for domain '{selected_domain}'. Please check your selection and vector store."
#                     )

#                 # Prepare chat history for prompt
#                 history_text = ""
#                 for message in chat_history:
#                     if hasattr(message, "role"):
#                         if message.role == "user":
#                             history_text += f"Support Rep: {message.content}\n"
#                         elif message.role == "assistant":
#                             history_text += f"Customer: {message.content}\n"
#                     else:
#                         # Fallback for HumanMessage/AIMessage
#                         if message.__class__.__name__ == "HumanMessage":
#                             history_text += f"Support Rep: {message.content}\n"
#                         elif message.__class__.__name__ == "AIMessage":
#                             history_text += f"Customer: {message.content}\n"

#                 # Prepare metrics for prompt
#                 metrics_text = ""
#                 behaviour_list = []
#                 for idx, metric in enumerate(eval_metrics, 1):
#                     # Extract behaviour and definition from page_content (assume format: 'Behaviour: ...\nDefinition: ...')
#                     page_lines = metric.page_content.split("\n")
#                     behaviour = ""
#                     definition = ""
#                     for line in page_lines:
#                         if line.lower().startswith("behaviour:"):
#                             behaviour = line.split(":", 1)[1].strip()
#                         elif line.lower().startswith("definition:"):
#                             definition = line.split(":", 1)[1].strip()
#                     if behaviour:
#                         behaviour_list.append(behaviour)
#                     score = metric.metadata.get(
#                         "Score", metric.metadata.get("score", "")
#                     )
#                     mandatory = metric.metadata.get(
#                         "Mandatory", metric.metadata.get("mandatory", "")
#                     )
#                     description = metric.metadata.get(
#                         "Description", metric.metadata.get("description", "")
#                     )
#                     metrics_text += f"Metric {idx}:\nBehaviour: {behaviour}\nDefinition: {definition}\nRecommended Score: {score}\nMandatory: {mandatory}\nDescription: {description}\n\n"
#                 print(f"____behav list ______ {behaviour_list}")

#                 eval_prompt = f"""
#                  You are an expert evaluator for customer support conversations.

#                  SCENARIO DOMAIN: {selected_domain}

#                  EVALUATION METRICS:
#                  {metrics_text}
#                 POLICY DOCUMENTS (Use to evaluate the metrics):
#                  {policy_documents_text}

#                  CHAT HISTORY:
#                  {history_text}

#                  STRICT INSTRUCTIONS:
#                     1. You MUST evaluate each behavior separately using the EXACT behavior names provided below:
#                     {behaviour_list}

#                     2. BEHAVIOR EVALUATION LOGIC - Follow this decision process for each behavior:
#                         - Check if behavior is MANDATORY in the metadata
#                         - If mandatory = TRUE: ALWAYS evaluate this behavior (score 0 to max)
#                         - If mandatory = FALSE: Read the description and analyze if it applies to this conversation
#                         - If description conditions don't match the conversation context, mark as "Not Applicable"

#                     3. POLICY COMPLIANCE CHECK:
#                         - For behaviors "Resolution", "Policy/Product/Service Knowledge", and "Process": 
#                         - Check if the support rep's responses followed the policy documents provided above
#                         - Include policy compliance in your scoring and reasoning

#                    4. CITATION LOGIC - VERY IMPORTANT:
#                      - In the Citation column, include ONLY the ACTUAL CHAT MESSAGE CONTENT from the support representative that you used to evaluate this behavior
#                      - DO NOT include any policy document content or references in the citation
#                      - DO NOT use generic references like "Chat #2" or "Message 3"
#                      - Copy the exact support representative message(s) that demonstrate (or fail to demonstrate) the behavior
#                      - ONLY cite content from the CHAT HISTORY section, never from the POLICY DOCUMENTS section
#                      - If you used the entire conversation history for evaluation, write "Entire conversation history used"
#                      - If you used multiple chat messages, include all relevant chat message content
#                      - Remember: Citations should ONLY contain what the support rep said, not policy information
                     
#                     5. SCORING LOGIC:
#                      - Each behavior has a MAXIMUM possible score from the metadata
#                      - IF behavior is FULLY demonstrated: Give the maximum score from metadata
#                      - IF behavior is PARTIALLY demonstrated: Give 75% of maximum score
#                      - IF behavior is NOT present: Give 0
#                      - IF behavior is NOT APPLICABLE: Mark as "N/A"

#                     6. REASON COLUMN REQUIREMENTS - CRITICAL:
#                      - DO NOT just restate the definition in the Reason column
#                      - Provide SPECIFIC analysis of what the support rep did or failed to do
#                      - Explain HOW their actions/responses align or don't align with the behavior definition
#                      - Reference specific policy compliance or violations when relevant
#                      - For FULL scores: Explain what the rep did well that earned the maximum score
#                      - For PARTIAL scores: Explain what was missing or could be improved (why not full score)
#                      - For ZERO scores: Explain what specific behavior was absent or done incorrectly
#                      - For N/A scores: Explain why this behavior doesn't apply to this conversation

#                     7. OUTPUT FORMAT - Use this exact table structure:

#                      | Behavior | Definition | Max Score | Awarded Score | Citation | Reason |
#                         |----------|------------|-----------|---------------|----------|-----------|
#                     | [Exact name] | [Definition] | [From metadata] | [Your score] | [Reference to chat history] | [Reason] |

#                     8. DO NOT:
#                      - Group behaviors together
#                      - Create new behavior names
#                      - Invent evidence not in chat history
#                      - Change the behavior names provided

#                  """

#                 # Call LLM for evaluation
#                 try:
#                     messages = [
#                         {
#                             "role": "system",
#                             "content": "You are an expert evaluator for customer support conversations.",
#                         },
#                         {"role": "user", "content": eval_prompt},
#                     ]

#                     # Count input tokens and add to list
#                     tokens = get_token_count(messages)
#                     # ...existing code...
#                     st.session_state.token_usage.append(tokens)

#                     response = client.chat.completions.create(
#                         model="gpt-4.1",
#                         messages=messages,
#                         max_tokens=1200,
#                         temperature=0.0,
#                         top_p=1.0,  # Changed from 0.5 to 1.0 for deterministic output
#                         seed=42,  # Add fixed seed for reproducibility
#                         frequency_penalty=0.0,
#                     )
#                     eval_result = response.choices[0].message.content.strip()
#                     print("[DEBUG] Raw LLM Evaluation Table Output:\n" + eval_result)

#                 except Exception as e:
#                     eval_result = f"Error during evaluation: {str(e)}"

#                 st.markdown("#### Evaluation Results")
#                 st.markdown(eval_result)

#                 def parse_llm_table(text):
#                     # Find all lines that start with '|'
#                     lines = [
#                         l for l in text.strip().split("\n") if l.strip().startswith("|")
#                     ]
#                     # Find the header line
#                     header_idx = None
#                     for i, line in enumerate(lines):
#                         if "Behavior" in line and "Definition" in line:
#                             header_idx = i
#                             break
#                     if header_idx is None or len(lines) < header_idx + 3:
#                         return []
#                     # Data lines start after header and separator
#                     data_lines = lines[header_idx + 2 :]
#                     result = []
#                     for line in data_lines:
#                         parts = [p.strip() for p in line.split("|")[1:-1]]
#                         # Always expect 6 columns, fill missing with 'N/A'
#                         while len(parts) < 6:
#                             parts.append("N/A")
#                         (
#                             behavior,
#                             definition,
#                             max_score,
#                             awarded_score,
#                             citation,
#                             reason,
#                         ) = parts
#                         try:
#                             awarded_score_val = float(awarded_score)
#                             max_score_val = float(max_score)
#                             result.append(
#                                 {
#                                     "Behavior": behavior,
#                                     "Definition": definition,
#                                     "MaxScore": max_score_val,
#                                     "AwardedScore": awarded_score_val,
#                                     "Citation": citation,
#                                     "Reason": reason,
#                                 }
#                             )
#                         except Exception:
#                             continue
#                     return result

#                 parsed_scores = parse_llm_table(eval_result)

#                 # Only include rows where AwardedScore is a number (exclude N/A)
#                 total_awarded = sum([row["AwardedScore"] for row in parsed_scores])
#                 total_possible = sum([row["MaxScore"] for row in parsed_scores])
#                 final_percentage = (
#                     (total_awarded / total_possible * 100) if total_possible else 0
#                 )

#                 st.markdown("---")
#                 st.markdown(
#                     f"**LLM Table Calculation:**\n- Total Awarded: {total_awarded:.2f}\n- Total Possible: {total_possible:.2f}\n- Final Percentage: {final_percentage:.2f}%"
#                 )

#                 # --- Export to Excel Button ---

#                 def export_evaluation_excel(
#                     chat_history,
#                     eval_table,
#                     total_awarded,
#                     total_possible,
#                     final_percentage,
#                 ):
#                     wb = openpyxl.Workbook()
#                     # Sheet 1: Chat History
#                     ws1 = wb.active
#                     ws1.title = "Chat History"
#                     ws1.append(["Role", "Message"])
#                     for msg in chat_history:
#                         if hasattr(msg, "role"):
#                             role = msg.role
#                             content = msg.content
#                         else:
#                             role = (
#                                 "user"
#                                 if msg.__class__.__name__ == "HumanMessage"
#                                 else "assistant"
#                             )
#                             content = msg.content
#                         ws1.append([role, content])

#                     # Sheet 2: Evaluation Table
#                     ws2 = wb.create_sheet(title="Evaluation Table")
#                     ws2.append(
#                         [
#                             "Behavior",
#                             "Definition",
#                             "Max Score",
#                             "Awarded Score",
#                             "Citation",
#                             "Reason",
#                         ]
#                     )
#                     # Use parsed_scores to write rows, always including citation
#                     for row in eval_table:
#                         ws2.append(
#                             [
#                                 row.get("Behavior", ""),
#                                 row.get("Definition", ""),
#                                 row.get("MaxScore", ""),
#                                 row.get("AwardedScore", ""),
#                                 row.get("Citation", "N/A"),
#                                 row.get("Reason", ""),
#                             ]
#                         )

#                     # Sheet 3: Final Scoring
#                     ws3 = wb.create_sheet(title="Final Scoring")
#                     ws3.append(["Total Awarded", "Total Possible", "Final Percentage"])
#                     ws3.append(
#                         [total_awarded, total_possible, f"{final_percentage:.2f}%"]
#                     )

#                     # NEW: Sheet 4: Metadata
#                     ws4 = wb.create_sheet(title="Metadata")
#                     ws4.append(
#                         [
#                             "username",
#                             "department",
#                             "issue_type",
#                             "tone",
#                             "timestamp",
#                             "eval_score",
#                         ]
#                     )
#                     ws4.append(
#                         [
#                             st.session_state.get("username", ""),
#                             str(st.session_state.get("scenario_type", "")),
#                             str(st.session_state.get("issue_type", "")),
#                             str(st.session_state.get("customer_tone", "")),
#                             datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#                             f"{final_percentage:.2f}",
#                         ]
#                     )

#                     output = BytesIO()
#                     wb.save(output)
#                     output.seek(0)
#                     return output

#                 excel_output = export_evaluation_excel(
#                     chat_history,
#                     parsed_scores,
#                     total_awarded,
#                     total_possible,
#                     final_percentage,
#                 )

#                 # 🚀 OPTION 2: IMMEDIATE SAVE TO GCS (No session state dependency)
#                 username = st.session_state.get("username", "")
#                 if username:
#                     # Get GCS storage manager
#                     gcs_manager = get_gcs_storage_manager()

#                     if gcs_manager.is_connected():
#                         # Prepare evaluation data for immediate GCS save
#                         eval_data = {
#                             "username": username,
#                             "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#                             "excel_bytes": excel_output.getvalue(),
#                             "department": str(selected_domain),
#                             "issue_type": str(st.session_state.get("issue_type", "")),
#                             "tone": str(st.session_state.get("customer_tone", "")),
#                             "eval_score": f"{final_percentage:.2f}%",
#                         }

#                         # Save immediately to GCS
#                         success, message = gcs_manager.save_evaluation_to_gcs(eval_data)

#                         if success:
#                             st.success(f"✅ Evaluation saved to cloud storage")
#                             print(
#                                 f"[DEBUG] ✅ Immediate save successful: {eval_data['timestamp']}"
#                             )
#                             # Increment sessions_completed counter for this user's assigned simulation
#                             try:
#                                 assigned_sim = st.session_state.get(
#                                     "assigned_simulation_dropdown"
#                                 ) or st.session_state.get("assigned_simulation")
#                                 username = st.session_state.get("username", "")
#                                 print(
#                                     f"[DEBUG] Attempting to mark completed: username='{username}', sim='{assigned_sim}'"
#                                 )
#                                 if assigned_sim and username:
#                                     result = user_sim_manager.mark_assignment_completed(
#                                         username, assigned_sim
#                                     )
#                                     print(f"[DEBUG] Mark completed result: {result}")
#                                 else:
#                                     print(
#                                         f"[WARN] Missing data - username: {username}, assigned_sim: {assigned_sim}"
#                                     )
#                             except Exception as e:
#                                 # non-fatal: evaluation saved but metadata update failed
#                                 print(
#                                     f"[ERROR] Failed to mark assignment completed: {e}"
#                                 )
#                                 import traceback

#                                 traceback.print_exc()
#                         else:
#                             st.error(f"❌ Failed to save evaluation: {message}")
#                             print(f"[ERROR] ❌ Immediate save failed: {message}")
#                     else:
#                         st.warning(
#                             "⚠️ Cloud storage unavailable. Evaluation completed but not saved."
#                         )
#                         print("[WARNING] GCS not connected, evaluation not saved")
#                 else:
#                     st.warning(
#                         "⚠️ No username found. Evaluation completed but not saved."
#                     )
#                     print("[WARNING] No username found, evaluation not saved")


# if __name__ == "__main__":
#     # Ensure any startup/runtime exceptions are surfaced in logs with full tracebacks
#     import traceback, sys

#     try:
#         main()
#     except Exception as e:
#         print("\n===== UNCAUGHT EXCEPTION IN app.py =====")
#         print(f"Type: {type(e).__name__}")
#         print(f"Error: {e}")
#         traceback.print_exc()
#         sys.stdout.flush()
#         sys.stderr.flush()
#         raise
