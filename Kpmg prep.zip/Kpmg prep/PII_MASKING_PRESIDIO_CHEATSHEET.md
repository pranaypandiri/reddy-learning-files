# PII Masking with Presidio - Complete Cheatsheet

---

## **What is Presidio?**

**Definition:** Microsoft's open-source library for detecting and anonymizing PII (Personally Identifiable Information).

**Key Features:**
- ✅ **Local processing** (not a cloud API - data stays on your server)
- ✅ Detects 20+ PII types (email, phone, SSN, credit cards, names)
- ✅ Multiple anonymization methods (mask, replace, redact, hash, encrypt)
- ✅ Reversible masking (can unmask later)

**Installation:**
```bash
pip install presidio-analyzer presidio-anonymizer
python -m spacy download en_core_web_lg
```

---

## **1. Basic Setup**

### Simple PII Detection
```python
from presidio_analyzer import AnalyzerEngine

# Initialize analyzer
analyzer = AnalyzerEngine()

# Detect PII
text = "My email is john@example.com and phone is 555-1234"
results = analyzer.analyze(text=text, language='en')

for result in results:
    print(f"Type: {result.entity_type}")       # EMAIL_ADDRESS, PHONE_NUMBER
    print(f"Text: {text[result.start:result.end]}")  # Actual PII value
    print(f"Score: {result.score}")            # Confidence 0-1
    print(f"Start: {result.start}, End: {result.end}")
    print("---")
```

**Output:**
```
Type: EMAIL_ADDRESS
Text: john@example.com
Score: 1.0
Start: 12, End: 29
---
Type: PHONE_NUMBER
Text: 555-1234
Score: 0.75
Start: 43, End: 51
```

---

### **How Analyzer Returns Multiple PII (Understanding start/end)**

**Key Concept:** Analyzer returns **one result per PII found**, each with its own start/end position.

```python
text = "Contact John at john@example.com or call 555-1234"
#       0123456789...........................43.......51

results = analyzer.analyze(text=text, language='en')

print(f"Found {len(results)} PII entities")  # 3 entities

# Result 1: PERSON
print(results[0].entity_type)    # "PERSON"
print(results[0].start)          # 8 (position of 'J' in 'John')
print(results[0].end)            # 12 (position after 'n')
print(text[8:12])                # "John"

# Result 2: EMAIL_ADDRESS
print(results[1].entity_type)    # "EMAIL_ADDRESS"
print(results[1].start)          # 16 (position of 'j' in 'john@...')
print(results[1].end)            # 33 (position after '.com')
print(text[16:33])               # "john@example.com"

# Result 3: PHONE_NUMBER
print(results[2].entity_type)    # "PHONE_NUMBER"
print(results[2].start)          # 43
print(results[2].end)            # 51
print(text[43:51])               # "555-1234"
```

**Visual Breakdown:**
```
Text: "Contact John at john@example.com or call 555-1234"
Index: 0       8   12  16              33      43      51

PII Found:
1. PERSON        [8:12]   = "John"
2. EMAIL_ADDRESS [16:33]  = "john@example.com"
3. PHONE_NUMBER  [43:51]  = "555-1234"
```

---

### **Multiple PII on Same Line**
```python
# Complex example: 4 PII entities in one sentence
text = "John (john@example.com, 555-1234) and Sarah (sarah@test.com) live at 123 Main St"

results = analyzer.analyze(text=text, language='en')

# Analyzer finds each PII separately
for i, result in enumerate(results, 1):
    pii_value = text[result.start:result.end]
    print(f"{i}. {result.entity_type:15} [{result.start:2}:{result.end:2}] = '{pii_value}'")

# Output:
# 1. PERSON          [ 0: 4] = 'John'
# 2. EMAIL_ADDRESS   [ 6:23] = 'john@example.com'
# 3. PHONE_NUMBER    [25:33] = '555-1234'
# 4. PERSON          [39:44] = 'Sarah'
# 5. EMAIL_ADDRESS   [46:61] = 'sarah@test.com'
# 6. LOCATION        [71:82] = '123 Main St'
```

**Key Points:**
- ✅ **One result per PII** (not one per line)
- ✅ **start/end are character positions** in the entire text (0-indexed)
- ✅ **Results are ordered** by position (left to right)
- ✅ **Use slicing** `text[start:end]` to extract actual value
- ✅ **Non-overlapping** (each character belongs to max one PII)

---

### **Working with Results List**
```python
text = "Email: john@example.com, Phone: 555-1234"
results = analyzer.analyze(text=text, language='en')

# Check how many PII found
if len(results) == 0:
    print("No PII detected")
elif len(results) == 1:
    print("One PII detected")
else:
    print(f"{len(results)} PII entities detected")

# Process each PII
for result in results:
    # Extract the actual PII text using start/end
    pii_text = text[result.start:result.end]
    
    # result.start = starting position (inclusive)
    # result.end = ending position (exclusive, like Python slicing)
    
    print(f"Found {result.entity_type}: '{pii_text}' at position [{result.start}:{result.end}]")
```

---

## **2. PII Anonymization (Masking)**

### Basic Anonymization
```python
from presidio_analyzer import AnalyzerEngine
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

# Initialize both engines
analyzer = AnalyzerEngine()
anonymizer = AnonymizerEngine()

text = "John Smith's email is john@example.com and SSN is 123-45-6789"

# Step 1: Analyze (detect PII)
results = analyzer.analyze(text=text, language='en')

# Step 2: Anonymize (mask PII)
anonymized_result = anonymizer.anonymize(
    text=text,
    analyzer_results=results,
    operators={
        "PERSON": OperatorConfig("replace", {"new_value": "<PERSON>"}),
        "EMAIL_ADDRESS": OperatorConfig("replace", {"new_value": "<EMAIL>"}),
        "US_SSN": OperatorConfig("replace", {"new_value": "<SSN>"})
    }
)

print(anonymized_result.text)
# Output: <PERSON>'s email is <EMAIL> and SSN is <SSN>
```

**✅ CORRECT WAY:** Use `anonymizer.anonymize()` method  
**❌ WRONG WAY:** Manual string replacement

---

### **How Anonymization Works with Multiple PII**

**Step-by-Step Process:**

```python
text = "Contact John at john@example.com or call 555-1234"

# Step 1: Analyzer finds each PII
results = analyzer.analyze(text=text, language='en')
# Returns 3 results:
# - PERSON: [8:12] = "John"
# - EMAIL_ADDRESS: [16:33] = "john@example.com" 
# - PHONE_NUMBER: [43:51] = "555-1234"

# Step 2: Anonymizer replaces EACH PII using its start/end positions
anonymized_result = anonymizer.anonymize(
    text=text,
    analyzer_results=results,
    operators={
        "PERSON": OperatorConfig("replace", {"new_value": "<PERSON>"}),
        "EMAIL_ADDRESS": OperatorConfig("replace", {"new_value": "<EMAIL>"}),
        "PHONE_NUMBER": OperatorConfig("replace", {"new_value": "<PHONE>"})
    }
)

print(anonymized_result.text)
# "Contact <PERSON> at <EMAIL> or call <PHONE>"
```

**Visual Transformation:**
```
BEFORE:
"Contact John at john@example.com or call 555-1234"
         ^^^^    ^^^^^^^^^^^^^^^^^         ^^^^^^^^
         [8:12]  [16:33]                   [43:51]
         PERSON  EMAIL_ADDRESS             PHONE_NUMBER

AFTER:
"Contact <PERSON> at <EMAIL> or call <PHONE>"
         ^^^^^^^^    ^^^^^^^         ^^^^^^^
         Replaced    Replaced        Replaced
```

---

### **Anonymizer Processes Each Result Independently**

```python
# Original text
text = "John (555-1234) and Sarah (sarah@test.com) work together"

# Analyzer finds 4 PII entities
results = analyzer.analyze(text=text, language='en')

# Anonymizer replaces each one
anonymized = anonymizer.anonymize(text=text, analyzer_results=results)

print(anonymized.text)
# "<PERSON> (<PHONE>) and <PERSON> (<EMAIL>) work together"

# Access individual replacements
for item in anonymized.items:
    print(f"Replaced {item.entity_type}: '{item.text}' with '{item.operator}'")

# Output:
# Replaced PERSON: 'John' with 'replace'
# Replaced PHONE_NUMBER: '555-1234' with 'replace'
# Replaced PERSON: 'Sarah' with 'replace'
# Replaced EMAIL_ADDRESS: 'sarah@test.com' with 'replace'
```

**Key Points:**
- ✅ Anonymizer processes **all results** from analyzer
- ✅ Each PII gets replaced using its **start/end position**
- ✅ Replacements happen **left to right** (to maintain text structure)
- ✅ Different PII types can have **different operators**

---

**✅ CORRECT WAY:** Use `anonymizer.anonymize()` method  
**❌ WRONG WAY:** Manual string replacement

---

## **3. Anonymization Operators**

### **1. REPLACE Operator**
```python
operators = {
    "EMAIL_ADDRESS": OperatorConfig("replace", {"new_value": "<EMAIL>"})
}

# Before: john@example.com
# After:  <EMAIL>
```
**Use:** Simple placeholder replacement

---

### **2. MASK Operator**
```python
operators = {
    "CREDIT_CARD": OperatorConfig("mask", {
        "masking_char": "*",
        "chars_to_mask": 12,
        "from_end": False
    })
}

# Before: 4111111111111111
# After:  4111************
```

**Parameters:**
- `masking_char`: Character to use (*, #, X)
- `chars_to_mask`: How many characters to hide
- `from_end`: False = mask from start, True = mask from end

---

### **3. REDACT Operator**
```python
operators = {
    "US_SSN": OperatorConfig("redact", {})
}

# Before: My SSN is 123-45-6789
# After:  My SSN is 
```
**Use:** Complete removal (leaves empty space)

---

### **4. HASH Operator**
```python
operators = {
    "EMAIL_ADDRESS": OperatorConfig("hash", {"hash_type": "sha256"})
}

# Before: john@example.com
# After:  a3f8b7c2d9e1f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9
```
**Use:** One-way anonymization (cannot reverse)

---

### **5. ENCRYPT Operator**
```python
from presidio_anonymizer.operators import AESCipher

operators = {
    "EMAIL_ADDRESS": OperatorConfig("encrypt", {"key": "WmZq4t7w!z%C*F-J"})
}

# Before: john@example.com
# After:  8f7a2b9c3d1e5f4g6h7i8j9k0l1m2n3o
# Can decrypt later with same key
```
**Use:** Reversible anonymization (can decrypt with key)

---

## **4. Mask Operator Deep Dive**

### **Parameters Explained**

#### **masking_char** - Which character to use
```python
# Asterisk (*)
OperatorConfig("mask", {"masking_char": "*", "chars_to_mask": 4})
# 4111111111111111 → 4111111111111***

# Hash (#)
OperatorConfig("mask", {"masking_char": "#", "chars_to_mask": 4})
# 4111111111111111 → 4111111111111###

# X
OperatorConfig("mask", {"masking_char": "X", "chars_to_mask": 4})
# 4111111111111111 → 4111111111111XXX
```

---

#### **chars_to_mask** - How many to hide
```python
# Hide 4 characters
OperatorConfig("mask", {"masking_char": "*", "chars_to_mask": 4})
# 4111111111111111 → 4111111111111***

# Hide 12 characters
OperatorConfig("mask", {"masking_char": "*", "chars_to_mask": 12})
# 4111111111111111 → 4111************

# Hide 16 characters (all)
OperatorConfig("mask", {"masking_char": "*", "chars_to_mask": 16})
# 4111111111111111 → ****************
```

---

#### **from_end** - Direction of masking
```python
# from_end=False (mask from START, show END)
OperatorConfig("mask", {
    "masking_char": "*",
    "chars_to_mask": 12,
    "from_end": False
})
# 4111111111111111 → ************1111 (show last 4)

# from_end=True (mask from END, show START)
OperatorConfig("mask", {
    "masking_char": "*",
    "chars_to_mask": 12,
    "from_end": True
})
# 4111111111111111 → 4111************ (show first 4)
```

---

### **Visual Examples**

**Credit Card: 4111111111111111**

| chars_to_mask | from_end | Result | Description |
|---------------|----------|--------|-------------|
| 12 | False | `************1111` | Show last 4 |
| 12 | True | `4111************` | Show first 4 |
| 13 | False | `*************111` | Show last 3 |
| 13 | True | `411*************` | Show first 3 |
| 8 | False | `********11111111` | Show last 8 |
| 8 | True | `41111111********` | Show first 8 |

**Formula:**
- `from_end=False`: Shows last `(total_length - chars_to_mask)` characters
- `from_end=True`: Shows first `(total_length - chars_to_mask)` characters

---

## **5. Reversible Masking (Unmask Pattern)**

### Complete Workflow
```python
from presidio_analyzer import AnalyzerEngine
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

analyzer = AnalyzerEngine()
anonymizer = AnonymizerEngine()

# Original text
original_text = "Contact John at john@example.com or call 555-1234"

# Step 1: Detect PII
results = analyzer.analyze(text=original_text, language='en')

# Step 2: Anonymize and save mapping
anonymized_result = anonymizer.anonymize(
    text=original_text,
    analyzer_results=results,
    operators={
        "PERSON": OperatorConfig("replace", {"new_value": "<PERSON>"}),
        "EMAIL_ADDRESS": OperatorConfig("replace", {"new_value": "<EMAIL>"}),
        "PHONE_NUMBER": OperatorConfig("replace", {"new_value": "<PHONE>"})
    }
)

# Extract mapping for later unmask
mapping = {}
for item in anonymized_result.items:
    mapping[f"<{item.entity_type}>"] = item.text

print("Masked:", anonymized_result.text)
print("Mapping:", mapping)

# Output:
# Masked: Contact <PERSON> at <EMAIL> or call <PHONE>
# Mapping: {'<PERSON>': 'John', '<EMAIL>': 'john@example.com', '<PHONE>': '555-1234'}

# Step 3: Send masked text to LLM
llm_response = send_to_llm(anonymized_result.text)
# LLM sees: "Contact <PERSON> at <EMAIL> or call <PHONE>"

# Step 4: Unmask LLM response
def unmask_response(text: str, mapping: dict) -> str:
    """Replace placeholders with original values"""
    for placeholder, original_value in mapping.items():
        text = text.replace(placeholder, original_value)
    return text

unmasked_response = unmask_response(llm_response, mapping)
print("Final:", unmasked_response)
```

**Flow:**
```
Original Text → Analyze → Anonymize + Save Mapping → Send to LLM → Unmask Response
```

---

## **6. Regex Operators for PII Detection**

### **\b - Word Boundary**
```python
# Without \b (matches partial words)
pattern = r"john"
"john" → ✅ Match
"johnathan" → ✅ Match (partial!)

# With \b (full words only)
pattern = r"\bjohn\b"
"john" → ✅ Match
"johnathan" → ❌ No match
```

**Use:** Prevent false positives in name detection

---

### **[] - Character Class**
```python
# Match any single character from set
pattern = r"[abc]"
"a" → ✅ Match
"b" → ✅ Match
"d" → ❌ No match

# Range
pattern = r"[0-9]"  # Any digit
pattern = r"[a-z]"  # Any lowercase letter
pattern = r"[A-Z]"  # Any uppercase letter

# Credit card pattern
pattern = r"[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{4}"
```

---

### **() - Capture Groups**
```python
# Extract parts of matched text
pattern = r"(\d{3})-(\d{2})-(\d{4})"  # SSN
"123-45-6789" → Groups: ("123", "45", "6789")

# Use for partial masking
def mask_ssn(ssn):
    match = re.search(r"(\d{3})-(\d{2})-(\d{4})", ssn)
    if match:
        return f"***-**-{match.group(3)}"  # Show only last 4
    return ssn

mask_ssn("123-45-6789")  # "***-**-6789"
```

---

### **Common PII Regex Patterns**
```python
# Email
r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"

# Phone (US)
r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b"

# SSN
r"\b\d{3}-\d{2}-\d{4}\b"

# Credit Card (Visa)
r"\b4[0-9]{12}(?:[0-9]{3})?\b"

# Credit Card (MasterCard)
r"\b5[1-5][0-9]{14}\b"

# IP Address
r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b"
```

---

## **7. Supported PII Types**

### **Built-in Entities**
```python
# Personal Info
PERSON, EMAIL_ADDRESS, PHONE_NUMBER

# Financial
CREDIT_CARD, IBAN_CODE, US_BANK_NUMBER

# Government IDs
US_SSN, US_PASSPORT, US_DRIVER_LICENSE, UK_NHS

# Location
LOCATION, US_STATE, US_ZIP_CODE

# Medical
MEDICAL_LICENSE, NRP (National Provider Identifier)

# Other
IP_ADDRESS, URL, DATE_TIME, AGE
```

---

### **Custom Entity Recognition**
```python
from presidio_analyzer import PatternRecognizer

# Define custom pattern
employee_id_recognizer = PatternRecognizer(
    supported_entity="EMPLOYEE_ID",
    patterns=[{
        "name": "employee_id_pattern",
        "regex": r"\bEMP\d{6}\b",
        "score": 0.9
    }]
)

# Add to analyzer
analyzer = AnalyzerEngine()
analyzer.registry.add_recognizer(employee_id_recognizer)

# Now detects custom pattern
text = "Employee ID: EMP123456"
results = analyzer.analyze(text=text, language='en')
# Detects: EMPLOYEE_ID
```

---

## **8. Production Patterns**

### **Pattern 1: Input Sanitization**
```python
class PIIMaskingService:
    def __init__(self):
        self.analyzer = AnalyzerEngine()
        self.anonymizer = AnonymizerEngine()
    
    def sanitize_input(self, user_input: str) -> tuple[str, dict]:
        """Mask PII before sending to LLM"""
        results = self.analyzer.analyze(text=user_input, language='en')
        
        anonymized = self.anonymizer.anonymize(
            text=user_input,
            analyzer_results=results,
            operators=self._get_operators()
        )
        
        # Save mapping
        mapping = {f"<{item.entity_type}>": item.text 
                   for item in anonymized.items}
        
        return anonymized.text, mapping
    
    def _get_operators(self):
        return {
            "PERSON": OperatorConfig("replace", {"new_value": "<PERSON>"}),
            "EMAIL_ADDRESS": OperatorConfig("replace", {"new_value": "<EMAIL>"}),
            "PHONE_NUMBER": OperatorConfig("replace", {"new_value": "<PHONE>"}),
            "CREDIT_CARD": OperatorConfig("mask", {
                "masking_char": "*",
                "chars_to_mask": 12,
                "from_end": True
            })
        }

# Usage
service = PIIMaskingService()
masked_text, mapping = service.sanitize_input("Call John at 555-1234")
```

---

### **Pattern 2: FastAPI Integration**
```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    reply: str
    pii_detected: bool

pii_service = PIIMaskingService()

@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    # Mask PII
    masked_input, mapping = pii_service.sanitize_input(request.message)
    
    # Send to LLM
    llm_response = llm.generate(masked_input)
    
    # Unmask response
    final_response = unmask_text(llm_response, mapping)
    
    return ChatResponse(
        reply=final_response,
        pii_detected=len(mapping) > 0
    )
```

---

### **Pattern 3: Logging with PII Removal**
```python
import logging

class PIIRemovingFilter(logging.Filter):
    def __init__(self):
        self.analyzer = AnalyzerEngine()
        self.anonymizer = AnonymizerEngine()
    
    def filter(self, record):
        # Anonymize log message
        results = self.analyzer.analyze(text=record.msg, language='en')
        
        if results:
            anonymized = self.anonymizer.anonymize(
                text=record.msg,
                analyzer_results=results
            )
            record.msg = anonymized.text
        
        return True

# Setup
logger = logging.getLogger()
logger.addFilter(PIIRemovingFilter())

# Now logs are PII-free
logger.info("User email: john@example.com")
# Logs: "User email: <EMAIL_ADDRESS>"
```

---

## **9. Performance Optimization**

### **Cache Analyzer Results**
```python
from functools import lru_cache

class OptimizedPIIService:
    def __init__(self):
        self.analyzer = AnalyzerEngine()
        self.anonymizer = AnonymizerEngine()
    
    @lru_cache(maxsize=1000)
    def detect_pii_cached(self, text: str) -> tuple:
        """Cache common queries"""
        results = self.analyzer.analyze(text=text, language='en')
        # Convert to tuple for caching
        return tuple((r.entity_type, r.start, r.end, r.score) for r in results)
```

---

### **Batch Processing**
```python
def batch_anonymize(texts: list[str]) -> list[str]:
    """Process multiple texts efficiently"""
    analyzer = AnalyzerEngine()
    anonymizer = AnonymizerEngine()
    
    masked_texts = []
    for text in texts:
        results = analyzer.analyze(text=text, language='en')
        anonymized = anonymizer.anonymize(text=text, analyzer_results=results)
        masked_texts.append(anonymized.text)
    
    return masked_texts

# Process 1000 texts
masked = batch_anonymize(user_inputs)
```

---

## **10. Interview Talking Points**

### **What is Presidio?**
> "Presidio is Microsoft's open-source PII detection and anonymization library. Unlike cloud APIs, it runs locally on your server, so sensitive data never leaves your infrastructure. It can detect 20+ PII types and offers multiple anonymization methods like masking, encryption, and hashing."

### **How does analyzer handle multiple PII in one text?**
> "The analyzer returns a list with one result per PII entity found. Each result has a `start` and `end` position indicating where that PII appears in the text (character indices). If there are 5 PII entities in one sentence, you get 5 results, each with its own start/end position. You can extract the actual value using Python slicing: `text[result.start:result.end]`."

### **How does reversible masking work?**
> "When anonymizing, Presidio returns an `items` list containing the mapping between placeholders and original values. I store this mapping in memory or cache, send the masked text to the LLM, then replace placeholders in the response with original values before returning to the user."

### **Mask operator parameters?**
> "Three key parameters: `masking_char` (which character to use like * or #), `chars_to_mask` (how many to hide), and `from_end` (direction - False shows the end, True shows the start). For credit cards, I typically use 12 masked characters from_end=True to show first 4 digits."

### **Why use Presidio over regex?**
> "Presidio uses ML models (spaCy) plus regex for better accuracy. It catches variations regex might miss, like 'my email is john at example dot com'. It's also maintained and updated with new PII patterns, whereas custom regex requires constant maintenance."

---

## **Quick Reference**

```python
# Install
pip install presidio-analyzer presidio-anonymizer
python -m spacy download en_core_web_lg

# Basic anonymization
from presidio_analyzer import AnalyzerEngine
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

analyzer = AnalyzerEngine()
anonymizer = AnonymizerEngine()

text = "Email: john@example.com"
results = analyzer.analyze(text=text, language='en')

anonymized = anonymizer.anonymize(
    text=text,
    analyzer_results=results,
    operators={
        "EMAIL_ADDRESS": OperatorConfig("replace", {"new_value": "<EMAIL>"})
    }
)

print(anonymized.text)  # "Email: <EMAIL>"

# Get mapping for unmask
mapping = {f"<{item.entity_type}>": item.text 
           for item in anonymized.items}
```

---

## **Operators Summary**

| Operator | Reversible | Use Case | Example |
|----------|------------|----------|---------|
| `replace` | ✅ Yes | Placeholder | `john@example.com` → `<EMAIL>` |
| `mask` | ✅ Yes | Partial hiding | `4111111111111111` → `4111************` |
| `redact` | ❌ No | Complete removal | `123-45-6789` → `` |
| `hash` | ❌ No | Deterministic anon | `john@example.com` → `a3f8b7c2...` |
| `encrypt` | ✅ Yes | Secure storage | `john@example.com` → `8f7a2b9c...` |

---

## **Visual Quick Reference: Multiple PII Detection**

### **How start/end Works with 2+ PII**
```python
text = "Contact John at john@example.com or call 555-1234"
#       ^       ^    ^  ^                ^  ^    ^
#       0       8    12 16              33  38   43   51

results = analyzer.analyze(text=text, language='en')
# Returns list with 3 items:

# results[0]:
#   entity_type: "PERSON"
#   start: 8
#   end: 12
#   text[8:12] = "John"

# results[1]:
#   entity_type: "EMAIL_ADDRESS"  
#   start: 16
#   end: 33
#   text[16:33] = "john@example.com"

# results[2]:
#   entity_type: "PHONE_NUMBER"
#   start: 43
#   end: 51
#   text[43:51] = "555-1234"
```

### **Character Position Indexing**
```
Text:     "Contact John at john@example.com or call 555-1234"
Index:     0       8   12  16              33      43      51
           |       |   |   |               |       |       |
           C       J   (sp)j               m       5       4
           
PII #1: PERSON        [8:12]   ← "John" (4 chars)
PII #2: EMAIL_ADDRESS [16:33]  ← "john@example.com" (17 chars)
PII #3: PHONE_NUMBER  [43:51]  ← "555-1234" (8 chars)
```

### **Key Rules**
1. **One result per PII** (not per line, not per sentence)
2. **start = inclusive** (character where PII begins)
3. **end = exclusive** (character after PII ends)
4. **Python slicing** `text[start:end]` extracts exact PII value
5. **Ordered by position** (left to right in text)
6. **No overlap** (each character belongs to at most one PII)

### **Common Pattern**
```python
# Loop through all detected PII
for result in results:
    # Get the actual PII text
    pii_value = text[result.start:result.end]
    
    # Process it
    print(f"Found {result.entity_type}: '{pii_value}'")
    print(f"Position: characters {result.start} to {result.end}")
    print(f"Confidence: {result.score:.2f}")
```

---

**📚 Official Docs:** https://microsoft.github.io/presidio/
