# Guardrails AI - Complete Cheatsheet

---

## **What is Guardrails AI?**

**Definition:** A framework to add validation, safety, and structure to LLM inputs and outputs.

**Purpose:**
- ✅ Prevent toxic/harmful language
- ✅ Keep responses on-topic
- ✅ Enforce structured outputs (JSON, Pydantic models)
- ✅ Validate data quality (length, format, choices)

**Installation:**
```bash
pip install guardrails-ai
```

---

## **1. Basic Setup**

### Simple Validator
```python
from guardrails import Guard
from guardrails.hub import ToxicLanguage

# Create guard with validator
guard = Guard().use(
    ToxicLanguage(threshold=0.5, on_fail="exception")
)

# Validate LLM output
try:
    result = guard.validate("This is a safe response")
    print(result.validated_output)
except Exception as e:
    print(f"Validation failed: {e}")
```

---

## **2. Key Validators**

### **ToxicLanguage** - Prevent harmful content
```python
from guardrails.hub import ToxicLanguage

guard = Guard().use(
    ToxicLanguage(
        threshold=0.5,  # 0.0-1.0, lower = stricter
        on_fail="exception"
    )
)

# Blocks toxic responses
result = guard.validate("You're amazing!")  # ✅ Pass
result = guard.validate("offensive text")    # ❌ Exception
```

---

### **RestrictToTopic** - Keep on topic
```python
from guardrails.hub import RestrictToTopic

guard = Guard().use(
    RestrictToTopic(
        valid_topics=["technology", "programming", "AI"],
        invalid_topics=["politics", "religion"],
        on_fail="exception"
    )
)

# Use case: Customer support chatbot
result = guard.validate("How do I install Python?")  # ✅ Pass
result = guard.validate("Who should I vote for?")    # ❌ Exception
```

---

### **ValidChoices** - Enforce specific values
```python
from guardrails.hub import ValidChoices

guard = Guard().use(
    ValidChoices(
        choices=["yes", "no", "maybe"],
        on_fail="reask"
    )
)

# Ensures LLM returns only allowed values
result = guard.validate("yes")      # ✅ Pass
result = guard.validate("perhaps")  # 🔄 Reask LLM
```

---

### **ValidLength** - Control output size
```python
from guardrails.hub import ValidLength

guard = Guard().use(
    ValidLength(
        min=10,
        max=100,
        on_fail="fix"
    )
)

# Limit response length
result = guard.validate("Short")  # 🔧 Fixed with padding/truncation
```

---

## **3. on_fail Strategies**

| Strategy | Behavior | Use Case | Extra Param |
|----------|----------|----------|-------------|
| `"exception"` | Raise error, stop execution | Critical validations (toxic content) | - |
| `"reask"` | Re-prompt LLM to fix issue | Recoverable errors (wrong format) | - |
| `"fix"` | Auto-correct and continue | Minor issues (length, formatting) | `fix_value="text"` |
| `"noop"` | Log warning, return original | Non-critical validations | - |

### **Example: Different Strategies**
```python
# 1. EXCEPTION - Block toxic content
guard_toxic = Guard().use(
    ToxicLanguage(on_fail="exception")
)

# 2. REASK - Retry on wrong format
guard_format = Guard().use(
    ValidChoices(choices=["A", "B", "C"], on_fail="reask")
)

# 3. FIX - Auto-correct length
guard_length = Guard().use(
    ValidLength(min=10, max=50, on_fail="fix")
)
```

---

### **on_fail with Custom Text (fix_value)**
```python
from guardrails.hub import ValidChoices

# If validation fails, return specific text
guard = Guard().use(
    ValidChoices(
        choices=["yes", "no", "maybe"],
        on_fail="fix",
        fix_value="unknown"  # Return this if LLM gives invalid choice
    )
)

# Example
result = guard.validate("definitely")  # Not in choices
print(result.validated_output)  # "unknown"

# Real use case: Sentiment analysis
sentiment_guard = Guard().use(
    ValidChoices(
        choices=["positive", "negative", "neutral"],
        on_fail="fix",
        fix_value="neutral"  # Default to neutral if uncertain
    )
)

llm_output = "somewhat good but also bad"  # Invalid
result = sentiment_guard.validate(llm_output)
print(result.validated_output)  # "neutral"
```

**Small Example:**
```python
# Question: "Is this safe?"
# Expected: "yes" or "no"
# LLM Response: "probably"

guard = Guard().use(
    ValidChoices(
        choices=["yes", "no"],
        on_fail="fix",
        fix_value="no"  # Default to safe choice
    )
)

result = guard.validate("probably")
print(result.validated_output)  # "no"
```

---

## **4. Structured Outputs with Pydantic**

### Basic Structured Output
```python
from pydantic import BaseModel, Field
from guardrails import Guard

class ProductReview(BaseModel):
    rating: int = Field(ge=1, le=5, description="Rating 1-5")
    sentiment: str = Field(pattern="^(positive|negative|neutral)$")
    summary: str = Field(max_length=100)

# Create guard with schema
guard = Guard.for_pydantic(output_class=ProductReview)

llm_output = """
{
    "rating": 5,
    "sentiment": "positive",
    "summary": "Great product, highly recommended!"
}
"""

result = guard.parse(llm_output)
print(result.rating)      # 5
print(result.sentiment)   # "positive"
print(type(result))       # <class 'ProductReview'>
```

---

### With Multiple Validators
```python
from guardrails.hub import ValidLength, RegexMatch

class UserProfile(BaseModel):
    username: str = Field(description="Username")
    email: str = Field(description="Email address")
    bio: str = Field(description="User bio")

guard = Guard.for_pydantic(output_class=UserProfile).use_many(
    ValidLength(min=3, max=20, on="username", on_fail="exception"),
    RegexMatch(regex=r"^[\w\.-]+@[\w\.-]+\.\w+$", on="email", on_fail="exception"),
    ValidLength(max=200, on="bio", on_fail="fix")
)

result = guard.parse(llm_output)
```

---

## **5. guard.parse() vs guard.validate()**

### **parse()** - For Structured Outputs
```python
from pydantic import BaseModel
from guardrails import Guard

class Response(BaseModel):
    message: str
    confidence: float

guard = Guard.for_pydantic(output_class=Response)

# Returns Pydantic object
result = guard.parse('{"message": "Hello", "confidence": 0.95}')

print(type(result))          # <class 'Response'>
print(result.message)        # "Hello" - direct field access
print(result.confidence)     # 0.95
```

**When to use:**
- ✅ Need typed objects (Pydantic models)
- ✅ Want direct field access (`result.field_name`)
- ✅ Building APIs with structured responses

---

### **validate()** - For Validation Details
```python
from guardrails import Guard
from guardrails.hub import ToxicLanguage

guard = Guard().use(ToxicLanguage(on_fail="exception"))

# Returns ValidationOutcome
result = guard.validate("This is a safe message")

print(type(result))               # <class 'ValidationOutcome'>
print(result.validated_output)    # "This is a safe message"
print(result.validation_passed)   # True
print(result.error)               # None
```

**When to use:**
- ✅ Need validation metadata (passed/failed, errors)
- ✅ Simple string outputs (no structure)
- ✅ Logging/debugging validation results

---

### **Comparison Table**

| Feature | parse() | validate() |
|---------|---------|------------|
| **Returns** | Pydantic object | ValidationOutcome |
| **Access output** | `result.field_name` | `result.validated_output` |
| **Use with** | Pydantic models | Any output |
| **Type safety** | ✅ Full typing | ❌ String/dict |
| **Validation details** | Limited | ✅ Full metadata |
| **Best for** | Structured APIs | Simple validation |

---

## **6. Multiple Validators (Chaining)**

```python
from guardrails import Guard
from guardrails.hub import ToxicLanguage, ValidLength, RestrictToTopic

guard = Guard().use_many(
    ToxicLanguage(threshold=0.5, on_fail="exception"),
    RestrictToTopic(valid_topics=["technology"], on_fail="exception"),
    ValidLength(min=50, max=500, on_fail="fix")
)

# All validators must pass
result = guard.validate(llm_response)
```

**Execution Order:** Validators run in the order specified.

---

## **7. Production Integration**

### **FastAPI Example**
```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from guardrails import Guard
from guardrails.hub import ToxicLanguage

app = FastAPI()

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    reply: str

# Initialize guard
guard = Guard().use(
    ToxicLanguage(threshold=0.5, on_fail="exception")
)

@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    try:
        # Validate input
        guard.validate(request.message)
        
        # Get LLM response
        llm_output = llm.generate(request.message)
        
        # Validate output
        validated = guard.validate(llm_output)
        
        return ChatResponse(reply=validated.validated_output)
    
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
```

---

### **LangChain Integration**
```python
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from guardrails import Guard
from guardrails.hub import ToxicLanguage, RestrictToTopic

# Setup LLM chain
llm = ChatOpenAI(model="gpt-4")
prompt = ChatPromptTemplate.from_template("Answer: {question}")
chain = prompt | llm

# Setup guardrails
guard = Guard().use_many(
    ToxicLanguage(on_fail="exception"),
    RestrictToTopic(valid_topics=["science", "technology"], on_fail="exception")
)

def protected_chat(question: str):
    # Validate input
    guard.validate(question)
    
    # Get LLM response
    response = chain.invoke({"question": question})
    
    # Validate output
    validated = guard.validate(response.content)
    
    return validated.validated_output

# Use it
answer = protected_chat("Explain quantum computing")
```

---

## **8. Custom Validators**

```python
from guardrails.validators import Validator, register_validator

@register_validator(name="no_urls", data_type="string")
class NoURLs(Validator):
    def validate(self, value, metadata):
        import re
        url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        
        if re.search(url_pattern, value):
            raise ValueError("URLs are not allowed in responses")
        
        return value

# Use custom validator
guard = Guard().use(NoURLs(on_fail="exception"))
```

---

## **9. Two-Step Validation (Cost Optimization)**

```python
from guardrails import Guard
from guardrails.hub import RestrictToTopic
import re

# Step 1: Cheap classifier (regex/keywords)
def quick_topic_check(user_query: str) -> bool:
    """Fast, free check before expensive LLM call"""
    allowed_keywords = ["python", "code", "program", "error", "bug"]
    blocked_keywords = ["politics", "religion", "medical advice"]
    
    query_lower = user_query.lower()
    
    # Block immediately if forbidden topic
    if any(word in query_lower for word in blocked_keywords):
        return False
    
    # Allow if clearly on-topic
    if any(word in query_lower for word in allowed_keywords):
        return True
    
    # Uncertain - needs LLM validation
    return None

# Step 2: Expensive LLM validation
guard = Guard().use(
    RestrictToTopic(valid_topics=["programming"], on_fail="exception")
)

def handle_query(user_query: str):
    # Quick check first
    quick_result = quick_topic_check(user_query)
    
    if quick_result == False:
        return "Sorry, I can only help with programming questions."
    
    if quick_result == True:
        # Skip expensive validation, go straight to LLM
        return generate_response(user_query)
    
    # Uncertain - use guardrails
    try:
        guard.validate(user_query)
        return generate_response(user_query)
    except:
        return "Sorry, I can only help with programming questions."
```

**💰 Cost Savings:** 80% of off-topic queries blocked by regex = 80% fewer LLM validation calls!

---

## **10. Common Patterns**

### **Pattern 1: Input + Output Validation**
```python
input_guard = Guard().use(ToxicLanguage(on_fail="exception"))
output_guard = Guard().use_many(
    ToxicLanguage(on_fail="exception"),
    ValidLength(max=500, on_fail="fix")
)

def safe_chat(user_message: str):
    input_guard.validate(user_message)       # Validate input
    response = llm.generate(user_message)
    validated = output_guard.validate(response)  # Validate output
    return validated.validated_output
```

---

### **Pattern 2: Structured API Response**
```python
class APIResponse(BaseModel):
    status: str = Field(pattern="^(success|error)$")
    data: dict
    message: str = Field(max_length=200)

guard = Guard.for_pydantic(output_class=APIResponse)

llm_output = llm.generate_json(prompt)
response = guard.parse(llm_output)  # Returns APIResponse object

return response.dict()  # Convert to dict for JSON response
```

---

### **Pattern 3: Multi-Language Support**
```python
from guardrails.hub import DetectLanguage

guard = Guard().use(
    DetectLanguage(
        allowed_languages=["en", "es", "fr"],
        on_fail="exception"
    )
)

# Ensures responses in allowed languages only
```

---

## **11. Debugging & Monitoring**

### View Validation History
```python
result = guard.validate(llm_output)

# Check what happened
print(result.validation_passed)  # True/False
print(result.error)              # Error message if failed
print(result.validated_output)   # Final output (potentially fixed)

# For parse() - access raw validation
result = guard.parse(llm_output)
print(result.__dict__)  # See all fields
```

---

### Log All Validations
```python
import logging

logging.basicConfig(level=logging.INFO)

guard = Guard().use(
    ToxicLanguage(on_fail="exception")
)

# Automatically logs validation results
result = guard.validate(text)
```

---

## **12. Interview Talking Points**

### **What is Guardrails AI?**
> "Guardrails AI is a validation framework that sits between your application and LLM. It validates both inputs and outputs to ensure safety, quality, and structure. Think of it as input validation for traditional APIs, but specifically designed for LLM responses."

### **When would you use it?**
> "I'd use Guardrails AI in production for:
> 1. **Customer-facing chatbots** - prevent toxic language
> 2. **Structured data extraction** - enforce JSON schemas with Pydantic
> 3. **Topic-restricted bots** - keep support bots on-topic
> 4. **API responses** - ensure consistent structure for frontend parsing"

### **parse() vs validate()?**
> "Use `parse()` when you need typed Pydantic objects for structured outputs - great for APIs. Use `validate()` when you need detailed validation metadata or are just checking string outputs. parse() gives you `result.field_name`, validate() gives you `result.validated_output`."

### **How do you handle invalid LLM outputs gracefully?**
> "I use `on_fail='fix'` with `fix_value` parameter to provide a safe default. For example, if the LLM returns an invalid sentiment like 'kinda good', I set `fix_value='neutral'` so the app continues without errors. This is better than throwing exceptions for minor issues."

### **How do you handle off-topic queries cost-effectively?**
> "I use a two-step approach: first, a cheap regex/keyword filter catches obvious off-topic queries. Only uncertain cases go through expensive LLM-based validation with RestrictToTopic. This saves 80% of validation costs while maintaining accuracy."

---

## **Quick Reference**

```python
# Install
pip install guardrails-ai

# Basic validation
from guardrails import Guard
from guardrails.hub import ToxicLanguage

guard = Guard().use(ToxicLanguage(on_fail="exception"))
result = guard.validate(text)

# Structured output
from pydantic import BaseModel
class MyModel(BaseModel):
    field: str

guard = Guard.for_pydantic(output_class=MyModel)
result = guard.parse(llm_json_output)
print(result.field)  # Direct access

# Multiple validators
guard = Guard().use_many(
    ToxicLanguage(on_fail="exception"),
    ValidLength(max=100, on_fail="fix")
)

# Custom fix value
from guardrails.hub import ValidChoices
guard = Guard().use(
    ValidChoices(
        choices=["yes", "no"],
        on_fail="fix",
        fix_value="no"  # Return "no" if invalid
    )
)
result = guard.validate("maybe")
print(result.validated_output)  # "no"
```

---

## **Common Validators Summary**

| Validator | Purpose | Key Parameters |
|-----------|---------|----------------|
| `ToxicLanguage` | Block harmful content | `threshold`, `on_fail` |
| `RestrictToTopic` | Keep responses on-topic | `valid_topics`, `invalid_topics` |
| `ValidChoices` | Enforce specific values | `choices`, `on_fail`, `fix_value` |
| `ValidLength` | Control output size | `min`, `max`, `on_fail` |
| `RegexMatch` | Pattern validation | `regex`, `on_fail` |
| `DetectLanguage` | Language filtering | `allowed_languages` |

---

**📚 Official Docs:** https://docs.guardrailsai.com/
