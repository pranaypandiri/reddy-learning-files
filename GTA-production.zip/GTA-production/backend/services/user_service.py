from sqlalchemy.orm import Session
from fastapi import HTTPException, status
import time
import logging
from typing import Dict, Any

from backend.models.user import User
from backend.utils.loginutlis import hash_password, verify_password, create_jwt, decode_jwt

logger = logging.getLogger(__name__)

class AuthService:
    TOKEN_EXPIRY_MINUTES = 300  # Move to config/env in real production

    def __init__(self, username: str, password: str, role: str = None, vendor: str = None, eligibility: str = None,workflow:Dict[str, Any]=None):
        self.username = username
        self._password = password
        self.role = role
        self.vendor = vendor
        self.eligibility = eligibility
        self.workflow = workflow

    def _get_user(self, db: Session) -> User:
        return db.query(User).filter(User.username == self.username).first()


    def register(self, db: Session) -> User:
        if self._get_user(db):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username already exists")

        hashed_pw = hash_password(self._password)
        new_user = User(
            username=self.username,
            password=hashed_pw,
            role=self.role,
            status="logout",
            is_login=0,
            vendor=self.vendor,
            eligibility=self.eligibility,
            workflow=self.workflow
        )
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        logger.info(f"User '{self.username}' registered successfully.")
        return new_user

    def login(self, db: Session) -> dict:
        user = self._get_user(db)

        if not user:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")

        if user.role == "admin":
            if not verify_password(self._password, user.password):
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
            
        if user.role == "user":
            if user.eligibility == "no":
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="User is not eligible")
        if user.is_login == 1:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="The user is currently logged in.")

        # Update user login status
        user.is_login = 1
        user.status = "online"
        db.commit()

        # Generate JWT token
        token = create_jwt(user.username, self.TOKEN_EXPIRY_MINUTES)

        return {
            "message": "Login successful",
            "token": token,
            "role": user.role,
            "username": user.username,
            "eligibility": user.eligibility,
            "vendor": user.vendor,
            "workflow": user.workflow
        }



    def refresh_token(self, db: Session, token: str) -> dict:
        try:
            payload = decode_jwt(token)
            username = payload.get("username")
            if not username:
                raise ValueError("Missing username in token")

            user = db.query(User).filter(User.username == username).first()
            if not user or not user.is_login:
                raise ValueError("User not logged in")

            new_token = create_jwt(username, self.TOKEN_EXPIRY_MINUTES)
            logger.info(f"Token refreshed for user '{username}'.")
            return {
                "message": "Token refreshed successfully",
                "token": new_token,
                "username": username,
                "role": user.role
            }

        except Exception as e:
            logger.error(f"Token refresh failed: {str(e)}")
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token refresh failed")

    def logout(self, db: Session) -> dict:
        user = self._get_user(db)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")


        user.is_login = 0
        user.status = "logout"
        db.commit()


        return {"message": "Logout successful"}


    def update_user_details(
        self,
        db: Session,
        new_username: str = None,
        new_role: str = None,
        new_password: str = None,
        new_vendor: str = None,
        new_eligibility: str = None,
        workflow: Dict[str, Any] = None
    ) -> dict:
        user = self._get_user(db)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

        changes = {}

        if new_username and new_username != user.username:
            if db.query(User).filter(User.username == new_username).first():
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="New username already exists")
            changes['old_username'] = user.username
            user.username = new_username
            changes['new_username'] = new_username

        if new_role and new_role != user.role:
            changes['old_role'] = user.role
            user.role = new_role
            changes['new_role'] = new_role

        if new_password:
            user.password = hash_password(new_password)
            changes['password_reset'] = True

        if new_vendor and new_vendor != user.vendor:
            changes['old_vendor'] = user.vendor
            user.vendor = new_vendor
            changes['new_vendor'] = new_vendor

        if new_eligibility and new_eligibility != user.eligibility:
            changes['old_eligibility'] = user.eligibility
            user.eligibility = new_eligibility
            changes['new_eligibility'] = new_eligibility

        if workflow is not None:
            changes['old_workflow'] = user.workflow
            user.workflow = workflow
            changes['new_workflow'] = workflow

        if not changes:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No changes provided")

        db.commit()
        db.refresh(user)

        logger.info(f"User '{self.username}' updated: {changes}")
        return {
            "message": "User details updated successfully",
            "changes": changes
        }

    def delete_user(self, db: Session) -> dict:
        user = self._get_user(db)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

        db.delete(user)
        db.commit()

        logger.info(f"User '{self.username}' deleted successfully.")
        return {"message": f"User '{self.username}' deleted successfully."}