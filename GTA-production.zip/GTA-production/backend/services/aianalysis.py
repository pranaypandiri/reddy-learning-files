# from google import genai
# import json
# import re
# from google.genai.types import (
#     FunctionDeclaration,
#     GenerateContentConfig,
#     GoogleSearch,
#     HarmBlockThreshold,
#     HarmCategory,
#     Part,
#     SafetySetting,
#     ThinkingConfig,
#     Tool,
#     ToolCodeExecution,
# )

# # Convert dict to list for proper JSON formatting
# def dict_to_list(data_dict):
#     return [value for key, value in data_dict.items()]

# # Prompt builder
# def build_prompt(data_list):
#     prompt = f"""
# You are a smart evaluation AI that strictly returns a valid JSON array and nothing else.

# Your task is to evaluate whether the user's answer to each question is correct. You will be given a JSON array where each object contains:
# - `id`: question ID
# - `question`: the question text
# - `answer`: the user's submitted answer
# - `type`: question type (subjective/objective)
# - `correctAnswer`: the correct answer

# Instructions:
# 1. For each item, compare the `answer` with the `correctAnswer`.
# 2. If the question `type` is "subjective", evaluate based on semantic similarity, factual correctness, and relevance.
# 3. Return the same JSON array structure, but add a new field:
#    - `isCorrect`: true or false

# Your response MUST be only the raw JSON array, without any markdown, comments, or other text.

# ### Input Data to Analyze:
# {json.dumps(data_list, indent=2)}
# """
#     return prompt

# # Clean LLM response
# def clean_json_response(response: str):
#     cleaned = re.sub(r"```json|```", "", response, flags=re.IGNORECASE).strip()
#     return json.loads(cleaned)

# # Call Gemini
# def get_content(vertexai: bool, projectid: str, location: str, model: str, prompt: str):
#     client = genai.Client(vertexai=vertexai, project=projectid, location=location)
#     response = client.models.generate_content(
#         model=model,
#         contents=[{"role": "user", "parts": [Part(text=prompt)]}]
#     )
#     return response.text
# # Config
# PROJECT_ID = "zippy-shift-440710-a5"
# LOCATION = "us-central1"
# MODEL_ID = "gemini-2.5-flash"



# # Run
# def cleanjsonresponce(data):    
#     data_list = dict_to_list(data)
#     prompt_text = build_prompt(data_list)
#     llm_response = get_content(True, PROJECT_ID, LOCATION, MODEL_ID, prompt_text)
#     result = clean_json_response(llm_response)
#     return result

# # # Output
# # try:
    
# #     print(json.dumps(result, indent=2))
# # except Exception as e:
# #     print("Error parsing response:", e)
# #     print("Raw response:", llm_response)