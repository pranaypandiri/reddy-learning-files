from sqlalchemy.orm import Session
from fastapi import HTTPException, status, UploadFile
import pandas as pd
from io import BytesIO
from backend.models.user import QuestionBank  # Adjust the import path as needed

class QuestionBankService:
    def __init__(self, file: UploadFile = None):
        self.file = file
    def upload_excel(self, db: Session):
        # Validate file extension
        if not self.file or not self.file.filename.endswith(".xlsx"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Only .xlsx files are supported"
            )

        # Validate file size (e.g., max 5MB)
        max_size_mb = 5
        self.file.file.seek(0, 2)  # Move to end of file
        file_size = self.file.file.tell()
        self.file.file.seek(0)  # Reset pointer to beginning

        if file_size > max_size_mb * 1024 * 1024:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File size exceeds {max_size_mb}MB limit"
            )

        # Read file contents
        contents = self.file.file.read()

        # Basic malicious content check: ensure it's a valid Excel file
        try:
            df = pd.read_excel(BytesIO(contents), engine='openpyxl')
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Uploaded file is not a valid Excel document"
            )

        required_columns = {
            "category", "sub_category", "question", "answer",
            "option1", "option2", "option3", "option4", "option5",
            "type", "required_time_in_minutes", "score", "set"
        }

        if not required_columns.issubset(df.columns):
            missing = required_columns - set(df.columns)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Missing columns: {', '.join(missing)}"
            )

        if "updated_at" not in df.columns:
            df["updated_at"] = None

        for col in df.columns:
            if col != "updated_at":
                df[col] = df[col].astype(str)

        try:
            questions = [
                QuestionBank(
                    policy=row["sub_category"],
                    workflow=row["category"],
                    question=row["question"],
                    answer=row["answer"],
                    options={
                        "option1": row["option1"],
                        "option2": row["option2"],
                        "option3": row["option3"],
                        "option4": row["option4"],
                        "option5": row["option5"]
                    },
                    type=row["type"],
                    score=float(row["score"]),
                    required_time_in_minutes=float(row["required_time_in_minutes"]),
                    set=row["set"],
                    updated_at=row["updated_at"]
                )
                for _, row in df.iterrows()
            ]
            db.bulk_save_objects(questions)
            db.commit()

        except Exception as e:
            db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error while uploading data: {str(e)}"
            )

        return {
            "message": "Question bank uploaded successfully",
            "uploaded_rows": len(questions)
        }
