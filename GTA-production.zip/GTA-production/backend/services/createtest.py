from sqlalchemy.orm import Session
from backend.models.user import QuestionBank,TestSetTracker
import random
from typing import Dict
from fastapi import HTTPException, status


class TestGenerator:
    def generate_test(self, workflow_name: str, db: Session) -> Dict:
        # Step 1: Get all unique set names in ascending order
        available_sets = db.query(QuestionBank.set)\
            .filter(QuestionBank.workflow == workflow_name)\
            .distinct().order_by(QuestionBank.set).all()
        
        available_sets = [s[0] for s in available_sets]  # Extract set names from tuples

        if not available_sets:
            raise HTTPException(status_code=404, detail="No sets found for the workflow")

        # Step 2: Get or initialize the tracker
        tracker = db.query(TestSetTracker).first()
        if not tracker:
            tracker = TestSetTracker(last_assigned_index=-1)
            db.add(tracker)
            db.commit()
            db.refresh(tracker)

        # Step 3: Determine next set index
        next_index = (tracker.last_assigned_index + 1) % len(available_sets)
        assigned_set = available_sets[next_index]

        # Step 4: Update tracker
        tracker.last_assigned_index = next_index
        db.commit()

        # Step 5: Fetch questions for the assigned set
        # questions = db.query(QuestionBank).filter(
        #     QuestionBank.workflow == workflow_name,
        #     QuestionBank.set == assigned_set
        # ).all()

        
        questions = (
            db.query(QuestionBank)
            .filter(
                QuestionBank.workflow == workflow_name,
                QuestionBank.set == assigned_set
            )
            .order_by(QuestionBank.id.asc())  # <-- Added this line
            .all()
        )


        if not questions:
            raise HTTPException(status_code=404, detail=f"No questions found for set {assigned_set}")

        # Step 6: Format response (use options JSON directly)
        response = [
            {
                'id': q.id,
                'policy': q.policy,
                'question': q.question,
                'options': q.options,  # JSON column with all options
                'answer': q.answer,
                'type': q.type,
                "time": q.required_time_in_minutes,
                "score": q.score
            } for q in questions
        ]

        total_time = sum(q["time"] for q in response)

        return {
            "assigned_set": assigned_set,
            "questions": response,
            "total_time_in_minutes": total_time
        }
    
    
    # def generate_test(self, workflow_name: str, db: Session) -> Dict:
    #     # Fetch all questions for the given workflow
    #     all_questions = db.query(QuestionBank).filter(QuestionBank.workflow == workflow_name).all()

    #     if not all_questions:
    #         raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No questions found for the specified workflow")

    #     # No randomization or limit — use all questions as-is
    #     response = [
    #         {
    #             'id': q.id,
    #             'policy': q.policy,
    #             'question': q.question,
    #             'options': [q.option1, q.option2, q.option3, q.option4, q.option5],
    #             'answer': q.answer,
    #             'type': q.type,
    #             "time": q.required_time_in_minutes,
    #             "score": q.score
    #         } for q in all_questions
    #     ]

    #     # Calculate total time required
    #     total_time = sum(q["time"] for q in response)

    #     return {
    #         'questions': response,
    #         'total_time_in_minutes': total_time
    #     }


# class TestGenerator:
#     def generate_test(self, workflow_name: str, db: Session) -> Dict:
#         # Fetch all questions for the given workflow
#         all_questions = db.query(QuestionBank).filter(QuestionBank.workflow == workflow_name).all()

#         if not all_questions:
#             raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No questions found for the specified workflow")

#         # Randomly select up to 20 questions
#         selected_questions = random.sample(all_questions, min(20, len(all_questions)))

#         # Shuffle the selected questions
#         random.shuffle(selected_questions)

#         # Format the response with answers included
#         response = [
#             {
#                 'id': q.id,
#                 'policy': q.policy,
#                 'question': q.question,
#                 'options': [q.option1, q.option2, q.option3, q.option4, q.option5],
#                 'answer': q.answer,
#                 'type': q.type,
#                 "time": q.required_time_in_minutes,
#                 "score": q.score
#             } for q in selected_questions
#         ]

#         # Calculate total time required
#         total_time = sum(q["time"] for q in response)

#         return {
#             'questions': response,
#             'total_time_in_minutes': total_time
#         }


# from sqlalchemy.orm import Session
# from backend.models.user import QuestionBank
# import random
# from typing import Dict
# from fastapi import HTTPException, status

# class TestGenerator:
#     def generate_test(self, workflow_name: str, db: Session, policy_distribution: Dict[str, int]) -> Dict:
#         all_questions = db.query(QuestionBank).filter(QuestionBank.workflow == workflow_name).all()

#         if not all_questions:
#             raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No questions found for the specified workflow")

#         total_questions = 20
#         response = []
#         used_question_ids = set()

#         for policy, percentage in policy_distribution.items():
#             count = round((percentage / 100) * total_questions)
#             policy_questions = [
#                 q for q in all_questions
#                 if q.policy == policy and q.id not in used_question_ids
#             ]

#             selected = random.sample(policy_questions, min(count, len(policy_questions)))
#             used_question_ids.update(q.id for q in selected)

#             response.extend([
#                 {
#                     'id': q.id,
#                     'policy': q.policy,
#                     'question': q.question,
#                     'options': [q.option1, q.option2, q.option3, q.option4, q.option5],
#                     'answer': q.answer,
#                     'type': q.type,
#                     "time": q.required_time_in_minutes,
#                     "score": q.score
#                 } for q in selected
#             ])

#             # Fallback: fill remaining from other policies
#             if len(selected) < count:
#                 remaining = count - len(selected)
#                 fallback_questions = [
#                     q for q in all_questions
#                     if q.policy != policy and q.id not in used_question_ids
#                 ]
#                 fallback_selected = random.sample(fallback_questions, min(remaining, len(fallback_questions)))
#                 used_question_ids.update(q.id for q in fallback_selected)

#                 response.extend([
#                     {
#                         'id': q.id,
#                         'policy': q.policy,
#                         'question': q.question,
#                         'options': [q.option1, q.option2, q.option3, q.option4, q.option5],
#                         'answer': q.answer,
#                         'type': q.type,
#                         "time": q.required_time_in_minutes,
#                         "score": q.score
#                     } for q in fallback_selected
#                 ])

#         # Ensure max 20 questions
#         response = response[:total_questions]
#         total_time = sum(q["time"] for q in response)

#         return {
#             'questions': response,
#             'total_time_in_minutes': total_time
#         }