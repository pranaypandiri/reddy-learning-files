import sys
import os
# Add project root and app directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Internal modules
from backend.database import engine, Base, SessionLocal

# get the DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


