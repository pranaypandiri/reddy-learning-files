from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os
from dotenv import load_dotenv
from urllib.parse import quote_plus


Base = declarative_base()

class DatabaseConfig:
    def __init__(self, db_type="sqlite", DB_USER=None, DB_PASSWORD=None, DB_NAME=None, DB_HOST=None, DB_PORT=None):
        self.db_type = db_type
        self.DB_USER = DB_USER
        self.DB_PASSWORD = DB_PASSWORD
        self.DB_NAME = DB_NAME
        self.DB_HOST = DB_HOST
        self.DB_PORT = DB_PORT

        self.engine = self._create_engine()
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

    def _create_engine(self):
        if self.db_type == "sqlite":
            BASE_DIR = os.path.dirname(os.path.abspath(__file__))
            db_url = f"sqlite:///{os.path.join(BASE_DIR, 'CaseSync.db')}"
            return create_engine(db_url, connect_args={"check_same_thread": False})

        elif self.db_type == "postgresql":
            if not all([self.DB_USER, self.DB_PASSWORD, self.DB_NAME, self.DB_HOST, self.DB_PORT]):
                raise ValueError("Missing PostgreSQL connection parameters.")
            # db_url = (
            #     f"postgresql+psycopg2://{self.DB_USER}:{self.DB_PASSWORD}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"
            # )
            # db_url = (
            #     f"postgresql+psycopg2://{self.DB_USER}:{self.DB_PASSWORD}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"
            # )
            
            db_url = (
                f"postgresql+psycopg2://{self.DB_USER}:{self.DB_PASSWORD}@localhost/{self.DB_NAME}"
                f"?host=/cloudsql/{self.DB_HOST}"
            )

            return create_engine(db_url)

        elif self.db_type == "mysql":
            if not all([self.DB_USER, self.DB_PASSWORD, self.DB_NAME, self.DB_HOST, self.DB_PORT]):
                raise ValueError("Missing MySQL connection parameters.")
            db_url = (
                f"mysql+pymysql://{self.DB_USER}:{self.DB_PASSWORD}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"
            )
            return create_engine(db_url)

        else:
            raise ValueError(f"Unsupported database type: {self.db_type}")


# Load environment variables from .env file
load_dotenv()

DB_USER = os.getenv("DB_USER")
DB_PASSWORD = quote_plus(os.getenv("DB_PASSWORD"))
DB_NAME = os.getenv("DB_NAME")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")

# DB_USER = "postgres"
# DB_PASSWORD = "SlFi.3_NTQN_4QYB"
# DB_NAME = "postgres"
# DB_HOST = "34.132.70.159"
# DB_PORT = "5432"


# db_config = DatabaseConfig(db_type="postgresql", DB_USER=DB_USER, DB_PASSWORD=DB_PASSWORD, DB_NAME=DB_NAME, DB_HOST=DB_HOST, DB_PORT=DB_PORT)





db_config = DatabaseConfig(db_type="postgresql", DB_USER=DB_USER, DB_PASSWORD=DB_PASSWORD, DB_NAME=DB_NAME, DB_HOST=DB_HOST, DB_PORT=DB_PORT)

engine = db_config.engine
SessionLocal = db_config.SessionLocal
