import secrets
import jwt
from datetime import datetime, timedelta
from fastapi import HTTPException
import bcrypt
import os
from dotenv import load_dotenv

load_dotenv()


SECRET_KEY = os.getenv("SECRET_KEY")

# Function to hash a password
def hash_password(password: str) -> str:
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

# Function to verify a password
def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

# function to create the jwt token

def create_jwt(usename: str,token_expire_limit :int):
    payload = {
        "username": usename,
        "exp": datetime.utcnow() + timedelta(minutes=token_expire_limit)
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")



def decode_jwt(token: str) -> dict:
    try:
        decoded = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return decoded
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


    
