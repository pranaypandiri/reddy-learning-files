from sqlalchemy import Column, String, Integer, DateTime, func,Date,event,BigInteger,Float
from sqlalchemy.dialects.postgresql import JSON
from backend.database import Base
from sqlalchemy.ext.mutable import MutableDict



class User(Base):
    __tablename__ = "users_table"
    __table_args__ = {'extend_existing': True}
    
    username = Column(String(255), primary_key=True, index=True, nullable=False)
    password = Column(String)
    role = Column(String(50))
    status = Column(String)
    vendor = Column(String)
    eligibility = Column(String)
    is_login = Column(Integer)
    workflow = Column(MutableDict.as_mutable(JSON))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())




class QuestionBank(Base):
    __tablename__ = "question_bank"
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    policy = Column(String)
    workflow = Column(String)
    question = Column(String)
    answer = Column(String)
    options = Column(JSON)  # New column for all options as JSON
    type = Column(String)
    score = Column(Float)
    required_time_in_minutes = Column(Float)
    set = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class SubmitData(Base):
    __tablename__ = "submit_data"
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    # date = Column(DateTime(timezone=True), server_default=func.now())
    date = Column(Date, server_default=func.current_date())
    username = Column(String)
    testdata = Column(JSON)  # Use JSON instead of String
    result = Column(String)
    totaltimetaken = Column(Float)
    compliance = Column(JSON)
    workflow = Column(String)
    vendor = Column(String)
    score = Column(Float)
    status = Column(String)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    

class Workflow(Base):
    __tablename__ = "workflow"
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    date = Column(Date, server_default=func.current_date())
    workflow = Column(String)
    distrbution = Column(JSON)
    passingscore = Column(Float)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class TestSetTracker(Base):
    __tablename__ = "test_set_tracker"

    id = Column(Integer, primary_key=True, autoincrement=True)
    last_assigned_index = Column(Integer, nullable=False, default=-1)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

