from pydantic import BaseModel
from typing import Optional,List, Dict, Any

class LoginInput(BaseModel):
    username: str
    password: str

class LogoutInput(BaseModel):
    username: str

class RegisterUser(BaseModel):
    username: str
    password: str
    role: str
    vendor: Optional[str] = None
    eligibility: Optional[str] = None
    workflow: Optional[Dict[str, Any]] = None

class UpdateUserInput(BaseModel):
    username: str
    new_username: Optional[str] = None
    new_role: Optional[str] = None
    new_password: Optional[str] = None
    new_vendor: Optional[str] = None
    new_eligibility: Optional[str] = None
    workflow: Optional[Dict[str, Any]] = None


class DeleteUserInput(BaseModel):
    username: str


class QuestionDeleteRequest(BaseModel):
    ids: List[int]


class SubmitDataCreate(BaseModel):
    testdata: Dict[str, Any]  # JSON-like structure
    result: Optional[str] = None
    workflow: Optional[str] = None
    totaltimetaken :Optional[float] = None
    score : Optional[float] =None
    compliance : Dict[str, Any]
    status : Optional[str] = "valid"
    vendor: Optional[str] = None
    



class SubmitDataUpdate(BaseModel):
    result: Optional[str]  # Only updating result
    status:Optional[str]


class UpdateWorkflowInput(BaseModel):
    workflow: str
    passingscore: Optional[float] = None



class GenrateTest(BaseModel):
    workflow: str

class GetResult(BaseModel):
    qustionid:List[int]
    workflow:str

