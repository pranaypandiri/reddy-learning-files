# FastAPI Core
from fastapi import (
    FastAPI, Depends, Body, Header, HTTPException, UploadFile, File,
    WebSocket, WebSocketDisconnect, Security, Query, Path, status, Request
)
from fastapi.responses import StreamingResponse
from fastapi.encoders import jsonable_encoder
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

# SQLAlchemy
from sqlalchemy import and_, or_, func
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError, IntegrityError

# Date & Time
from datetime import datetime, timedelta, timezone

# Data Handling
from io import BytesIO
import pandas as pd
import json
import asyncio
import os
from collections import Counter, defaultdict

# Security Headers
import secure


# Rate Limiting
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

# Logging
import logging

# # for local
# from init_db import get_db
# from schemas.user import LoginInput, LogoutInput,RegisterUser , UpdateUserInput,DeleteUserInput,QuestionDeleteRequest,SubmitDataCreate,SubmitDataUpdate,UpdateWorkflowInput,GenrateTest,GetResult
# from services.user_service import AuthService
# from services.createtest import TestGenerator
# from services.upload_data import QuestionBankService
# from models.user import QuestionBank,SubmitData,User,Workflow
# # from services.aianalysis import cleanjsonresponce
# from utils.loginutlis import decode_jwt,hash_password



# for deployment
from backend.init_db import get_db
from backend.schemas.user import LoginInput, LogoutInput,RegisterUser , UpdateUserInput,DeleteUserInput,QuestionDeleteRequest,SubmitDataCreate,SubmitDataUpdate,UpdateWorkflowInput,GenrateTest,GetResult
from backend.services.user_service import AuthService
from backend.services.createtest import TestGenerator
from backend.services.upload_data import QuestionBankService
from backend.models.user import QuestionBank,SubmitData,User,Workflow
# from backend.services.aianalysis import cleanjsonresponce
from backend.utils.loginutlis import decode_jwt



# Environment mode
APP_MODE = os.getenv("APP_MODE", "development")

# Swagger URLs (disabled in production)
docs_url = None if APP_MODE == "production" else "/docs"
redoc_url = None if APP_MODE == "production" else "/redoc"
openapi_url = None if APP_MODE == "production" else "/openapi.json"

# Initialize FastAPI app
app = FastAPI(
    title="GTA",
    version="1.0.2",
    docs_url=docs_url,
    redoc_url=redoc_url,
    openapi_url=openapi_url
)

# Logging
logger = logging.getLogger(__name__)

# Security
security = HTTPBearer()

# Rate Limiting
limiter = Limiter(key_func=get_remote_address)

# Secure Headers (new API)
secure_headers = secure.Secure()

# Secure Headers Middleware 
@app.middleware("http")
async def set_secure_headers(request: Request, call_next):
    response = await call_next(request)

    # Manually set headers
    response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"

    return response

# CORS Middleware 
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Consider restricting in production
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
)


@app.get("/")
def read_root():
    return {"Message": "API Running"}


# Login Endpoint
@app.post("/login", summary="User login")
@limiter.limit("5/minute")
async def login(userInput: LoginInput, request: Request, db: Session = Depends(get_db)):
    if not userInput.username or not userInput.password:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username and password are required")

    try:
        user = AuthService(userInput.username.strip(), userInput.password)
        logger.info(f"Login attempt for user: {userInput.username}")
        return user.login(db)
    except Exception as e:
        logger.error(f"Login failed for user {userInput.username}: {str(e)}")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Login failed")

# Refresh Token Endpoint
@app.get("/auth/refresh", summary="Refresh JWT token")
@limiter.limit("10/minute")
def refresh_session(request: Request,credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        auth = AuthService(username="", password="")
        return auth.refresh_token(db, token)
    except Exception as e:
        logger.error(f"Token refresh failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token refresh failed")

# Logout Endpoint
@app.post("/logout", summary="User logout")
@limiter.limit("10/minute")
async def logout(userInput: LogoutInput, request: Request,db: Session = Depends(get_db)):
    if not userInput.username:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username is required")

    try:
        user = AuthService(userInput.username.strip(), password=None)
        return user.logout(db)
    except Exception as e:
        logger.error(f"Logout failed for user {userInput.username}: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Logout failed")

# Register Endpoint
@app.post("/register", summary="Register a new user")
@limiter.limit("3/minute")
async def register(userInput: RegisterUser,
                   request: Request,
                #    credentials: HTTPAuthorizationCredentials = Security(security),
                   db: Session = Depends(get_db)):
    # token = credentials.credentials
    # try:
    #     validate_token_and_get_user(token, "admin", db)
    # except Exception as e:
    #     logger.warning(f"Unauthorized registration attempt: {str(e)}")
    #     raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")

    if not userInput.username or not userInput.password:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username and password are required")

    user = AuthService(
        username=userInput.username.strip(),
        password=userInput.password,
        role=userInput.role,
        vendor=userInput.vendor,
        eligibility=userInput.eligibility,
        workflow=userInput.workflow
    )

    try:
        registered_user = user.register(db)
        logger.info(f"User registered: {userInput.username}")
        return registered_user
    except IntegrityError:
        db.rollback()
        logger.warning(f"Duplicate registration attempt: {userInput.username}")
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="User already exists")
    except Exception as e:
        db.rollback()
        logger.error(f"Registration failed for user {userInput.username}: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Registration failed")

# Delete User Endpoint
@app.post("/delete", summary="Delete a user")
@limiter.limit("5/minute")
async def delete_user(userInput: DeleteUserInput,
                      request: Request,
                      credentials: HTTPAuthorizationCredentials = Security(security),
                      db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
    except Exception as e:
        logger.warning(f"Unauthorized delete attempt: {str(e)}")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")

    try:
        user = AuthService(userInput.username.strip(), password="", role=None)
        result = user.delete_user(db)
        logger.info(f"User deleted: {userInput.username}")
        return result
    except Exception as e:
        db.rollback()
        logger.error(f"User deletion failed for {userInput.username}: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="User deletion failed")

# Update User Endpoint
@app.put("/user/update", summary="Update user details")
@limiter.limit("5/minute")
async def update_user_details(userInput: UpdateUserInput,
                              request: Request,
                              credentials: HTTPAuthorizationCredentials = Security(security),
                              db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
    except Exception as e:
        logger.warning(f"Unauthorized update attempt: {str(e)}")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")

    try:
        user_service = AuthService(userInput.username.strip(), password="")
        update_result = user_service.update_user_details(
            db=db,
            new_username=userInput.new_username,
            new_role=userInput.new_role,
            new_password=userInput.new_password,
            new_vendor=userInput.new_vendor,
            new_eligibility=userInput.new_eligibility,
            workflow=userInput.workflow
        )
        logger.info(f"User updated: {userInput.username}")
        return update_result
    except Exception as e:
        db.rollback()
        logger.error(f"User update failed for {userInput.username}: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="User update failed")


# Download User Template
@app.get("/users/template", summary="Download user creation Excel template")
@limiter.limit("10/minute")
async def download_user_template(request: Request,credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")

    headers = ["username", "password", "role", "vendor", "eligibility", "is_attempted"]
    df = pd.DataFrame(columns=headers)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name="Users")
    output.seek(0)
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=user_template.xlsx"}
    )

# Upload User Excel
@app.post("/users/upload", summary="Upload Excel to create users in bulk")
@limiter.limit("3/minute")
async def upload_user_excel(request: Request,credentials: HTTPAuthorizationCredentials = Security(security), file: UploadFile = File(...), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")

    try:
        df = pd.read_excel(file.file)
        required_columns = {"username", "password", "role", "vendor", "eligibility", "is_attempted"}
        if not required_columns.issubset(df.columns):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Missing required columns: {required_columns}")

        created_users = []
        for _, row in df.iterrows():
            try:
                auth_service = AuthService(
                    username=row["username"],
                    password=row["password"],
                    role=row["role"],
                    vendor=row.get("vendor"),
                    eligibility=row.get("eligibility")
                )
                user = auth_service.register(db)
                created_users.append(user.username)
            except Exception as e:
                logger.warning(f"User creation failed for {row['username']}: {str(e)}")
                continue

        return {
            "message": f"{len(created_users)} users created successfully",
            "users": created_users
        }

    except Exception as e:
        logger.error(f"Bulk upload failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Bulk upload failed")

# Download Question Bank Template
@app.get("/question-bank/template", summary="Download QuestionBank Excel template")
@limiter.limit("10/minute")
async def download_question_bank_template(request: Request,credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")

    headers = [
        "category", "sub_category", "question", "answer",
        "option1", "option2", "option3", "option4", "option5",
        "type", "required_time_in_minutes", "score", "set"
    ]

    dummy_data = [
        {
            "category": "Assessment Test",
            "sub_category": "Quantitative",
            "question": "What is the capital of India?",
            "answer": "New Delhi",
            "option1": "New Delhi",
            "option2": "Bihar",
            "option3": "Kolkata",
            "option4": "Haryana",
            "option5": "",
            "type": "objective",
            "required_time_in_minutes": 2,
            "score": 5,
            "set": "set1"
        },
        {
            "category": "Assessment Test",
            "sub_category": "Verbal",
            "question": "Which word is a synonym of 'Happy'?",
            "answer": "Joyful",
            "option1": "Joyful",
            "option2": "Sad",
            "option3": "Angry",
            "option4": "Tired",
            "option5": "",
            "type": "objective",
            "required_time_in_minutes": 2,
            "score": 5,
            "set": "set1"
        }
    ]

    df = pd.DataFrame(dummy_data, columns=headers)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name="QuestionBank")
    output.seek(0)

    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=question_bank_template.xlsx"}
    )


# Upload Question Bank
@app.post("/upload-question-bank", summary="Upload Excel to populate Question Bank")
@limiter.limit("3/minute")
async def upload_question_bank(request: Request,credentials: HTTPAuthorizationCredentials = Security(security), file: UploadFile = File(...), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
        service = QuestionBankService(file)
        result = service.upload_excel(db)
        return result
    except Exception as e:
        logger.error(f"Question bank upload failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Upload failed")

# Generate Test
@app.post("/generate-test", tags=["Test"])
@limiter.limit("5/minute")
async def generate_test_endpoint(userInput: GenrateTest,request: Request, credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "user", db)
        test_generator = TestGenerator()
        test_data = test_generator.generate_test(userInput.workflow, db)
        return test_data
    except Exception as e:
        logger.error(f"Test generation failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Test generation failed")

# Get Result
@app.post("/getResult", tags=["Test"])
@limiter.limit("5/minute")
async def get_result_endpoint(requests: GetResult,request: Request, credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "user", db)
        questions_answer = db.query(QuestionBank).filter(QuestionBank.id.in_(requests.qustionid)).all()
        data = {q.id: q.answer for q in questions_answer}
        passing_percentage = db.query(Workflow).filter(Workflow.workflow == requests.workflow).first()
        return {"result": data, "passingPercentage": passing_percentage.passingscore}
    except Exception as e:
        logger.error(f"Result generation failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Result generation failed")

# Delete Questions
@app.delete("/delete-questions", tags=["Question Bank"])
@limiter.limit("3/minute")
async def delete_questions(requests: QuestionDeleteRequest,request: Request, credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
        questions_to_delete = db.query(QuestionBank).filter(QuestionBank.id.in_(requests.ids)).all()
        if not questions_to_delete:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No questions found for the given IDs")
        for question in questions_to_delete:
            db.delete(question)
        db.commit()
        return {"message": f"Deleted {len(questions_to_delete)} question(s)", "deleted_ids": requests.ids}
    except Exception as e:
        logger.error(f"Question deletion failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Deletion failed")

# Submit Data
@app.post("/submit-data/")
@limiter.limit("5/minute")
async def create_submit_data(data: SubmitDataCreate,request: Request, credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        username = validate_token_and_get_user(token, "user", db)
        new_entry = SubmitData(
            username=username,
            testdata=data.testdata,
            result=data.result,
            workflow=data.workflow,
            totaltimetaken=data.totaltimetaken,
            compliance=data.compliance,
            score=data.score,
            vendor=data.vendor,
            status=data.status
        )
        user = db.query(User).filter(User.username == username).first()
        user.workflow[data.workflow] = False
        db.add(new_entry)
        db.commit()
        db.refresh(new_entry)
        db.refresh(user)
        return {"message": "Data submitted successfully", "id": new_entry.id}
    except Exception as e:
        logger.error(f"Data submission failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Submission failed")

# Update Result
@app.put("/submit-data/{data_id}/update-result")
@limiter.limit("5/minute")
async def update_result(data_id: int, update: SubmitDataUpdate,request: Request, credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
        entry = db.query(SubmitData).filter(SubmitData.id == data_id).first()
        if not entry:
            raise HTTPException(status_code=404, detail="Data not found")
        if update.result is not None:
            entry.result = update.result
        if update.status is not None:
            entry.status = update.status
        db.commit()
        db.refresh(entry)
        return {"message": "Result updated successfully", "id": entry.id, "result": entry.result, "status": entry.status}
    except Exception as e:
        logger.error(f"Result update failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Update failed")

# Get All Users
@app.get("/usersdata/")
@limiter.limit("10/minute")
def get_all_users(
                   request: Request,
                    credentials: HTTPAuthorizationCredentials = Security(security),
                   db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
        users = db.query(User).all()
        return users
    except Exception as e:
        logger.error(f"Fetching users failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to fetch users")

# Get Workflow
@app.get("/workflow/")
@limiter.limit("10/minute")
def workflow(request: Request,credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
        workflows = db.query(Workflow).all()
        return workflows
    except Exception as e:
        logger.error(f"Fetching workflows failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to fetch workflows")

# Get All Questions
@app.get("/questionsdata/")
@limiter.limit("10/minute")
def get_all_questions(request: Request,credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
        questions = db.query(QuestionBank).all()
        return questions
    except Exception as e:
        logger.error(f"Fetching questions failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to fetch questions")

# Get All Submitted Data
@app.get("/submitted-data/")
@limiter.limit("10/minute")
def get_all_submitted_data(request: Request,credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
        submissions = db.query(SubmitData).all()
        return submissions
    except Exception as e:
        logger.error(f"Fetching submissions failed: {str(e)}")



# Download submissions (row-based format)
@app.get("/download-submissions-excel/", summary="Download submissions in row-based format")
@limiter.limit("5/minute")
def download_submissions_excel(
    request: Request,
    start_date: datetime = Query(..., description="Start date in YYYY-MM-DD format"),
    end_date: datetime = Query(..., description="End date in YYYY-MM-DD format"),
    credentials: HTTPAuthorizationCredentials = Security(security),
    db: Session = Depends(get_db)
):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
        data = db.query(SubmitData).filter(
            SubmitData.date >= start_date,
            SubmitData.date <= end_date
        ).all()

        rows = []
        for entry in data:
            if entry.testdata and isinstance(entry.testdata, dict):
                for item in entry.testdata.values():
                    rows.append({
                        "date": entry.date,
                        "question_id": item.get("id"),
                        "username": entry.username,
                        "question": item.get("question"),
                        "answer": item.get("attemptedAnswer"),
                        "answer_correct": item.get("isCorrectAnswer"),
                    })

        df = pd.DataFrame(rows)
        for col in ["date", "created_at", "updated_at"]:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col]).dt.tz_localize(None)

        output = BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Submissions')
        output.seek(0)

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=submissions_row_format.xlsx"}
        )
    except Exception as e:
        logger.error(f"Download submissions failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Download failed")

# Download submissions (user-only format)
@app.get("/download-submissions-excel-useronly/", summary="Download submissions in row-based format")
@limiter.limit("5/minute")
def download_submissions_excel_useronly(
    request: Request,
    start_date: datetime = Query(..., description="Start date in YYYY-MM-DD format"),
    end_date: datetime = Query(..., description="End date in YYYY-MM-DD format"),
    credentials: HTTPAuthorizationCredentials = Security(security),
    db: Session = Depends(get_db)
):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
        data = db.query(SubmitData).filter(
            SubmitData.date >= start_date,
            SubmitData.date <= end_date
        ).all()

        rows = []
        for entry in data:
            if entry.testdata and isinstance(entry.testdata, dict):
                rows.append({
                    "date": entry.date,
                    "vendor": entry.vendor,
                    "username": entry.username,
                    "totaltimetaken": entry.totaltimetaken,
                    "workflow": entry.workflow,
                    "score": entry.score,
                    "result": entry.result,
                })

        df = pd.DataFrame(rows)
        for col in ["date", "created_at", "updated_at"]:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col]).dt.tz_localize(None)

        output = BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Submissions')
        output.seek(0)

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=submissions_userdata.xlsx"}
        )
    except Exception as e:
        logger.error(f"Download user-only submissions failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Download failed")

# Add Workflow
@app.post("/addworkflow")
@limiter.limit("3/minute")
def add_workflow(userInput: UpdateWorkflowInput, request: Request,credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
        data = Workflow(workflow=userInput.workflow, passingscore=userInput.passingscore)
        db.add(data)
        db.commit()
        db.refresh(data)
        return {"message": "Workflow added successfully", "id": data.id}
    except Exception as e:
        logger.error(f"Add workflow failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Workflow creation failed")

# Update Workflow
@app.put("/updateFlow")
@limiter.limit("3/minute")
def update_workflow(userInput: UpdateWorkflowInput,request: Request, credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        validate_token_and_get_user(token, "admin", db)
        workflow_data = db.query(Workflow).filter(Workflow.workflow == userInput.workflow).first()
        if not workflow_data:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")

        updated = False
        if userInput.passingscore is not None and userInput.passingscore != workflow_data.passingscore:
            workflow_data.passingscore = userInput.passingscore
            updated = True
        if userInput.workflow is not None and userInput.workflow != workflow_data.workflow:
            workflow_data.workflow = userInput.workflow
            updated = True

        if updated:
            db.commit()
            db.refresh(workflow_data)
            return {"message": "Workflow updated successfully", "id": workflow_data.workflow}
        else:
            return {"message": "No changes detected", "id": workflow_data.workflow}
    except Exception as e:
        logger.error(f"Update workflow failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Workflow update failed")

# Get Workflow for User
@app.get("/getworkflow")
@limiter.limit("5/minute")
async def get_workflow(request: Request,credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        username = validate_token_and_get_user(token, "user", db)
        workflow_user = db.query(User).filter(User.username == username).first()
        if not workflow_user or not workflow_user.workflow:
            raise HTTPException(status_code=404, detail="User workflow not found")

        submit_entries = db.query(SubmitData).filter(SubmitData.username == username).all()
        submit_status_map = {entry.workflow: entry.status for entry in submit_entries if entry.workflow}

        final_workflows = []
        for workflow_name, attempted in workflow_user.workflow.items():
            status = submit_status_map.get(workflow_name)
            if attempted is True and status != "valid":
                final_workflows.append(workflow_name)
            elif attempted is False and status != "valid":
                final_workflows.append(workflow_name)

        return {"workflow": list(set(final_workflows))}
    except Exception as e:
        logger.error(f"Get workflow failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to fetch workflow")

# Get Submitted Data for User
@app.get("/getSubmittedData")
@limiter.limit("5/minute")
async def getsubmiteddata(request: Request,credentials: HTTPAuthorizationCredentials = Security(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    try:
        username = validate_token_and_get_user(token, "user", db)
        submitdata = db.query(SubmitData).filter(
            SubmitData.username == username,
            SubmitData.status == "valid"
        ).all()
        return {"submitdata": submitdata}
    except Exception as e:
        logger.error(f"Get submitted data failed: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to fetch submitted data")

def validate_token_and_get_user(token,required_role,db):
    decoded_token = decode_jwt(token)

    if not decoded_token:
        raise HTTPException(status_code=401, detail="Invalid token")

    username = decoded_token.get("username")
    if not username:
        raise HTTPException(status_code=400, detail="Username not found in token")

    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if required_role and user.role != required_role:
        raise HTTPException(status_code=403, detail=f"Permission denied for role '{user.role}'")

    return username


