"""
Test Firestore connection
"""

from google.cloud import firestore

PROJECT_ID = "ai-practice-388514"

print("Testing Firestore connection...")
try:
    db = firestore.Client(project=PROJECT_ID)

    # Try to create a test document
    test_ref = db.collection("test_sessions").document("test_123")
    test_ref.set({"test": "Hello Firestore!", "timestamp": firestore.SERVER_TIMESTAMP})

    print("✅ Firestore connected successfully!")

    # Read it back
    doc = test_ref.get()
    if doc.exists:
        print(f"✅ Test document created: {doc.to_dict()}")

    # Clean up
    test_ref.delete()
    print("✅ Test document deleted")

except Exception as e:
    print(f"❌ Error: {e}")
