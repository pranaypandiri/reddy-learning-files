# 🧪 LangSmith Cheat Sheet

## 🎯 What is LangSmith?
Tracing + Evaluation + Monitoring for LLM applications

---

## 📦 Setup (3 ENV VARS - MEMORIZE!)

```python
import os
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "lsv2_pt_xxxxx"
os.environ["LANGCHAIN_PROJECT"] = "My-Project"

from langsmith import Client
client = Client()
```

**That's it!** All LangChain/LangGraph calls are now traced.

---

## 1️⃣ Create Dataset (Upload Test Cases)

```python
# Create dataset ONCE
dataset = client.create_dataset(
    dataset_name="My-Test-Dataset",
    description="Test cases for evaluation"
)

# Add examples
client.create_example(
    inputs={"question": "What is Python?"},      # Input to agent
    outputs={"expected_topic": "programming"},   # Expected (for evaluator)
    dataset_id=dataset.id
)

# Add multiple examples
examples = [
    {"inputs": {"question": "What is ML?"}, "outputs": {"expected": "machine learning"}},
    {"inputs": {"question": "What is AI?"}, "outputs": {"expected": "artificial intelligence"}},
]
for ex in examples:
    client.create_example(inputs=ex["inputs"], outputs=ex["outputs"], dataset_id=dataset.id)
```

---

## 2️⃣ Create ONE Simple Evaluator

```python
from langsmith.schemas import Run, Example

def quality_evaluator(run: Run, example: Example) -> dict:
    """
    SIGNATURE: (run, example) → {"key", "score", "comment"}
    
    run.outputs = Agent's actual response
    example.outputs = Expected values from dataset
    """
    # Get agent output
    agent_output = ""
    if run.outputs:
        agent_output = run.outputs.get("output", "")
    
    # Get expected from dataset
    expected = example.outputs.get("expected", "")
    
    # Score: 1.0 if expected keyword in response, else 0.0
    score = 1.0 if expected.lower() in agent_output.lower() else 0.0
    
    return {
        "key": "relevance",           # Metric name in UI
        "score": score,               # 0.0 to 1.0
        "comment": f"Expected: {expected}"  # Optional explanation
    }
```

### Evaluator Template:
```python
def my_evaluator(run: Run, example: Example) -> dict:
    actual = run.outputs.get("output", "")
    expected = example.outputs.get("expected", "")
    score = ...  # Your logic
    return {"key": "metric_name", "score": score}
```

---

## 3️⃣ Run Evaluation

```python
from langsmith import evaluate

# Your agent function (takes inputs dict, returns dict)
def my_agent(inputs: dict) -> dict:
    response = llm.invoke(inputs["question"])
    return {"output": response.content}

# Run evaluation
results = evaluate(
    my_agent,                          # Your function
    data="My-Test-Dataset",            # Dataset name
    evaluators=[quality_evaluator],    # List of evaluators
    experiment_prefix="v1"             # Label in UI
)

print(results.aggregate_metrics)
```

---

## 4️⃣ A/B Testing (Compare Two Prompts)

```python
# Two different prompts
PROMPT_A = "Be helpful and concise."
PROMPT_B = "Be an expert with detailed answers."

def agent_a(inputs: dict) -> dict:
    response = llm.invoke([SystemMessage(content=PROMPT_A), HumanMessage(content=inputs["question"])])
    return {"output": response.content}

def agent_b(inputs: dict) -> dict:
    response = llm.invoke([SystemMessage(content=PROMPT_B), HumanMessage(content=inputs["question"])])
    return {"output": response.content}

# Test both
results_a = evaluate(agent_a, data="My-Dataset", evaluators=[quality_evaluator], experiment_prefix="helpful")
results_b = evaluate(agent_b, data="My-Dataset", evaluators=[quality_evaluator], experiment_prefix="expert")

# Compare in LangSmith UI!
```

---

## 5️⃣ Production Monitoring

```python
from datetime import datetime, timedelta

# Get recent runs
runs = client.list_runs(
    project_name="My-Project",
    start_time=datetime.now() - timedelta(hours=24)
)

# Calculate metrics
errors = sum(1 for r in runs if r.error)
total = len(list(runs))
error_rate = errors / total if total > 0 else 0

print(f"Error rate: {error_rate:.2%}")

# Get feedback scores
for run in runs:
    feedbacks = client.list_feedback(run_id=run.id)
    for fb in feedbacks:
        print(f"{fb.key}: {fb.score}")
```

---

## 📊 Visual Flow

```
┌──────────────────────────────────────────────────────────────────────────┐
│                         LANGSMITH WORKFLOW                               │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  1. SETUP                                                                │
│     os.environ["LANGCHAIN_TRACING_V2"] = "true"                         │
│     os.environ["LANGCHAIN_API_KEY"] = "..."                             │
│                                                                          │
│  2. CREATE DATASET                                                       │
│     client.create_dataset("Name")                                        │
│     client.create_example(inputs={...}, outputs={...})                   │
│                                                                          │
│  3. DEFINE EVALUATOR                                                     │
│     def eval(run, example) → {"key", "score"}                           │
│                                                                          │
│  4. RUN EVALUATION                                                       │
│     evaluate(agent_func, data="Name", evaluators=[eval])                 │
│                                                                          │
│  5. VIEW IN UI                                                           │
│     smith.langchain.com → Projects → Experiments                         │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## 🔑 Key Syntax to Memorize

```python
# 1. SETUP (3 env vars)
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "key"
os.environ["LANGCHAIN_PROJECT"] = "project"

# 2. CLIENT
from langsmith import Client
client = Client()

# 3. DATASET
client.create_dataset(dataset_name="Name")
client.create_example(inputs={...}, outputs={...}, dataset_id=id)

# 4. EVALUATOR SIGNATURE (ALWAYS THIS!)
def evaluator(run: Run, example: Example) -> dict:
    return {"key": "name", "score": 0.0-1.0}

# 5. EVALUATE
from langsmith import evaluate
evaluate(func, data="Dataset", evaluators=[eval], experiment_prefix="label")
```

---

## 📈 Two Evaluation Methods

### Method 1: LLM-as-Judge (Accurate but Slow)
```python
def llm_judge(run: Run, example: Example) -> dict:
    prompt = f"""
    Expected: {example.outputs['expected']}
    Actual: {run.outputs['output']}
    Rate accuracy 0-10:
    """
    score = llm.invoke(prompt)  # Extra LLM call
    return {"key": "accuracy", "score": float(score.content) / 10}
```

### Method 2: Cosine Similarity (Fast but Less Interpretable)
```python
from langchain_google_vertexai import VertexAIEmbeddings
import numpy as np

embeddings = VertexAIEmbeddings(model_name="textembedding-gecko@003")

def cosine_eval(run: Run, example: Example) -> dict:
    expected_vec = embeddings.embed_query(example.outputs['expected'])
    actual_vec = embeddings.embed_query(run.outputs['output'])
    
    # Cosine similarity
    score = np.dot(expected_vec, actual_vec) / (np.linalg.norm(expected_vec) * np.linalg.norm(actual_vec))
    return {"key": "similarity", "score": float(score)}
```

| Method | Speed | Cost | Accuracy | Use When |
|--------|-------|------|----------|----------|
| LLM-as-Judge | Slow | $$$ | High | Critical accuracy needed |
| Cosine | Fast | $ | Medium | High volume, quick checks |

---

## ❌ Common Mistakes → ✅ Correct

| Wrong ❌ | Correct ✅ |
|---------|----------|
| No API key | `os.environ["LANGCHAIN_API_KEY"] = "..."` |
| `LANGCHAIN_TRACING` | `LANGCHAIN_TRACING_V2` |
| `run.output` | `run.outputs` (plural) |
| Return just score | Return `{"key": "name", "score": value}` |
| `@evaluator` decorator | Just a plain function |

---

## 🧠 Interview One-Liner

> "LangSmith uses 3 env vars for tracing. For evaluation: create dataset with `client.create_dataset()`, define evaluator as `(run, example) → {key, score}`, and run with `evaluate(agent, data, evaluators)`. A/B testing runs same dataset on two prompts and compares in UI."

---

## 🔗 Quick Reference

| Task | Code |
|------|------|
| Enable tracing | `LANGCHAIN_TRACING_V2 = "true"` |
| Create dataset | `client.create_dataset(dataset_name="...")` |
| Add test case | `client.create_example(inputs, outputs, dataset_id)` |
| Get runs | `client.list_runs(project_name="...")` |
| Get feedback | `client.list_feedback(run_id=id)` |
| Run eval | `evaluate(func, data, evaluators, experiment_prefix)` |
