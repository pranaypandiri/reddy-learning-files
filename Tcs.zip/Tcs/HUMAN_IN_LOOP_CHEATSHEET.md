# 🔄 Human-in-Loop (HITL) Cheat Sheet

## 🎯 What is Human-in-Loop?
Agent PAUSES → Human Reviews → Agent RESUMES with decision

---

## 📦 Essential Imports
```python
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver      # In-memory (dev)
from langgraph.checkpoint.sqlite import SqliteSaver      # SQLite (production)
from typing import TypedDict
```

---

## 1️⃣ Define State (Include human_decision!)

```python
class State(TypedDict):
    input: str              # User's request
    draft_response: str     # Agent prepares BEFORE interrupt
    human_decision: str     # Injected AFTER interrupt ("yes"/"no")
    final_response: str     # Created AFTER resume
```

| Field | Who Sets It | When |
|-------|-------------|------|
| `input` | User | Start |
| `draft_response` | Node BEFORE interrupt | Before pause |
| `human_decision` | `update_state()` | After human approves |
| `final_response` | Node AFTER interrupt | After resume |

---

## 2️⃣ Create Nodes

```python
# NODE 1: Runs BEFORE interrupt
def process_request(state: State):
    draft = f"I will process: {state['input']}"
    return {"draft_response": draft}  # ← Sets draft_response

# NODE 2: Runs AFTER interrupt (after human decision injected)
def human_review(state: State):
    if state["human_decision"] == "yes":
        return {"final_response": f"✅ APPROVED: {state['draft_response']}"}
    else:
        return {"final_response": "❌ REJECTED"}
```

---

## 3️⃣ Build Graph with Interrupt

```python
workflow = StateGraph(State)
workflow.add_node("process", process_request)
workflow.add_node("human_review", human_review)

workflow.set_entry_point("process")
workflow.add_edge("process", "human_review")
workflow.add_edge("human_review", END)

# ⭐ CRITICAL: Checkpointer + interrupt_before
checkpointer = MemorySaver()  # or SqliteSaver.from_conn_string("./memory.db")

graph = workflow.compile(
    checkpointer=checkpointer,           # Saves state
    interrupt_before=["human_review"]    # ⏸️ Pause BEFORE this node
)
```

### Key Points:
| Setting | Purpose |
|---------|---------|
| `checkpointer` | Saves state so we can resume later |
| `interrupt_before=["node"]` | Pause BEFORE this node executes |
| `interrupt_after=["node"]` | Pause AFTER this node executes |

---

## 4️⃣ Start Request (Will Pause)

```python
# Config with unique thread_id (like "save game" ID)
config = {"configurable": {"thread_id": "session_123"}}

# Initial state
initial = {
    "input": "Refund $500",
    "draft_response": "",
    "human_decision": "",
    "final_response": ""
}

# This PAUSES at human_review node
result = graph.invoke(initial, config)

# result now has:
# {
#     "input": "Refund $500",
#     "draft_response": "I will process: Refund $500",  ← FILLED
#     "human_decision": "",  ← STILL EMPTY
#     "final_response": ""   ← STILL EMPTY
# }

print(f"Draft: {result['draft_response']}")
# Save case_id → thread_id mapping in your DB for later
```

---

## 5️⃣ Resume After Human Decision

```python
# Same thread_id = Same paused state
config = {"configurable": {"thread_id": "session_123"}}

# INJECT human decision
graph.update_state(config, {"human_decision": "yes"})

# RESUME (None = continue from pause, don't restart)
final = graph.invoke(None, config)

# final now has:
# {
#     "input": "Refund $500",
#     "draft_response": "I will process: Refund $500",
#     "human_decision": "yes",  ← INJECTED
#     "final_response": "✅ APPROVED: I will process: Refund $500"  ← FILLED
# }

print(f"Final: {final['final_response']}")
```

---

## 6️⃣ FastAPI Integration

```python
from fastapi import FastAPI
app = FastAPI()

# Store case_id → thread_id mapping
pending_cases = {}

@app.post("/start")
def start_request(user_input: str, session_id: str):
    config = {"configurable": {"thread_id": session_id}}
    result = graph.invoke({...}, config)  # Pauses
    
    case_id = f"CASE_{session_id[:8]}"
    pending_cases[case_id] = session_id
    
    # Notify supervisor here (email/slack)
    return {"case_id": case_id, "draft": result["draft_response"]}

@app.post("/review/{case_id}")
def handle_review(case_id: str, decision: str):
    thread_id = pending_cases[case_id]
    config = {"configurable": {"thread_id": thread_id}}
    
    graph.update_state(config, {"human_decision": decision})
    final = graph.invoke(None, config)  # Resumes
    
    return {"result": final["final_response"]}
```

---

## 📊 Visual Flow

```
┌─────────────────────────────────────────────────────────────────┐
│ PHASE 1: START                                                  │
│ graph.invoke(initial, config)                                   │
│     ↓                                                           │
│ [process_request] → sets draft_response                         │
│     ↓                                                           │
│ ⏸️ INTERRUPT (before human_review)                              │
│     ↓                                                           │
│ Returns result with draft_response filled                       │
└─────────────────────────────────────────────────────────────────┘
                    ↓
          ⏰ Human reviews (hours/days)
                    ↓
┌─────────────────────────────────────────────────────────────────┐
│ PHASE 2: RESUME                                                 │
│ graph.update_state(config, {"human_decision": "yes"})           │
│ graph.invoke(None, config)                                      │
│     ↓                                                           │
│ [human_review] → reads decision, sets final_response            │
│     ↓                                                           │
│ END → Returns final result                                      │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔑 Key Syntax to Memorize

```python
# 1. COMPILE with interrupt
graph = workflow.compile(
    checkpointer=MemorySaver(),
    interrupt_before=["node_name"]
)

# 2. CONFIG with thread_id
config = {"configurable": {"thread_id": "unique_id"}}

# 3. START (will pause)
result = graph.invoke(initial_state, config)

# 4. INJECT decision
graph.update_state(config, {"field": "value"})

# 5. RESUME
final = graph.invoke(None, config)  # None = continue
```

---

## ❌ Common Mistakes → ✅ Correct

| Wrong ❌ | Correct ✅ |
|---------|----------|
| No checkpointer | `checkpointer=MemorySaver()` |
| `graph.invoke(input, config)` to resume | `graph.invoke(None, config)` |
| Different thread_id to resume | SAME thread_id |
| Forget `update_state` before resume | Must inject decision first |

---

## 🧠 Interview One-Liner

> "Human-in-loop uses `interrupt_before` to pause the graph. The checkpointer saves state using `thread_id`. When human approves via API, we use `update_state()` to inject the decision, then `invoke(None, config)` to resume from the exact pause point."

---

## 📧 Notify Supervisor (GCP Options)

```python
# Option 1: Gmail API
from googleapiclient.discovery import build
service.users().messages().send(userId='me', body={'raw': raw})

# Option 2: Cloud Functions + SendGrid
import sendgrid
sg.send(Mail(from_email='...', to_emails='...', subject='...'))

# Option 3: Pub/Sub → Cloud Function → Email
publisher.publish(topic_path, data=json.dumps(case_data).encode())
```
