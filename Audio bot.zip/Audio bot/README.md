# Voice Chatbot - Basic Testing

Simple voice chatbot to test the complete pipeline before adding custom knowledge (RAG).

## What This Tests

✅ **PyAudio Input** - Microphone capture (16kHz, mono)  
✅ **PyAudio Output** - Speaker playback (24kHz, mono)  
✅ **Gemini Live API** - Real-time streaming  
✅ **Latency Measurement** - How fast responses are  
✅ **Audio Quality** - Both input and output  

## Setup

1. Make sure you're in the virtual environment:
```bash
source /Users/ge20425940/Downloads/ImageToQueryLLM/.venv1/bin/activate
```

2. Set your GCP credentials:
```bash
# Set your GCP project ID
export GCP_PROJECT_ID="your-project-id"

# Set your GCP location (region)
export GCP_LOCATION="us-central1"  # or your preferred region

# Authenticate with GCP (if not already done)
gcloud auth application-default login
```

3. Run the chatbot:
```bash
cd "/Users/ge20425940/Downloads/Agentic ai medium /audio bot"
python voice_chatbot_basic.py
```

## How It Works

```
You speak into mic
    ↓
PyAudio captures (16kHz)
    ↓
Sends to Gemini Live API
    ↓
Gemini Live:
  - Transcribes (STT)
  - Generates response
  - Converts to audio (TTS)
    ↓
PyAudio plays through speakers (24kHz)
    ↓
You hear response
```

## What to Test

**Basic Conversation:**
- "Hello, how are you?"
- "What's 25 plus 17?"
- "Tell me a joke"
- "What day is it today?"

**Test Latency:**
- Ask simple questions
- Check the latency reported
- Target: < 1 second

**Test Audio Quality:**
- Is transcription accurate?
- Is voice clear?
- Any echo or distortion?

## Expected Output

```
🚀 Starting Voice Chatbot...
Make sure your microphone and speakers are working!

============================================================
🎙️  VOICE CHATBOT - Basic Testing
============================================================
Model: gemini-2.5-flash-native-audio-preview-09-2025
Input: 16kHz mono | Output: 24kHz mono
============================================================

🎤 Starting microphone...
✅ Microphone ready (16kHz, mono)
🔊 Starting speakers...
✅ Speakers ready (24kHz, mono)
📡 Connecting to Gemini Live API...
✅ Connected to Gemini Live!

🎧 Listening... Speak now!
(Press Ctrl+C to stop)

⏱️  Response #1 - Latency: 0.45s
🎧 Listening... Speak now!

⏱️  Response #2 - Latency: 0.52s
🎧 Listening... Speak now!
```

## Troubleshooting

**"No microphone detected"**
- Check System Preferences → Security & Privacy → Microphone
- Grant permission to Terminal/iTerm

**"No sound output"**
- Check your speaker volume
- Verify correct output device selected

**"Import error: google.genai"**
- Make sure virtual environment is activated
- Run: `pip list | grep google-genai`

**"HTTP 403 error"**
- Check your API key is set correctly
- Verify API key has Gemini Live access

## Next Steps

Once this works:
1. ✅ Add your 2 documents (about 2 people)
2. ✅ Add FAISS vector store (RAG)
3. ✅ Add function calling for retrieval
4. ✅ Test domain-specific questions

## Notes

- **No custom knowledge yet** - it's just basic Gemini responses
- **Testing the pipes** - making sure audio works both ways
- **Measuring latency** - confirming it's under 1 second
- **Creating template** - foundation for adding RAG later
