"""
Check available Gemini models through Vertex AI
"""

from google import genai
import os

PROJECT_ID = "ai-practice-388514"
LOCATION = "us-central1"

print(f"Checking available models in project: {PROJECT_ID}")
print(f"Location: {LOCATION}\n")

try:
    # Initialize client with Vertex AI
    client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)

    print("✅ Successfully connected to Vertex AI\n")

    # Try common Gemini Live model names
    model_names_to_try = [
        "gemini-2.0-flash-exp",
        "models/gemini-2.0-flash-exp",
        "gemini-2.5-flash-native-audio-preview-09-2025",
        "gemini-exp-1206",
        "models/gemini-exp-1206",
        "gemini-2.0-flash-thinking-exp-1219",
    ]

    print("Testing which models work with Live API:\n")
    for model_name in model_names_to_try:
        try:
            # Just try to create a config - don't actually connect
            config = genai.types.LiveConnectConfig(response_modalities=["AUDIO"])
            print(f"✅ {model_name} - Config created successfully")
        except Exception as e:
            print(f"❌ {model_name} - Error: {str(e)[:100]}")

except Exception as e:
    print(f"❌ Error connecting to Vertex AI: {e}")
    import traceback

    traceback.print_exc()
