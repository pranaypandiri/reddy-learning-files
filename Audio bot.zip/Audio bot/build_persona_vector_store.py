"""Build a FAISS vector store for persona knowledge.

Run:
    python build_persona_vector_store.py

This script creates `data/kb_documents/personas.faiss` and a matching
`data/kb_documents/personas_metadata.json` file. Set the Azure OpenAI
credentials in the environment before running:

    export AZURE_OPENAI_API_KEY="..."
    export AZURE_OPENAI_ENDPOINT="https://<your-endpoint>.openai.azure.com/"
    export AZURE_OPENAI_EMBEDDING_MODEL="text-embedding-3-large"
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List

import faiss  # type: ignore
import numpy as np
from langchain_openai import AzureOpenAIEmbeddings

DEFAULT_AZURE_API_KEY = "83265f364fe844f298b2d4f8a5a39426"
DEFAULT_AZURE_ENDPOINT = "https://genai-demos.openai.azure.com/"
DEFAULT_EMBED_MODEL = "text-embedding-3-large"

# ---------------------------------------------------------------------------
# Persona source content (can be replaced with file reads later)
# ---------------------------------------------------------------------------
PERSONAS: List[Dict[str, str]] = [
    {
        "id": "reddy",
        "name": "Reddy",
        "content": (
            "Reddy is a vibrant personality from Australia who has an "
            "insatiable passion for cinema. He spends his weekends exploring "
            "independent film festivals across Sydney and Melbourne, always on "
            "the lookout for the next groundbreaking documentary or arthouse "
            "film. His apartment is filled with movie posters from Cannes and "
            "Sundance, and he maintains an extensive collection of Criterion "
            "Collection Blu-rays. Reddy loves discussing cinematography "
            "techniques, film noir aesthetics, and the evolution of Australian "
            "cinema. He's known among his friends for hosting monthly movie "
            "nights where he introduces them to hidden gems from around the "
            "world. When he's not watching films, Reddy enjoys surfing at Bondi "
            "Beach and exploring the coastal landscapes that remind him of the "
            "sweeping shots in his favorite movies. He's particularly drawn to "
            "films that explore human connections and the way stories can "
            "bridge cultural divides."
        ),
    },
    {
        "id": "hari",
        "name": "Hari",
        "content": (
            "Hari hails from India and has dedicated his life to the "
            "appreciation and creation of art. He grew up surrounded by the "
            "rich artistic traditions of his homeland, from classical Indian "
            "paintings to contemporary street art in Mumbai. Hari's studio is "
            "a colorful sanctuary where he experiments with mixed media, "
            "blending traditional Indian motifs with modern abstract "
            "techniques. He's deeply inspired by the works of M.F. Husain and "
            "Raja Ravi Varma, often spending hours in galleries studying "
            "brushwork and composition. Hari believes that art is a universal "
            "language that transcends borders and connects people across "
            "different cultures. On weekends, he conducts free art workshops "
            "for children in his neighborhood, teaching them about color theory "
            "and self-expression. He's fascinated by how visual storytelling "
            "can convey emotions and narratives without words, and he often "
            "collaborates with local filmmakers to create stunning visual "
            "narratives that celebrate India's diverse cultural heritage."
        ),
    },
]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def get_embedder() -> AzureOpenAIEmbeddings:
    """Create an Azure OpenAI embedding client using environment settings."""

    api_key = os.getenv("AZURE_OPENAI_API_KEY", DEFAULT_AZURE_API_KEY)
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", DEFAULT_AZURE_ENDPOINT)
    model = os.getenv("AZURE_OPENAI_EMBEDDING_MODEL", DEFAULT_EMBED_MODEL)

    return AzureOpenAIEmbeddings(
        model=model,
        api_key=api_key,
        openai_api_type="azure",
        azure_endpoint=endpoint,
        api_version="2024-02-15-preview",
    )


def build_faiss_index(embeddings: np.ndarray) -> faiss.IndexFlatIP:
    """Create an IndexFlatIP and populate it with normalized embeddings."""

    if embeddings.ndim != 2:
        raise ValueError("Embeddings array must be 2-dimensional.")

    # Normalize for cosine similarity using inner product search.
    faiss.normalize_L2(embeddings)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    return index


def persist_index(
    index: faiss.IndexFlatIP, metadata: List[Dict[str, Any]], *, output_dir: Path
) -> None:
    """Persist FAISS index and JSON metadata to disk."""

    output_dir.mkdir(parents=True, exist_ok=True)
    faiss_path = output_dir / "personas.faiss"
    metadata_path = output_dir / "personas_metadata.json"

    faiss.write_index(index, str(faiss_path))
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    print(f"✅ Saved FAISS index: {faiss_path}")
    print(f"✅ Saved metadata: {metadata_path}")


# ---------------------------------------------------------------------------
# Main routine
# ---------------------------------------------------------------------------


def main() -> None:
    embedder = get_embedder()

    texts = [doc["content"] for doc in PERSONAS]
    metadata = [
        {
            "id": doc["id"],
            "name": doc["name"],
            "content": doc["content"],
        }
        for doc in PERSONAS
    ]

    print("🔢 Generating embeddings...")
    vectors = embedder.embed_documents(texts)
    embeddings = np.asarray(vectors, dtype="float32")

    print("📦 Building FAISS index...")
    index = build_faiss_index(embeddings)

    output_dir = Path(__file__).resolve().parent / "data" / "kb_documents"
    persist_index(index, metadata, output_dir=output_dir)


if __name__ == "__main__":
    main()
