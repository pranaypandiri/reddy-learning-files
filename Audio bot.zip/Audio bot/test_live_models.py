"""
Test which models actually support Live API in Vertex AI
"""

from google import genai
from google.genai import types
import asyncio

PROJECT_ID = "ai-practice-388514"
LOCATION = "us-central1"


async def test_live_api_connection(model_name):
    """Try to actually connect to Live API with a model"""
    try:
        client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
        config = types.LiveConnectConfig(
            response_modalities=["AUDIO"],
            system_instruction="You are a test assistant.",
        )

        print(f"  Attempting Live API connection with {model_name}...")
        async with client.aio.live.connect(model=model_name, config=config) as session:
            print(f"  ✅ SUCCESS - {model_name} supports Live API!")
            return True
    except Exception as e:
        error_msg = str(e)
        if "not supported in the live api" in error_msg.lower():
            print(f"  ❌ {model_name} - NOT supported in Live API")
        elif "policy violation" in error_msg.lower():
            print(
                f"  ⚠️  {model_name} - Policy violation (might not be available in region)"
            )
        else:
            print(f"  ❌ {model_name} - Error: {error_msg[:150]}")
        return False


async def main():
    print(f"Testing Live API support in Vertex AI")
    print(f"Project: {PROJECT_ID}")
    print(f"Location: {LOCATION}\n")
    print("=" * 80 + "\n")

    # Model names to test for Live API support
    model_names_to_test = [
        # The one you suggested
        "gemini-live-2.5-flash-preview-native-audio-09-2025",
        # Standard models
        "gemini-2.0-flash-exp",
        "gemini-exp-1206",
        # With models/ prefix
        "models/gemini-2.0-flash-exp",
        "models/gemini-exp-1206",
        # Multimodal/Live specific names (guessing)
        "gemini-2.0-flash-live",
        "gemini-live-exp",
        "gemini-2.5-flash-native-audio-preview-09-2025",
        # Full publisher path
        f"projects/{PROJECT_ID}/locations/{LOCATION}/publishers/google/models/gemini-2.0-flash-exp",
    ]

    for model_name in model_names_to_test:
        print(f"Testing: {model_name}")
        await test_live_api_connection(model_name)
        print()
        await asyncio.sleep(0.3)  # Small delay between tests


if __name__ == "__main__":
    asyncio.run(main())
