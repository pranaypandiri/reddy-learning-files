#!/usr/bin/env python3
"""
Quick test to verify all dependencies are working
Run this before running the main voice chatbot
"""

import sys

print("🔍 Checking dependencies...\n")

# Test 1: PyAudio
print("1️⃣  Testing PyAudio...")
try:
    import pyaudio

    p = pyaudio.PyAudio()

    # List audio devices
    print(f"   ✅ PyAudio {pyaudio.__version__} installed")
    print(f"   📱 Found {p.get_device_count()} audio devices")

    # Find default input/output
    try:
        default_input = p.get_default_input_device_info()
        print(f"   🎤 Default mic: {default_input['name']}")
    except:
        print("   ⚠️  No default microphone found")

    try:
        default_output = p.get_default_output_device_info()
        print(f"   🔊 Default speaker: {default_output['name']}")
    except:
        print("   ⚠️  No default speaker found")

    p.terminate()

except ImportError as e:
    print(f"   ❌ PyAudio not installed: {e}")
    sys.exit(1)

# Test 2: Google GenAI
print("\n2️⃣  Testing Google GenAI SDK...")
try:
    from google import genai
    from google.genai import types

    print(f"   ✅ google-genai installed")

    # Check if GCP credentials are set
    import os

    project_id = os.environ.get("GCP_PROJECT_ID")
    location = os.environ.get("GCP_LOCATION")

    if project_id:
        print(f"   ✅ GCP_PROJECT_ID is set: {project_id}")
    else:
        print("   ⚠️  GCP_PROJECT_ID not set in environment")
        print("   💡 Set it with: export GCP_PROJECT_ID='your-project-id'")

    if location:
        print(f"   ✅ GCP_LOCATION is set: {location}")
    else:
        print("   ⚠️  GCP_LOCATION not set (will use default: us-central1)")
        print("   💡 Set it with: export GCP_LOCATION='us-central1'")

    # Check for GCP credentials
    gcp_creds = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    if gcp_creds:
        print(f"   ✅ GOOGLE_APPLICATION_CREDENTIALS is set")
    else:
        print("   ℹ️  GOOGLE_APPLICATION_CREDENTIALS not set")
        print("   💡 Using default credentials (gcloud auth)")

except ImportError as e:
    print(f"   ❌ google-genai not installed: {e}")
    sys.exit(1)

# Test 3: Asyncio
print("\n3️⃣  Testing asyncio...")
try:
    import asyncio

    print(f"   ✅ asyncio available")
except ImportError as e:
    print(f"   ❌ asyncio not available: {e}")
    sys.exit(1)

# Test 4: Try to create a simple audio stream
print("\n4️⃣  Testing audio stream creation...")
try:
    p = pyaudio.PyAudio()

    # Try to open mic stream
    test_stream = p.open(
        format=pyaudio.paInt16,
        channels=1,
        rate=16000,
        input=True,
        frames_per_buffer=1024,
    )
    test_stream.stop_stream()
    test_stream.close()
    print("   ✅ Can open microphone stream")

    # Try to open speaker stream
    test_stream = p.open(
        format=pyaudio.paInt16,
        channels=1,
        rate=24000,
        output=True,
        frames_per_buffer=1024,
    )
    test_stream.stop_stream()
    test_stream.close()
    print("   ✅ Can open speaker stream")

    p.terminate()

except Exception as e:
    print(f"   ❌ Audio stream error: {e}")
    print("   💡 Check microphone permissions in System Preferences")

# Summary
print("\n" + "=" * 60)
print("✅ All dependency checks complete!")
print("=" * 60)
print("\n💡 You're ready to run: python voice_chatbot_basic.py")
print("   (Make sure GOOGLE_API_KEY is set first)\n")
