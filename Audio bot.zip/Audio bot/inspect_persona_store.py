"""Utility to inspect the persona FAISS store.

Run:
    python inspect_persona_store.py

Prints stored metadata entries and optionally runs a quick similarity check.
"""

from __future__ import annotations

import json
from pathlib import Path

import faiss  # type: ignore
import numpy as np

from persona_knowledge import _get_embedder, _KB_DIR  # type: ignore

FAISS_PATH = _KB_DIR / "personas.faiss"
METADATA_PATH = _KB_DIR / "personas_metadata.json"


def print_metadata() -> None:
    data = json.loads(METADATA_PATH.read_text(encoding="utf-8"))
    print("\n=== Persona Metadata ===")
    for idx, doc in enumerate(data):
        print(f"[{idx}] id={doc.get('id')} name={doc.get('name')}")
        print(doc.get("content", "").strip())
        print("-")


def run_sample_queries() -> None:
    try:
        embedder = _get_embedder()
    except Exception as exc:  # noqa: BLE001
        print(f"Embedding setup failed: {exc}")
        return

    index = faiss.read_index(str(FAISS_PATH))

    for query in ["Hari", "Tell me about Reddy", "Who is Hari the artist?"]:
        vec = np.asarray([embedder.embed_query(query)], dtype="float32")
        faiss.normalize_L2(vec)
        scores, ids = index.search(vec, 2)
        print(f"Query: {query}")
        print(f"  scores={scores[0].tolist()} ids={ids[0].tolist()}")


def main() -> None:
    if not FAISS_PATH.exists() or not METADATA_PATH.exists():
        raise SystemExit("Persona store is missing; run build_persona_vector_store.py")

    print_metadata()
    run_sample_queries()


if __name__ == "__main__":
    main()
