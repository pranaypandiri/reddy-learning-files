"""
Basic Voice Chatbot with Gemini Live API
=========================================
Simple voice chatbot to test:
- PyAudio microphone input
- PyAudio speaker output
- Gemini Live API integration
- Real-time latency measurement

No custom knowledge (RAG) - just basic conversation for testing the pipeline.
"""

import asyncio
import audioop
import os
import time
from typing import Any, Dict, Optional

import pyaudio
from google import genai
from google.genai import types

from persona_knowledge import PersonaKnowledgeError, lookup_person

# ============================================================================
# CONFIGURATION
# ============================================================================

# Vertex AI Configuration (GCP)
PROJECT_ID = os.getenv("GCP_PROJECT_ID", "ai-practice-388514")
LOCATION = os.getenv("GCP_LOCATION", "us-central1")

# Gemini Live API Configuration
GEMINI_MODEL = "gemini-live-2.5-flash-preview-native-audio-09-2025"  # This model supports Live API!

# PyAudio Configuration for INPUT (Microphone)
INPUT_FORMAT = pyaudio.paInt16  # 16-bit
INPUT_CHANNELS = 1  # Mono
INPUT_RATE = 16000  # 16kHz sample rate
INPUT_CHUNK = 1024  # Frames per buffer

# PyAudio Configuration for OUTPUT (Speakers)
OUTPUT_FORMAT = pyaudio.paInt16  # 16-bit
OUTPUT_CHANNELS = 1  # Mono
OUTPUT_RATE = 24000  # 24kHz sample rate (Gemini output)
OUTPUT_CHUNK = 1024  # Frames per buffer

# Voice activity detection (simple energy based)
VAD_SILENCE_THRESHOLD = 500  # Lower -> more sensitive
VAD_SILENCE_DURATION_MS = 600  # Silence window to mark end-of-turn

# System Instruction (Simple, no RAG)
SYSTEM_INSTRUCTION = """
You are a friendly voice assistant.
Keep your responses short and conversational (1-2 sentences).
Speak naturally like you're having a conversation.
"""

# Tool declaration for persona lookup
LOOKUP_PERSON_FUNCTION: Dict[str, Any] = {
    "name": "lookup_person",
    "description": (
        "Fetch background information about a known person from the internal "
        "knowledge base."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "description": "Full name of the person to look up.",
            },
            "question": {
                "type": "string",
                "description": (
                    "Optional follow-up question that provides additional context "
                    "for the lookup."
                ),
            },
        },
        "required": ["name"],
    },
}

# ============================================================================
# AUDIO SETUP
# ============================================================================


class AudioHandler:
    """Handles PyAudio input (mic) and output (speakers)"""

    def __init__(self):
        self.p = pyaudio.PyAudio()
        self.mic_stream = None
        self.speaker_stream = None

    def start_microphone(self):
        """Start capturing audio from microphone"""
        print("🎤 Starting microphone...")
        self.mic_stream = self.p.open(
            format=INPUT_FORMAT,
            channels=INPUT_CHANNELS,
            rate=INPUT_RATE,
            input=True,
            frames_per_buffer=INPUT_CHUNK,
        )
        print("✅ Microphone ready (16kHz, mono)")

    def start_speakers(self):
        """Start playback through speakers"""
        print("🔊 Starting speakers...")
        self.speaker_stream = self.p.open(
            format=OUTPUT_FORMAT,
            channels=OUTPUT_CHANNELS,
            rate=OUTPUT_RATE,
            output=True,
            frames_per_buffer=OUTPUT_CHUNK,
        )
        print("✅ Speakers ready (24kHz, mono)")

    def read_mic_chunk(self):
        """Read one chunk of audio from microphone"""
        if self.mic_stream:
            return self.mic_stream.read(INPUT_CHUNK, exception_on_overflow=False)
        return None

    def play_audio_chunk(self, audio_data):
        """Play one chunk of audio through speakers"""
        if self.speaker_stream and audio_data:
            self.speaker_stream.write(audio_data)

    def cleanup(self):
        """Close all streams and terminate PyAudio"""
        print("\n🧹 Cleaning up audio resources...")
        if self.mic_stream:
            self.mic_stream.stop_stream()
            self.mic_stream.close()
        if self.speaker_stream:
            self.speaker_stream.stop_stream()
            self.speaker_stream.close()
        self.p.terminate()
        print("✅ Audio cleanup complete")


# ============================================================================
# GEMINI LIVE API HANDLER
# ============================================================================


class GeminiLiveHandler:
    """Handles connection to Gemini Live API"""

    def __init__(self):
        # Initialize Vertex AI client with project and location
        self.client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
        self.session = None
        self.config = types.LiveConnectConfig(
            response_modalities=["AUDIO"],
            system_instruction=SYSTEM_INSTRUCTION,
            tools=[types.Tool(function_declarations=[LOOKUP_PERSON_FUNCTION])],
        )

    def connect(self):
        """Get async context manager for Gemini Live API connection"""
        print("📡 Connecting to Gemini Live API...")
        return self.client.aio.live.connect(model=GEMINI_MODEL, config=self.config)

    async def send_audio(self, audio_bytes):
        """Send audio chunk to Gemini Live"""
        if self.session:
            await self.session.send_realtime_input(
                audio=types.Blob(mime_type="audio/pcm", data=audio_bytes)
            )

    async def send_tool_result(
        self,
        *,
        function_name: str,
        call_id: Optional[str],
        response_payload: Dict[str, Any],
    ):
        """Send tool/function response back to Gemini."""

        if not self.session:
            return

        tool_response: Dict[str, Any] = {
            "name": function_name,
            "response": response_payload,
        }
        if call_id:
            tool_response["id"] = call_id

        await self.session.send_tool_response(function_responses=tool_response)

    async def receive_responses(self):
        """Receive streaming responses from Gemini Live across turns"""
        if not self.session:
            return

        while True:
            async for response in self.session.receive():
                yield response

    async def end_audio_stream(self):
        """Signal Gemini that the current user turn has ended"""
        if self.session:
            await self.session.send_realtime_input(audio_stream_end=True)


# ============================================================================
# MAIN VOICE CHATBOT
# ============================================================================


async def run_voice_chatbot():
    """Main function - runs the voice chatbot"""

    print("\n" + "=" * 60)
    print("🎙️  VOICE CHATBOT - Basic Testing")
    print("=" * 60)
    print(f"GCP Project: {PROJECT_ID}")
    print(f"Location: {LOCATION}")
    print(f"Model: {GEMINI_MODEL}")
    print(f"Input: 16kHz mono | Output: 24kHz mono")
    print("=" * 60 + "\n")

    # Initialize audio handler
    audio = AudioHandler()
    audio.start_microphone()
    audio.start_speakers()

    # Initialize Gemini Live handler
    gemini = GeminiLiveHandler()

    try:
        # Connect to Gemini Live
        async with gemini.connect() as session:
            gemini.session = session
            print("✅ Connected to Gemini Live!")

            print("\n🎧 Listening... Speak now!")
            print("(Press Ctrl+C to stop)\n")

            # Track conversation state
            conversation_count = 0
            start_time = None

            # Create tasks for sending and receiving
            async def send_audio_task():
                """Continuously send mic audio to Gemini"""
                silence_frame_limit = max(
                    1,
                    int((VAD_SILENCE_DURATION_MS / 1000) * (INPUT_RATE / INPUT_CHUNK)),
                )
                speaking = False
                silence_frames = 0

                while True:
                    audio_chunk = audio.read_mic_chunk()
                    if audio_chunk:
                        try:
                            volume_level = audioop.max(audio_chunk, 2)
                        except audioop.error:
                            volume_level = 0

                        if volume_level > VAD_SILENCE_THRESHOLD:
                            speaking = True
                            silence_frames = 0
                        elif speaking:
                            silence_frames += 1
                        else:
                            silence_frames = 0

                        await gemini.send_audio(audio_chunk)

                        if speaking and silence_frames >= silence_frame_limit:
                            await gemini.end_audio_stream()
                            speaking = False
                            silence_frames = 0
                    await asyncio.sleep(0.01)

            async def handle_tool_calls(tool_call):
                if not getattr(tool_call, "function_calls", None):
                    return

                for fn_call in tool_call.function_calls:
                    function_name = getattr(fn_call, "name", "")
                    args = getattr(fn_call, "args", {}) or {}
                    call_id = getattr(fn_call, "id", None)

                    print(f"🛠️  Tool requested: {function_name} -> {args}")

                    if function_name != "lookup_person":
                        await gemini.send_tool_result(
                            function_name=function_name,
                            call_id=call_id,
                            response_payload={
                                "error": f"Function '{function_name}' is not implemented.",
                            },
                        )
                        continue

                    person_name = args.get("name") or args.get("person")
                    question = args.get("question")

                    try:
                        result = lookup_person(person_name, question)
                        payload = {
                            "result": result,
                            "requested_name": person_name,
                            "question": question,
                        }
                    except PersonaKnowledgeError as err:
                        payload = {
                            "error": str(err),
                            "requested_name": person_name,
                        }

                    await gemini.send_tool_result(
                        function_name=function_name,
                        call_id=call_id,
                        response_payload=payload,
                    )

            async def receive_audio_task():
                """Continuously receive and play audio from Gemini"""
                nonlocal conversation_count, start_time

                async for response in gemini.receive_responses():
                    if getattr(response, "tool_call", None):
                        await handle_tool_calls(response.tool_call)
                        continue

                    # Check if we got audio data
                    if response.data is not None:
                        # First audio chunk received - start timing
                        if start_time is None:
                            start_time = time.time()

                        # Play audio through speakers
                        audio.play_audio_chunk(response.data)

                    # Check if response is complete
                    if hasattr(response, "server_content") and response.server_content:
                        if response.server_content.model_turn:
                            # Response complete - calculate latency
                            if start_time:
                                latency = time.time() - start_time
                                conversation_count += 1

                                print(
                                    f"\n⏱️  Response #{conversation_count} - Latency: {latency:.2f}s"
                                )
                                print("🎧 Listening... Speak now!\n")

                                # Reset for next turn
                                start_time = None

            # Run both tasks concurrently
            await asyncio.gather(send_audio_task(), receive_audio_task())

    except KeyboardInterrupt:
        print("\n\n⏹️  Stopping voice chatbot...")

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback

        traceback.print_exc()

    finally:
        # Cleanup
        audio.cleanup()
        print("\n👋 Goodbye!\n")


# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    print("\n🚀 Starting Voice Chatbot...")
    print("Make sure your microphone and speakers are working!")

    try:
        asyncio.run(run_voice_chatbot())
    except KeyboardInterrupt:
        print("\n\n👋 Exiting...")
