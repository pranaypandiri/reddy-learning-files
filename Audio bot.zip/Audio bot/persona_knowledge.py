"""Persona knowledge base lookup utilities.

Loads the FAISS index built by ``build_persona_vector_store.py`` and exposes
helpers that the voice chatbot can call through the Gemini Live tool-calling
interface.
"""

from __future__ import annotations

import json
import os
import threading
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional

# Workaround for macOS FAISS + OpenMP dual loading when combined with other binaries.
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import faiss  # type: ignore
import numpy as np
from langchain_openai import AzureOpenAIEmbeddings

_KB_DIR = Path(__file__).resolve().parent / "data" / "kb_documents"
_FAISS_PATH = _KB_DIR / "personas.faiss"
_METADATA_PATH = _KB_DIR / "personas_metadata.json"
_SIMILARITY_THRESHOLD = 0.55
_LOCK = threading.Lock()

# Hard-coded defaults so the bot works without environment configuration.
_DEFAULT_AZURE_API_KEY = "83265f364fe844f298b2d4f8a5a39426"
_DEFAULT_AZURE_ENDPOINT = "https://genai-demos.openai.azure.com/"
_DEFAULT_EMBED_MODEL = "text-embedding-3-large"


class PersonaKnowledgeError(RuntimeError):
    """Raised when the knowledge base cannot be queried."""


def _get_embedder() -> AzureOpenAIEmbeddings:
    api_key = os.getenv("AZURE_OPENAI_API_KEY", _DEFAULT_AZURE_API_KEY)
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", _DEFAULT_AZURE_ENDPOINT)
    model = os.getenv("AZURE_OPENAI_EMBEDDING_MODEL", _DEFAULT_EMBED_MODEL)

    return AzureOpenAIEmbeddings(
        model=model,
        api_key=api_key,
        openai_api_type="azure",
        azure_endpoint=endpoint,
        api_version="2024-02-15-preview",
    )


@lru_cache(maxsize=1)
def _load_index() -> tuple[faiss.IndexFlatIP, List[Dict[str, Any]]]:
    if not _FAISS_PATH.exists() or not _METADATA_PATH.exists():
        raise PersonaKnowledgeError(
            f"Knowledge base files not found under {_KB_DIR}. Build the vector store first."
        )

    index = faiss.read_index(str(_FAISS_PATH))
    metadata = json.loads(_METADATA_PATH.read_text(encoding="utf-8"))

    return index, metadata


@lru_cache(maxsize=1)
def _load_metadata() -> List[Dict[str, Any]]:
    if not _METADATA_PATH.exists():
        raise PersonaKnowledgeError(
            f"Metadata file not found at {_METADATA_PATH}. Rebuild the persona store."
        )
    return json.loads(_METADATA_PATH.read_text(encoding="utf-8"))


def _summarize_content(content: str, sentences: int = 3) -> str:
    content = content.strip()
    if not content:
        return ""
    parts = [s.strip() for s in content.split(".") if s.strip()]
    if not parts:
        return content
    snippet = ". ".join(parts[:sentences])
    if not snippet.endswith("."):
        snippet += "."
    return snippet


def _format_answer(doc: Dict[str, Any], score: float) -> Dict[str, Any]:
    summary = _summarize_content(doc.get("content", ""))
    if not summary:
        summary = f"I found a person named {doc.get('name', 'unknown')}, but no detailed notes were stored."

    return {
        "name": doc.get("name"),
        "confidence": round(float(score), 3),
        "summary": summary,
    }


def lookup_person(
    name: str, question: Optional[str] = None, *, k: int = 2
) -> Dict[str, Any]:
    """Return knowledge base details about a person."""

    if not name:
        raise PersonaKnowledgeError("Name is required for persona lookup.")

    # Prefer a direct metadata hit by name/id.
    metadata = _load_metadata()
    target = name.strip().lower()

    for doc in metadata:
        doc_name = str(doc.get("name", "")).strip().lower()
        doc_id = str(doc.get("id", "")).strip().lower()
        if target in {doc_name, doc_id}:
            summary = _summarize_content(doc.get("content", ""))
            if question:
                summary = (
                    f"Here's what I know about {doc.get('name')}: {summary}"
                    f" If you're wondering about '{question}', this is the closest match I have."
                )
            return {
                "name": doc.get("name"),
                "summary": summary or doc.get("content", ""),
                "confidence": 1.0,
                "source_id": doc.get("id"),
            }

    # Fall back to vector similarity for fuzzier queries.
    try:
        index, metadata_with_vectors = _load_index()
        embedder = _get_embedder()
    except PersonaKnowledgeError:
        return {
            "name": name,
            "summary": f"I couldn't find any notes about {name} yet.",
            "confidence": 0.0,
        }

    query_parts = [name.lower()]
    if question:
        query_parts.append(question)
    query_text = " \n ".join(query_parts)

    vector = np.asarray([embedder.embed_query(query_text)], dtype="float32")
    faiss.normalize_L2(vector)

    with _LOCK:
        scores, ids = index.search(vector, min(k, index.ntotal))

    results: List[Dict[str, Any]] = []
    for score, idx in zip(scores[0], ids[0]):
        if idx == -1:
            continue
        if score < _SIMILARITY_THRESHOLD:
            continue
        doc = metadata_with_vectors[idx]
        formatted = _format_answer(doc, score)
        formatted["source_id"] = doc.get("id")
        results.append(formatted)

    if not results:
        return {
            "name": name,
            "summary": f"I couldn't find any notes about {name} yet.",
            "confidence": 0.0,
        }

    top = results[0]
    if question:
        top["summary"] = (
            f"{top['summary']} If you're specifically asking about '{question}', this is what I have on record."
        )

    top["alternates"] = [r for r in results[1:]]
    return top


__all__ = ["lookup_person", "PersonaKnowledgeError"]
