User: analyze this thing bro okay... 

GitHub Copilot: Read [](file:///Users/ge20425940/Downloads/Agentic%20ai%20medium%20/tcs%20prep/pilot.md)

Let me see if there's more content: 

Read [](file:///Users/ge20425940/Downloads/Agentic%20ai%20medium%20/tcs%20prep/pilot.md#61-61), lines 61 to 61

Alright bro, here's my analysis of your interview prep doc:

---

## 📊 What This Document Is

This looks like a **self-assessment for a TCS GenAI/LLM role**. It breaks down:
- What you should focus on
- Your gaps vs the job description
- A quick Python retry decorator example

---

## ✅ Good Takes in the Doc

| Priority | Assessment |
|----------|------------|
| **RAG** | Spot on — they want hands-on RAG pipeline building |
| **Agentic AI / LangGraph** | Perfect match — you have multi-agent experience with LangChain/LangGraph |
| **DSA/Coding** | Realistic — moderate array/string problems, not hardcore LC |

---

## ⚠️ Gaps Identified (Pay Attention)

| Gap | Why It Matters |
|-----|----------------|
| **FastAPI** | Explicitly in JD twice — you NEED to know routing, async endpoints, serving ML models |
| **Azure** | They use Azure, you have GCP — be ready to translate (e.g., "I used Vertex AI, which maps to Azure ML") |
| **Fine-tuning** | Know LoRA/QLoRA concepts, when to fine-tune vs use RAG |
| **System Design** | Hidden priority — "How would you scale a RAG system?" type questions |

---

## 🎯 My Suggestions

1. **FastAPI Prep (1-2 hours max)**
   - Build a simple `/predict` endpoint
   - Understand `async def`, dependency injection, Pydantic models

2. **Azure Mapping Table** — Make a mental cheatsheet:
   - GCS → Azure Blob Storage
   - Vertex AI → Azure OpenAI / Azure ML
   - Cloud Run → Azure Container Apps

3. **That retry decorator at the bottom** — It's a classic interview question pattern. Know:
   - How decorators work
   - What `*args, **kwargs` do
   - Exponential backoff variant

4. **Prep 2-3 "war stories"** from your projects:
   - A time RAG failed and how you fixed it
   - How you handled latency/scale
   - A tricky agent orchestration decision

---

**Bottom line:** Your doc is solid prep material. The gaps identified are accurate. Want me to help you drill into any specific area — FastAPI, system design questions, or mock interview scenarios?

User: so i learnt many aspects okay.. but  in my previous interviews i feels tressed unable do some question like basic linear regression and also how to train and predcit the mdoels on 2 small list because.. i ma mor egen ai focused...

so what i decided is i will practice the hugging face tranformer.. see i know tranform architecture i worked in rag and agentic ai .. but this hugging face tranformers i know certain thing with the sft and in general stiff needed be know in the coee aspect wise then i can rock right...


and also osme ml stuff like how to have predci using scikit learn and also classification thats it..

i have 3.3 exp and it is tcs so .. tellme lsit which i need to be know in these areas then we are good i think bro dont you think 

GitHub Copilot: Bro I totally get it — you're deep in GenAI but got caught off-guard on the "basics" that interviewers love to ask. With 3.3 years exp at TCS level, here's the **exact focused list** you need:

---

## 🔥 Scikit-Learn Basics (1-2 hours max)

**Just know these 5 things cold:**

| Concept | What to Know |
|---------|--------------|
| **Linear Regression** | `LinearRegression().fit(X, y)` → `model.predict(X_test)` |
| **Logistic Regression** | Binary classification, sigmoid, `LogisticRegression()` |
| **Train-Test Split** | `train_test_split(X, y, test_size=0.2)` |
| **Metrics** | `accuracy_score`, `precision_score`, `recall_score`, `f1_score`, `mean_squared_error` |
| **Simple Pipeline** | Load data → split → fit → predict → evaluate |

**Code you MUST be able to write from memory:**
```python
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_squared_error

# Given 2 lists
X = [[1], [2], [3], [4], [5]]
y = [2, 4, 6, 8, 10]

# Train & Predict
model = LinearRegression()
model.fit(X, y)
pred = model.predict([[6]])  # → 12

# Classification version
model = LogisticRegression()
model.fit(X_train, y_train)
preds = model.predict(X_test)
print(accuracy_score(y_test, preds))
```

---

## 🤗 Hugging Face Transformers (Core Stuff)

**For 3.3 yrs GenAI person at TCS, know these:**

| Area | What to Know |
|------|--------------|
| **Pipeline API** | `pipeline("sentiment-analysis")`, `pipeline("text-generation")` |
| **Tokenizer** | `tokenizer(text, return_tensors="pt")`, `tokenizer.decode()` |
| **Model Loading** | `AutoModel.from_pretrained()`, `AutoTokenizer.from_pretrained()` |
| **Inference** | Forward pass, `model(**inputs)`, getting logits |
| **Fine-tuning concepts** | `Trainer`, `TrainingArguments`, `SFTTrainer` (you know this) |
| **Model Hub** | How to load models, what `model_id` means |

**Code you should know:**
```python
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification

# Easy way - Pipeline
classifier = pipeline("sentiment-analysis")
result = classifier("I love this product!")

# Manual way - Tokenizer + Model
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased")

inputs = tokenizer("Hello world", return_tensors="pt")
outputs = model(**inputs)
logits = outputs.logits
```

---

## 📋 Your Final Checklist (TCS 3.3 yrs level)

### Scikit-Learn (Must Know)
- [ ] LinearRegression - fit, predict, MSE
- [ ] LogisticRegression - fit, predict, accuracy
- [ ] train_test_split
- [ ] At least 3 metrics (accuracy, precision, recall OR MSE, MAE, R²)
- [ ] What is overfitting/underfitting (verbal answer)

### Hugging Face (Must Know)
- [ ] `pipeline()` for quick inference
- [ ] `AutoTokenizer` + `AutoModel` pattern
- [ ] Tokenizer encode/decode
- [ ] What are `input_ids`, `attention_mask`
- [ ] Difference between encoder (BERT) vs decoder (GPT) vs encoder-decoder (T5)
- [ ] What is fine-tuning vs prompt engineering vs RAG (you know this)

### Bonus (Good to Know)
- [ ] LoRA/QLoRA concept (parameter efficient fine-tuning)
- [ ] What is `Trainer` class
- [ ] Model quantization basics (4-bit, 8-bit)

---

## 🎯 My Take

Bro for TCS with your GenAI background, if you nail:
1. **5 lines of sklearn code** (fit/predict pattern)
2. **HuggingFace pipeline + manual tokenizer/model pattern**
3. **Your RAG + Agentic AI stories**

You're golden. They won't grill you like Google. Just don't blank on the basics again.

**Want me to create a quick practice file with these patterns so you can run through them?**

User: yeah i fele the confidence.. anything with pandas and numpy and torch thing should be aware or not ?

GitHub Copilot: Bro yes — but **minimal stuff**. Here's what's actually asked at TCS level:

---

## 🐼 Pandas (Must Know)

| Operation | Code |
|-----------|------|
| Load CSV | `df = pd.read_csv("file.csv")` |
| View data | `df.head()`, `df.shape`, `df.info()`, `df.describe()` |
| Select column | `df["col"]` or `df.col` |
| Filter rows | `df[df["age"] > 25]` |
| Handle nulls | `df.isnull().sum()`, `df.dropna()`, `df.fillna(0)` |
| Group by | `df.groupby("col").mean()` |
| Apply function | `df["col"].apply(lambda x: x*2)` |

**That's it.** They won't ask you pivot tables or multi-index stuff.

---

## 🔢 NumPy (Must Know)

| Operation | Code |
|-----------|------|
| Create array | `np.array([1,2,3])` |
| Shape/Reshape | `arr.shape`, `arr.reshape(2,3)` |
| Basic ops | `np.mean()`, `np.sum()`, `np.max()`, `np.min()` |
| Matrix multiply | `np.dot(a, b)` or `a @ b` |
| Zeros/Ones | `np.zeros((3,3))`, `np.ones((2,2))` |
| Random | `np.random.rand(3,3)`, `np.random.randint(0,10,5)` |

---

## 🔥 PyTorch (Light Touch)

Since you're GenAI focused, know **concept level** + basic syntax:

| Concept | What to Know |
|---------|--------------|
| **Tensor basics** | `torch.tensor([1,2,3])`, `.shape`, `.to("cuda")` |
| **Model structure** | `nn.Module`, `__init__`, `forward()` |
| **Training loop concept** | forward → loss → backward → optimizer step |
| **Difference from TF** | Dynamic graph vs static graph |

**Basic code pattern:**
```python
import torch
import torch.nn as nn

# Tensor
x = torch.tensor([1.0, 2.0, 3.0])
x = x.to("cuda")  # Move to GPU

# Simple model structure (conceptual)
class SimpleModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(10, 1)
    
    def forward(self, x):
        return self.linear(x)

# Training loop (know the 4 steps)
# 1. output = model(input)
# 2. loss = loss_fn(output, target)
# 3. loss.backward()
# 4. optimizer.step()
```

---

## 📊 Reality Check for TCS 3.3 yrs

| Topic | Priority | Depth Needed |
|-------|----------|--------------|
| **Pandas** | HIGH | Read CSV, filter, groupby, nulls |
| **NumPy** | MEDIUM | Arrays, reshape, basic math |
| **PyTorch** | LOW | Conceptual + tensor basics |
| **Sklearn** | HIGH | fit/predict pattern |
| **HuggingFace** | HIGH | pipeline + tokenizer/model |

---

## ✅ Final Minimal Checklist

```
Pandas:
[ ] read_csv, head, shape, describe
[ ] filter rows, select columns
[ ] groupby, apply
[ ] handle nulls

NumPy:
[ ] create array, reshape
[ ] mean, sum, dot product

PyTorch:
[ ] tensor creation, .to("cuda")
[ ] know what nn.Module is
[ ] know the 4-step training loop (verbal)
```

---

**Bro honest opinion:** For TCS, Pandas > NumPy > PyTorch in terms of what they'll ask. PyTorch deep dive they won't do — you're not applying for Meta Research. 

**Want me to make a single practice file with all this so you can run through once before the interview?**

User: youa re super cool bro.. so the thing i wil gvie the description it mght help just okay...
role & responsibilities

• Design and implement GenAI solutions leveraging LLMs, RAG pipelines, and Agentic AI architectures.

• Develop and fine-tune deep learning models for NLP tasks using frameworks like PyTorch or TensorFlow.

• Build scalable APIs using FastAPI to serve AI models and integrate with enterprise systems.

• Collaborate with data scientists and ML engineers to deploy models using CI/CD pipelines on Azure

. • Optimize model performance and ensure robustness in production environments.

• Stay updated with the latest research and advancements in generative AI and deep learning.

• Scalability & Performance: Ability to write efficient code and consider scalability and latency implications for Gen AI applications.


Preferred candidate profile


• Strong programming skills in Python with experience in building ML/NLP applications.

• Hands-on experience with Deep Learning, Machine Learning, and Natural Language Processing.

• Proficiency in working with LLMs (e.g., GPT,Gemini, LLaMA, Mistral) and RAG architecture.

• Experience with Agentic AI frameworks and autonomous agent design.

Familiarity with FastAPI for building RESTful APIs.
• Experience with CI/CD pipelines and deploying solutions on Azure Cloud, GCP and AWS

Solid understanding of data structures, algorithms, and software engineering principles.
• Bachelors or masters degree in computer science, AI, Data Science, or related field.

• Retrieval Augmented Generation (RAG): Hands-on experience in building and optimizing RAG pipelines from scratch

• Expert-level proficiency and hands-on experience with LangChain and/or LlamaIndex for building complex LLM applications, including chains, agents, memory, and tool integration.

just in case okay 


GitHub Copilot: Bro this JD is GOLD. Now I can give you the **exact priority list**. Let me map it out:

---

## 🎯 JD Analysis → Your Prep Map

| JD Requirement | Your Status | Priority |
|----------------|-------------|----------|
| RAG pipelines from scratch | ✅ You have this | FLEX IT |
| LangChain/LlamaIndex expert | ✅ You have this | FLEX IT |
| Agentic AI / autonomous agents | ✅ LangGraph experience | FLEX IT |
| LLMs (GPT, Gemini, LLaMA, Mistral) | ✅ You work with these | FLEX IT |
| FastAPI for REST APIs | ⚠️ GAP | **HIGH PREP** |
| PyTorch/TensorFlow for NLP | ⚠️ GAP | **MEDIUM PREP** |
| CI/CD on Azure | ⚠️ GAP (you have GCP) | **MEDIUM PREP** |
| DSA + software engineering | ⚠️ Basics needed | **MEDIUM PREP** |
| Scalability & Performance | 🔶 Know concepts | **TALK READY** |

---

## 🔥 Your Final Prep Checklist (Prioritized)

### ✅ ALREADY STRONG (Just prep stories)
- [ ] RAG pipeline architecture (chunking, embedding, retrieval, generation)
- [ ] LangChain chains, agents, memory, tools
- [ ] Agentic AI with LangGraph
- [ ] Working with LLMs (GPT, Gemini)

### 🚨 HIGH PRIORITY (Must Learn Before Interview)

**1. FastAPI (1-2 hours)**
```python
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class PredictRequest(BaseModel):
    text: str

class PredictResponse(BaseModel):
    result: str
    confidence: float

@app.post("/predict", response_model=PredictResponse)
async def predict(request: PredictRequest):
    # Your model inference here
    return PredictResponse(result="positive", confidence=0.95)

# Run: uvicorn main:app --reload
```

**Know these FastAPI concepts:**
- [ ] `@app.get()`, `@app.post()` decorators
- [ ] Pydantic models for request/response
- [ ] `async def` vs `def`
- [ ] Dependency injection basics
- [ ] How to serve an ML model via endpoint

---

### 🟡 MEDIUM PRIORITY

**2. PyTorch/TensorFlow for NLP (Conceptual + Basic Code)**
```python
# They want to see you know the flow
import torch
from transformers import AutoTokenizer, AutoModel

# Load model
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
model = AutoModel.from_pretrained("bert-base-uncased")

# Inference
inputs = tokenizer("Hello world", return_tensors="pt")
with torch.no_grad():
    outputs = model(**inputs)
    embeddings = outputs.last_hidden_state
```

**3. Azure Mapping (Know equivalents)**
| Your GCP Experience | Azure Equivalent |
|---------------------|------------------|
| Vertex AI | Azure OpenAI / Azure ML |
| Cloud Storage (GCS) | Azure Blob Storage |
| Cloud Run | Azure Container Apps |
| BigQuery | Azure Synapse |
| Cloud Build | Azure DevOps Pipelines |

**4. CI/CD Concepts (Verbal)**
- [ ] What is CI/CD pipeline
- [ ] GitHub Actions / Azure DevOps basics
- [ ] Docker containerization
- [ ] How you'd deploy a model (container → registry → cloud run/container apps)

---

### 📚 DSA (Basic Level for TCS)
- [ ] Arrays: Two sum, sliding window
- [ ] Strings: Reverse, palindrome, anagram
- [ ] HashMap usage
- [ ] Basic recursion
- [ ] Time/Space complexity (Big O)

---

## 🗣️ Interview Answer Templates

**"Tell me about your RAG experience"**
> "I built RAG pipelines using LangChain with FAISS/Vertex AI vector stores. I handled chunking strategies, embedding selection, and retrieval optimization. In production, I dealt with [specific challenge] and solved it by [solution]."

**"How do you serve models in production?"**
> "I use FastAPI to create REST endpoints with Pydantic validation. For scalability, I containerize with Docker and deploy on [Cloud Run/Azure Container Apps]. I implement async endpoints for non-blocking inference."

**"Explain your Agentic AI work"**
> "I built multi-agent systems using LangGraph where agents have specialized roles. For example, [your GTE project]. The orchestration handles tool calling, memory, and conditional routing between agents."

---

## ⏰ If Interview is Tomorrow

| Time | Focus |
|------|-------|
| 1 hour | FastAPI basics (build one endpoint) |
| 30 min | Sklearn fit/predict pattern |
| 30 min | HuggingFace tokenizer/model pattern |
| 30 min | Review your RAG/Agent projects for stories |
| 30 min | Azure mapping + CI/CD verbal answers |

---

**Bro real talk:** This JD is literally YOUR profile + FastAPI + Azure. You're like 70% there. Just don't blank on FastAPI and basic ML code, and you're set.

**Want me to create a practice file with FastAPI + ML patterns you can run through?**





---------------------



Bro I totally get it — you're deep in GenAI but got caught off-guard on the "basics" that interviewers love to ask. With 3.3 years exp at TCS level, here's the **exact focused list** you need:

---

## 🔥 Scikit-Learn Basics (1-2 hours max)

**Just know these 5 things cold:**

| Concept | What to Know |
|---------|--------------|
| **Linear Regression** | `LinearRegression().fit(X, y)` → `model.predict(X_test)` |
| **Logistic Regression** | Binary classification, sigmoid, `LogisticRegression()` |
| **Train-Test Split** | `train_test_split(X, y, test_size=0.2)` |
| **Metrics** | `accuracy_score`, `precision_score`, `recall_score`, `f1_score`, `mean_squared_error` |
| **Simple Pipeline** | Load data → split → fit → predict → evaluate |

**Code you MUST be able to write from memory:**
```python
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_squared_error

# Given 2 lists
X = [[1], [2], [3], [4], [5]]
y = [2, 4, 6, 8, 10]

# Train & Predict
model = LinearRegression()
model.fit(X, y)
pred = model.predict([[6]])  # → 12

# Classification version
model = LogisticRegression()
model.fit(X_train, y_train)
preds = model.predict(X_test)
print(accuracy_score(y_test, preds))
```

---

## 🤗 Hugging Face Transformers (Core Stuff)

**For 3.3 yrs GenAI person at TCS, know these:**

| Area | What to Know |
|------|--------------|
| **Pipeline API** | `pipeline("sentiment-analysis")`, `pipeline("text-generation")` |
| **Tokenizer** | `tokenizer(text, return_tensors="pt")`, `tokenizer.decode()` |
| **Model Loading** | `AutoModel.from_pretrained()`, `AutoTokenizer.from_pretrained()` |
| **Inference** | Forward pass, `model(**inputs)`, getting logits |
| **Fine-tuning concepts** | `Trainer`, `TrainingArguments`, `SFTTrainer` (you know this) |
| **Model Hub** | How to load models, what `model_id` means |

**Code you should know:**
```python
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification

# Easy way - Pipeline
classifier = pipeline("sentiment-analysis")
result = classifier("I love this product!")

# Manual way - Tokenizer + Model
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased")

inputs = tokenizer("Hello world", return_tensors="pt")
outputs = model(**inputs)
logits = outputs.logits
```

---

## 📋 Your Final Checklist (TCS 3.3 yrs level)

### Scikit-Learn (Must Know)
- [ ] LinearRegression - fit, predict, MSE
- [ ] LogisticRegression - fit, predict, accuracy
- [ ] train_test_split
- [ ] At least 3 metrics (accuracy, precision, recall OR MSE, MAE, R²)
- [ ] What is overfitting/underfitting (verbal answer)

### Hugging Face (Must Know)
- [ ] `pipeline()` for quick inference
- [ ] `AutoTokenizer` + `AutoModel` pattern
- [ ] Tokenizer encode/decode
- [ ] What are `input_ids`, `attention_mask`
- [ ] Difference between encoder (BERT) vs decoder (GPT) vs encoder-decoder (T5)
- [ ] What is fine-tuning vs prompt engineering vs RAG (you know this)

### Bonus (Good to Know)
- [ ] LoRA/QLoRA concept (parameter efficient fine-tuning)
- [ ] What is `Trainer` class
- [ ] Model quantization basics (4-bit, 8-bit)

---

## 🎯 My Take

Bro for TCS with your GenAI background, if you nail:
1. **5 lines of sklearn code** (fit/predict pattern)
2. **HuggingFace pipeline + manual tokenizer/model pattern**
3. **Your RAG + Agentic AI stories**

You're golden. They won't grill you like Google. Just don't blank on the basics again.

**Want me to create a quick practice file with these patterns so you can run through them?**


Bro yes — but **minimal stuff**. Here's what's actually asked at TCS level:

---

## 🐼 Pandas (Must Know)

| Operation | Code |
|-----------|------|
| Load CSV | `df = pd.read_csv("file.csv")` |
| View data | `df.head()`, `df.shape`, `df.info()`, `df.describe()` |
| Select column | `df["col"]` or `df.col` |
| Filter rows | `df[df["age"] > 25]` |
| Handle nulls | `df.isnull().sum()`, `df.dropna()`, `df.fillna(0)` |
| Group by | `df.groupby("col").mean()` |
| Apply function | `df["col"].apply(lambda x: x*2)` |

**That's it.** They won't ask you pivot tables or multi-index stuff.

---

## 🔢 NumPy (Must Know)

| Operation | Code |
|-----------|------|
| Create array | `np.array([1,2,3])` |
| Shape/Reshape | `arr.shape`, `arr.reshape(2,3)` |
| Basic ops | `np.mean()`, `np.sum()`, `np.max()`, `np.min()` |
| Matrix multiply | `np.dot(a, b)` or `a @ b` |
| Zeros/Ones | `np.zeros((3,3))`, `np.ones((2,2))` |
| Random | `np.random.rand(3,3)`, `np.random.randint(0,10,5)` |

---

## 🔥 PyTorch (Light Touch)

Since you're GenAI focused, know **concept level** + basic syntax:

| Concept | What to Know |
|---------|--------------|
| **Tensor basics** | `torch.tensor([1,2,3])`, `.shape`, `.to("cuda")` |
| **Model structure** | `nn.Module`, `__init__`, `forward()` |
| **Training loop concept** | forward → loss → backward → optimizer step |
| **Difference from TF** | Dynamic graph vs static graph |

**Basic code pattern:**
```python
import torch
import torch.nn as nn

# Tensor
x = torch.tensor([1.0, 2.0, 3.0])
x = x.to("cuda")  # Move to GPU

# Simple model structure (conceptual)
class SimpleModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(10, 1)
    
    def forward(self, x):
        return self.linear(x)

# Training loop (know the 4 steps)
# 1. output = model(input)
# 2. loss = loss_fn(output, target)
# 3. loss.backward()
# 4. optimizer.step()
```

---

## 📊 Reality Check for TCS 3.3 yrs

| Topic | Priority | Depth Needed |
|-------|----------|--------------|
| **Pandas** | HIGH | Read CSV, filter, groupby, nulls |
| **NumPy** | MEDIUM | Arrays, reshape, basic math |
| **PyTorch** | LOW | Conceptual + tensor basics |
| **Sklearn** | HIGH | fit/predict pattern |
| **HuggingFace** | HIGH | pipeline + tokenizer/model |

---

## ✅ Final Minimal Checklist

```
Pandas:
[ ] read_csv, head, shape, describe
[ ] filter rows, select columns
[ ] groupby, apply
[ ] handle nulls

NumPy:
[ ] create array, reshape
[ ] mean, sum, dot product

PyTorch:
[ ] tensor creation, .to("cuda")
[ ] know what nn.Module is
[ ] know the 4-step training loop (verbal)
```

---

**Bro honest opinion:** For TCS, Pandas > NumPy > PyTorch in terms of what they'll ask. PyTorch deep dive they won't do — you're not applying for Meta Research. 

**Want me to make a single practice file with all this so you can run through once before the interview?**





------------


---

# 🔥 PyTorch nn.Module — Topic List

Here's what we'll cover:

---

## Building Models

| Topic | What You'll Learn |
|-------|-------------------|
| `nn.Module` basics | The base class for ALL neural networks |
| `__init__` method | Where you define layers |
| `forward` method | Where you define how data flows |
| `nn.Linear` | Fully connected layer (most basic) |
| `nn.ReLU`, `nn.Sigmoid`, `nn.Softmax` | Activation functions |
| `nn.Sequential` | Quick way to stack layers |

---

## Training Components

| Topic | What You'll Learn |
|-------|-------------------|
| Loss functions | `nn.MSELoss`, `nn.CrossEntropyLoss` |
| Optimizers | `optim.SGD`, `optim.Adam` |
| Full training loop | With model, loss, optimizer |
| `model.train()` vs `model.eval()` | Training mode vs inference mode |

---

## Save & Load

| Topic | What You'll Learn |
|-------|-------------------|
| `torch.save()` | Save model |
| `torch.load()` | Load model |
| `state_dict()` | Model weights |

---

## Bonus (Edge Topics)

| Topic | What You'll Learn |
|-------|-------------------|
| `DataLoader` & `Dataset` | How to feed data to models |
| Batch dimension | Why shape is `(batch, features)` |
| Moving model to GPU | `model.to("cuda")` |

---

## After This You'll Be Able To:

```python
# Define a model
class MyModel(nn.Module):
    def __init__(self):
        ...
    def forward(self, x):
        ...

# Train it
model = MyModel()
optimizer = optim.Adam(model.parameters(), lr=0.001)
loss_fn = nn.CrossEntropyLoss()

for epoch in range(100):
    # training loop
    ...

# Save it
torch.save(model.state_dict(), "model.pt")
```

---

**Want to start or still on break?**