# Firestore Session Management - Complete Cheat Sheet

## Setup & Initialization

```python
from google.cloud import firestore

# Initialize Firestore client
db = firestore.Client(project="your-project-id")

# For local development with emulator
db = firestore.Client(project="demo-project")
```

---

## 1. CREATE Operations

### Create with Custom ID (Recommended for Sessions)
```python
session_id = "session_123"

db.collection("sessions").document(session_id).set({
    "user_id": "john",
    "created_at": firestore.SERVER_TIMESTAMP,
    "messages": [],
    "status": "active",
    "message_count": 0
})
```

### Create with Auto-generated ID
```python
timestamp, doc_ref = db.collection("sessions").add({
    "user_id": "john",
    "created_at": firestore.SERVER_TIMESTAMP,
    "messages": []
})

session_id = doc_ref.id  # Get the generated ID
```

---

## 2. READ Operations

### Read by Document ID
```python
doc = db.collection("sessions").document("session_123").get()

if doc.exists:
    data = doc.to_dict()  # Convert to dictionary
    print(data["messages"])
else:
    print("Session not found")
```

### Query with Single Condition
```python
# Get all sessions for a user
docs = db.collection("sessions").where("user_id", "==", "john").get()

for doc in docs:
    print(doc.id, doc.to_dict())
```

### Query with Multiple Conditions
```python
# Active sessions for john, ordered by creation time
docs = db.collection("sessions") \
    .where("user_id", "==", "john") \
    .where("status", "==", "active") \
    .order_by("created_at", direction=firestore.Query.DESCENDING) \
    .limit(10) \
    .stream()  # Use stream() for large result sets

for doc in docs:
    session_data = doc.to_dict()
```

### Count Documents
```python
count = db.collection("sessions") \
    .where("status", "==", "active") \
    .count() \
    .get()

total = count[0][0].value
print(f"Active sessions: {total}")
```

### OR Conditions (using `in` operator)
```python
# Sessions with status "active" OR "pending"
docs = db.collection("sessions") \
    .where("status", "in", ["active", "pending"]) \
    .get()

# Limitation: Max 10 values in the array
```

### Comparison Operators
```python
# Greater than
recent_sessions = db.collection("sessions") \
    .where("created_at", ">", some_timestamp) \
    .get()

# Less than or equal
old_sessions = db.collection("sessions") \
    .where("created_at", "<=", cutoff_time) \
    .get()

# Array contains
tagged_sessions = db.collection("sessions") \
    .where("tags", "array_contains", "urgent") \
    .get()
```

---

## 3. UPDATE Operations

### Update Specific Fields
```python
db.collection("sessions").document("session_123").update({
    "status": "completed",
    "updated_at": firestore.SERVER_TIMESTAMP
})
```

### Append to Array (Atomic - Race-condition Safe)
```python
# Add message to messages array
db.collection("sessions").document("session_123").update({
    "messages": firestore.ArrayUnion([
        {
            "role": "user",
            "content": "Hello",
            "timestamp": firestore.SERVER_TIMESTAMP
        }
    ])
})

# Can append multiple items at once
db.collection("sessions").document("session_123").update({
    "messages": firestore.ArrayUnion([msg1, msg2, msg3])
})
```

### Remove from Array
```python
db.collection("sessions").document("session_123").update({
    "messages": firestore.ArrayRemove([message_to_remove])
})
```

### Increment Counter (Atomic - Race-condition Safe)
```python
# Increment by 1
db.collection("sessions").document("session_123").update({
    "message_count": firestore.Increment(1)
})

# Increment by any amount
db.collection("sessions").document("session_123").update({
    "view_count": firestore.Increment(5)
})

# Decrement (negative increment)
db.collection("sessions").document("session_123").update({
    "credits": firestore.Increment(-10)
})
```

**Why use Increment?**
- Handles concurrent updates correctly (no race conditions)
- Server-side operation (atomic)
- Better than read → calculate → write

### Delete a Field
```python
db.collection("sessions").document("session_123").update({
    "temp_data": firestore.DELETE_FIELD
})
```

---

## 4. DELETE Operations

### Delete Single Document
```python
db.collection("sessions").document("session_123").delete()
```

### Batch Delete (Up to 500 per batch)
```python
batch = db.batch()

# Query documents to delete
old_sessions = db.collection("sessions") \
    .where("status", "==", "completed") \
    .limit(500) \
    .stream()

delete_count = 0
for doc in old_sessions:
    batch.delete(doc.reference)  # Use doc.reference, not doc.id
    delete_count += 1

# Execute all deletes atomically
if delete_count > 0:
    batch.commit()
    print(f"Deleted {delete_count} sessions")
```

### Delete Multiple Batches (For >500 documents)
```python
def delete_collection(collection_ref, batch_size=500):
    """Delete all documents in a collection"""
    while True:
        docs = collection_ref.limit(batch_size).stream()
        deleted = 0
        
        batch = db.batch()
        for doc in docs:
            batch.delete(doc.reference)
            deleted += 1
        
        if deleted > 0:
            batch.commit()
            print(f"Deleted {deleted} documents")
        
        if deleted < batch_size:
            break  # No more documents

# Usage
old_sessions = db.collection("sessions").where("status", "==", "old")
delete_collection(old_sessions)
```

---

## 5. TRANSACTIONS (For Concurrent Updates)

### Basic Transaction
```python
@firestore.transactional
def update_session_safely(transaction, session_ref):
    """Update session with read-modify-write safety"""
    
    # Read within transaction
    snapshot = session_ref.get(transaction=transaction)
    data = snapshot.to_dict()
    
    # Modify
    data["message_count"] += 1
    data["last_updated"] = firestore.SERVER_TIMESTAMP
    
    # Write within transaction
    transaction.update(session_ref, data)

# Execute transaction
session_ref = db.collection("sessions").document("session_123")
transaction = db.transaction()
update_session_safely(transaction, session_ref)
```

### When to Use Transactions?
- ✅ Read → calculate → write operations with race conditions
- ✅ Need to update multiple documents atomically
- ✅ Conditional updates (only update if condition met)

### When NOT to Use Transactions?
- ❌ Simple increments (use `firestore.Increment()` instead)
- ❌ Single field updates (use `.update()` directly)
- ❌ Array operations (use `ArrayUnion/ArrayRemove`)

---

## 6. REAL-TIME LISTENERS (Live Updates)

### Listen to Single Document
```python
def on_session_update(doc_snapshot, changes, read_time):
    """Called automatically when session changes"""
    
    doc = doc_snapshot[0]  # First (and only) document
    
    if doc.exists:
        data = doc.to_dict()
        messages = data.get("messages", [])
        
        # Update UI with new data
        print(f"Session updated: {len(messages)} messages")
        update_frontend(messages)

# Start listening
session_id = "session_123"
listener = db.collection("sessions").document(session_id).on_snapshot(on_session_update)

# Stop listening (IMPORTANT - prevents memory leaks and costs!)
listener.unsubscribe()
```

### Listen to Query (Multiple Documents)
```python
def on_active_sessions_change(query_snapshot, changes, read_time):
    """Called when any active session changes"""
    
    for change in changes:
        doc = change.document
        
        if change.type.name == "ADDED":
            print(f"New session: {doc.id}")
            add_to_dashboard(doc.to_dict())
            
        elif change.type.name == "MODIFIED":
            print(f"Updated session: {doc.id}")
            update_in_dashboard(doc.to_dict())
            
        elif change.type.name == "REMOVED":
            print(f"Removed session: {doc.id}")
            remove_from_dashboard(doc.id)

# Listen to all active sessions
dashboard_listener = db.collection("sessions") \
    .where("status", "==", "active") \
    .on_snapshot(on_active_sessions_change)

# Cleanup
dashboard_listener.unsubscribe()
```

### Real-time Listener Parameters

**`doc_snapshot` or `query_snapshot`:**
- List of DocumentSnapshot objects
- For single doc: List with 1 item
- For query: List with all matching docs

**`changes`:**
- List of DocumentChange objects (only for queries)
- Each change has:
  - `change.type.name`: "ADDED" | "MODIFIED" | "REMOVED"
  - `change.document`: The DocumentSnapshot

**`read_time`:**
- Server timestamp when snapshot was created

### Use Cases for Listeners
- ✅ Live chat (see messages instantly)
- ✅ Supervisor dashboards (monitor sessions in real-time)
- ✅ Collaborative editing
- ✅ Real-time notifications

**Important:** Always `unsubscribe()` when done to avoid memory leaks and costs!

---

## 7. SUBCOLLECTIONS (For Large Data)

### When to Use Subcollections?
- Document size approaching 1MB limit
- Need to organize related data hierarchically
- Want to query nested data independently

### Structure Example
```
sessions/
  └── session_123/  (metadata only)
        ├── user_id: "john"
        ├── status: "active"
        └── messages/  (subcollection)
              ├── msg_1
              ├── msg_2
              └── msg_3
```

### Add to Subcollection
```python
# Add message to messages subcollection
db.collection("sessions").document("session_123") \
  .collection("messages").add({
      "role": "user",
      "content": "Hello",
      "timestamp": firestore.SERVER_TIMESTAMP
  })
```

### Query Subcollection
```python
# Get all messages for a session, ordered by time
messages = db.collection("sessions").document("session_123") \
             .collection("messages") \
             .order_by("timestamp") \
             .stream()

for msg in messages:
    print(msg.to_dict())
```

### Delete Document with Subcollections
**Important:** Deleting parent does NOT delete subcollections!

```python
def delete_session_completely(session_id):
    """Delete session and all its subcollections"""
    
    # Delete messages subcollection first
    messages_ref = db.collection("sessions").document(session_id).collection("messages")
    delete_collection(messages_ref)
    
    # Then delete parent
    db.collection("sessions").document(session_id).delete()
```

---

## 8. ERROR HANDLING

```python
from google.cloud.exceptions import NotFound, FailedPrecondition

try:
    doc = db.collection("sessions").document("session_123").get()
    
    if not doc.exists:
        print("Session not found")
        return None
    
    return doc.to_dict()
    
except NotFound:
    print("Collection doesn't exist")
    
except FailedPrecondition as e:
    print(f"Index required for query: {e}")
    # Create index in Firestore console
    
except Exception as e:
    print(f"Unexpected error: {e}")
```

---

## 9. BEST PRACTICES

### ✅ DO
- Use custom IDs for sessions (easier retrieval)
- Use `ArrayUnion` for atomic array updates
- Use `firestore.Increment()` for counters
- Use `SERVER_TIMESTAMP` for consistent time
- Use batch operations for multiple updates/deletes
- Use subcollections when document > 500KB
- Use transactions for read-modify-write patterns
- Always check `doc.exists` before using data
- Limit queries (don't fetch everything at once)
- Unsubscribe from listeners when done

### ❌ DON'T
- Store large binary data in Firestore (use Cloud Storage)
- Use client-side timestamps (inconsistent across timezones)
- Forget to handle `doc.exists == False`
- Leave listeners running indefinitely
- Do read → calculate → write without transactions
- Exceed 1MB per document
- Query without indexes (slow and fails)
- Delete parent assuming subcollections are deleted

---

## 10. PRODUCTION SESSION MANAGER

```python
class FirestoreSessionManager:
    def __init__(self, project_id: str):
        self.db = firestore.Client(project=project_id)
        self.collection = "sessions"
    
    def create_session(self, session_id: str, user_id: str):
        """Create new session"""
        self.db.collection(self.collection).document(session_id).set({
            "user_id": user_id,
            "created_at": firestore.SERVER_TIMESTAMP,
            "messages": [],
            "status": "active",
            "message_count": 0
        })
    
    def get_session(self, session_id: str):
        """Retrieve session by ID"""
        doc = self.db.collection(self.collection).document(session_id).get()
        return doc.to_dict() if doc.exists else None
    
    def add_message(self, session_id: str, role: str, content: str):
        """Add message to session atomically"""
        self.db.collection(self.collection).document(session_id).update({
            "messages": firestore.ArrayUnion([{
                "role": role,
                "content": content,
                "timestamp": firestore.SERVER_TIMESTAMP
            }]),
            "message_count": firestore.Increment(1)
        })
    
    def get_user_sessions(self, user_id: str, limit: int = 10):
        """Get recent sessions for user"""
        docs = self.db.collection(self.collection) \
            .where("user_id", "==", user_id) \
            .order_by("created_at", direction=firestore.Query.DESCENDING) \
            .limit(limit) \
            .stream()
        
        return [{"id": doc.id, **doc.to_dict()} for doc in docs]
    
    def close_session(self, session_id: str):
        """Mark session as completed"""
        self.db.collection(self.collection).document(session_id).update({
            "status": "completed",
            "ended_at": firestore.SERVER_TIMESTAMP
        })
    
    def delete_session(self, session_id: str):
        """Delete session"""
        self.db.collection(self.collection).document(session_id).delete()
    
    def cleanup_old_sessions(self, days_old: int = 30):
        """Delete sessions older than specified days"""
        from datetime import datetime, timedelta
        
        cutoff = datetime.now() - timedelta(days=days_old)
        
        batch = self.db.batch()
        old_sessions = self.db.collection(self.collection) \
            .where("created_at", "<", cutoff) \
            .limit(500) \
            .stream()
        
        count = 0
        for doc in old_sessions:
            batch.delete(doc.reference)
            count += 1
        
        if count > 0:
            batch.commit()
        
        return count
```

---

## Quick Reference Table

| Operation | Method | Use Case |
|-----------|--------|----------|
| **Create with custom ID** | `.document(id).set()` | Sessions with known IDs |
| **Create with auto ID** | `.add()` | General documents |
| **Read by ID** | `.document(id).get()` | Single document lookup |
| **Query** | `.where().get()` | Filter documents |
| **Update fields** | `.update()` | Modify specific fields |
| **Append to array** | `ArrayUnion()` | Add to array safely |
| **Increment** | `Increment()` | Update counters safely |
| **Delete doc** | `.delete()` | Remove document |
| **Batch operations** | `batch.commit()` | Multiple operations atomically |
| **Transactions** | `@transactional` | Read-modify-write safely |
| **Real-time** | `.on_snapshot()` | Live updates |
| **Subcollections** | `.collection().collection()` | Nested data |

---

## Common Firestore Limits

- **Document size:** 1 MB max
- **Batch writes:** 500 operations max
- **Array size:** 20,000 elements recommended
- **Transaction timeout:** 60 seconds
- **Query results:** No hard limit (but use pagination)
- **Subcollection depth:** 100 levels max (practically use 2-3)

---

## Interview Key Points

**Must Know:**
- CRUD operations (set, get, update, delete)
- Queries (where, order_by, limit)
- ArrayUnion for atomic array updates
- Increment for atomic counter updates
- Batch operations for efficiency
- doc.to_dict() vs doc.reference

**Good to Know:**
- Transactions for race conditions
- Real-time listeners for live features
- Subcollections for large data
- Error handling patterns

**Nice to Have:**
- Firestore security rules
- Composite indexes
- Query optimization
