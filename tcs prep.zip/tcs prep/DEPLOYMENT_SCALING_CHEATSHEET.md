# GenAI Developer - Deployment & Scaling Cheat Sheet

## 1. RETRY LOGIC (Tenacity)

**When:** You call external LLM APIs (OpenAI, Gemini)

**Code:**
```python
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from google.api_core.exceptions import ResourceExhausted

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(min=1, max=10),
    retry=retry_if_exception_type(ResourceExhausted)
)
def call_llm(prompt: str) -> str:
    model = GenerativeModel("gemini-pro")
    response = model.generate_content(prompt)
    return response.text
```

**What to Say:**
"I use tenacity for automatic retry with exponential backoff on LLM failures. Retries 3 times with 1s, 2s, 4s delays. Only retries on rate limit errors, not invalid API keys."

---

## 2. RATE LIMITING (Slowapi)

**When:** Users calling YOUR API (but usually API Gateway handles this)

**Setup:**
```python
from fastapi import FastAPI, Request
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
app = FastAPI()
app.state.limiter = limiter

@app.post("/generate")
@limiter.limit("10/minute")
async def generate(request: Request, prompt: str):
    result = call_llm(prompt)
    return {"response": result}
```

**What to Say:**
"In production, API Gateway handles rate limiting and authentication. For standalone services, I can implement it with slowapi - limiting requests per user IP or API key."

---

## 3. CACHING (Redis) - MOST IMPORTANT

**Why:** 80% cost reduction, 100x faster for repeated queries

**Code:**
```python
import redis
import hashlib
import json

redis_client = redis.Redis(host='localhost', port=6379, decode_responses=True)

def get_cache_key(prompt: str) -> str:
    return hashlib.md5(prompt.encode()).hexdigest()

# Check cache
cached = redis_client.get(cache_key)
if cached:
    return json.loads(cached)

# Cache miss - call LLM
result = call_llm(prompt)

# Save to cache (1 hour TTL)
redis_client.setex(cache_key, 3600, json.dumps(result))
```

**Key Commands:**
```python
redis_client.setex(key, 3600, value)  # Set with expiration
redis_client.get(key)                  # Get value
redis_client.exists(key)               # Check if exists
redis_client.delete(key)               # Delete
```

**What to Say:**
"Redis caching reduces LLM API calls by 60-80% for repeated queries. Cache hit takes 10ms vs 2 seconds for LLM call. I hash prompts to create cache keys and set TTL based on use case - FAQs cache for hours, dynamic content for minutes."

---

## 4. DOCKERFILE

**Basic Template:**
```dockerfile
FROM python:3.11-slim
WORKDIR /app

# Copy requirements FIRST (caching)
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy code AFTER (changes frequently)
COPY . .

# Environment variables
ENV PORT=8000

# Run command
CMD uvicorn main:app --host 0.0.0.0 --port $PORT
```

**Why requirements first?** Docker layer caching - code changes often, dependencies rarely change

**Key Commands:**
```bash
docker build -t my-app .                    # Build
docker run -d -p 8000:8000 my-app          # Run
docker logs -f my-app                       # Logs
```

**What to Say:**
"I containerize FastAPI apps using Dockerfile with python:3.11-slim base. Copy requirements first for better caching - code changes don't trigger package reinstall. Use environment variables for flexibility across environments."

---

## 5. LATENCY OPTIMIZATION

**Top 2 Techniques (80% of the value):**

### A. Caching (covered above)
- 80% faster for repeated queries

### B. Streaming
```python
from fastapi.responses import StreamingResponse

@app.post("/generate-stream")
async def generate_stream(prompt: str):
    async def generate():
        response = model.generate_content(prompt, stream=True)
        for chunk in response:
            yield f"data: {chunk.text}\n\n"
    
    return StreamingResponse(generate(), media_type="text/event-stream")
```

**What to Say:**
"Two main optimizations: 1) Redis caching (80% hit rate = 80% cost savings), 2) Streaming responses for better UX - users see text appearing immediately rather than waiting 3 seconds for full response."

---

## 6. CI/CD PIPELINE FLOW

**The Flow:**
```
Your Laptop
    ↓ git push
GitHub (main branch)
    ↓ webhook
Cloud Build
    ├─ Run Tests (pytest)
    ├─ Build Docker Image
    ├─ Push to Container Registry
    └─ Deploy to Cloud Run
    ↓
Live API
```

**Your Responsibilities:**
- ✅ Write code, tests, Dockerfile
- ✅ Push to GitHub
- ✅ Check logs if deployment fails
- ❌ Don't configure pipeline (Platform team)

**What to Say:**
"I push code to GitHub, CI/CD pipeline automatically runs tests, builds Docker image, and deploys to Cloud Run. Takes 3-5 minutes. If deployment fails, I check Cloud Build logs to identify the issue - usually test failures or missing dependencies."

---

## 7. CLOUD RUN vs AZURE CONTAINER APPS

**Both:** Serverless container platforms - auto-scale, managed infrastructure

| Feature | GCP Cloud Run | Azure Container Apps |
|---------|---------------|---------------------|
| Deploy | `gcloud run deploy` | `az containerapp create` |
| Scale | 0 to 1000 instances | 0 to 30 instances |
| Cold start | 1-2 seconds | 1-2 seconds |

**Key Commands:**
```bash
# GCP
gcloud run deploy my-app \
  --image gcr.io/project/my-app \
  --region us-central1 \
  --min-instances 1 \
  --max-instances 10

# Azure
az containerapp create \
  --name my-app \
  --image myregistry.azurecr.io/my-app \
  --min-replicas 1 \
  --max-replicas 10
```

**What to Say:**
"Cloud Run is serverless - I provide Docker image, it handles auto-scaling and infrastructure. Azure Container Apps is the equivalent. Both eliminate server management and provide auto HTTPS endpoints."

---

## 8. AUTO-SCALING

**Horizontal Scaling:** Add more containers (what serverless does)
```
Low traffic:  [Container 1]
High traffic: [Container 1] [Container 2] [Container 3] [Container 4]
Back to low:  [Container 1]  (others shut down)
```

**Key Settings:**
- **Concurrency:** 80 requests per container (default)
- **Min instances:** 1 (keep warm, no cold start)
- **Max instances:** 100 (cost control)

**What to Say:**
"Cloud Run uses horizontal auto-scaling - creates more container instances when traffic increases. Each handles 80 concurrent requests. I set min instances to 1 for production to avoid cold starts. Scales automatically from 1 to hundreds based on traffic."

---

## 9. MODEL DEPLOYMENT (Vertex AI)

**Flow:**
```
1. Upload Model → Vertex AI Model Registry
2. Deploy Model → Managed Endpoint
3. Call Endpoint → Get Predictions
```

**Commands:**
```bash
# Upload model
gcloud ai models upload \
  --region=us-central1 \
  --display-name=my-model \
  --container-image-uri=gcr.io/project/predictor

# Deploy to endpoint
gcloud ai endpoints deploy-model ENDPOINT_ID \
  --model=MODEL_ID
```

**What to Say:**
"I upload models to Vertex AI Model Registry, then deploy to managed endpoints. Vertex AI handles auto-scaling and load balancing. I call endpoints via REST API or Python SDK. For updates, I version models and can do blue-green deployments."

---

## 10. CHECKING LOGS

**Cloud Run:**
```bash
# View logs
gcloud run services logs read my-app --region us-central1

# Live logs
gcloud run services logs tail my-app

# Filter errors
gcloud run services logs read my-app | grep -i "error"
```

**Kubernetes:**
```bash
# Pod logs
kubectl logs my-pod

# Live logs
kubectl logs -f my-pod

# Last 1 hour
kubectl logs my-pod --since=1h

# Search errors
kubectl logs my-pod | grep -i "error"
```

**What to Say:**
"I use Cloud Logging for debugging. My FastAPI app uses Python logging module which automatically appears in Cloud Logging. For issues, I filter by severity (ERROR/WARNING) and time range. Can use gcloud CLI or web console."

---

## INTERVIEW TEMPLATE - WHAT TO SAY

**"For my GenAI projects:**

**Development:**
- FastAPI with async endpoints
- Redis caching (80% latency reduction, 60-80% cost savings)
- Streaming responses for better UX
- Retry logic with tenacity for LLM failures

**Deployment:**
- Docker containers for consistent environments
- CI/CD via Cloud Build - git push → auto-deploy in 3-5 minutes
- Cloud Run for serverless deployment with auto-scaling

**Optimization:**
- Caching (biggest win - 2 seconds to 10ms)
- Token reduction for faster processing
- Pre-warmed models at startup

**Scaling:**
- Horizontal auto-scaling (1 to 100+ instances)
- Min instances = 1 to avoid cold starts
- 80 concurrent requests per instance

**Collaboration:**
- API Gateway handles auth and rate limiting
- Platform team manages infrastructure and pipelines
- I focus on application code, testing, and optimization

**Monitoring:**
- Cloud Logging for debugging
- Application logs with Python logging
- Filter by severity and time for troubleshooting"**

---

## QUICK REFERENCE

**Redis:**
```python
redis_client.setex(key, 3600, value)  # Cache with TTL
redis_client.get(key)                  # Retrieve
```

**Docker:**
```bash
docker build -t my-app .
docker run -d -p 8000:8000 my-app
```

**Cloud Run:**
```bash
gcloud run deploy my-app --image gcr.io/project/my-app
gcloud run services logs read my-app
```

**Logs:**
```bash
gcloud run services logs read my-app | grep "error"
kubectl logs my-pod | grep "error"
```

---

## KEY NUMBERS TO REMEMBER

- **Caching:** 80% hit rate = 80% cost savings, 2000ms → 10ms
- **Retry:** 3 attempts with 1s, 2s, 4s delays
- **Rate limit:** 10-100 requests per minute (typical)
- **Auto-scale:** 80 concurrent requests per instance
- **CI/CD:** 3-5 minutes from push to production
- **Cold start:** 1-2 seconds (avoid with min instances = 1)
- **TTL:** 1 hour (3600s) for cache is common

---

**Focus Areas for TCS Interview:**
1. ✅ Caching (Redis) - Most important
2. ✅ Retry logic (Tenacity)
3. ✅ Docker basics
4. ✅ CI/CD flow understanding
5. ✅ Cloud Run/Serverless concepts
6. ✅ Basic log checking

**Don't stress about:**
- ❌ Deep Kubernetes (not your job)
- ❌ Complex CI/CD pipeline writing
- ❌ API Gateway configuration details
- ❌ Advanced DevOps stuff

---

## 🐳 DOCKER & KUBERNETES - 3.3 YoE EXPECTATIONS

### Docker - MUST KNOW (Hands-on Required)

#### Basic Dockerfile Example
```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy app
COPY . .

# Expose port
EXPOSE 8000

# Run
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

#### Essential Docker Commands
```bash
# Build image
docker build -t my-app .

# Run container
docker run -p 8000:8000 my-app

# Run with environment variables
docker run -e OPENAI_API_KEY=$OPENAI_API_KEY -p 8000:8000 my-app

# Run with volume mount
docker run -v $(pwd)/data:/app/data -p 8000:8000 my-app

# List containers
docker ps

# View logs
docker logs <container-id>

# Execute command in container
docker exec -it <container-id> bash

# Stop container
docker stop <container-id>
```

#### Docker Compose (FastAPI + DB)
```yaml
version: '3.8'

services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/mydb
    depends_on:
      - db
  
  db:
    image: postgres:15
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=mydb
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

---

### Kubernetes - CONCEPTS ONLY (Awareness Level)

#### What You Need to Know (Conceptual)
```
Kubernetes = Container orchestration platform

Key Components:
- Pod: Smallest unit (wrapper for containers)
- Deployment: Manages replicas and updates
- Service: Exposes app (LoadBalancer, ClusterIP)
- ConfigMap: Configuration data
- Secret: Sensitive data
- HPA: Horizontal Pod Autoscaler

Why K8s?
- Auto-scaling based on load
- Self-healing (restarts failed containers)
- Load balancing
- Rolling updates with zero downtime
```

#### Basic kubectl Commands (Awareness)
```bash
# View pods
kubectl get pods

# View logs
kubectl logs <pod-name>

# Describe pod (debugging)
kubectl describe pod <pod-name>

# Get services
kubectl get services

# Check deployments
kubectl get deployments
```

---

### INTERVIEW QUESTIONS & ANSWERS

#### Q1: "How would you containerize your FastAPI RAG app?"

**Answer:**
> "I'd create a Dockerfile with Python 3.11 base image, copy requirements.txt and install dependencies first (for layer caching), then copy the application code. I'd expose port 8000 and use uvicorn as the server. 
>
> For production, I'd use a multi-stage build to reduce image size, set up proper health check endpoints, and configure environment variables for secrets like API keys. I'd also add a .dockerignore file to exclude unnecessary files like .git and __pycache__."

**Code:**
```dockerfile
# Multi-stage build
FROM python:3.11-slim as builder
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

FROM python:3.11-slim
WORKDIR /app
COPY --from=builder /usr/local/lib/python3.11/site-packages /usr/local/lib/python3.11/site-packages
COPY . .
EXPOSE 8000
HEALTHCHECK --interval=30s --timeout=3s \
  CMD curl -f http://localhost:8000/health || exit 1
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

---

#### Q2: "How do you handle secrets in Docker?"

**Answer:**
> "I never hardcode secrets in Dockerfiles or code. For local development, I use environment variables passed at runtime via -e flag or --env-file with a .env file. 
>
> For production, I use cloud-native secret management like GCP Secret Manager or Kubernetes secrets, and inject them as environment variables at runtime. In docker-compose, I use the env_file directive to load from .env files that are in .gitignore."

**Code:**
```bash
# Local dev - environment variables
docker run -e OPENAI_API_KEY=$OPENAI_API_KEY my-app

# With .env file
docker run --env-file .env my-app

# Docker compose
# docker-compose.yml
services:
  api:
    build: .
    env_file:
      - .env  # Never commit this file!
```

---

#### Q3: "Have you deployed to Kubernetes?"

**Answer (Honest for 3.3 YoE):**
> "I've primarily worked with Docker containers and deployed to managed services like Cloud Run and App Engine, which abstract Kubernetes complexity. 
>
> I understand Kubernetes fundamentals - pods, deployments, services, and the orchestration benefits like auto-scaling and self-healing. I've collaborated with DevOps teams to define resource requirements and health checks for my containers.
>
> For a GenAI app, I know to specify appropriate memory limits (LLMs are memory-heavy, typically 2-4GB), configure horizontal pod autoscaling based on CPU/memory, and set up liveness and readiness probes for health monitoring.
>
> While I haven't written Kubernetes manifests from scratch, I can work with existing K8s setups and understand how to optimize containerized applications for orchestration."

---

#### Q4: "How would you scale your RAG app in production?"

**Answer:**
> "I'd design for horizontal scaling with these considerations:
>
> **1. Stateless Architecture:**
> - Store vectors in external database (Pinecone, Vertex AI Vector Search), not in-memory
> - Use external cache (Redis) for query results
> - No session state in containers
>
> **2. Scaling Strategy:**
> - Start with Cloud Run for simplicity (auto-scales 0 to N based on requests)
> - If more control needed, move to GKE with Horizontal Pod Autoscaler
> - Scale based on memory usage (LLMs are memory-bound) rather than just CPU
>
> **3. Optimization:**
> - Implement caching layer for repeated queries (80% hit rate typical)
> - Use connection pooling for database connections
> - Async processing for non-critical tasks
> - Load balance with Cloud Load Balancer or K8s Service
>
> **4. Resource Limits:**
> - Set memory limits per instance (e.g., 4GB for LLM + embeddings)
> - Configure max concurrent requests per instance (based on model size)
> - Set min instances to 1 to avoid cold starts
>
> **5. Monitoring:**
> - Track latency (p50, p95, p99)
> - Monitor memory usage per instance
> - Set up alerts for error rates and high latency
> - Use distributed tracing to identify bottlenecks"

---

#### Q5: "What's the difference between Docker and Kubernetes?"

**Answer:**
> "Docker is a containerization platform that packages applications with their dependencies into containers. It solves the 'it works on my machine' problem by ensuring consistency across environments.
>
> Kubernetes is a container orchestration platform that manages multiple Docker containers at scale. It handles deployment, scaling, load balancing, and self-healing across a cluster of machines.
>
> **Analogy:** Docker is like having a single shipping container. Kubernetes is like the entire shipping yard that manages thousands of containers - deciding where to place them, how many to use, replacing damaged ones, and routing traffic between them.
>
> For a small application, Docker alone is sufficient. For production systems with high availability and scaling needs, Kubernetes adds the orchestration layer."

---

#### Q6: "Explain a multi-stage Docker build and why use it."

**Answer:**
> "Multi-stage builds use multiple FROM statements in a Dockerfile to create intermediate images and copy only necessary artifacts to the final image.
>
> **Benefits:**
> - Smaller final image size (only runtime dependencies, no build tools)
> - Faster deployment (less data to transfer)
> - More secure (fewer attack surfaces)
> - Better caching (separate build and runtime stages)
>
> **Example:** For a Python app, the first stage installs all dependencies including build tools (gcc, etc.). The second stage copies only the installed packages, not the build tools. This can reduce image size from 1.5GB to 300MB."

**Code:**
```dockerfile
# Stage 1: Build
FROM python:3.11 as builder
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Stage 2: Runtime
FROM python:3.11-slim
WORKDIR /app
# Copy only installed packages
COPY --from=builder /usr/local/lib/python3.11/site-packages /usr/local/lib/python3.11/site-packages
COPY . .
CMD ["python", "app.py"]
```

---

#### Q7: "How do you debug a failing container in production?"

**Answer:**
> "I follow this systematic approach:
>
> **1. Check Logs:**
> ```bash
> docker logs <container-id>
> kubectl logs <pod-name>
> ```
>
> **2. Check Container Status:**
> ```bash
> docker ps -a  # See if container exited
> kubectl describe pod <pod-name>  # Check events
> ```
>
> **3. Access Container Shell (if running):**
> ```bash
> docker exec -it <container-id> bash
> kubectl exec -it <pod-name> -- bash
> ```
>
> **4. Check Resource Usage:**
> ```bash
> docker stats
> kubectl top pods
> ```
>
> **5. Verify Environment Variables:**
> ```bash
> docker inspect <container-id> | grep -A 20 Env
> ```
>
> **6. Test Health Endpoint:**
> ```bash
> curl http://localhost:8000/health
> ```
>
> Common issues I look for:
> - Out of memory (OOMKilled)
> - Missing environment variables
> - Port conflicts
> - Failed health checks
> - Application errors in logs"

---

### Priority for 3.3 YoE GenAI Developer

| Skill | Priority | Depth | Prep Time |
|-------|----------|-------|-----------|
| **Docker Basics** | 🔥 HIGH | Hands-on | 2 hours |
| **Docker Compose** | 🔥 HIGH | Practical | 1 hour |
| **Multi-stage Builds** | ⚠️ MEDIUM | Conceptual | 30 mins |
| **Kubernetes Concepts** | ⚠️ MEDIUM | Awareness | 30 mins |
| **kubectl Basics** | ⚠️ LOW | Commands only | 15 mins |
| **CI/CD** | ⚠️ MEDIUM | High-level | 30 mins |

**Total Prep: 3-4 hours**

---

### What Interviewers ACTUALLY Expect at 3.3 YoE

✅ **You SHOULD know:**
- Write and understand Dockerfiles
- Build and run Docker containers
- Use docker-compose for local development
- Handle environment variables and secrets properly
- Basic debugging with logs and exec
- Understand why containers are useful
- Conceptual knowledge of K8s (pods, deployments, scaling)

⚠️ **Nice to have:**
- Multi-stage builds
- Basic kubectl commands
- Understanding of K8s services and ingress
- CI/CD pipeline awareness

❌ **NOT expected:**
- Advanced K8s networking
- Writing Helm charts
- K8s operators or CRDs
- Deep DevOps expertise
- Infrastructure as Code (Terraform)

**Remember:** You're a GenAI Developer, not a DevOps Engineer. Focus on APPLICATION CODE and how to containerize it. Let platform teams handle complex orchestration!



# ==================== DEPLOYMENT ====================
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-genai-app
  labels:
    app: genai-app
spec:
  # Manual replica count (HPA will override this)
  replicas: 2
  
  selector:
    matchLabels:
      app: genai-app
  
  template:
    metadata:
      labels:
        app: genai-app
    
    spec:
      containers:
      - name: genai-app
        image: gcr.io/my-project/genai-app:v1.0
        
        ports:
        - containerPort: 8080
        
        # ========== RESOURCE LIMITS ==========
        resources:
          # REQUESTS = Minimum guaranteed resources
          requests:
            cpu: "500m"        # 0.5 CPU cores
            memory: "1Gi"      # 1 GB RAM
            nvidia.com/gpu: "0" # No GPU (for CPU pods)
          
          # LIMITS = Maximum allowed resources
          limits:
            cpu: "2000m"       # 2 CPU cores max
            memory: "4Gi"      # 4 GB RAM max
            nvidia.com/gpu: "0"
        
        # ========== HEALTH CHECKS ==========
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 5
        
        # ========== ENVIRONMENT VARIABLES ==========
        env:
        - name: PORT
          value: "8080"
        - name: ENV
          value: "production"
        - name: OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: api-secrets
              key: openai-api-key

---
# ==================== SERVICE ====================
apiVersion: v1
kind: Service
metadata:
  name: genai-app-service
spec:
  selector:
    app: genai-app
  ports:
    - port: 80              # External port
      targetPort: 8080      # Container port
  type: LoadBalancer        # Creates external IP

---
# ==================== HORIZONTAL POD AUTOSCALER ====================
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: genai-app-hpa
spec:
  # ========== TARGET DEPLOYMENT ==========
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: my-genai-app      # Must match Deployment name above
  
  # ========== MIN/MAX REPLICAS ==========
  minReplicas: 2            # Minimum pods (always running)
  maxReplicas: 10           # Maximum pods (cost control)
  
  # ========== SCALING METRICS ==========
  metrics:
  
  # Scale based on CPU usage
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70    # Scale up when CPU > 70%
  
  # Scale based on Memory usage
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80    # Scale up when Memory > 80%
  
  # ========== SCALING BEHAVIOR (Optional) ==========
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 0    # Scale up immediately
      policies:
      - type: Percent
        value: 100                     # Double pods at once
        periodSeconds: 15              # Every 15 seconds
      - type: Pods
        value: 2                       # Or add 2 pods
        periodSeconds: 15
      selectPolicy: Max                # Use the larger value
    
    scaleDown:
      stabilizationWindowSeconds: 300  # Wait 5 minutes before scaling down
      policies:
      - type: Percent
        value: 50                      # Remove half the pods
        periodSeconds: 15
      - type: Pods
        value: 1                       # Or remove 1 pod
        periodSeconds: 15
      selectPolicy: Min                # Use the smaller value





      Here are the Azure equivalents for the GCP services you mentioned:

## GCP to Azure Service Mapping

**1. Cloud Run (GCP) →**
- **Azure Container Apps** (serverless containers, auto-scaling)
- **Azure Container Instances** (simpler, single containers)

**2. Custom Jobs (Vertex AI) →**
- **Azure Machine Learning Jobs** (training jobs)
- **Azure Batch** (compute-intensive workloads)

**3. Vertex AI (GCP) →**
- **Azure Machine Learning** (unified ML platform)
- Includes: Training, deployment, MLOps, AutoML

**4. Endpoints (Vertex AI) →**
- **Azure Machine Learning Endpoints**
  - **Managed Online Endpoints** (real-time inference)
  - **Batch Endpoints** (batch inference)

## Quick Comparison

| GCP Service | Azure Equivalent | Purpose |
|-------------|------------------|---------|
| Cloud Run | Azure Container Apps | Serverless containers |
| Vertex AI Custom Jobs | Azure ML Jobs | Custom training |
| Vertex AI | Azure Machine Learning | Full ML platform |
| Vertex AI Endpoints | Azure ML Endpoints | Model deployment |

**Key Differences to Remember:**
- Azure Container Apps has more built-in features (Dapr, KEDA) than Cloud Run
- Azure ML is more integrated with Azure ecosystem (similar to how Vertex AI integrates with GCP)
- Both platforms support similar deployment patterns (real-time, batch, serverless)