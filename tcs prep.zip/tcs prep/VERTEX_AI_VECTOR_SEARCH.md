# Vertex AI Vector Search - Complete Guide

## Table of Contents
1. [FAISS vs Vertex AI Comparison](#faiss-vs-vertex-ai-comparison)
2. [Complete Workflow (6 Steps)](#complete-workflow)
3. [Tree-AH Algorithm Explained](#tree-ah-algorithm-explained)
4. [Index Parameters Deep Dive](#index-parameters-deep-dive)
5. [Filtering (Categorical & Numeric)](#filtering)
6. [Production Benefits](#production-benefits)
7. [Interview Answers](#interview-answers)

---

## FAISS vs Vertex AI Comparison

### Quick Mapping

| **FAISS (Local)** | **Vertex AI Vector Search (Cloud)** |
|-------------------|-------------------------------------|
| `FAISS.from_documents(docs, embed)` | Upload to GCS → Create Index → Deploy |
| `index.add(vectors)` | Upload embeddings.jsonl to GCS |
| `similarity_search(query, k=5)` | `endpoint.match(queries=[emb], num_neighbors=5)` |
| `as_retriever(search_kwargs={"k":5})` | Same via `MatchingEngine.from_components()` |
| `filter={"type": "health"}` | `restricts=[{"namespace":"type", "allow":["health"]}]` |
| ❌ No numeric filtering | ✅ `numeric_restricts` with LESS/GREATER |
| IndexFlatL2 (exact) | Brute-force index |
| IndexIVFFlat (approximate) | Tree-AH index |

### When to Use Each

**FAISS:**
- ✅ Prototyping/development
- ✅ Small scale (<1M vectors)
- ✅ Single user/low traffic
- ✅ Can tolerate downtime

**Vertex AI:**
- ✅ Production system
- ✅ Large scale (>1M vectors)
- ✅ High availability (99.9% SLA)
- ✅ Auto-scaling
- ✅ Frequent updates (incremental)

---

## Complete Workflow

### Overview
```
Step 1: Prepare Data (embeddings + metadata)
    ↓
Step 2: Upload to GCS
    ↓
Step 3: Create Index (Tree-AH algorithm - 30-60 mins)
    ↓
Step 4: Create Endpoint (API gateway)
    ↓
Step 5: Deploy Index to Endpoint (10-20 mins)
    ↓
Step 6: Search
```

---

### Step 1: Prepare Data

**What:** Convert documents → embeddings → JSONL format

```python
from langchain_google_vertexai import VertexAIEmbeddings
from langchain.schema import Document
import json

# Initialize embedding model
embedding_model = VertexAIEmbeddings(model_name="textembedding-gecko@003")

# Your documents
documents = [
    Document(
        page_content="Health insurance covers medical expenses",
        metadata={"type": "health", "page": 1, "year": 2024}
    )
]

# Convert to Vertex AI format
vertex_data = []
for i, doc in enumerate(documents):
    embedding = embedding_model.embed_query(doc.page_content)
    
    vertex_item = {
        "id": str(i),
        "embedding": embedding,  # List of 768 floats
        "restricts": [
            {"namespace": "type", "allow": [doc.metadata["type"]]},
            {"namespace": "page", "allow": [str(doc.metadata["page"])]}
        ],
        # Optional: Numeric metadata for range filtering
        "numeric_restricts": [
            {"namespace": "year", "value_int": doc.metadata["year"]}
        ]
    }
    vertex_data.append(vertex_item)

# Save to JSONL
with open("embeddings.jsonl", "w") as f:
    for item in vertex_data:
        f.write(json.dumps(item) + "\n")
```

**Key Points:**
- JSONL = one JSON object per line
- `restricts` = categorical metadata (strings)
- `numeric_restricts` = numeric metadata (for range queries)

---

### Step 2: Upload to GCS

**What:** Upload JSONL to Google Cloud Storage

```python
from google.cloud import storage

storage_client = storage.Client(project="your-project-id")
bucket = storage_client.bucket("my-bucket")
blob = bucket.blob("embeddings/data.jsonl")
blob.upload_from_filename("embeddings.jsonl")

gcs_uri = "gs://my-bucket/embeddings/"  # Folder path for Step 3
```

---

### Step 3: Create Index

**What:** Build searchable index using Tree-AH algorithm

```python
from google.cloud import aiplatform

aiplatform.init(project="your-project-id", location="us-central1")

index = aiplatform.MatchingEngineIndex.create_tree_ah_index(
    display_name="policy-docs-index",
    
    # Basic config
    dimensions=768,  # Must match embedding model
    contents_delta_uri="gs://my-bucket/embeddings/",
    
    # Distance method
    distance_measure_type="DOT_PRODUCT_DISTANCE",  # For normalized embeddings
    
    # Tree structure
    leaf_node_embedding_count=500,  # Docs per cluster
    
    # Search behavior
    approximate_neighbors_count=150,  # Candidates per cluster
    leaf_nodes_to_search_percent=7  # % of clusters to search
)

# Takes 30-60 minutes to build
index.wait()
```

**Parameters Explained:**

| Parameter | What it controls | Typical Value |
|-----------|-----------------|---------------|
| `dimensions` | Vector size | 768 (gecko), 1536 (OpenAI) |
| `leaf_node_embedding_count` | Docs per cluster | 500 |
| `approximate_neighbors_count` | Candidates per cluster | 150 |
| `leaf_nodes_to_search_percent` | % clusters searched | 7% |

**Example Math:**
- 100K docs ÷ 500 = 200 clusters
- 200 clusters × 7% = 14 clusters searched
- 14 clusters × 150 candidates = 2,100 docs examined (out of 100K!)

---

### Step 4: Create Endpoint

**What:** Create API gateway for searches

```python
endpoint = aiplatform.MatchingEngineIndexEndpoint.create(
    display_name="policy-search-endpoint",
    public_endpoint_enabled=True
)
```

**Time:** 2-3 minutes

---

### Step 5: Deploy Index to Endpoint

**What:** Connect index to endpoint + provision compute

```python
deployed_index = endpoint.deploy_index(
    index=index,
    deployed_index_id="policy_v1",
    machine_type="n1-standard-2",  # 2 CPUs, 7.5GB RAM
    min_replica_count=1,  # Always running (no cold start)
    max_replica_count=10,  # Auto-scale up to 10
    enable_access_logging=True
)

endpoint.wait()  # Takes 10-20 minutes
```

**Machine Types:**
- `n1-standard-2`: 2 CPUs, 7.5GB (small)
- `n1-standard-4`: 4 CPUs, 15GB (medium)
- `n1-standard-16`: 16 CPUs, 60GB (large)

---

### Step 6: Search

#### Option A: Raw API

```python
from langchain_google_vertexai import VertexAIEmbeddings

embedding_model = VertexAIEmbeddings(model_name="textembedding-gecko@003")
query_embedding = embedding_model.embed_query("claim process")

response = endpoint.match(
    deployed_index_id="policy_v1",
    queries=[query_embedding],
    num_neighbors=5
)

for match in response[0]:
    print(f"ID: {match.id}, Distance: {match.distance}")
```

#### Option B: LangChain (FAISS-like)

```python
from langchain.vectorstores import MatchingEngine

vectorstore = MatchingEngine.from_components(
    project_id="your-project-id",
    region="us-central1",
    index_id=index.resource_name.split("/")[-1],
    endpoint_id=endpoint.resource_name.split("/")[-1],
    embedding=VertexAIEmbeddings(model_name="textembedding-gecko@003")
)

# Same as FAISS!
results = vectorstore.similarity_search(query="claim process", k=5)

# With scores
results = vectorstore.similarity_search_with_score(query="claim process", k=5)

# As retriever
retriever = vectorstore.as_retriever(search_kwargs={"k": 5})
```

---

## Tree-AH Algorithm Explained

### What Problem Does It Solve?

**Brute Force (slow):**
- 1M documents → Compare query with ALL 1M
- Time: ~10 seconds

**Tree-AH (fast):**
- Organize into tree structure → Only search relevant clusters
- Time: ~0.05 seconds (200x faster!)

---

### How Tree is Built

#### Step 1: K-means Clustering (Recursive)

```
Level 1: Split 100K docs into 10 clusters using K-means
    Cluster A: 12K docs (centroid at [0.5, 0.2, -0.3, ...])
    Cluster B: 8K docs
    ...
    Cluster J: 11K docs

Level 2: Split each cluster into 10 sub-clusters
    Cluster A → A1, A2, ..., A10
    Now have 10 × 10 = 100 clusters

Level 3: Continue until leaf_node_embedding_count reached
    Final: Each leaf has ~500 docs

Tree structure:
Root
├── Cluster A (12K)
│   ├── A1 (1.5K)
│   │   ├── A1a (500 docs) ← LEAF
│   │   ├── A1b (500 docs) ← LEAF
│   │   └── A1c (500 docs) ← LEAF
```

**Key:** Documents grouped by VECTOR SIMILARITY (math), not topic/category

---

### Asymmetric Hashing (AH) - Speed Optimization

#### The Problem:
```
Query arrives → Need to find which of 1000 clusters to search
Naive: Compare with all 1000 centroids (768-dim vectors)
= 1000 × 768 = 768,000 float operations
Time: ~10ms
```

#### The Solution: Pre-computed Hash Codes

**Build Phase (one-time):**
```
For each centroid:
1. Split 768 dimensions into 8 chunks of 96 dims

   Centroid A = [0.5, 0.2, -0.3, ..., 0.7]
   Chunk 1 (dims 0-95): [0.5, 0.2, -0.3, ...]
   Chunk 2 (dims 96-191): [0.1, -0.4, 0.6, ...]

2. Quantize each chunk to binary:
   If value > 0: bit = 1
   If value < 0: bit = 0

3. Create hash code:
   Chunk 1 → Hash: "5A3F"
   Chunk 2 → Hash: "8B12"
   ...

Centroid A fingerprint = ["5A3F", "8B12", ..., "C4E9"]
```

**Search Phase (every query):**
```
Query: "insurance claim" → [0.12, -0.45, 0.89, ...]

1. Hash query same way:
   Query fingerprint = ["5B2E", "8B10", "7A3C", ...]

2. Compare hashes (FAST bitwise ops):
   Query:     ["5B2E", "8B10", "7A3C", ...]
   Centroid A: ["5A3F", "8B12", "7A3D", ...] → 1 match
   Centroid B: ["9F21", "1C44", "2B88", ...] → 0 matches
   Centroid C: ["5B3F", "8B11", "7A3C", ...] → 2 matches

3. Centroid C has most matches → Likely most similar

4. Full vector comparison ONLY on top 20 candidates
   (Not all 1000!)
```

**Why It's Fast:**

| Operation | Time per Operation |
|-----------|-------------------|
| Float multiplication | ~10 nanoseconds |
| Hash comparison (XOR) | ~0.1 nanoseconds |

**Speed:**
- Hash comparison: 1000 × 8 = 8,000 operations × 0.1ns = 0.5ms
- Full comparison: 20 × 768 = 15,360 operations × 10ns = 1ms
- **Total: 1.5ms** (vs 10ms without hashing)

**"Asymmetric":**
- Centroids: Pre-computed binary hashes (stored)
- Query: Computed on-the-fly (each search)
- Different comparison methods for stored vs query

---

### Tree-AH vs Other Algorithms

| Algorithm | Method | Speed | Accuracy | Available |
|-----------|--------|-------|----------|-----------|
| **Brute Force** | Compare all | Slow | 100% | FAISS, Vertex AI |
| **IVF** | Clustering only | Fast | ~95% | FAISS |
| **Tree-AH** | Clustering + Tree + Hashing | Fast | ~95% | Vertex AI |
| **HNSW** | Graph-based | Fastest | ~99% | FAISS only |

**Tree-AH = IVF + Hierarchical structure + Hashing optimization**

---

## Index Parameters Deep Dive

### Distance Measure Types

```python
distance_measure_type="DOT_PRODUCT_DISTANCE"  # Default
```

| Type | When to Use | Formula |
|------|-------------|---------|
| `DOT_PRODUCT_DISTANCE` | Normalized embeddings (gecko, OpenAI) | A · B |
| `SQUARED_L2_DISTANCE` | Non-normalized embeddings | (A - B)² |
| `COSINE_DISTANCE` | Rarely needed | Same as DOT_PRODUCT for normalized |

**Why DOT_PRODUCT = Cosine for normalized vectors:**
```
Cosine similarity = (A · B) / (||A|| × ||B||)

When ||A|| = ||B|| = 1 (normalized):
Cosine = (A · B) / 1 = A · B = Dot product

Vertex AI embeddings ARE normalized, so DOT_PRODUCT is faster (no division)
```

---

### Tree Structure Parameters

**leaf_node_embedding_count = 500**

What it controls:
- How many documents per leaf cluster
- Smaller (100-200) = More clusters = More precise but slower
- Larger (1000-2000) = Fewer clusters = Faster but less precise

Example:
- 100K docs ÷ 500 = 200 leaf clusters

---

### Search Behavior Parameters

**approximate_neighbors_count = 150**

What it controls:
- How many candidates to return from each cluster searched
- Higher = better accuracy, slower
- Range: 10-150

**leaf_nodes_to_search_percent = 7**

What it controls:
- What % of all leaf clusters to search
- Higher = better accuracy, slower
- Range: 1-10%

**Together:**
```
200 clusters × 7% = 14 clusters searched
14 clusters × 150 candidates = 2,100 docs examined
Out of 100,000 total = 98% reduction!
```

---

## Filtering

### Categorical Filtering (Strings)

**Use Case:** Filter by document type, status, category

```python
# LangChain (works)
results = vectorstore.similarity_search(
    query="claim process",
    k=5,
    filter=[
        {"namespace": "type", "allow": ["health", "dental"]},  # OR logic
        {"namespace": "status", "allow": ["active"]}  # AND logic
    ]
)

# Raw API
response = endpoint.match(
    deployed_index_id="policy_v1",
    queries=[query_embedding],
    num_neighbors=5,
    restricts=[
        {"namespace": "type", "allow": ["health"]},
        {"namespace": "year", "allow": ["2024"]}
    ]
)
```

**Logic:** (type=health OR dental) AND status=active

---

### Numeric Filtering (Range Queries)

**Use Case:** Filter by price, rating, year ranges

**⚠️ Must use raw API - LangChain doesn't support this**

```python
response = endpoint.match(
    deployed_index_id="policy_v1",
    queries=[query_embedding],
    num_neighbors=5,
    numeric_restricts=[
        {"namespace": "price", "value_int": 1000, "op": "LESS"},  # <
        {"namespace": "rating", "value_float": 4.0, "op": "GREATER_EQUAL"}  # >=
    ]
)
```

**Operations:**

| Operation | Meaning | Example |
|-----------|---------|---------|
| `"LESS"` | < | `price < 1000` |
| `"LESS_EQUAL"` | <= | `price <= 1000` |
| `"EQUAL"` | == | `year == 2024` |
| `"GREATER_EQUAL"` | >= | `rating >= 4.0` |
| `"GREATER"` | > | `age > 18` |
| `"NOT_EQUAL"` | != | `status != 0` |

---

### Combined Filtering

```python
response = endpoint.match(
    deployed_index_id="policy_v1",
    queries=[query_embedding],
    num_neighbors=5,
    
    # Categorical
    restricts=[
        {"namespace": "type", "allow": ["health", "dental"]},
        {"namespace": "status", "allow": ["active"]}
    ],
    
    # Numeric
    numeric_restricts=[
        {"namespace": "price", "value_int": 1000, "op": "LESS"},
        {"namespace": "rating", "value_float": 4.0, "op": "GREATER_EQUAL"}
    ]
)
```

**Logic:** (type=health OR dental) AND status=active AND price<1000 AND rating>=4.0

---

## Production Benefits

### Why FAISS Fails in Production

| Problem | Impact |
|---------|--------|
| **Memory Limits** | 10M vectors = 30GB RAM → Single machine can't handle |
| **No High Availability** | Server crashes → Search goes down |
| **Slow Updates** | Add docs → Rebuild entire index (2 hours downtime) |
| **No Auto-Scaling** | 1000 concurrent users → Server crashes |
| **Manual DevOps** | YOU set up load balancers, replicas, monitoring |

### How Vertex AI Solves It

| Feature | Benefit |
|---------|---------|
| **Distributed** | Handles billions of vectors across cluster |
| **99.9% SLA** | Auto-failover, multiple replicas |
| **Incremental Updates** | Add docs without rebuilding (10 mins, no downtime) |
| **Auto-Scaling** | 1 replica → 50 replicas in 2 minutes |
| **Managed Infrastructure** | Google handles servers, you write code |

### Cost Reality

**FAISS Approach:**
- 3 VMs (64GB each): $900/month
- Load balancer: $50/month
- DevOps engineer (20% time): $4,000/month
- **Total: $4,950/month**

**Vertex AI:**
- Pay per query + storage: $400-800/month
- 0 DevOps time
- **Total: $400-800/month**

**Savings: $4,000+/month** + better reliability

---

## Interview Answers

### Q: "What is Vertex AI Vector Search?"

*"Vertex AI Vector Search is Google's managed vector database service for production-scale similarity search. It's the cloud equivalent of FAISS - I prepare embeddings locally, upload to GCS, and Vertex AI builds a distributed index using the tree-AH algorithm. It provides 99.9% uptime, auto-scaling, and incremental updates without downtime."*

---

### Q: "How does it differ from FAISS?"

*"FAISS is great for development but has production limitations - single machine memory, no auto-scaling, full index rebuilds for updates. Vertex AI is distributed across clusters, auto-scales based on traffic, and supports incremental updates. The core concepts are identical - both use clustering algorithms for approximate nearest neighbor search - but Vertex AI removes the operational burden."*

---

### Q: "Explain the tree-AH algorithm"

*"Tree-AH uses three techniques:*
1. *K-means clustering recursively partitions documents into a hierarchical tree until leaf clusters have ~500 documents*
2. *Asymmetric hashing pre-computes binary hash codes for each cluster centroid - splits 768 dimensions into 8 chunks, converts to hash codes*
3. *During search, query is hashed the same way, compared with centroid hashes using fast bitwise operations to filter 1000 clusters down to top 20 candidates, then full vector comparison only on those 20*

*This reduces comparisons from 768,000 to ~15,000 operations, making search 6-7x faster while maintaining 95% accuracy."*

---

### Q: "What parameters do you configure?"

*"Four key areas:*
1. *Basic: dimensions (768 for gecko), GCS path*
2. *Distance method: DOT_PRODUCT for normalized embeddings*
3. *Tree structure: `leaf_node_embedding_count=500` controls cluster size*
4. *Search behavior: `approximate_neighbors_count=150` for candidates per cluster, `leaf_nodes_to_search_percent=7` to search 7% of clusters*

*For 100K documents, this means 200 clusters, searching 14 of them, examining ~2,100 docs instead of all 100K."*

---

### Q: "How do you handle filtering?"

*"Two types:*
1. *Categorical filtering with `restricts` - works through LangChain for string metadata like document type or status*
2. *Numeric filtering with `numeric_restricts` - requires raw endpoint.match() API for range queries with operators like LESS, GREATER. Supports combining both types - for example, filtering health insurance documents under $1000 with rating >= 4.0"*

---

### Q: "What's the deployment process?"

*"Six steps:*
1. *Generate embeddings and format as JSONL with metadata*
2. *Upload to GCS bucket*
3. *Create index with tree-AH (30-60 minutes)*
4. *Create endpoint (API gateway)*
5. *Deploy index to endpoint with auto-scaling config (10-20 minutes)*
6. *Query via LangChain wrapper or raw API*

*After deployment, auto-scales from min to max replicas based on traffic, with 99.9% uptime SLA."*

---

### Q: "When would you use Vertex AI over FAISS?"

*"Use Vertex AI for production systems with:*
- *Scale: >1M vectors or high traffic*
- *Availability: Need 99.9% uptime*
- *Updates: Frequent document additions without downtime*
- *Auto-scaling: Traffic spikes like Black Friday*

*Use FAISS for:*
- *Development/prototyping*
- *Small scale (<1M vectors)*
- *Low traffic, single user*
- *Learning and experimentation*

*I typically prototype with FAISS locally for fast iteration, then deploy to Vertex AI for production."*

---

## Quick Reference

### Complete Code Template

```python
# Step 1: Prepare Data
from langchain_google_vertexai import VertexAIEmbeddings
import json

embedding_model = VertexAIEmbeddings(model_name="textembedding-gecko@003")
vertex_data = []
for i, doc in enumerate(documents):
    vertex_data.append({
        "id": str(i),
        "embedding": embedding_model.embed_query(doc.page_content),
        "restricts": [{"namespace": "type", "allow": [doc.metadata["type"]]}],
        "numeric_restricts": [{"namespace": "year", "value_int": doc.metadata["year"]}]
    })

with open("embeddings.jsonl", "w") as f:
    for item in vertex_data:
        f.write(json.dumps(item) + "\n")

# Step 2: Upload to GCS
from google.cloud import storage
storage_client = storage.Client()
bucket = storage_client.bucket("my-bucket")
bucket.blob("embeddings/data.jsonl").upload_from_filename("embeddings.jsonl")

# Step 3: Create Index
from google.cloud import aiplatform
aiplatform.init(project="project-id", location="us-central1")
index = aiplatform.MatchingEngineIndex.create_tree_ah_index(
    display_name="my-index",
    dimensions=768,
    distance_measure_type="DOT_PRODUCT_DISTANCE",
    contents_delta_uri="gs://my-bucket/embeddings/",
    leaf_node_embedding_count=500,
    approximate_neighbors_count=150,
    leaf_nodes_to_search_percent=7
)
index.wait()

# Step 4: Create Endpoint
endpoint = aiplatform.MatchingEngineIndexEndpoint.create(
    display_name="my-endpoint",
    public_endpoint_enabled=True
)

# Step 5: Deploy
endpoint.deploy_index(
    index=index,
    deployed_index_id="v1",
    machine_type="n1-standard-2",
    min_replica_count=1,
    max_replica_count=10
)
endpoint.wait()

# Step 6: Search
from langchain.vectorstores import MatchingEngine
vectorstore = MatchingEngine.from_components(
    project_id="project-id",
    region="us-central1",
    index_id=index.resource_name.split("/")[-1],
    endpoint_id=endpoint.resource_name.split("/")[-1],
    embedding=embedding_model
)

results = vectorstore.similarity_search("query", k=5)
retriever = vectorstore.as_retriever(search_kwargs={"k": 5})
```

---

**Good luck with the interview! 🚀**
