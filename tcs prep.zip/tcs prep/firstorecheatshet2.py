# ============================================
# FIRESTORE SESSION MANAGEMENT CHEAT SHEET
# ============================================

from google.cloud import firestore

# Initialize
db = firestore.Client(project="your-project-id")

# -------------------- CREATE --------------------
# With custom ID (recommended for sessions)
db.collection("sessions").document("session_123").set(
    {
        "user_id": "john",
        "created_at": firestore.SERVER_TIMESTAMP,
        "messages": [],
        "status": "active",
    }
)

# With auto-generated ID
timestamp, doc_ref = db.collection("sessions").add({...})
session_id = doc_ref.id

# -------------------- READ --------------------
# By ID
doc = db.collection("sessions").document("session_123").get()
if doc.exists:
    data = doc.to_dict()

# Query - single condition
docs = db.collection("sessions").where("user_id", "==", "john").get()

# Query - multiple conditions
docs = (
    db.collection("sessions")
    .where("user_id", "==", "john")
    .where("status", "==", "active")
    .order_by("created_at", direction=firestore.Query.DESCENDING)
    .limit(10)
    .stream()
)

for doc in docs:
    print(doc.id, doc.to_dict())

# Count
count = db.collection("sessions").where("status", "==", "active").count().get()
total = count[0][0].value

# -------------------- UPDATE --------------------
# Update fields
db.collection("sessions").document("session_123").update(
    {"status": "completed", "updated_at": firestore.SERVER_TIMESTAMP}
)

# Append to array (atomic)
db.collection("sessions").document("session_123").update(
    {
        "messages": firestore.ArrayUnion(
            [
                {
                    "role": "user",
                    "content": "Hello",
                    "timestamp": firestore.SERVER_TIMESTAMP,
                }
            ]
        )
    }
)

# Increment counter
db.collection("sessions").document("session_123").update(
    {"message_count": firestore.Increment(1)}
)

# Remove field
db.collection("sessions").document("session_123").update(
    {"temp_field": firestore.DELETE_FIELD}
)

# -------------------- DELETE --------------------
# Single document
db.collection("sessions").document("session_123").delete()

# Batch delete (up to 500 per batch)
batch = db.batch()
docs = db.collection("sessions").where("status", "==", "old").limit(500).stream()
for doc in docs:
    batch.delete(doc.reference)
batch.commit()


# -------------------- TRANSACTIONS --------------------
@firestore.transactional
def safe_update(transaction, session_ref):
    snapshot = session_ref.get(transaction=transaction)
    transaction.update(session_ref, {"field": "new_value"})


session_ref = db.collection("sessions").document("session_123")
transaction = db.transaction()
safe_update(transaction, session_ref)


# -------------------- REAL-TIME LISTENERS --------------------
def on_snapshot(doc_snapshot, changes, read_time):
    for doc in doc_snapshot:
        print(f"Updated: {doc.to_dict()}")


listener = db.collection("sessions").document("session_123").on_snapshot(on_snapshot)
# Stop: listener.unsubscribe()

# -------------------- SUBCOLLECTIONS --------------------
# Add to subcollection
db.collection("sessions").document("session_123").collection("messages").add(
    {"role": "user", "content": "Hi"}
)

# Query subcollection
messages = (
    db.collection("sessions")
    .document("session_123")
    .collection("messages")
    .order_by("timestamp")
    .stream()
)

# -------------------- SPECIAL OPERATORS --------------------
# OR condition (in operator)
docs = db.collection("sessions").where("status", "in", ["active", "pending"]).get()

# Greater than / Less than
docs = db.collection("sessions").where("created_at", ">", "some_timestamp").get()

# Array contains
docs = db.collection("sessions").where("tags", "array_contains", "urgent").get()

# -------------------- ERROR HANDLING --------------------
from google.cloud.exceptions import NotFound

try:
    doc = db.collection("sessions").document("session_123").get()
    if not doc.exists:
        # Handle missing document
        pass
except NotFound:
    # Handle missing collection
    pass
except Exception as e:
    # Handle other errors
    print(f"Error: {e}")

# -------------------- BEST PRACTICES --------------------
# ✅ Use custom IDs for sessions
# ✅ Use ArrayUnion for atomic array updates
# ✅ Use SERVER_TIMESTAMP for consistent time
# ✅ Use batch for multiple operations
# ✅ Limit queries (don't fetch everything)
# ✅ Use subcollections if doc > 1MB
# ✅ Use transactions for concurrent updates
# ✅ Handle doc.exists before using data
