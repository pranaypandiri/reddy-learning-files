hi there mate 

I am tackling the q9 question first see... yeah I have choosen the fine tuning ehre becasue to find out the pattern and inclicned on the accuracy.. the rag and llm will privide results based on the context window but we cant give 100 examples or the top k examples because we may miss out the things actually... so i have chossen the fine tuning mdoel.. to have the supervised learning and find the patterns understto the voculabary fo the customers data..


q15:

yeah the full mdoel weoghts are large we need to have higher gpu to load the in the first palce and also those mdoel are trian on the large corpus for sure but not the customer data with a different voculabary or patterns.. and so to make the model train on our custom data we will be picking the last 16 layers and tune the according to our model with q and k values of the layers actually... 




bnb stuff i know 
we need quantization because the 7b parameters are 16 bit hard to laod that much space in the gpu so we make the 4bit. compresss the values basiclaly then if we compresse it may effect the computation again so at the time computation of the weight or soem operation we again conevrt them torch16 for the computation okay..

and double quant is to 4bit the parameters helpful for the claucaltion like max variables and these kidn of thisng to double quent to reduce more space..

and when we have the numebrs of values from 7b what we do is perform in the batches and find the mac and min valeus and use a formula i dont know the formula then we perform the operation egt the value and perform nf4 binning because the valeus of these around the 0 to 1 so we have more buckets to be kept in this areas thats why we will sue them nf4 and fal udner the bucket and the time retrievela use the sma eforumla to retriev back...



the forumal is scale =  max = min / 15 

then again for qunatization it is  weight - min / scla e
dequantization it will be like min + values * scale 



------ lora 


yeah lora is been used to make the base mdoel to laring the patterns inthe custome data and fidn out the patetrns between the language it is  asupervised learning...


now the lora we chosse 16 bit matrcies for training the attention layers .. we can go uoto 64 it based on the task...

alpha i dont know what the hell  and target module here are the q and v .. basiclaly from the transform architecture the q state hat is the question or what we are lokking for actualy and v is ehat information this partiuclar data provide or the workd .. so we tune the mdoel to ask the question because here our taks is to clasify means ask the respective question.. and v is extract those necessary data produces by the words there.. and not the k beause i dont know why 

droput is for the regularization 

bias we dont train them we focus on the weights 

task type casual lm there seq to seq also this just decoder taks so casual lm

yeah and rhwn it comes to hte backpropagation here see first we have the layer ready make the 16 matrices zer at the first epoch then after when we do the backprop we do kind of like... i dont know the back prop stuff there i know some a and b matrices will be there and b will be mdoifed with some learning rate and stufff but yeah i dont kniw thos stuff 



traing args things :

training means first think of the epochs and batch size and gradient is do the gradient update only after the complete batch execuetion decrease the backprop overhead 


then the updates of the weight learing rate and warmupstpes and optimizer means the adma thing fp 16 for weights store

logging and monitoring save the best mdoel and logging for 10 steps 

group by elngth simliar examples and dataloader worker 4 becasue the it matches t4 gp