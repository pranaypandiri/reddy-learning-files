# 🚀 GenAI Interview Cheat Sheet - TCS Prep
*Complete Reference for 3.3 YoE | Production Focus*

---

## 📋 Table of Contents
1. [Prompting & CoT](#prompting--cot)
2. [LangChain Chains (LCEL)](#langchain-chains-lcel)
3. [Memory Systems](#memory-systems)
4. [Tools & Agents](#tools--agents)
5. [FAISS Vector Search](#faiss-vector-search)
6. [Production Patterns](#production-patterns)
7. [Callbacks & Streaming](#callbacks--streaming)
8. [Multimodal (Images)](#multimodal-images)
9. [Interview Q&A](#interview-qa)
10. [Quick Shortcuts](#quick-shortcuts)

---

## 1. Prompting & CoT

### PromptTemplate Basics
```python
from langchain.prompts import PromptTemplate

# Simple template
prompt = PromptTemplate(
    input_variables=["product", "audience"],
    template="Write a marketing email for {product} targeting {audience}."
)
text = prompt.format(product="AI Course", audience="developers")
```

**KEY POINT:** Only `input_variables` and `template` exist. No `output_variables`!

### Partial Templates (Pre-fill Variables)
```python
# Scenario: Same company name for all prompts
prompt = PromptTemplate(
    input_variables=["product"],
    template="Write email for {product} from {company}.",
    partial_variables={"company": "TechCorp"}
)

# OR use partial() method
base_prompt = PromptTemplate(
    input_variables=["product", "company"],
    template="Write email for {product} from {company}."
)
prompt = base_prompt.partial(company="TechCorp")

# Now only need to provide product
prompt.format(product="AI Tool")
```

**USE CASE:** API keys, timestamps, company info that's constant across requests.

### ChatPromptTemplate (Multi-Message)
```python
from langchain.prompts import ChatPromptTemplate

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a {role}."),
    ("human", "{user_input}"),
    ("ai", "I understand. Let me help with {task}."),
    ("human", "{follow_up}")
])

messages = prompt.format_messages(
    role="Python expert",
    user_input="How to use FAISS?",
    task="vector search",
    follow_up="Show code example"
)
```

### Chain of Thought (CoT)
```python
# Simple CoT trigger
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant."),
    ("human", "{question}\n\nLet's think step by step:")
])

# Structured CoT
class Reasoning(BaseModel):
    steps: List[str]
    final_answer: str

prompt = ChatPromptTemplate.from_messages([
    ("system", "Break down your reasoning into steps."),
    ("human", "{question}")
])

chain = prompt | llm.with_structured_output(Reasoning)
```

**WHEN TO USE:** Math problems, logic puzzles, multi-step analysis, debugging.

### Structured Output
```python
from pydantic import BaseModel, Field

class ProductReview(BaseModel):
    sentiment: str = Field(description="positive/negative/neutral")
    score: int = Field(description="1-5 rating")
    summary: str

# Method 1: with_structured_output (BEST - Native)
llm = ChatOpenAI(model="gpt-4")
structured_llm = llm.with_structured_output(ProductReview)
result = structured_llm.invoke("Great product! Worth every penny.")

# Method 2: PydanticOutputParser (when model doesn't support native)
from langchain.output_parsers import PydanticOutputParser

parser = PydanticOutputParser(pydantic_object=ProductReview)
prompt = PromptTemplate(
    template="Analyze: {text}\n{format_instructions}",
    input_variables=["text"],
    partial_variables={"format_instructions": parser.get_format_instructions()}
)
chain = prompt | llm | parser
```

**COMPARISON:**
- `with_structured_output()`: Direct function calling, faster, GPT-4/Gemini only
- `PydanticOutputParser`: Adds instructions to prompt, works with any LLM

---

## 2. LangChain Chains (LCEL)

### LCEL Pipe Operator (Modern Way)
```python
# Pattern: prompt | llm | parser
chain = prompt | llm | output_parser
result = chain.invoke({"input": "value"})
```

### Simple Chain
```python
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema.output_parser import StrOutputParser

prompt = ChatPromptTemplate.from_template("Tell me a joke about {topic}")
llm = ChatOpenAI(model="gpt-4")
parser = StrOutputParser()

chain = prompt | llm | parser
result = chain.invoke({"topic": "programming"})
```

### Sequential Chain (Multi-Step)
```python
from langchain_core.runnables import RunnablePassthrough

# Step 1: Generate code
code_prompt = ChatPromptTemplate.from_template("Write Python code for: {task}")
code_chain = code_prompt | llm | StrOutputParser()

# Step 2: Explain code
explain_prompt = ChatPromptTemplate.from_template(
    "Explain this code:\n{code}"
)

# Combine steps
full_chain = (
    {"task": RunnablePassthrough()}
    | {"code": code_chain}
    | {"code": lambda x: x["code"]}  # Pass code to next step
    | explain_prompt
    | llm
    | StrOutputParser()
)

result = full_chain.invoke("binary search")
```

**KEY TRICK:** Use lambda to wrap single steps: `{"code": lambda x: code_chain.invoke(x)}`

### Parallel Chain (Concurrent Execution)
```python
from langchain_core.runnables import RunnableParallel

# Run multiple analyses at once
analysis_chain = RunnableParallel(
    sentiment=sentiment_prompt | llm | StrOutputParser(),
    summary=summary_prompt | llm | StrOutputParser(),
    keywords=keyword_prompt | llm | StrOutputParser()
)

results = analysis_chain.invoke({"text": "Product review text..."})
# Returns: {"sentiment": "...", "summary": "...", "keywords": "..."}
```

**USE CASE:** Product analysis, document processing, multi-angle evaluation.

### Router Chain (Conditional)
```python
from langchain_core.runnables import RunnableBranch

def route_query(x):
    query = x["query"].lower()
    if "code" in query:
        return "technical"
    elif "price" in query or "cost" in query:
        return "sales"
    else:
        return "general"

router = RunnableBranch(
    (lambda x: route_query(x) == "technical", technical_chain),
    (lambda x: route_query(x) == "sales", sales_chain),
    general_chain  # Default
)

chain = {"query": RunnablePassthrough()} | router
```

### RAG Chain (Retrieval + Generation)
```python
from langchain_core.runnables import RunnablePassthrough

def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

# Classic RAG pattern
rag_chain = (
    {
        "context": retriever | format_docs,
        "question": RunnablePassthrough()
    }
    | prompt
    | llm
    | StrOutputParser()
)

rom fastapi import FastAPI
from fastapi.responses import StreamingResponse

app = FastAPI()

@app.post("/chat/stream")
async def chat_stream(message: str):
    async def generate():
        async for chunk in rag_chain.astream(message):
            yield f"data: {chunk}\n\n"
    
    return StreamingResponse(generate(), media_type="text/event-stream")

# With sources
rag_with_sources = (
    {
        "context": retriever | format_docs,
        "question": RunnablePassthrough(),
        "sources": retriever | (lambda docs: [doc.metadata["source"] for doc in docs])
    }
    | prompt
    | llm
    | StrOutputParser()
)
```

**DICT VALUES AUTO-INVOKE:** When you write `{"context": retriever}`, LangChain automatically calls `retriever.invoke(input)`.

---

## 3. Memory Systems

### Memory Types Comparison
| Type | Storage | Use Case | Pros | Cons |
|------|---------|----------|------|------|
| **ConversationBufferMemory** | Full history | Chatbots | Complete context | Token overflow |
| **ConversationBufferWindowMemory** | Last K messages | Support chat | Fixed size | Loses old context |
| **ConversationSummaryMemory** | Summarized history | Long sessions | Compact | Summary cost |
| **ConversationSummaryBufferMemory** | Recent + summary | Production chat | Balanced | Complex |

### ConversationBufferMemory
```python
from langchain.memory import ConversationBufferMemory

memory = ConversationBufferMemory(
    memory_key="chat_history",
    return_messages=True  # Returns Message objects, not strings
)

memory.save_context(
    {"input": "What's AI?"},
    {"output": "Artificial Intelligence is..."}
)

# Retrieve
history = memory.load_memory_variables({})
# {"chat_history": [HumanMessage(...), AIMessage(...)]}
```

### Window Memory (Last K Messages)
```python
memory = ConversationBufferWindowMemory(
    k=4,  # Last 4 messages (2 exchanges)
    memory_key="chat_history",
    return_messages=True
)
```

### Summary Memory
```python
memory = ConversationSummaryMemory(
    llm=ChatOpenAI(model="gpt-3.5-turbo"),
    memory_key="chat_history"
)
# Automatically summarizes old messages
```

### Firestore Persistence (Production)
```python
from langchain_google_firestore import FirestoreChatMessageHistory

def get_memory(session_id: str):
    return FirestoreChatMessageHistory(
        collection_name="chat_sessions",
        session_id=session_id,
        project_id="your-project"
    )

# Manual save
history = get_memory("user_123")
history.add_user_message("Hello")
history.add_ai_message("Hi there!")

# Retrieve
messages = history.messages  # List[BaseMessage]
```

### RunnableWithMessageHistory (Auto Save/Load)
```python
from langchain_core.runnables.history import RunnableWithMessageHistory


# Base chain
chain = prompt | llm | StrOutputParser()

# Wrap with memory
chain_with_memory = RunnableWithMessageHistory(
    chain,
    lambda session_id: FirestoreChatMessageHistory(
        collection_name="sessions",
        session_id=session_id,
        project_id="my-project"
    ),
    input_messages_key="input",
    history_messages_key="chat_history"
)

# Use with session
response = chain_with_memory.invoke(
    {"input": "What's my name?"},
    config={"configurable": {"session_id": "user_123"}}
)
```

**KEY BENEFIT:** Automatic save after each invoke, no manual memory.save_context().


### Custom Variables + Firestore
```python
from google.cloud import firestore

db = firestore.Client()


def save_custom_data(session_id: str, user_data: dict):
    # Save chat history (handled by FirestoreChatMessageHistory)
    history = FirestoreChatMessageHistory(
        collection_name="sessions",
        session_id=session_id
    )
    
    # Save custom fields in same document
    doc_ref = db.collection("sessions").document(session_id)
    doc_ref.set({
        "user_profile": user_data,
        "last_active": firestore.SERVER_TIMESTAMP
    }, merge=True)  # merge=True preserves messages field

# Retrieve
def get_session_data(session_id: str):
    doc = db.collection("sessions").document(session_id).get()
    if doc.exists:
        data = doc.to_dict()
        return {
            "messages": data.get("messages", []),
            "user_profile": data.get("user_profile", {})
        }
```

**CRITICAL:** Use `merge=True` to avoid overwriting the `messages` field!

---

## 4. Tools & Agents

### Tool Definition
```python
from langchain.tools import tool

@tool
def search_database(query: str) -> str:
    """Search the product database for items matching the query."""
    # Your search logic
    return f"Found 5 products for: {query}"

# With multiple parameters
@tool
def calculate_shipping(weight: float, country: str) -> float:
    """Calculate shipping cost based on weight (kg) and destination country."""
    rates = {"US": 10, "UK": 15, "IN": 8}
    return weight * rates.get(country, 20)
```

**DOCSTRING IS CRITICAL:** LLM reads docstring to decide when to use tool!

### bind_tools vs Agents

#### bind_tools (Manual Control)
```python
tools = [search_database, calculate_shipping]
llm_with_tools = llm.bind_tools(tools)

response = llm_with_tools.invoke("Find laptops under $1000")
# Response has tool_calls attribute
if response.tool_calls:
    for tool_call in response.tool_calls:
        tool_name = tool_call["name"]
        tool_args = tool_call["args"]
        # YOU manually execute
        if tool_name == "search_database":
            result = search_database.invoke(tool_args)
```

**USE WHEN:** You want control over tool execution, approval workflows, cost limits.

#### AgentExecutor (Automatic)
```python
from langchain.agents import create_tool_calling_agent, AgentExecutor

# Prompt must have agent_scratchpad
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant with access to tools."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}")  # Agent's reasoning
])

agent = create_tool_calling_agent(llm, tools, prompt)
agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True,
    max_iterations=5
)

response = agent_executor.invoke({"input": "Find laptops and calculate shipping to India"})
# Automatically: calls search_database → gets results → calls calculate_shipping → returns final answer
```

**KEY DIFFERENCE:**
- `bind_tools`: LLM suggests tools, you execute
- `AgentExecutor`: LLM suggests tools AND automatically executes them

### Agent Modes
```python
# 1. ReAct (Default - Reasoning + Acting)
agent = create_react_agent(llm, tools, prompt)
# Thinks step-by-step: "I need to search first, then calculate..."

# 2. OpenAI Functions (Tool Calling)
agent = create_tool_calling_agent(llm, tools, prompt)
# Uses native function calling API

# 3. Structured Chat
agent = create_structured_chat_agent(llm, tools, prompt)
# For multi-input tools with complex parameters
```

### Tool Chaining (Automatic)
```python
@tool
def get_stock_price(ticker: str) -> float:
    """Get current stock price for a ticker symbol."""
    return 150.25

@tool
def calculate_portfolio_value(ticker: str, shares: int) -> float:
    """Calculate total value of stock holdings."""
    price = get_stock_price.invoke({"ticker": ticker})  # Agent chains automatically!
    return price * shares

tools = [get_stock_price, calculate_portfolio_value]
agent = create_tool_calling_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools)

# User: "What's my AAPL portfolio worth if I have 100 shares?"
# Agent automatically: calls get_stock_price("AAPL") → calls calculate_portfolio_value("AAPL", 100)
```

---

## 5. FAISS Vector Search

### Why FAISS?
- **Speed:** Billion-scale search in milliseconds
- **Flexibility:** Multiple index types for different scenarios
- **Production Ready:** Used by Meta, Google, Microsoft

### HNSW (Medium Data - Up to 1M vectors)
```python
import faiss
import numpy as np

dimension = 1536  # OpenAI embeddings

# Create HNSW index
M = 32  # Number of connections (higher = better accuracy, slower build)
index = faiss.IndexHNSWFlat(dimension, M)
index.hnsw.efConstruction = 40  # Build-time accuracy (40-200 typical)
index.hnsw.efSearch = 16  # Search-time accuracy (16-512 typical)

# Add vectors (NO TRAINING NEEDED)
vectors = np.random.random((10000, dimension)).astype('float32')
index.add(vectors)

# Search
query = np.random.random((1, dimension)).astype('float32')
distances, indices = index.search(query, k=5)
```

**PARAMETERS:**
- **M:** 16 (fast) → 32 (balanced) → 64 (accurate)
- **efConstruction:** 40 (fast) → 200 (accurate)
- **efSearch:** 16 (fast) → 128 (accurate)

**TRADE-OFF:** Higher values = better accuracy but slower.

### IVF (Large Data - 1M+ vectors)
```python
nlist = 100  # Number of clusters (sqrt(N) to 4*sqrt(N))
quantizer = faiss.IndexFlatL2(dimension)
index = faiss.IndexIVFFlat(quantizer, dimension, nlist)

# MUST TRAIN FIRST
training_data = vectors[:10000]  # Use subset for training
index.train(training_data)

# Now add all vectors
index.add(vectors)

# Search
index.nprobe = 10  # Check top 10 clusters (higher = slower but better)
distances, indices = index.search(query, k=5)
```

**PARAMETERS:**
- **nlist:** 100 (1M vectors) → 1000 (10M vectors) → 4000 (100M vectors)
- **nprobe:** 1 (fastest) → 10 (balanced) → 100 (accurate)

**RULE OF THUMB:**
- nlist ≈ sqrt(number_of_vectors)
- nprobe ≈ nlist / 10

### LangChain FAISS Integration
```python
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings

# Create from documents
embeddings = OpenAIEmbeddings()
vectorstore = FAISS.from_documents(docs, embeddings)

# Save
vectorstore.save_local("faiss_index")

# Load
vectorstore = FAISS.load_local("faiss_index", embeddings, allow_dangerous_deserialization=True)

# Use as retriever
retriever = vectorstore.as_retriever(
    search_type="similarity",
    search_kwargs={"k": 3}
)

# Advanced: MMR (Maximum Marginal Relevance)
retriever = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={
        "k": 5,
        "fetch_k": 20,  # Fetch 20 candidates
        "lambda_mult": 0.5  # Diversity vs relevance (0=diverse, 1=relevant)
    }
)
```

### RAG Chain with FAISS
```python
def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

prompt = ChatPromptTemplate.from_template("""
Use the following context to answer the question.

Context: {context}

Question: {question}

Answer:""")

rag_chain = (
    {
        "context": retriever | format_docs,
        "question": RunnablePassthrough()
    }
    | prompt
    | llm
    | StrOutputParser()
)

response = rag_chain.invoke("What is FAISS?")
```

---

## 6. Production Patterns

### Error Handling with Tenacity
```python
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from openai import RateLimitError, APIError

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10),
    retry=retry_if_exception_type((RateLimitError, APIError))
)
def call_llm_with_retry(prompt: str):
    return llm.invoke(prompt)
```

### Rate Limiting
```python
import asyncio
from collections import deque

class RateLimiter:
    def __init__(self, max_requests: int, time_window: int):
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests = deque()
    
    async def acquire(self):
        now = asyncio.get_event_loop().time()
        
        # Remove old requests
        while self.requests and self.requests[0] < now - self.time_window:
            self.requests.popleft()
        
        # Wait if at limit
        if len(self.requests) >= self.max_requests:
            sleep_time = self.requests[0] + self.time_window - now
            await asyncio.sleep(sleep_time)
        
        self.requests.append(now)

# Usage
limiter = RateLimiter(max_requests=10, time_window=60)  # 10 req/min

async def rate_limited_call(prompt: str):
    await limiter.acquire()
    return await llm.ainvoke(prompt)
```

### Caching with Redis


from google.cloud import firestore, storage
import redis
import hashlib
import json

# Initialize
redis_client = redis.Redis(host='localhost', port=6379, decode_responses=True)
db = firestore.Client()
bucket = storage.Client().bucket("cache-bucket")

def get_cache_key(prompt: str) -> str:
    return hashlib.md5(prompt.encode()).hexdigest()


# ========== REDIS CACHE (FASTEST) ==========
async def redis_cache(prompt: str):
    key = get_cache_key(prompt)
    
    # Check cache
    cached = redis_client.get(key)
    if cached:
        return json.loads(cached)  # Cache HIT
    
    # Call LLM
    response = await llm.ainvoke(prompt)
    
    # Save cache with TTL (expires in 1 hour)
    redis_client.setex(key, 3600, json.dumps(response.content))
    return response.content


# ========== FIRESTORE CACHE ==========
async def firestore_cache(prompt: str):
    key = get_cache_key(prompt)
    doc_ref = db.collection("cache").document(key)
    
    # Check cache
    doc = doc_ref.get()
    if doc.exists:
        return doc.to_dict()["response"]  # Cache HIT
    
    # Call LLM
    response = await llm.ainvoke(prompt)
    
    # Save cache
    doc_ref.set({"response": response.content})
    return response.content


# ========== GCS CACHE ==========
async def gcs_cache(prompt: str):
    key = get_cache_key(prompt)
    blob = bucket.blob(f"cache/{key}.json")
    
    # Check cache
    if blob.exists():
        data = json.loads(blob.download_as_text())
        return data["response"]  # Cache HIT
    
    # Call LLM
    response = await llm.ainvoke(prompt)
    
    # Save cache
    blob.upload_from_string(json.dumps({"response": response.content}))
    return response.content
```python
import redis
import json
import hashlib

redis_client = redis.Redis(host='localhost', port=6379, db=0)

def get_cache_key(prompt: str) -> str:
    return hashlib.md5(prompt.encode()).hexdigest()

def cached_llm_call(prompt: str, ttl: int = 3600):
    cache_key = get_cache_key(prompt)
    
    # Check cache
    cached = redis_client.get(cache_key)
    if cached:
        return json.loads(cached)
    
    # Call LLM
    response = llm.invoke(prompt)
    
    # Save to cache
    redis_client.setex(cache_key, ttl, json.dumps(response))
    
    return response
```

### Monitoring with LangSmith
```python
import os
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "your_api_key"
os.environ["LANGCHAIN_PROJECT"] = "production-chat"

# Automatic tracing of all chains
chain = prompt | llm | parser
result = chain.invoke({"input": "test"})
# Logged to LangSmith with latency, tokens, cost
```

### FastAPI Endpoint
```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

class ChatRequest(BaseModel):
    message: str
    session_id: str

class ChatResponse(BaseModel):
    response: str
    tokens_used: int

@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    try:
        response = await chain_with_memory.ainvoke(
            {"input": request.message},
            config={"configurable": {"session_id": request.session_id}}
        )
        return ChatResponse(
            response=response,
            tokens_used=llm.get_num_tokens(request.message)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```


from slowapi import Limiter
from fastapi import FastAPI

# 1. Define key function (how to identify users)
def get_identifier(request):
    return request.headers.get("X-API-Key", "anonymous")

# 2. Create limiter
limiter = Limiter(key_func=get_identifier)

# 3. Attach to FastAPI app
app = FastAPI()
app.state.limiter = limiter

# 4. Apply decorator to endpoint
@app.post("/chat")
@limiter.limit("10/minute")  # ← This is the rate limit!
async def chat(message: str):
    return {"response": "..."}
---

## 7. Callbacks & Streaming

### Observer Pattern Explanation
**Q: How does LangChain know which callback method to call?**

A: LangChain uses the **Observer Pattern**:
1. LangChain has predefined event types: `llm_start`, `llm_new_token`, `llm_end`, `chain_start`, etc.
2. When event occurs, LangChain looks for methods named `on_{event_type}`
3. Your callback class inherits `BaseCallbackHandler` which defines these method signatures

```python
# Inside LangChain (simplified)
class CallbackManager:
    def trigger_event(self, event_type: str, *args):
        method_name = f"on_{event_type}"
        for callback in self.callbacks:
            if hasattr(callback, method_name):
                getattr(callback, method_name)(*args)
```

### Standard Callback Methods
```python
from langchain.callbacks.base import BaseCallbackHandler

class CustomCallback(BaseCallbackHandler):
    def on_llm_start(self, serialized, prompts, **kwargs):
        """Called when LLM starts"""
        print(f"Starting LLM with {len(prompts)} prompts")
    
    def on_llm_new_token(self, token: str, **kwargs):
        """Called for each new token (streaming)"""
        print(token, end="", flush=True)
    
    def on_llm_end(self, response, **kwargs):
        """Called when LLM finishes"""
        print(f"\nLLM finished. Tokens: {response.llm_output['token_usage']}")
    
    def on_llm_error(self, error, **kwargs):
        """Called on LLM error"""
        print(f"LLM Error: {error}")
    
    def on_chain_start(self, serialized, inputs, **kwargs):
        """Called when chain starts"""
        print(f"Chain starting with: {inputs}")
    
    def on_chain_end(self, outputs, **kwargs):
        """Called when chain ends"""
        print(f"Chain finished: {outputs}")
```

### Streaming with Azure/Vertex
```python
from langchain_openai import AzureChatOpenAI
from langchain_google_vertexai import ChatVertexAI

# Azure
llm = AzureChatOpenAI(
    deployment_name="gpt-4",
    streaming=True,
    callbacks=[CustomCallback()]
)

# Vertex AI
llm = ChatVertexAI(
    model="gemini-pro",
    streaming=True,
    callbacks=[CustomCallback()]
)

# Stream
for chunk in llm.stream("Tell me a story"):
    print(chunk.content, end="", flush=True)
```

### Async Streaming


from fastapi import FastAPI
from fastapi.responses import StreamingResponse

@app.post("/chat")
async def chat_complete(message: str):
    # For simple responses - use ainvoke()
    response = await llm.ainvoke(message)
    return {"response": response.content}

@app.post("/chat-stream")
async def chat_streaming(message: str):
    # For ChatGPT-like streaming - use astream()
    async def generate():
        async for chunk in llm.astream(message):
            yield f"{chunk.content}"
    
    return StreamingResponse(generate(), media_type="text/plain")
```python
async def stream_response(query: str):
    async for chunk in llm.astream(query):
        print(chunk.content, end="", flush=True)
        # In FastAPI: yield chunk.content

# With chain
async def stream_rag(question: str):
    async for chunk in rag_chain.astream(question):
        yield chunk
```

### Async Patterns
```python
import asyncio

# gather: Wait for all (parallel)
results = await asyncio.gather(
    llm.ainvoke("Query 1"),
    llm.ainvoke("Query 2"),
    llm.ainvoke("Query 3")
)
# Returns: [response1, response2, response3] (in order)

# as_completed: Process as they finish
tasks = [
    llm.ainvoke("Query 1"),
    llm.ainvoke("Query 2"),
    llm.ainvoke("Query 3")
]
for coro in asyncio.as_completed(tasks):
    result = await coro
    print(f"Got result: {result}")  # Order not guaranteed
```

**USE CASES:**
- `gather`: When you need all results together (e.g., multi-angle analysis)
- `as_completed`: When you want to show results ASAP (e.g., dashboard updates)

---

## 8. Multimodal (Images)

### Image Input Formats

#### URL (Best for Production)
```python
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4-vision-preview", max_tokens=300)

response = llm.invoke([
    {
        "type": "text",
        "text": "What's in this image?"
    },
    {
        "type": "image_url",
        "image_url": {"url": "https://example.com/product.jpg"}
    }
])
```

#### Base64 Encoding
```python
import base64

def encode_image(image_path: str) -> str:
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")

base64_image = encode_image("product.jpg")

response = llm.invoke([
    {
        "type": "text",
        "text": "Describe this product"
    },
    {
        "type": "image_url",
        "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}
    }
])
```

### Gemini Vision
```python
from langchain_google_vertexai import ChatVertexAI
from google.cloud import storage

llm = ChatVertexAI(model="gemini-pro-vision")

# From GCS
response = llm.invoke([
    {
        "type": "text",
        "text": "What objects are in this image?"
    },
    {
        "type": "image_url",
        "image_url": {"url": "gs://my-bucket/image.jpg"}
    }
])
```

### FastAPI Upload Endpoint
```python
from fastapi import FastAPI, File, UploadFile
import base64

app = FastAPI()

@app.post("/analyze-image")
async def analyze_image(file: UploadFile = File(...), prompt: str = "Describe this image"):
    # Read image
    contents = await file.read()
    base64_image = base64.b64encode(contents).decode("utf-8")
    
    # Analyze
    response = llm.invoke([
        {"type": "text", "text": prompt},
        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}}
    ])
    
    return {"analysis": response.content}
```

### Batch Image Analysis
```python
async def analyze_images_batch(image_urls: List[str]):
    tasks = []
    for url in image_urls:
        messages = [
            {"type": "text", "text": "Describe this product"},
            {"type": "image_url", "image_url": {"url": url}}
        ]
        tasks.append(llm.ainvoke(messages))
    
    results = await asyncio.gather(*tasks)
    return results
```

### Image Size Optimization
```python
from PIL import Image
import io

def optimize_image(image_path: str, max_size: int = 1024) -> bytes:
    img = Image.open(image_path)
    
    # Resize if too large
    if max(img.size) > max_size:
        ratio = max_size / max(img.size)
        new_size = tuple(int(dim * ratio) for dim in img.size)
        img = img.resize(new_size, Image.Resampling.LANCZOS)
    
    # Convert to bytes
    buffer = io.BytesIO()
    img.save(buffer, format="JPEG", quality=85)
    return buffer.getvalue()
```

---

## 9. Interview Q&A

### Q1: When to use bind_tools vs AgentExecutor?
**A:** 
- **bind_tools**: When you need manual approval, cost control, or want to log before execution
- **AgentExecutor**: When tools are safe to auto-execute and you trust the LLM's judgment
- **Example**: bind_tools for payment APIs, AgentExecutor for read-only database queries

### Q2: Why use Firestore instead of in-memory for chat history?
**A:**
- **Persistence**: Survives server restarts
- **Multi-user**: Each user has their own session_id
- **Scalability**: Works across multiple server instances
- **Analytics**: Can query historical conversations
- **Example**: Production chatbots with 1000+ concurrent users

### Q3: HNSW vs IVF - which to choose?
**A:**
- **HNSW**: < 1M vectors, need high accuracy, have enough RAM
- **IVF**: > 1M vectors, can trade accuracy for speed, limited RAM
- **Example**: 100K product catalog → HNSW; 10M Wikipedia embeddings → IVF

### Q4: Why use partial() in prompts?
**A:**
- Pre-fill constants (API keys, company name, timestamp)
- Avoids passing same values repeatedly
- Cleaner code: `prompt.format(query="...")` vs `prompt.format(query="...", company="...", timestamp="...")`

### Q5: ConversationBufferMemory vs ConversationSummaryMemory?
**A:**
- **Buffer**: Short sessions (< 10 exchanges), need exact context
- **Summary**: Long sessions (50+ exchanges), okay with paraphrasing
- **Trade-off**: Buffer = token cost on context, Summary = LLM cost on summarization

### Q6: When to use Sequential vs Parallel chains?
**A:**
- **Sequential**: When next step depends on previous (code generation → explanation)
- **Parallel**: When steps are independent (sentiment + summary + keywords)
- **Performance**: Parallel is 3x faster for 3 independent tasks

### Q7: How does retriever know what to search?
**A:** When you write `{"context": retriever}` in a chain, LangChain:
1. Receives input (e.g., "What is FAISS?")
2. Automatically calls `retriever.invoke("What is FAISS?")`
3. Passes retrieved docs to next step
4. Magic: Dict values are treated as Runnables and invoked with chain input

### Q8: Why use with_structured_output over PydanticOutputParser?
**A:**
- **with_structured_output**: Uses native function calling, faster, no prompt pollution
- **PydanticOutputParser**: Adds instructions to prompt, uses more tokens, works with any LLM
- **Rule**: Use with_structured_output if model supports it (GPT-4, Gemini); fallback to parser for others

### Q9: What's agent_scratchpad in agent prompts?
**A:** 
- Space where agent writes its reasoning
- Contains: tool calls → tool outputs → next thought
- Enables multi-step reasoning: "I'll search first, then analyze results, then answer"
- **Must include** in create_tool_calling_agent prompts!

### Q10: How to prevent memory overwriting in Firestore?
**A:** Use `merge=True` when saving custom fields:
```python
doc_ref.set({"user_profile": {...}}, merge=True)
```
Without `merge=True`, the entire document is replaced, deleting the `messages` field!

---

## 10. Quick Shortcuts

### Syntax Shortcuts
```python
# 1. Pipe operator instead of verbose syntax
# Old:
chain = LLMChain(llm=llm, prompt=prompt, output_parser=parser)
# New:
chain = prompt | llm | parser

# 2. RunnablePassthrough to pass input through
{"question": RunnablePassthrough()}  # Just passes input as-is

# 3. Lambda for single-step wrapping
{"code": lambda x: code_chain.invoke(x)}

# 4. StrOutputParser for simple text
from langchain.schema.output_parser import StrOutputParser
parser = StrOutputParser()  # Just extracts .content from message

# 5. Format docs in one line
format_docs = lambda docs: "\n\n".join(d.page_content for d in docs)

# 6. Session config shorthand
config = {"configurable": {"session_id": "user_123"}}
```

### Common Patterns

#### Pattern 1: RAG in 5 Lines
```python
rag = (
    {"context": retriever | format_docs, "question": RunnablePassthrough()}
    | ChatPromptTemplate.from_template("Context: {context}\n\nQuestion: {question}")
    | llm | StrOutputParser()
)
```

#### Pattern 2: Memory in 3 Lines
```python
chain_with_memory = RunnableWithMessageHistory(
    chain,
    lambda session_id: FirestoreChatMessageHistory("sessions", session_id, "project-id"),
    input_messages_key="input", history_messages_key="chat_history"
)
```

#### Pattern 3: Agent in 4 Lines
```python
agent = create_tool_calling_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools, verbose=True)
response = executor.invoke({"input": "Find products and calculate shipping"})
```

#### Pattern 4: Structured Output in 2 Lines
```python
structured_llm = llm.with_structured_output(MyModel)
result = structured_llm.invoke("Extract data from this text...")
```

### Debugging Tricks
```python
# 1. Print intermediate steps in chains
chain = (
    {"input": RunnablePassthrough()}
    | RunnableLambda(lambda x: print(f"Step 1: {x}") or x)
    | prompt
    | RunnableLambda(lambda x: print(f"Step 2: {x}") or x)
    | llm
)

# 2. Check what retriever returns
docs = retriever.invoke("test query")
print(f"Found {len(docs)} docs")
print(docs[0].page_content)

# 3. Inspect tool calls
response = llm_with_tools.invoke("test")
print(response.tool_calls)  # List of dicts with name, args

# 4. View agent reasoning
executor = AgentExecutor(agent=agent, tools=tools, verbose=True)
# Prints: Thought → Action → Observation → Final Answer

# 5. Count tokens before calling
tokens = llm.get_num_tokens(prompt)
print(f"Will use ~{tokens} tokens")
```

### Performance Optimization
```python
# 1. Batch requests
results = await asyncio.gather(*[llm.ainvoke(q) for q in queries])

# 2. Cache with TTL
@lru_cache(maxsize=1000)
def cached_embed(text: str):
    return embeddings.embed_query(text)

# 3. Limit retriever results
retriever = vectorstore.as_retriever(search_kwargs={"k": 3})  # Not 10

# 4. Use cheaper model for simple tasks
cheap_llm = ChatOpenAI(model="gpt-3.5-turbo")
expensive_llm = ChatOpenAI(model="gpt-4")

# 5. Stream for perceived speed
for chunk in llm.stream(prompt):
    print(chunk.content, end="", flush=True)
```

### Common Mistakes to Avoid
```python
# ❌ Wrong: Using old LLMChain
from langchain.chains import LLMChain
chain = LLMChain(llm=llm, prompt=prompt)

# ✅ Right: Use LCEL
chain = prompt | llm | StrOutputParser()

# ❌ Wrong: Forgetting agent_scratchpad
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are helpful"),
    ("human", "{input}")
])

# ✅ Right: Include placeholder
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are helpful"),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}")
])

# ❌ Wrong: return_messages=False (returns strings)
memory = ConversationBufferMemory(return_messages=False)

# ✅ Right: return_messages=True (returns Message objects)
memory = ConversationBufferMemory(return_messages=True)

# ❌ Wrong: Not using merge=True
doc_ref.set({"custom_field": "value"})  # Deletes messages!

# ✅ Right: merge=True
doc_ref.set({"custom_field": "value"}, merge=True)

# ❌ Wrong: Sequential when could be parallel
result1 = chain1.invoke(input)
result2 = chain2.invoke(input)

# ✅ Right: Use RunnableParallel
results = RunnableParallel(r1=chain1, r2=chain2).invoke(input)
```

---

## 🎯 Final Tips for Interview

### When Asked "How Would You Build X?"
1. **Clarify requirements**: "How many users? Response time? Budget?"
2. **Choose components**: "I'd use FAISS for < 1M docs, Firestore for sessions..."
3. **Show trade-offs**: "HNSW is more accurate but uses more RAM..."
4. **Mention monitoring**: "I'd track latency with LangSmith..."

### When Asked to Debug
1. **Check verbose mode**: `AgentExecutor(verbose=True)` or print statements
2. **Verify inputs**: Print what goes into each chain step
3. **Test components**: Test retriever, LLM, parser separately
4. **Check errors**: Look at exception messages for rate limits, auth issues

### When Asked About Scale
1. **Async**: Use `ainvoke()`, `astream()`, `asyncio.gather()`
2. **Caching**: Redis for responses, vectorstore for embeddings
3. **Rate limiting**: Tenacity retry + custom rate limiter
4. **Monitoring**: LangSmith traces + custom metrics

### Code to Memorize
- **RAG**: `{"context": retriever | format_docs, "question": RunnablePassthrough()} | prompt | llm`
- **Memory**: `RunnableWithMessageHistory(chain, get_memory_fn, input_messages_key, history_messages_key)`
- **Agent**: `create_tool_calling_agent(llm, tools, prompt)` → `AgentExecutor(agent, tools)`
- **FAISS HNSW**: `faiss.IndexHNSWFlat(dim, M)` with `efConstruction` and `efSearch`
- **Structured Output**: `llm.with_structured_output(MyModel)`

---

**Good Luck with TCS Interview! 🚀**

*Remember: Focus on WHY you choose something, not just WHAT. They want to see you can make production decisions with trade-offs in mind.*
