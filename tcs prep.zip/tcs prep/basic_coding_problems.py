"""
BASIC CODING PROBLEMS - COMPLETE SOLUTIONS
Tiger Analytics / Interview Prep
All problems with multiple approaches where applicable
"""

# ============ PROBLEM 1: FIBONACCI ============


def fib_recursive(n):
    """Fibonacci using recursion - O(2^n) time, O(n) space"""
    if n <= 1:
        return n
    return fib_recursive(n - 1) + fib_recursive(n - 2)


def fib_iterative(n):
    """Fibonacci using iteration - O(n) time, O(1) space - BEST!"""
    if n <= 1:
        return n

    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b


def fib_memoization(n, memo={}):
    """Fibonacci with memoization - O(n) time, O(n) space"""
    if n in memo:
        return memo[n]
    if n <= 1:
        return n

    memo[n] = fib_memoization(n - 1, memo) + fib_memoization(n - 2, memo)
    return memo[n]


# Test
print("=== FIBONACCI ===")
print(f"fib(5) recursive: {fib_recursive(5)}")  # 5
print(f"fib(5) iterative: {fib_iterative(5)}")  # 5
print(f"fib(10) memoization: {fib_memoization(10)}")  # 55
print()


# ============ PROBLEM 2: FACTORIAL ============


def factorial_recursive(n):
    """Factorial using recursion - O(n) time, O(n) space"""
    if n <= 1:
        return 1
    return n * factorial_recursive(n - 1)


def factorial_iterative(n):
    """Factorial using iteration - O(n) time, O(1) space - BEST!"""
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result


# Test
print("=== FACTORIAL ===")
print(f"5! recursive: {factorial_recursive(5)}")  # 120
print(f"5! iterative: {factorial_iterative(5)}")  # 120
print()


# ============ PROBLEM 3: PALINDROME CHECK ============


def is_palindrome_slicing(s):
    """Palindrome using slicing - O(n) time, O(n) space"""
    s = s.lower().replace(" ", "")
    return s == s[::-1]


def is_palindrome_two_pointers(s):
    """Palindrome using two pointers - O(n) time, O(1) space - BEST!"""
    s = s.lower().replace(" ", "")
    left, right = 0, len(s) - 1

    while left < right:
        if s[left] != s[right]:
            return False
        left += 1
        right -= 1

    return True


def is_palindrome_alphanum_only(s):
    """Palindrome checking only alphanumeric - LeetCode style"""
    left, right = 0, len(s) - 1

    while left < right:
        # Skip non-alphanumeric
        while left < right and not s[left].isalnum():
            left += 1
        while left < right and not s[right].isalnum():
            right -= 1

        if s[left].lower() != s[right].lower():
            return False

        left += 1
        right -= 1

    return True


# Test
print("=== PALINDROME ===")
print(f"'racecar' is palindrome: {is_palindrome_slicing('racecar')}")  # True
print(f"'hello' is palindrome: {is_palindrome_two_pointers('hello')}")  # False
print(
    f"'A man, a plan, a canal: Panama' (alphanum): {is_palindrome_alphanum_only('A man, a plan, a canal: Panama')}"
)  # True
print()


# ============ PROBLEM 4: VALID ANAGRAM ============


def is_anagram_sorting(s1, s2):
    """Anagram using sorting - O(n log n) time, O(n) space"""
    return sorted(s1.lower()) == sorted(s2.lower())


def is_anagram_hashmap(s1, s2):
    """Anagram using hashmap - O(n) time, O(n) space - BEST!"""
    if len(s1) != len(s2):
        return False

    s1, s2 = s1.lower(), s2.lower()
    freq = {}

    for char in s1:
        freq[char] = freq.get(char, 0) + 1

    for char in s2:
        if char not in freq:
            return False
        freq[char] -= 1
        if freq[char] < 0:
            return False

    return True


def is_anagram_counter(s1, s2):
    """Anagram using Counter - O(n) time, O(n) space - PYTHONIC!"""
    from collections import Counter

    return Counter(s1.lower()) == Counter(s2.lower())


# Test
print("=== ANAGRAM ===")
print(
    f"'listen' and 'silent' are anagrams: {is_anagram_sorting('listen', 'silent')}"
)  # True
print(
    f"'hello' and 'world' are anagrams: {is_anagram_hashmap('hello', 'world')}"
)  # False
print(
    f"'Listen' and 'Silent' are anagrams: {is_anagram_counter('Listen', 'Silent')}"
)  # True
print()


# ============ PROBLEM 5: REVERSE STRING ============


def reverse_string_slicing(s):
    """Reverse using slicing - O(n) time, O(n) space"""
    return s[::-1]


def reverse_string_two_pointers(s):
    """Reverse using two pointers (in-place for list) - O(n) time, O(1) space"""
    s_list = list(s)
    left, right = 0, len(s_list) - 1

    while left < right:
        s_list[left], s_list[right] = s_list[right], s_list[left]
        left += 1
        right -= 1

    return "".join(s_list)


def reverse_string_stack(s):
    """Reverse using stack concept"""
    stack = []
    for char in s:
        stack.append(char)

    result = ""
    while stack:
        result += stack.pop()

    return result


# Test
print("=== REVERSE STRING ===")
print(f"Reverse 'hello': {reverse_string_slicing('hello')}")  # olleh
print(f"Reverse 'world': {reverse_string_two_pointers('world')}")  # dlrow
print()


# ============ PROBLEM 6: FIRST NON-REPEATING CHARACTER ============


def first_unique_char(s):
    """First unique char - O(n) time, O(n) space"""
    freq = {}

    # Count frequencies
    for char in s:
        freq[char] = freq.get(char, 0) + 1

    # Find first with count 1
    for i, char in enumerate(s):
        if freq[char] == 1:
            return i  # Return index

    return -1  # No unique character


def first_unique_char_counter(s):
    """Using Counter - more Pythonic"""
    from collections import Counter

    freq = Counter(s)

    for i, char in enumerate(s):
        if freq[char] == 1:
            return i

    return -1


# Test
print("=== FIRST UNIQUE CHARACTER ===")
print(f"First unique in 'leetcode': index {first_unique_char('leetcode')}")  # 0 ('l')
print(
    f"First unique in 'loveleetcode': index {first_unique_char('loveleetcode')}"
)  # 2 ('v')
print(f"First unique in 'aabb': {first_unique_char('aabb')}")  # -1
print()


# ============ PROBLEM 7: COUNT VOWELS AND CONSONANTS ============


def count_vowels_consonants(s):
    """Count vowels and consonants - O(n) time, O(1) space"""
    vowels = "aeiouAEIOU"
    vowel_count = 0
    consonant_count = 0

    for char in s:
        if char.isalpha():
            if char in vowels:
                vowel_count += 1
            else:
                consonant_count += 1

    return vowel_count, consonant_count


# Test
print("=== VOWELS AND CONSONANTS ===")
v, c = count_vowels_consonants("hello world")
print(f"'hello world' has {v} vowels and {c} consonants")  # 3 vowels, 7 consonants
print()


# ============ PROBLEM 8: CHECK IF STRING CONTAINS ONLY DIGITS ============


def is_all_digits_builtin(s):
    """Using built-in method"""
    return s.isdigit()


def is_all_digits_manual(s):
    """Manual check - O(n) time"""
    if not s:
        return False

    for char in s:
        if not char.isdigit():
            return False

    return True


def is_all_digits_try_except(s):
    """Using try-except"""
    try:
        int(s)
        return True
    except ValueError:
        return False


# Test
print("=== CHECK ONLY DIGITS ===")
print(f"'12345' is all digits: {is_all_digits_builtin('12345')}")  # True
print(f"'123abc' is all digits: {is_all_digits_manual('123abc')}")  # False
print()


# ============ PROBLEM 9: REMOVE DUPLICATES FROM STRING ============


def remove_duplicates_set(s):
    """Remove duplicates maintaining order - O(n) time, O(n) space"""
    seen = set()
    result = []

    for char in s:
        if char not in seen:
            seen.add(char)
            result.append(char)

    return "".join(result)


def remove_duplicates_dict(s):
    """Using dict to maintain insertion order (Python 3.7+)"""
    return "".join(dict.fromkeys(s))


# Test
print("=== REMOVE DUPLICATES ===")
print(
    f"'programming' without duplicates: {remove_duplicates_set('programming')}"
)  # progamin
print(f"'hello' without duplicates: {remove_duplicates_dict('hello')}")  # helo
print()


# ============ PROBLEM 10: POWER (x^n) ============


def power_iterative(x, n):
    """Power using iteration - O(n) time"""
    if n < 0:
        x = 1 / x
        n = -n

    result = 1
    for _ in range(n):
        result *= x

    return result


def power_fast(x, n):
    """Fast power using binary exponentiation - O(log n) time - BEST!"""
    if n < 0:
        x = 1 / x
        n = -n

    result = 1
    current = x

    while n > 0:
        if n % 2 == 1:  # Odd power
            result *= current
        current *= current  # Square the base
        n //= 2

    return result


def power_recursive(x, n):
    """Recursive power - O(log n) time"""
    if n == 0:
        return 1
    if n < 0:
        return power_recursive(1 / x, -n)

    if n % 2 == 0:  # Even
        half = power_recursive(x, n // 2)
        return half * half
    else:  # Odd
        return x * power_recursive(x, n - 1)


# Test
print("=== POWER ===")
print(f"2^10 iterative: {power_iterative(2, 10)}")  # 1024
print(f"2^10 fast: {power_fast(2, 10)}")  # 1024
print(f"2^-2 recursive: {power_recursive(2, -2)}")  # 0.25
print()


# ============ PROBLEM 11: PRIME NUMBER CHECK ============


def is_prime(n):
    """Check if number is prime - O(√n) time"""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False

    # Check odd divisors up to √n
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2

    return True


def is_prime_pythonic(n):
    """More Pythonic version"""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False

    return all(n % i != 0 for i in range(3, int(n**0.5) + 1, 2))


# Test
print("=== PRIME CHECK ===")
print(f"17 is prime: {is_prime(17)}")  # True
print(f"18 is prime: {is_prime(18)}")  # False
print(f"29 is prime: {is_prime_pythonic(29)}")  # True
print()


# ============ PROBLEM 12: SUM OF DIGITS ============


def sum_of_digits_iterative(n):
    """Sum of digits using iteration - O(log n) time"""
    n = abs(n)  # Handle negative numbers
    total = 0

    while n > 0:
        total += n % 10
        n //= 10

    return total


def sum_of_digits_recursive(n):
    """Sum of digits using recursion"""
    n = abs(n)
    if n == 0:
        return 0
    return (n % 10) + sum_of_digits_recursive(n // 10)


def sum_of_digits_string(n):
    """Using string conversion - Pythonic"""
    return sum(int(digit) for digit in str(abs(n)))


# Test
print("=== SUM OF DIGITS ===")
print(f"Sum of digits of 12345: {sum_of_digits_iterative(12345)}")  # 15
print(f"Sum of digits of 999: {sum_of_digits_recursive(999)}")  # 27
print(f"Sum of digits of -123: {sum_of_digits_string(-123)}")  # 6
print()


# ============ BONUS: STRING COMPRESSION ============


def compress_string(s):
    """
    String compression: 'aaabbcdd' -> 'a3b2c1d2'
    O(n) time, O(n) space - BEST POSSIBLE for this problem
    Cannot do O(1) space in Python because strings are immutable
    """
    if not s:
        return ""

    result = []  # List is more efficient than string concatenation
    count = 1

    for i in range(1, len(s)):
        if s[i] == s[i - 1]:
            count += 1
        else:
            result.append(s[i - 1])
            result.append(str(count))
            count = 1

    # Add last group
    result.append(s[-1])
    result.append(str(count))

    return "".join(result)  # Single join is O(n), efficient


# Test
print("=== STRING COMPRESSION ===")
print(f"'aaabbcdd' compressed: {compress_string('aaabbcdd')}")  # a3b2c1d2
print(f"'aabcccccaaa' compressed: {compress_string('aabcccccaaa')}")  # a2b1c5a3
print()


# ============ SUMMARY ============
print("=" * 50)
print("ALL BASIC PROBLEMS COMPLETED!")
print("=" * 50)
print(
    """
Key Takeaways:
1. Fibonacci - Iterative is best (O(n) time, O(1) space)
2. Palindrome - Two pointers for O(1) space
3. Anagram - HashMap/Counter for O(n) time
4. Power - Fast power for O(log n) time
5. Prime - Check up to √n only
6. String problems - Usually O(n) space minimum in Python (immutable strings)

Time Complexities to Remember:
- Iteration: Usually O(n)
- Recursion without memo: Usually O(2^n) or worse
- Recursion with memo: Usually O(n)
- Two pointers: Usually O(n)
- HashMap operations: O(1) average
- Sorting: O(n log n)
"""
)
