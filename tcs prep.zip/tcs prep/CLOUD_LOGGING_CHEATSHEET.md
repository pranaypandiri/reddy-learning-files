# Cloud Logging Cheatsheet for GenAI Engineers 🚀

> Quick reference for TCS interview prep - memorize the patterns!

---

## 📌 The Flow (Big Picture)

```
┌─────────────────────────────────────────────────────────────────┐
│                        YOUR APP                                 │
│                                                                 │
│  1. Request comes in                                            │
│           ↓                                                     │
│  2. Middleware: start_trace() → generates trace_id              │
│           ↓                                                     │
│  3. Your code runs (retrieval, LLM call, etc.)                 │
│           ↓                                                     │
│  4. Logger: log_llm_call() → structured JSON with trace_id     │
│           ↓                                                     │
│  5. Cloud Logging receives it automatically                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    GCP CLOUD LOGGING                            │
│                                                                 │
│  - Search/Query logs                                            │
│  - Create alerts                                                │
│  - Export to BigQuery → Grafana (infra team)                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔥 Core Setup (3 Lines!)

```python
import google.cloud.logging

client = google.cloud.logging.Client()
client.setup_logging()  # All Python logs → Cloud Logging!
```

**Credentials:**
- On GCP (Cloud Run, GKE): Auto-detected ✅
- Locally: Set `GOOGLE_APPLICATION_CREDENTIALS=/path/to/key.json`

---

## 📝 Structured JSON Logging

```python
import logging
import json

logger = logging.getLogger("genai-app")

# ALWAYS log as JSON for searchability
logger.info(json.dumps({
    "event": "llm_call",
    "trace_id": "abc123",
    "model": "gpt-4",
    "tokens_in": 100,
    "tokens_out": 200,
    "latency_ms": 1250,
    "cost_usd": 0.027
}))
```

---

## 🔗 Trace ID with ContextVar

```python
from contextvars import ContextVar
import uuid

# Thread-safe storage for trace_id
trace_id_var: ContextVar[str] = ContextVar('trace_id', default="no-trace")

def start_trace():
    new_id = str(uuid.uuid4())[:8]
    trace_id_var.set(new_id)
    return new_id

def get_trace_id():
    return trace_id_var.get()
```

**Why ContextVar?**
- Global variable = breaks with concurrent requests
- Passing trace_id everywhere = ugly
- ContextVar = each request gets its own "box" ✅

---

## 🎯 Complete Logger Class (Memorize This!)

```python
import google.cloud.logging
import logging
import json
import time
import uuid
import re
from contextvars import ContextVar

# Setup
client = google.cloud.logging.Client()
client.setup_logging()
logger = logging.getLogger("genai-app")

# Thread-safe trace ID
trace_id_var: ContextVar[str] = ContextVar('trace_id', default="no-trace")

# Pricing
PRICING = {
    "gpt-4": {"input": 0.03, "output": 0.06},
    "gpt-4o": {"input": 0.005, "output": 0.015},
    "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
}


def mask_pii(text: str) -> str:
    """Mask emails and phones"""
    if not text:
        return text
    text = re.sub(r'([a-zA-Z])[a-zA-Z0-9._%+-]*@([a-zA-Z0-9.-]+)', r'\1***@\2', text)
    text = re.sub(r'\b(\d{2})\d{6}(\d{2})\b', r'\1******\2', text)
    return text


def calculate_cost(model: str, tokens_in: int, tokens_out: int) -> float:
    if model not in PRICING:
        return 0.0
    p = PRICING[model]
    return round((tokens_in/1000) * p["input"] + (tokens_out/1000) * p["output"], 6)


class GenAILogger:
    def __init__(self, service_name: str = "genai-service"):
        self.service_name = service_name
    
    def start_trace(self) -> str:
        new_id = str(uuid.uuid4())[:8]
        trace_id_var.set(new_id)
        return new_id
    
    @property
    def trace_id(self) -> str:
        return trace_id_var.get()
    
    def _log(self, level: str, event: str, **data):
        payload = {
            "service": self.service_name,
            "trace_id": self.trace_id,
            "event": event,
            "timestamp_ms": int(time.time() * 1000),
            **data
        }
        getattr(logger, level)(json.dumps(payload))
    
    def log_llm_call(self, model: str, prompt: str, response: str,
                     tokens_in: int, tokens_out: int, latency_ms: float):
        self._log(
            level="info",
            event="llm_call",
            model=model,
            prompt=mask_pii(prompt[:500]),
            response=mask_pii(response[:500]),
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=round(latency_ms, 2),
            cost_usd=calculate_cost(model, tokens_in, tokens_out)
        )
    
    def log_error(self, step: str, error: str):
        self._log(level="error", event="error", step=step, error=str(error)[:1000])


# Global instance
genai_log = GenAILogger(service_name="my-app")
```

---

## ⚡ FastAPI Integration

```python
from fastapi import FastAPI, Request

app = FastAPI()

@app.middleware("http")
async def logging_middleware(request: Request, call_next):
    trace_id = genai_log.start_trace()  # Auto for all requests!
    response = await call_next(request)
    response.headers["X-Trace-ID"] = trace_id
    return response

@app.post("/chat")
def chat(message: str):
    # trace_id already set by middleware
    start = time.time()
    result = call_llm(message)
    genai_log.log_llm_call(...)
    return result
```

---

## 🔍 GCP Query Cheatsheet

| Find What | Query |
|-----------|-------|
| All LLM calls | `jsonPayload.event = "llm_call"` |
| Errors only | `jsonPayload.event = "error"` |
| Slow calls (>2s) | `jsonPayload.latency_ms > 2000` |
| Trace request | `jsonPayload.trace_id = "abc123"` |
| By model | `jsonPayload.model = "gpt-4"` |
| High cost | `jsonPayload.cost_usd > 0.1` |
| Text search | `jsonPayload.prompt : "keyword"` |
| Combine | `condition1 AND condition2` |

---

## 🔒 PII Masking Patterns

```python
import re

def mask_pii(text):
    # Email: john@gmail.com → j***@gmail.com
    text = re.sub(r'([a-zA-Z])[a-zA-Z0-9._%+-]*@([a-zA-Z0-9.-]+)', r'\1***@\2', text)
    
    # Phone: 9876543210 → 98******10
    text = re.sub(r'\b(\d{2})\d{6}(\d{2})\b', r'\1******\2', text)
    
    # Credit Card: 4111111111111111 → 4111********1111
    text = re.sub(r'\b(\d{4})\d{8}(\d{4})\b', r'\1********\2', text)
    
    return text
```

**Regex Quick Reference:**
- `()` = CAPTURE (save as \1, \2)
- No `()` = SKIP (match but don't save)
- `\d{2}` = exactly 2 digits
- `\b` = word boundary

---

## 💰 Cost Calculation

```python
PRICING = {
    "gpt-4": {"input": 0.03, "output": 0.06},      # per 1K tokens
    "gpt-4o": {"input": 0.005, "output": 0.015},
}

def calculate_cost(model, tokens_in, tokens_out):
    p = PRICING.get(model, {"input": 0, "output": 0})
    return (tokens_in/1000) * p["input"] + (tokens_out/1000) * p["output"]

# Example: GPT-4, 500 in, 200 out
# = (500/1000 × 0.03) + (200/1000 × 0.06)
# = 0.015 + 0.012 = $0.027
```

---

## 🚨 Alerts

```yaml
# Error Alert
Filter: jsonPayload.event = "error"
Action: Email immediately

# Cost Alert (via Log-based Metric)
Metric: Sum of jsonPayload.cost_usd
Alert: When > $100/hour
```

---

## 🎤 Interview Answers

### "How do you handle logging in production?"

> "I use GCP Cloud Logging with structured JSON logs. Each log has trace_id, event type, latency, token counts, and cost. The trace_id lets me follow a request through all steps. For LLM calls, I also mask PII before logging and calculate per-call costs for budget tracking."

### "What about observability for GenAI apps?"

> "For development, I use LangSmith for LLM-specific tracing. For production at scale, Cloud Logging with structured logs is simpler and more cost-effective. Infra team can pipe logs to BigQuery and Grafana for dashboards."

### "How do you handle multiple concurrent requests?"

> "I use Python's ContextVar to store trace_id per request. It's thread-safe - each request gets its own trace_id that all functions can access without passing it around."

---

## 📊 Quick Reference Table

| Concept | Code/Pattern |
|---------|--------------|
| Setup | `client.setup_logging()` |
| Structured log | `logger.info(json.dumps({...}))` |
| Trace ID | `uuid.uuid4()[:8]` |
| Store trace | `ContextVar` |
| Dynamic method | `getattr(logger, "info")("msg")` |
| Middleware | `@app.middleware("http")` |
| Mask PII | `re.sub(pattern, replacement, text)` |
| Capture group | `(\d{2})` → use as `\1` |
| Skip (no save) | `\d{2}` (no parentheses) |

---

## ✅ Checklist Before Interview

- [ ] Can explain 3-line setup
- [ ] Know why ContextVar (not global variable)
- [ ] Can write simple PII mask regex
- [ ] Know GCP query syntax
- [ ] Can explain trace_id flow
- [ ] Know when to use LangSmith vs Cloud Logging
- [ ] Understand cost calculation formula

---

## 🧠 One-Liners to Remember

1. **Setup:** "3 lines, auto-sends to Cloud Logging"
2. **Trace ID:** "UUID creates it, ContextVar stores it per request"
3. **Regex ():** "Capture = save for later, no () = skip"
4. **Middleware:** "Runs before/after every request automatically"
5. **LangSmith vs Cloud Logging:** "LangSmith for dev/LLM-specific, Cloud Logging for prod/general"
6. **Cost:** "tokens ÷ 1000 × price per 1K"

---

**You're ready! Good luck! 🚀**
