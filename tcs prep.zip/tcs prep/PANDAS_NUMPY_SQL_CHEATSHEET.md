# 🚀 Pandas, NumPy, SQL & SQLAlchemy Cheatsheet
*Complete Reference for 3.3 YoE Interview | TCS Prep*

---

## 📋 Table of Contents
1. [Pandas Essentials](#pandas-essentials)
2. [NumPy Essentials](#numpy-essentials)
3. [SQL - Joins & Group By](#sql-joins--group-by)
4. [SQL - Window Functions (RANK)](#sql-window-functions-rank)
5. [SQLAlchemy - Session & Text](#sqlalchemy-session--text)
6. [SQLAlchemy - Relationships](#sqlalchemy-relationships)
7. [Interview Q&A](#interview-qa)

---

## 🐼 Pandas Essentials

### Loading & Inspection
```python
import pandas as pd

# Read data
df = pd.read_csv('data.csv', parse_dates=['date_col'])
df = pd.read_sql("SELECT * FROM table", engine)

# Inspection
df.info()           # Types, null counts
df.describe()       # Statistics
df.head(10)         # First 10 rows
df.shape            # (rows, cols)
df.columns          # Column names
df.dtypes           # Data types
df.isna().sum()     # Missing values
```

### Selection & Filtering
```python
# Boolean indexing
df[df['age'] > 25]
df[(df['age'] > 25) & (df['city'] == 'NYC')]

# Query (faster, cleaner)
df.query("age > 25 and city == 'NYC'")

# loc vs iloc
df.loc[df['age'] > 25, ['name', 'email']]  # Label-based
df.iloc[0:5, [0, 2, 4]]                    # Position-based

# isin
df[df['status'].isin(['active', 'pending'])]
```

### GroupBy (CRITICAL!)
```python
# Simple aggregation
df.groupby('category')['sales'].sum()

# Multiple aggregations
df.groupby('category').agg({
    'sales': ['sum', 'mean', 'count'],
    'quantity': 'sum',
    'customer_id': 'nunique'
})

# Custom column names
df.groupby('category').agg(
    total_sales=('sales', 'sum'),
    avg_price=('price', 'mean'),
    unique_customers=('customer_id', pd.Series.nunique)
)

# Transform (keeps original shape!)
df['sales_pct'] = df['sales'] / df.groupby('category')['sales'].transform('sum')
```

**GroupBy Visual:**
```
BEFORE (6 rows):           groupby().sum()        transform('sum')
category | sales           category | total      category | sales | total
---------|------           ---------|------      ---------|-------|------
A        | 100             A        | 450        A        | 100   | 450
A        | 150             B        | 700        A        | 150   | 450
A        | 200             C        | 500        A        | 200   | 450
B        | 300             (3 rows)              B        | 300   | 700
B        | 400                                   B        | 400   | 700
C        | 500                                   C        | 500   | 500
                                                 (6 rows - SAME!)
```

### Merging & Joining
```python
# Merge (SQL-like joins)
pd.merge(df1, df2, on='id', how='left')
pd.merge(df1, df2, left_on='user_id', right_on='id', how='inner')

# Multiple keys
pd.merge(df1, df2, on=['date', 'region'], how='left')

# Join (on index)
df1.set_index('id').join(df2.set_index('id'), how='left')
```

**Join Visual:**
```
df1.set_index('user_id').join(df2.set_index('user_id'))

df1 (index=user_id)    +    df2 (index=user_id)    =    Result
user_id | name              user_id | city             user_id | name  | city
--------|------             --------|------            --------|-------|------
101     | Alice             101     | NYC              101     | Alice | NYC
102     | Bob               102     | LA               102     | Bob   | LA
```

### Index Operations
```python
# Set index (O(1) lookups!)
df.set_index('user_id', inplace=True)
df.reset_index(inplace=True)

# Access by index
df.loc[12345]  # O(1) with index, O(n) without!

# Multi-index
df.set_index(['date', 'category'])
```

### DateTime Operations
```python
# Convert to datetime
df['date'] = pd.to_datetime(df['date'])

# Extract components
df['year'] = df['date'].dt.year
df['month'] = df['date'].dt.month
df['day_name'] = df['date'].dt.day_name()
df['quarter'] = df['date'].dt.quarter

# Date math
df['delivery_date'] = df['order_date'] + pd.Timedelta(days=7)
df['days_ago'] = (pd.Timestamp.now() - df['date']).dt.days

# Resampling (time series)
df.set_index('date').resample('M').sum()  # Monthly totals
```

### Pivot Tables
```python
pd.pivot_table(
    df, 
    values='sales',
    index='date',
    columns='category',
    aggfunc='sum',
    fill_value=0
)
```

**Pivot Visual:**
```
LONG FORMAT:                WIDE FORMAT:
date       | cat   | sales  date       | Electronics | Clothing
-----------|-------|------  -----------|-------------|----------
2024-01-01 | Elec  | 1000   2024-01-01 | 1000        | 500
2024-01-01 | Cloth | 500    2024-01-02 | 1200        | 600
2024-01-02 | Elec  | 1200
2024-01-02 | Cloth | 600
```

### Missing Data
```python
df.isna().sum()                        # Count NaN
df.dropna()                            # Drop rows with NaN
df.fillna(0)                           # Fill with 0
df['age'].fillna(df['age'].median())   # Fill with median
```

### String Operations
```python
df['email'].str.lower()
df['name'].str.split(' ', expand=True)
df['text'].str.contains('keyword', case=False)
df['phone'].str.replace(r'\D', '', regex=True)  # Remove non-digits
```

### Window Functions (Ranking)
```python
# Rank within groups
df['rank'] = df.groupby('category')['sales'].rank(method='dense', ascending=False)

# Rolling calculations
df['sales_7day_avg'] = df['sales'].rolling(window=7).mean()

# Shift (lag/lead)
df['prev_sales'] = df['sales'].shift(1)
df['sales_change'] = df['sales'] - df['sales'].shift(1)
```

---

## 🔢 NumPy Essentials

### Array Creation
```python
import numpy as np

# Basic creation
arr = np.array([1, 2, 3, 4])
arr2d = np.array([[1, 2], [3, 4]])
Array A: (3, 4, 5)
Array B:    (4, 1)
Result:  (3, 4, 5) ✓ Compatible

Array A: (3, 4, 5)
Array B:    (4, 3)
Result:     ERROR  ✗ (5 ≠ 3)
# Special arrays
np.zeros((3, 4))
np.ones((2, 3))
np.eye(3)                    # Identity matrix
np.arange(0, 10, 2)          # [0, 2, 4, 6, 8]
np.linspace(0, 1, 5)         # [0, 0.25, 0.5, 0.75, 1]

# Random
np.random.rand(3, 4)         # Uniform [0, 1)
np.random.randn(3, 4)        # Normal distribution
np.random.randint(0, 10, size=(3, 4))
```

### Indexing & Slicing
```python
arr = np.array([10, 20, 30, 40, 50])
arr[0]              # 10
arr[1:4]            # [20, 30, 40]
arr[-1]             # 50

# Boolean indexing
arr[arr > 25]       # [30, 40, 50]

# Fancy indexing
arr[[0, 2, 4]]      # [10, 30, 50] - specific indices
```

### Operations
```python
# Element-wise
arr + 5
arr * 2
arr ** 2

# Matrix operations
A @ B               # Matrix multiplication (dot product)
A.T                 # Transpose

# Aggregations
arr.sum()
arr.mean()
arr.std()
arr.min()
arr.max()

# Axis-wise
arr2d.sum(axis=0)   # Sum columns
arr2d.sum(axis=1)   # Sum rows
```

### Reshaping
```python
arr = np.arange(12)
arr.reshape(3, 4)           # 3x4 array
arr.flatten()               # 1D array
arr.ravel()                 # 1D view (faster)
arr[np.newaxis, :]          # Add dimension
```

### Vectorization (Fast!)
```python
# BAD (slow)
result = [x ** 2 for x in arr]

# GOOD (fast - vectorized)
result = arr ** 2
```

---

## 🗄️ SQL - Joins & Group By

### Basic Joins
```sql
-- INNER JOIN
SELECT u.name, o.product, o.amount
FROM users u
INNER JOIN orders o ON u.id = o.user_id;

-- LEFT JOIN
SELECT u.name, COUNT(o.id) as order_count
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
GROUP BY u.name;

-- Multiple joins
SELECT u.name, o.product, p.price
FROM users u
JOIN orders o ON u.id = o.user_id
JOIN products p ON o.product_id = p.id;
```

**Join Visual:**
```
INNER JOIN:                    LEFT JOIN:
users       orders             users       orders
id | name   id | user_id       id | name   id | user_id
---|-----   ---|--------        ---|-----   ---|--------
1  | Alice  1  | 1    ┐         1  | Alice  1  | 1    ┐
2  | Bob    2  | 1    ├─Match   2  | Bob    2  | 1    ├─Match
3  | Charlie           │         3  | Charlie           │ No match (NULL)
                                                         
Result: 2 rows (only matches)  Result: 3 rows (all users)
```

### Group By & Aggregations
```sql
-- Simple GROUP BY
SELECT category, 
       COUNT(*) as total_products,
       AVG(price) as avg_price,
       SUM(stock) as total_stock
FROM products
GROUP BY category;

-- Multiple grouping
SELECT region, category, SUM(sales)
FROM sales_data
GROUP BY region, category;

-- HAVING (filter groups)
SELECT category, AVG(price)
FROM products
GROUP BY category
HAVING AVG(price) > 100;
```

### Subqueries
```sql
-- Subquery in WHERE
SELECT name, salary
FROM employees
WHERE salary > (SELECT AVG(salary) FROM employees);

-- Subquery in FROM
SELECT dept, avg_salary
FROM (
    SELECT department as dept, AVG(salary) as avg_salary
    FROM employees
    GROUP BY department
) AS dept_stats
WHERE avg_salary > 70000;
```

---

## 📊 SQL - Window Functions (RANK)

### RANK Functions
```sql
-- RANK (skips numbers for ties)
SELECT 
    name,
    department,
    salary,
    RANK() OVER (PARTITION BY department ORDER BY salary DESC) as rank
FROM employees;
```

**RANK Visual:**
```
name    | dept  | salary | rank
--------|-------|--------|------
Alice   | Sales | 90000  | 1     ← Highest in Sales
Bob     | Sales | 85000  | 2     ← Tied
Charlie | Sales | 85000  | 2     ← Tied
David   | Sales | 80000  | 4     ← Skips 3!
Eve     | IT    | 95000  | 1     ← Highest in IT (new group!)
Frank   | IT    | 92000  | 2
```

### RANK vs DENSE_RANK vs ROW_NUMBER
```sql
SELECT 
    salary,
    RANK() OVER (ORDER BY salary DESC) as rank,
    DENSE_RANK() OVER (ORDER BY salary DESC) as dense_rank,
    ROW_NUMBER() OVER (ORDER BY salary DESC) as row_num
FROM employees;
```

**Result:**
```
salary | rank | dense_rank | row_num
-------|------|------------|--------
95000  | 1    | 1          | 1
90000  | 2    | 2          | 2
85000  | 3    | 3          | 3
85000  | 3    | 3          | 4       ← Tie handling
80000  | 5    | 4          | 5
        ↑      ↑            ↑
     Skips   No skip   Always unique
```

### Finding Nth Highest Salary
```sql
-- 2nd highest salary
SELECT name, salary
FROM (
    SELECT name, salary,
           DENSE_RANK() OVER (ORDER BY salary DESC) as rank
    FROM employees
) x
WHERE rank = 2;

-- 2nd highest per department
SELECT name, department, salary
FROM (
    SELECT name, department, salary,
           DENSE_RANK() OVER (PARTITION BY department ORDER BY salary DESC) as rank
    FROM employees
) x
WHERE rank = 2;
```

### Other Window Functions
```sql
-- Running total
SELECT 
    date,
    sales,
    SUM(sales) OVER (ORDER BY date) as cumulative_sales
FROM daily_sales;

-- Moving average (7-day)
SELECT 
    date,
    sales,
    AVG(sales) OVER (
        ORDER BY date 
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) as sales_7day_avg
FROM daily_sales;

-- LAG/LEAD
SELECT 
    date,
    sales,
    LAG(sales, 1) OVER (ORDER BY date) as prev_day,
    sales - LAG(sales, 1) OVER (ORDER BY date) as day_over_day
FROM daily_sales;
```

### PARTITION BY Explained
```
WITHOUT PARTITION BY:          WITH PARTITION BY department:
All rows ranked together       Each department ranked separately

name    | salary | rank        name    | dept  | salary | dept_rank
--------|--------|------       --------|-------|--------|----------
Eve     | 95000  | 1           Alice   | Sales | 90000  | 1  ← Best in Sales
Alice   | 90000  | 2           Bob     | Sales | 85000  | 2
Frank   | 92000  | 3           Eve     | IT    | 95000  | 1  ← Best in IT (reset!)
Bob     | 85000  | 4           Frank   | IT    | 92000  | 2
```

---

## 🔧 SQLAlchemy - Session & Text

### Database Configuration
```python
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Connection URL format:
# "postgresql://username:password@hostname:port/database"
DATABASE_URL = "postgresql+pg8000://user:pass@localhost:5432/mydb"

# Create engine
engine = create_engine(DATABASE_URL, echo=True)

# Session factory
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)

# Base for models
Base = declarative_base()

# Get session (dependency)
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

### Using Session
```python
from sqlalchemy.orm import Session

# Basic pattern
with Session(engine) as session:
    # Your queries here
    session.commit()

# With error handling
with Session(engine) as session:
    try:
        # Operations
        session.add(user)
        session.commit()
    except Exception as e:
        session.rollback()
        raise e
```

### Raw SQL with text()
```python
from sqlalchemy import text

# SELECT (no commit needed)
with Session(engine) as session:
    result = session.execute(
        text("SELECT * FROM users WHERE age > :age"),
        {"age": 25}
    )
    for row in result:
        print(row.name, row.email)

# INSERT/UPDATE/DELETE (commit required!)
with Session(engine) as session:
    session.execute(
        text("INSERT INTO users (name, email) VALUES (:name, :email)"),
        {"name": "Alice", "email": "alice@example.com"}
    )
    session.commit()  # ← REQUIRED!

# Complex query
with Session(engine) as session:
    result = session.execute(text("""
        SELECT u.name, COUNT(o.id) as order_count
        FROM users u
        LEFT JOIN orders o ON u.id = o.user_id
        GROUP BY u.name
        HAVING COUNT(o.id) > :min_orders
    """), {"min_orders": 2})
```

### ORM CRUD Operations
```python
from models import User

# CREATE
with Session(engine) as session:
    user = User(name="Alice", email="alice@example.com", age=25)
    session.add(user)
    session.commit()
    session.refresh(user)  # Get ID after insert

# READ
with Session(engine) as session:
    users = session.query(User).all()
    user = session.query(User).filter(User.id == 1).first()
    users = session.query(User).filter(User.age > 25, User.name.like('%Alice%')).all()

# UPDATE
with Session(engine) as session:
    user = session.query(User).filter(User.id == 1).first()
    user.age = 26
    session.commit()

# DELETE
with Session(engine) as session:
    user = session.query(User).filter(User.id == 1).first()
    session.delete(user)
    session.commit()
```

### Query Methods
```python
.all()              # List of all results
.first()            # First result or None
.one()              # Exactly one (error if 0 or >1)
.one_or_none()      # One or None (error if >1)
.count()            # Count results

# Filtering
.filter(User.age == 25)
.filter(User.age > 25)
.filter(User.name.like('%Alice%'))
.filter(User.name.in_(['Alice', 'Bob']))
.filter(User.age.between(20, 30))

# Ordering & Limiting
.order_by(User.age.desc())
.limit(10)
.offset(20)
```

---

## 🔗 SQLAlchemy - Relationships

### ONE-TO-MANY (Most Common)
```python
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

# Parent (ONE side)
class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    name = Column(String)
    
    # One user has MANY orders
    orders = relationship("Order", back_populates="user")

# Child (MANY side)
class Order(Base):
    __tablename__ = 'orders'
    
    id = Column(Integer, primary_key=True)
    product = Column(String)
    amount = Column(Float)
    
    # Foreign Key - links to User
    user_id = Column(Integer, ForeignKey('users.id'))
    
    # Many orders belong to ONE user
    user = relationship("User", back_populates="orders")
```

**Visual:**
```
USERS TABLE:               ORDERS TABLE:
┌────┬───────┐            ┌────┬─────────┬────────┬─────────┐
│ id │ name  │            │ id │ product │ amount │ user_id │ ← FK
├────┼───────┤            ├────┼─────────┼────────┼─────────┤
│ 1  │ Alice │ ←──────────┤ 1  │ Laptop  │ 1000   │    1    │
│ 2  │ Bob   │ ←──────────┤ 2  │ Mouse   │ 50     │    1    │
└────┴───────┘            │ 3  │ Monitor │ 300    │    2    │
                          └────┴─────────┴────────┴─────────┘
```

**Usage:**
```python
# Create user with orders
user = User(name="Alice")
order1 = Order(product="Laptop", amount=1000)
order2 = Order(product="Mouse", amount=50)

user.orders.append(order1)
user.orders.append(order2)

session.add(user)
session.commit()

# Query
user = session.query(User).first()
for order in user.orders:  # Access orders via relationship
    print(order.product)

order = session.query(Order).first()
print(order.user.name)  # Access user via relationship
```

### ONE-TO-ONE
```python
class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    name = Column(String)
    
    # uselist=False for one-to-one
    profile = relationship("Profile", back_populates="user", uselist=False)

class Profile(Base):
    __tablename__ = 'profiles'
    
    id = Column(Integer, primary_key=True)
    bio = Column(String)
    
    # UNIQUE constraint for one-to-one
    user_id = Column(Integer, ForeignKey('users.id'), unique=True)
    
    user = relationship("User", back_populates="profile")
```

**Usage:**
```python
user = User(name="Alice")
profile = Profile(bio="Python Developer")

user.profile = profile  # Single object (not list!)

# Access
print(user.profile.bio)  # Not user.profiles[0]
```

### MANY-TO-MANY
```python
from sqlalchemy import Table

# Junction/Association table
student_courses = Table(
    'student_courses',
    Base.metadata,
    Column('student_id', Integer, ForeignKey('students.id')),
    Column('course_id', Integer, ForeignKey('courses.id'))
)

class Student(Base):
    __tablename__ = 'students'
    
    id = Column(Integer, primary_key=True)
    name = Column(String)
    
    courses = relationship("Course", secondary=student_courses, back_populates="students")

class Course(Base):
    __tablename__ = 'courses'
    
    id = Column(Integer, primary_key=True)
    title = Column(String)
    
    students = relationship("Student", secondary=student_courses, back_populates="courses")
```

**Visual:**
```
STUDENTS:        STUDENT_COURSES:         COURSES:
┌────┬──────┐   ┌────────────┬─────────┐ ┌────┬────────┐
│ id │ name │   │ student_id │course_id│ │ id │ title  │
├────┼──────┤   ├────────────┼─────────┤ ├────┼────────┤
│ 1  │Alice │←──┤     1      │    1    │─→│ 1  │ Math   │
│ 2  │ Bob  │←──┤     1      │    2    │─→│ 2  │Science │
└────┴──────┘   │     2      │    1    │  └────┴────────┘
                └────────────┴─────────┘
```

**Usage:**
```python
alice = Student(name="Alice")
math = Course(title="Math")
science = Course(title="Science")

alice.courses.append(math)
alice.courses.append(science)

# Query
for course in alice.courses:
    print(course.title)  # Math, Science
```

### FastAPI Repository Pattern
```python
# repository.py
class UserRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def get_all(self):
        return self.db.query(User).all()
    
    def get_by_id(self, user_id: int):
        return self.db.query(User).filter(User.id == user_id).first()
    
    def create(self, name: str, email: str):
        user = User(name=name, email=email)
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        return user

# main.py
from fastapi import FastAPI, Depends

def get_user_repo(db: Session = Depends(get_db)):
    return UserRepository(db)

@app.get("/users/")
def get_users(repo: UserRepository = Depends(get_user_repo)):
    return repo.get_all()
```

---

## 💡 Interview Q&A

### Pandas
**Q: What's the difference between groupby().sum() and transform()?**
> "groupby().sum() collapses data to one row per group (aggregation). transform() broadcasts the group result back to all original rows, maintaining the dataframe's shape. Use transform() when you need group calculations for each row, like calculating percentage of group total."

**Q: Why use df.query() instead of boolean indexing?**
> "query() is faster for large datasets due to numexpr optimization and has cleaner syntax. Both return new dataframes without modifying the original. I use query() for complex conditions and boolean indexing when I need the explicit syntax."

**Q: How does pandas index improve performance?**
> "Pandas indexes use hash tables for O(1) average lookup time. df.loc[value] is a hash lookup directly to row position, making it 100-500x faster than boolean filtering for large datasets. I set indexes on frequently queried columns like user_id or date."

### NumPy
**Q: What is vectorization?**
> "Vectorization is applying operations to entire arrays using optimized C code instead of Python loops. arr * 2 is much faster than [x * 2 for x in arr] because NumPy executes the operation in compiled code. I always vectorize operations for performance."

### SQL
**Q: Explain RANK vs DENSE_RANK.**
> "RANK skips numbers after ties (1,2,2,4), while DENSE_RANK doesn't skip (1,2,2,3). For finding nth highest salary, I use DENSE_RANK to avoid gaps. PARTITION BY divides data into groups and ranks each group separately, resetting the rank counter for each partition."

**Q: How to find 2nd highest salary per department?**
```sql
SELECT name, department, salary
FROM (
    SELECT name, department, salary,
           DENSE_RANK() OVER (PARTITION BY department ORDER BY salary DESC) as rank
    FROM employees
) x
WHERE rank = 2;
```

### SQLAlchemy
**Q: When do you need session.commit()?**
> "commit() is required for INSERT, UPDATE, DELETE operations to persist changes. SELECT queries don't need commit. I always use try/except with rollback() to handle errors and maintain transaction consistency."

**Q: Explain one-to-many relationship setup.**
> "Foreign key goes on the 'many' side (orders.user_id references users.id). Both sides define relationship() with back_populates. The parent uses a list (user.orders), child uses single object (order.user). The relationship handles joins automatically."

**Q: What's the difference between merge() and join()?**
> "merge() joins on any columns (SQL-like), join() joins on indexes by default. I use merge() for general cases with on= parameter, and join() when both dataframes already have matching indexes set up, which is faster."

---

## 🎯 Key Takeaways for Interview

1. **Pandas**: GroupBy aggregates (fewer rows), Transform broadcasts (same rows)
2. **NumPy**: Always vectorize, avoid loops for performance
3. **SQL**: DENSE_RANK for nth highest, PARTITION BY for group-wise ranking
4. **SQLAlchemy**: FK on "many" side, commit() for writes, Session in FastAPI Depends
5. **Indexes**: Hash-based O(1) lookups in pandas, B-tree in databases
6. **Relationships**: one-to-many (FK on many), one-to-one (unique FK), many-to-many (junction table)

---

**Good luck with your interview! 🚀**
