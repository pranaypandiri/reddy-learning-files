yeah see the intention is too redcue the man power is simple for a trainee we need multiple supervisor to train them to giv eout the scenairo but here we mici the cutomer to reuce the human power..

i use the similairy matching retreieval with top k docs and mvoe the dock to form the scenario and then pass it to the llm mdoel with firestore as the emmeory and the conevrsation kick off with the pacing the scnario later it goes on 

2. anything with hardware need of the escalation but hardware proelms are where realy low msot of the repetivie thing wcih need soems teps to be follwoed 

3. cjeck the repsosne of the last 10 witht he chunk retrievala nd the query to th answr and see the factaull and answrr eleveanc eof the ragas.. then i willl do i dont knwo what t do bro 
