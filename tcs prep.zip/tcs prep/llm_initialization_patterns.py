"""
Different ways to initialize LLMs and pass prompts
- Azure OpenAI vs Vertex AI vs Regular OpenAI
- Chat models vs Completion models
- Message-based vs PromptTemplate-based
"""

from langchain_google_vertexai import ChatVertexAI
from langchain_openai import AzureChatOpenAI, ChatOpenAI, OpenAI
from langchain_core.prompts import PromptTemplate, ChatPromptTemplate
from langchain_core.messages import HumanMessage, SystemMessage
import os

# ============================================
# 1. VERTEX AI - Google Cloud
# ============================================

# Method 1A: Chat Model - Direct
vertex_chat = ChatVertexAI(
    model="gemini-1.5-flash",
    temperature=0.7,
    project="your-project-id",
    location="us-central1",
)

# Method 1B: Chat Model - With Messages
response = vertex_chat.invoke(
    [
        SystemMessage(content="You are a helpful assistant"),
        HumanMessage(content="What is AI?"),
    ]
)
print("Vertex with Messages:", response.content)


# Method 1C: Chat Model - With PromptTemplate
vertex_prompt = ChatPromptTemplate.from_messages(
    [("system", "You are a {role}"), ("human", "Explain {topic} in simple terms")]
)

vertex_chain = vertex_prompt | vertex_chat
response = vertex_chain.invoke({"role": "teacher", "topic": "machine learning"})
print("Vertex with ChatPromptTemplate:", response.content)


# Method 1D: Simple PromptTemplate (for single string)
simple_vertex_prompt = PromptTemplate(
    input_variables=["question"], template="Answer this question: {question}"
)

vertex_simple_chain = simple_vertex_prompt | vertex_chat
response = vertex_simple_chain.invoke({"question": "What is Python?"})
print("Vertex with Simple PromptTemplate:", response.content)


# ============================================
# 2. AZURE OPENAI - Microsoft Azure
# ============================================

# Method 2A: Chat Model - Direct
azure_chat = AzureChatOpenAI(
    azure_endpoint="https://your-resource.openai.azure.com/",
    api_key="your-api-key",  # or use os.getenv("AZURE_OPENAI_API_KEY")
    api_version="2024-02-15-preview",
    deployment_name="gpt-4",  # Your deployment name in Azure
    temperature=0.7,
)

# Method 2B: Chat Model - With Messages
response = azure_chat.invoke(
    [
        SystemMessage(content="You are a coding assistant"),
        HumanMessage(content="Write a hello world in Python"),
    ]
)
print("Azure with Messages:", response.content)


# Method 2C: Chat Model - With ChatPromptTemplate
azure_prompt = ChatPromptTemplate.from_messages(
    [("system", "You are an expert in {domain}"), ("human", "{query}")]
)

azure_chain = azure_prompt | azure_chat
response = azure_chain.invoke({"domain": "data science", "query": "What is RAG?"})
print("Azure with ChatPromptTemplate:", response.content)


# Method 2D: Simple PromptTemplate
simple_azure_prompt = PromptTemplate(
    input_variables=["task"], template="Complete this task: {task}"
)

azure_simple_chain = simple_azure_prompt | azure_chat
response = azure_simple_chain.invoke({"task": "Explain arrays"})
print("Azure with Simple PromptTemplate:", response.content)


# ============================================
# 3. REGULAR OPENAI (Non-Azure)
# ============================================

# Method 3A: Chat Model
openai_chat = ChatOpenAI(
    model="gpt-4",
    api_key="your-openai-api-key",  # or os.getenv("OPENAI_API_KEY")
    temperature=0.7,
)

# Method 3B: Chat with Messages
response = openai_chat.invoke(
    [SystemMessage(content="You are helpful"), HumanMessage(content="Hello")]
)
print("OpenAI Chat with Messages:", response.content)


# Method 3C: Chat with PromptTemplate
openai_prompt = ChatPromptTemplate.from_template("You are a {role}. Answer: {question}")

openai_chain = openai_prompt | openai_chat
response = openai_chain.invoke({"role": "scientist", "question": "What is DNA?"})
print("OpenAI Chat with Template:", response.content)


# ============================================
# 4. COMPLETION MODELS (Legacy/Non-Chat)
# ============================================

# Method 4A: OpenAI Completion Model (NOT chat)
openai_completion = OpenAI(
    model="gpt-3.5-turbo-instruct",  # Completion model, not chat
    api_key="your-openai-api-key",
    temperature=0.7,
)

# Method 4B: Completion with Simple String
response = openai_completion.invoke("What is the capital of France?")
print("OpenAI Completion Direct:", response)


# Method 4C: Completion with PromptTemplate
completion_prompt = PromptTemplate(
    input_variables=["topic"], template="Write a short paragraph about {topic}:"
)

completion_chain = completion_prompt | openai_completion
response = completion_chain.invoke({"topic": "AI ethics"})
print("OpenAI Completion with Template:", response)


# ============================================
# 5. COMPARISON TABLE
# ============================================

"""
┌─────────────────────────────────────────────────────────────────────┐
│                    LLM INITIALIZATION QUICK REFERENCE                │
├─────────────────┬───────────────────────┬───────────────────────────┤
│   Provider      │   Chat Model          │   Completion Model        │
├─────────────────┼───────────────────────┼───────────────────────────┤
│ Vertex AI       │ ChatVertexAI()        │ N/A (use chat)            │
│ Azure OpenAI    │ AzureChatOpenAI()     │ AzureOpenAI() [deprecated]│
│ Regular OpenAI  │ ChatOpenAI()          │ OpenAI()                  │
└─────────────────┴───────────────────────┴───────────────────────────┘

PROMPT METHODS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Direct Messages (Chat Models Only):
   llm.invoke([SystemMessage(...), HumanMessage(...)])

2. ChatPromptTemplate (Chat Models Only):
   ChatPromptTemplate.from_messages([
       ("system", "..."),
       ("human", "...")
   ]) | llm

3. Simple PromptTemplate (Works with Both):
   PromptTemplate(
       input_variables=["var"],
       template="..."
   ) | llm

4. Direct String (Completion Models):
   llm.invoke("raw string prompt")

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

KEY DIFFERENCES:
- Chat Models: Expect message objects (SystemMessage, HumanMessage)
- Completion Models: Expect raw strings
- ChatPromptTemplate: For chat models with roles (system, human, ai)
- PromptTemplate: For simple string templates (works with both)

BEST PRACTICES:
✓ Use Chat Models (ChatVertexAI, AzureChatOpenAI) for modern apps
✓ Use ChatPromptTemplate for complex multi-turn conversations
✓ Use PromptTemplate for simple single prompts
✗ Avoid Completion Models (legacy, being phased out)
"""


# ============================================
# 6. PRACTICAL EXAMPLES
# ============================================


# Example 1: Vertex AI with structured prompt
def create_vertex_chain():
    llm = ChatVertexAI(model="gemini-1.5-flash", project="your-project")

    prompt = ChatPromptTemplate.from_messages(
        [("system", "You are a {role}. Be {style}."), ("human", "{user_input}")]
    )

    return prompt | llm


# Usage:
# chain = create_vertex_chain()
# result = chain.invoke({"role": "teacher", "style": "concise", "user_input": "Explain AI"})


# Example 2: Azure with reusable template
def create_azure_chain():
    llm = AzureChatOpenAI(
        azure_endpoint=os.getenv("AZURE_ENDPOINT"),
        api_key=os.getenv("AZURE_KEY"),
        deployment_name="gpt-4",
    )

    prompt = PromptTemplate(
        input_variables=["context", "question"],
        template="Context: {context}\n\nQuestion: {question}\n\nAnswer:",
    )

    return prompt | llm


# Usage:
# chain = create_azure_chain()
# result = chain.invoke({"context": "AI is...", "question": "What is AI?"})


# Example 3: Without messages - Pure template approach
def simple_template_approach():
    llm = ChatVertexAI(model="gemini-1.5-flash")

    # No messages! Just template
    template = PromptTemplate.from_template(
        "Summarize this in {num_words} words: {text}"
    )

    chain = template | llm
    return chain.invoke({"num_words": "20", "text": "Long text here..."})


print("\n✅ All LLM initialization patterns demonstrated!")


## **Azure OpenAI Chat vs Vertex AI Chat - Key Differences**

# ### **1. Cloud Provider & Models**

# | Aspect | Azure OpenAI | Vertex AI |
# |--------|--------------|-----------|
# | **Provider** | Microsoft Azure | Google Cloud Platform |
# | **Models** | OpenAI (GPT-4, GPT-3.5-turbo, GPT-4o) | Google (Gemini 1.5 Flash/Pro, PaLM 2) |
# | **Model Access** | Need Azure deployment | Direct model access |

# ---

# ### **2. Initialization Differences**

# #### **Azure OpenAI (2 ways):**

# **Way 1: Direct OpenAI SDK (what you're using)**
# ```python
# from openai import AzureOpenAI

# client = AzureOpenAI(
#     api_key="your-key",
#     api_version="2024-12-01-preview",
#     azure_endpoint="https://your-resource.openai.azure.com/"
# )

# response = client.chat.completions.create(
#     model="gpt-4.1",  # Your DEPLOYMENT NAME in Azure
#     messages=[{"role": "user", "content": "Hello"}]
# )
# ```

# **Way 2: LangChain Wrapper**
# ```python
# from langchain_openai import AzureChatOpenAI

# llm = AzureChatOpenAI(
#     azure_endpoint="https://your-resource.openai.azure.com/",
#     api_key="your-key",
#     api_version="2024-02-15-preview",
#     deployment_name="gpt-4",  # Your deployment name
#     temperature=0.7
# )

# response = llm.invoke([HumanMessage(content="Hello")])
# ```

# #### **Vertex AI:**

# ```python
# from langchain_google_vertexai import ChatVertexAI

# llm = ChatVertexAI(
#     model="gemini-1.5-flash",  # ACTUAL model name, not deployment
#     temperature=0.7,
#     project="your-gcp-project-id",
#     location="us-central1"
# )

# response = llm.invoke([HumanMessage(content="Hello")])
# ```

# ---

# ### **3. Major Differences**

# | Feature | Azure OpenAI | Vertex AI |
# |---------|--------------|-----------|
# | **Authentication** | API Key | GCP Service Account or ADC |
# | **Endpoint** | Custom endpoint per resource | Standard GCP endpoint |
# | **Model naming** | Deployment name (you choose) | Fixed model names (gemini-1.5-flash) |
# | **API Version** | Required explicit version | Not needed |
# | **Response access** | `response.choices[0].message.content` | `response.content` (LangChain) |
# | **Pricing** | Per token (OpenAI pricing) | Per character (Google pricing) |

# ---

# ### **4. Response Structure Differences**

# #### **Azure OpenAI Direct SDK:**
# ```python
# response = client.chat.completions.create(...)

# # Access response
# text = response.choices[0].message.content
# ```

# **Response object:**
# ```python
# {
#   "choices": [
#     {
#       "message": {
#         "role": "assistant",
#         "content": "Answer here"
#       },
#       "finish_reason": "stop"
#     }
#   ]
# }
# ```

# #### **Vertex AI (LangChain):**
# ```python
# response = llm.invoke([HumanMessage(...)])

# # Access response
# text = response.content  # Direct access
# ```

# **Response object:**
# ```python
# AIMessage(
#     content="Answer here",
#     response_metadata={...}
# )
# ```

# ---

# ### **5. Code Comparison - Same Task**

# **Task:** Generate a customer response

# #### **Your Current Azure Approach:**
# ```python
# response = client.chat.completions.create(
#     model="gpt-4.1",
#     messages=[
#         {"role": "system", "content": "You are helpful"},
#         {"role": "user", "content": "What is AI?"}
#     ],
#     max_tokens=200,
#     temperature=1.0
# )

# result = response.choices[0].message.content.strip()
# ```

# #### **Equivalent Vertex AI Approach:**
# ```python
# llm = ChatVertexAI(
#     model="gemini-1.5-flash",
#     temperature=1.0,
#     max_output_tokens=200  # NOT max_tokens
# )

# response = llm.invoke([
#     SystemMessage(content="You are helpful"),
#     HumanMessage(content="What is AI?")
# ])

# result = response.content.strip()
# ```

# ---

# ### **6. Key Functional Differences**

# | Feature | Azure OpenAI | Vertex AI |
# |---------|--------------|-----------|
# | **seed parameter** | ✅ Supported | ❌ Not supported |
# | **top_p** | ✅ Yes | ✅ Yes (called top_p) |
# | **frequency_penalty** | ✅ Yes | ❌ Not available |
# | **presence_penalty** | ✅ Yes | ❌ Not available |
# | **max_tokens** | ✅ Yes | ✅ Yes (called max_output_tokens) |
# | **streaming** | ✅ Yes | ✅ Yes |
# | **function calling** | ✅ Yes (tools) | ✅ Yes (tools) |
# | **JSON mode** | ✅ Yes | ✅ Yes (limited) |

# ---

# ### **7. Performance & Cost**

# | Aspect | Azure OpenAI | Vertex AI |
# |--------|--------------|-----------|
# | **Latency** | Lower (US/Europe) | Lower (if using GCP infra) |
# | **Context window** | GPT-4: 128K tokens | Gemini 1.5: 1M tokens |
# | **Cost** | Higher (GPT-4 expensive) | Lower (Gemini cheaper) |
# | **Rate limits** | Per deployment | Per project |

# ---

# ## **Bottom Line:**

# **Functionally:** Almost identical for basic chat completion
# - Both generate text
# - Both support system/user/assistant messages
# - Both have temperature, top_p, max_tokens

# **Key difference:**
# - **Azure** = OpenAI models (GPT-4) via Microsoft
# - **Vertex** = Google models (Gemini) via GCP
# - **Your code uses Azure's direct SDK** (not LangChain wrapper) for more control

# **In your resume projects:**
# - United app = Azure OpenAI (GPT-4)
# - GTE project = Vertex AI (Gemini)

# Both work the same conceptually - just different cloud providers and models!
