# ML/AI Fundamentals Cheatsheet - TCS Interview Prep

## Table of Contents
1. [Object-Oriented Programming (OOPs)](#1-object-oriented-programming-oops)
2. [Transformers Architecture](#2-transformers-architecture)
3. [LLM Parameters (Temperature, Top-p, etc.)](#3-llm-parameters)

---

# 1. Object-Oriented Programming (OOPs)

## Core Concepts

### 1.1 Classes and Objects

```python
class VectorStore:
    # Class variable (shared by all instances)
    total_stores = 0
    
    def __init__(self, name, dimension):
        # Instance variables (unique to each object)
        self.name = name
        self.dimension = dimension
        self.embeddings = []
        VectorStore.total_stores += 1
    
    def add_embedding(self, vector):
        self.embeddings.append(vector)

# Creating objects
store1 = VectorStore("policy_store", 768)
store2 = VectorStore("product_store", 1024)

print(VectorStore.total_stores)  # 2 (class variable)
print(store1.name)  # "policy_store" (instance variable)
```

**Interview Q:** "What's the difference between class and instance variables?"

**A:** Class variables are shared across all instances and stored in the class namespace. Instance variables are unique to each object and stored in `self`. Use class variables for shared state (counters, configs), instance variables for object-specific data.

---

### 1.2 Encapsulation (Private/Protected)

```python
class RAGPipeline:
    def __init__(self, api_key):
        self.model_name = "gpt-4"           # Public
        self._cache = {}                    # Protected (convention: single _)
        self.__api_key = api_key           # Private (name mangling: double __)
    
    def query(self, text):
        # Public method - anyone can call
        results = self._retrieve(text)      # Call protected method
        return self.__format_response(results)
    
    def _retrieve(self, text):
        # Protected method - internal use, but accessible
        if text in self._cache:
            return self._cache[text]
        # ... retrieval logic
    
    def __format_response(self, results):
        # Private method - name mangled to _RAGPipeline__format_response
        return {"results": results, "api_key": self.__api_key}

pipeline = RAGPipeline("secret123")
pipeline.query("test")              # ✅ Works
pipeline._retrieve("test")          # ✅ Works (but shouldn't - convention only)
pipeline.__format_response([])      # ❌ AttributeError
pipeline._RAGPipeline__format_response([])  # ✅ Works (name mangling exposed)
```

**Key Points:**
- `public`: No underscore - accessible everywhere
- `_protected`: Single underscore - internal use (convention, not enforced)
- `__private`: Double underscore - name mangled to `_ClassName__method`

---

### 1.3 Inheritance

```python
class BaseRetriever:
    def __init__(self, k=5):
        self.k = k
    
    def retrieve(self, query):
        raise NotImplementedError("Subclass must implement retrieve()")
    
    def format_results(self, docs):
        return [doc.page_content for doc in docs]

class DenseRetriever(BaseRetriever):
    def __init__(self, vector_store, k=5):
        super().__init__(k)  # Call parent constructor
        self.vector_store = vector_store
    
    def retrieve(self, query):
        # Override parent method
        return self.vector_store.similarity_search(query, k=self.k)

class HybridRetriever(BaseRetriever):
    def __init__(self, dense_retriever, bm25_retriever, k=5):
        super().__init__(k)
        self.dense = dense_retriever
        self.bm25 = bm25_retriever
    
    def retrieve(self, query):
        # Completely different implementation
        dense_results = self.dense.retrieve(query)
        bm25_results = self.bm25.retrieve(query)
        return self._merge(dense_results, bm25_results)
    
    def _merge(self, r1, r2):
        # Child-specific method
        return r1 + r2
```

**Types of Inheritance:**
```python
# Single Inheritance
class Child(Parent):
    pass

# Multiple Inheritance
class Hybrid(DenseRetriever, BM25Retriever):
    pass

# Multilevel Inheritance
class Base:
    pass
class Middle(Base):
    pass
class Final(Middle):
    pass
```

---

### 1.4 Polymorphism

**Method Overriding:**
```python
class Retriever:
    def search(self, query):
        return "Base search"

class VectorRetriever(Retriever):
    def search(self, query):
        return "Vector search"  # Overrides parent

class BM25Retriever(Retriever):
    def search(self, query):
        return "BM25 search"  # Overrides parent

# Polymorphism in action
retrievers = [VectorRetriever(), BM25Retriever()]
for r in retrievers:
    print(r.search("test"))  # Calls correct method based on object type
# Output:
# Vector search
# BM25 search
```

**Method Overloading (Python doesn't support - use default args):**
```python
class Chunker:
    def split(self, text, size=1000, overlap=200, strategy="recursive"):
        # Single method handles all cases
        if strategy == "recursive":
            return self._recursive_split(text, size, overlap)
        elif strategy == "semantic":
            return self._semantic_split(text, size)

# Usage
chunker.split("text")                          # Uses defaults
chunker.split("text", 500)                     # Custom size
chunker.split("text", 500, 100, "semantic")    # All custom
```

---

### 1.5 Abstraction (Abstract Base Classes)

```python
from abc import ABC, abstractmethod

class BaseEmbedding(ABC):
    @abstractmethod
    def embed_query(self, text):
        """Must be implemented by subclass"""
        pass
    
    @abstractmethod
    def embed_documents(self, texts):
        """Must be implemented by subclass"""
        pass
    
    def get_dimension(self):
        # Concrete method (optional to override)
        return 768

class OpenAIEmbedding(BaseEmbedding):
    def embed_query(self, text):
        # Must implement
        return [0.1, 0.5, ...]
    
    def embed_documents(self, texts):
        # Must implement
        return [[0.1, 0.5, ...], [0.2, 0.4, ...]]

# Can't instantiate abstract class
# base = BaseEmbedding()  # ❌ TypeError

# Must implement all abstract methods
openai = OpenAIEmbedding()  # ✅ Works
```

---

### 1.6 Magic Methods (Dunder Methods)

```python
class Document:
    def __init__(self, content, metadata):
        self.content = content
        self.metadata = metadata
    
    def __str__(self):
        # Called by str() and print()
        return f"Document: {self.content[:50]}..."
    
    def __repr__(self):
        # Called by repr() - should be unambiguous
        return f"Document(content='{self.content[:20]}...', metadata={self.metadata})"
    
    def __len__(self):
        # Called by len()
        return len(self.content)
    
    def __getitem__(self, key):
        # Called by doc[key]
        return self.metadata[key]
    
    def __eq__(self, other):
        # Called by doc1 == doc2
        return self.content == other.content
    
    def __add__(self, other):
        # Called by doc1 + doc2
        return Document(
            content=self.content + "\n" + other.content,
            metadata={**self.metadata, **other.metadata}
        )

doc = Document("Hello world", {"source": "test.pdf"})
print(doc)              # Calls __str__
print(len(doc))         # Calls __len__
print(doc["source"])    # Calls __getitem__
doc2 = doc + doc        # Calls __add__
```

**Common Magic Methods:**
| Method | Usage | Example |
|--------|-------|---------|
| `__init__` | Constructor | `obj = Class()` |
| `__str__` | String representation | `print(obj)` |
| `__repr__` | Developer representation | `repr(obj)` |
| `__len__` | Length | `len(obj)` |
| `__getitem__` | Indexing | `obj[key]` |
| `__setitem__` | Assignment | `obj[key] = val` |
| `__eq__` | Equality | `obj1 == obj2` |
| `__lt__` | Less than | `obj1 < obj2` |
| `__add__` | Addition | `obj1 + obj2` |
| `__call__` | Callable | `obj()` |

---

### 1.7 Property Decorators

```python
class VectorStore:
    def __init__(self):
        self._embeddings = []
        self._is_trained = False
    
    @property
    def count(self):
        # Getter - access like attribute: store.count
        return len(self._embeddings)
    
    @property
    def is_trained(self):
        return self._is_trained
    
    @is_trained.setter
    def is_trained(self, value):
        # Setter - store.is_trained = True
        if not isinstance(value, bool):
            raise ValueError("is_trained must be boolean")
        self._is_trained = value
    
    @property
    def dimension(self):
        if not self._embeddings:
            return None
        return len(self._embeddings[0])

store = VectorStore()
print(store.count)          # Calls count getter (no parentheses!)
store.is_trained = True     # Calls is_trained setter
print(store.dimension)      # Computed property
```

**Why use @property?**
- Access like attribute, but execute code
- Add validation in setter
- Compute values on-the-fly
- Hide implementation details

---

## OOPs Interview Questions

**Q1: What are the four pillars of OOP?**

**A:** 
1. **Encapsulation:** Bundling data and methods, hiding internals (private/protected)
2. **Inheritance:** Child class inherits from parent, promotes code reuse
3. **Polymorphism:** Same interface, different implementations (method overriding)
4. **Abstraction:** Hiding complexity, showing only essential features (abstract classes)

**Q2: What's the difference between `__str__` and `__repr__`?**

**A:** 
- `__str__`: User-friendly string for end users (`print()`)
- `__repr__`: Unambiguous representation for developers (debugging, should ideally be `eval()`-able)

```python
class Point:
    def __str__(self):
        return f"Point at ({self.x}, {self.y})"  # Readable
    
    def __repr__(self):
        return f"Point(x={self.x}, y={self.y})"  # Recreatable
```

**Q3: Explain method resolution order (MRO) in multiple inheritance**

**A:** Python uses C3 linearization (left-to-right, depth-first). Use `Class.__mro__` to see order.

```python
class A:
    def method(self):
        print("A")

class B(A):
    def method(self):
        print("B")

class C(A):
    def method(self):
        print("C")

class D(B, C):
    pass

D().method()  # Prints "B" (B comes before C in MRO)
print(D.__mro__)  # (D, B, C, A, object)
```

---

# 2. Transformers Architecture

## 2.1 The Big Picture

```
SEQUENCE-TO-SEQUENCE MODEL:

Input Sequence → [ENCODER] → Context Vector → [DECODER] → Output Sequence
   "Hello"                                                    "Bonjour"
   "How"                                                      "Comment"
   "are"                                                      "allez"
   "you"                                                      "vous"
```

### Key Innovation: **Self-Attention**
Instead of processing sequentially (RNN), look at ALL words at once!

```
Traditional RNN:
"The cat sat on the mat" → Process word by word → Slow, forgets earlier context

Transformer:
"The cat sat on the mat" → Process ALL WORDS TOGETHER → Fast, sees full context
```

---

## 2.2 Architecture Components

```
TRANSFORMER ARCHITECTURE:

INPUT: "The cat sat"
   ↓
[Input Embedding] → Convert words to vectors [768 dims]
   ↓
[Positional Encoding] → Add position info (word order matters!)
   ↓
┌─────────────────────────────────────┐
│         ENCODER (6 layers)          │
│  ┌────────────────────────────┐    │
│  │  Multi-Head Self-Attention  │    │  ← Look at all input words
│  └────────────────────────────┘    │
│            ↓                        │
│  ┌────────────────────────────┐    │
│  │   Feed-Forward Network      │    │  ← Process each word independently
│  └────────────────────────────┘    │
│  (Repeat 6 times)                   │
└─────────────────────────────────────┘
   ↓
[Encoder Output: Context vectors]
   ↓
┌─────────────────────────────────────┐
│         DECODER (6 layers)          │
│  ┌────────────────────────────┐    │
│  │  Masked Self-Attention      │    │  ← Look at previous output words only
│  └────────────────────────────┘    │
│            ↓                        │
│  ┌────────────────────────────┐    │
│  │  Cross-Attention            │    │  ← Look at encoder output
│  └────────────────────────────┘    │
│            ↓                        │
│  ┌────────────────────────────┐    │
│  │  Feed-Forward Network       │    │
│  └────────────────────────────┘    │
│  (Repeat 6 times)                   │
└─────────────────────────────────────┘
   ↓
[Linear + Softmax] → Probability distribution over vocab
   ↓
OUTPUT: "Le chat assis"
```

---

## 2.3 Self-Attention Mechanism (THE CORE)

### The Problem:
```
Sentence: "The animal didn't cross the street because it was too tired"

Question: What does "it" refer to?
- The animal? ✅
- The street? ❌

How does the model figure this out? → ATTENTION!
```

### The Solution: Query, Key, Value (QKV)

```
STEP 1: Create Q, K, V matrices

"it" word embedding → [0.1, 0.5, 0.3, ...]
                      ↓
              ┌───────┼───────┐
              ↓       ↓       ↓
         [Wq]×Q  [Wk]×K  [Wv]×V
              ↓       ↓       ↓
         Query    Key    Value


STEP 2: Calculate attention scores

Query("it") · Key("animal") = 0.9  ← High! "it" looks at "animal"
Query("it") · Key("street") = 0.2  ← Low
Query("it") · Key("tired")  = 0.7  ← Medium


STEP 3: Softmax (normalize to probabilities)

Scores: [0.9, 0.2, 0.7, ...]
  ↓
Softmax: [0.5, 0.05, 0.3, ...]  ← Sum = 1
         (animal gets 50% attention!)


STEP 4: Weighted sum of Values

Output("it") = 0.5 × Value("animal") + 0.05 × Value("street") + 0.3 × Value("tired")
             = [0.45, 0.6, 0.3, ...]  ← New representation that "knows" it = animal
```

### Formula:
```
Attention(Q, K, V) = softmax(Q·K^T / √d_k) × V

Where:
- Q·K^T: Similarity scores between query and all keys
- √d_k: Scale factor (prevents large values in softmax)
- softmax: Converts scores to probabilities
- × V: Weighted average of values
```

---

## 2.4 Multi-Head Attention

**Why?** Different heads learn different relationships!

```
SINGLE-HEAD:
"it" → Looks at "animal" (subject reference)

MULTI-HEAD (8 heads):
Head 1: "it" → "animal" (subject)
Head 2: "it" → "tired" (state description)
Head 3: "it" → "didn't cross" (action relationship)
...
Head 8: Learns something else

Concatenate all heads → Final representation captures MULTIPLE aspects!
```

```python
# Simplified code
class MultiHeadAttention:
    def __init__(self, d_model=768, num_heads=8):
        self.num_heads = num_heads
        self.d_k = d_model // num_heads  # 768 / 8 = 96 per head
        
        self.W_q = Linear(d_model, d_model)  # Query projection
        self.W_k = Linear(d_model, d_model)  # Key projection
        self.W_v = Linear(d_model, d_model)  # Value projection
        self.W_o = Linear(d_model, d_model)  # Output projection
    
    def forward(self, x):
        batch_size = x.shape[0]
        
        # 1. Linear projections in batch
        Q = self.W_q(x).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        K = self.W_k(x).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        V = self.W_v(x).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        
        # 2. Apply attention
        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.d_k)
        attention_weights = F.softmax(scores, dim=-1)
        output = torch.matmul(attention_weights, V)
        
        # 3. Concatenate heads
        output = output.transpose(1, 2).contiguous().view(batch_size, -1, d_model)
        
        # 4. Final linear
        return self.W_o(output)
```

---

## 2.5 Positional Encoding

**Problem:** Attention has NO concept of word order!
```
"Dog bites man" and "Man bites dog" → Same attention (wrong!)
```

**Solution:** Add position information to embeddings

```python
def positional_encoding(max_len=512, d_model=768):
    pe = torch.zeros(max_len, d_model)
    position = torch.arange(0, max_len).unsqueeze(1)  # [0, 1, 2, ..., 511]
    
    # Alternate sin/cos for even/odd dimensions
    div_term = torch.exp(torch.arange(0, d_model, 2) * -(math.log(10000.0) / d_model))
    
    pe[:, 0::2] = torch.sin(position * div_term)  # Even dims
    pe[:, 1::2] = torch.cos(position * div_term)  # Odd dims
    
    return pe

# Usage
word_embeddings = embed("Hello")  # [0.1, 0.5, 0.3, ...]
pos_encoding = positional_encoding()[0]  # Position 0
final_input = word_embeddings + pos_encoding  # Add position info!
```

**Why sin/cos?**
- Unique pattern for each position
- Model can learn relative positions (sin(x+k) can be expressed using sin(x) and cos(x))
- Works for any sequence length

---

## 2.6 Encoder vs Decoder

| Component | Encoder | Decoder |
|-----------|---------|---------|
| **Purpose** | Understand input | Generate output |
| **Attention Type** | Self-attention (bidirectional) | Masked self-attention (causal) |
| **Looks At** | All input words | Previous output words only |
| **Use Case** | BERT, embeddings | GPT, translation |

```
ENCODER (BERT-style):
"The cat sat" → Can look at ALL words (bidirectional)
    ↓
Understanding: "cat" sees "The", "sat" (full context)


DECODER (GPT-style):
Generate: "The" → Can only see "The"
Generate: "cat" → Can see "The", "cat" (not future words!)
Generate: "sat" → Can see "The", "cat", "sat"
    ↓
Autoregressive: Generates one word at a time
```

---

## 2.7 Model Variants

### BERT (Encoder-Only)
```
Input: "The [MASK] sat on the mat"
  ↓
Encoder (bidirectional attention)
  ↓
Output: Predict [MASK] = "cat"

Use Cases:
- Text classification
- Question answering
- Named entity recognition
- Embeddings
```

### GPT (Decoder-Only)
```
Input: "The cat sat"
  ↓
Decoder (causal attention - can't see future)
  ↓
Output: Predict next word = "on"

Use Cases:
- Text generation
- Chat
- Completion
```

### T5 (Encoder-Decoder)
```
Input: "translate English to French: Hello"
  ↓
Encoder → understands input
  ↓
Decoder → generates "Bonjour"

Use Cases:
- Translation
- Summarization
- Any seq-to-seq task
```

---

## Transformers Interview Questions

**Q1: Why is attention "O(n²)" and how do we optimize it?**

**A:** 
Attention computes similarity between ALL pairs of tokens: n tokens × n tokens = n² operations.

**Optimizations:**
- **Sparse Attention:** Only attend to nearby tokens (Longformer)
- **Linear Attention:** Approximate attention with linear complexity (Linformer)
- **Flash Attention:** Optimize memory access patterns on GPU
- **Sliding Window:** Local attention with window size (e.g., 512 tokens)

**Q2: What's the difference between encoder and decoder self-attention?**

**A:**
- **Encoder:** Bidirectional - token can attend to all other tokens (past + future)
- **Decoder:** Causal/Masked - token can only attend to previous tokens (past only)

This is enforced by masking future positions in the attention matrix.

**Q3: Why do we need positional encoding?**

**A:** Attention is permutation-invariant - "dog bites man" and "man bites dog" would be identical without position information. Positional encoding adds unique patterns to each position, allowing the model to distinguish word order.

---

# 3. LLM Parameters

## 3.1 Temperature

**What it does:** Controls randomness in text generation

```
SAMPLING PROCESS:

Model outputs logits: [2.3, 1.5, 0.8, 0.2]  (raw scores)
  ↓
Apply temperature: logits / temperature
  ↓
Softmax: Convert to probabilities
  ↓
Sample: Pick next token based on probabilities
```

### Effect of Temperature:

```python
# Original probabilities
probabilities = [0.5, 0.3, 0.15, 0.05]  # "dog", "cat", "bird", "fish"

# Temperature = 0.1 (low - more deterministic)
[0.85, 0.12, 0.02, 0.01]  # Strongly prefers "dog"

# Temperature = 1.0 (default - balanced)
[0.5, 0.3, 0.15, 0.05]  # Original distribution

# Temperature = 2.0 (high - more random)
[0.35, 0.28, 0.22, 0.15]  # More uniform distribution
```

### Visual:
```
Temperature = 0.1 (Creative = 0, Focused = 10):
"The capital of France is Paris."
"The capital of France is Paris."  ← Always same (boring!)

Temperature = 0.7 (Creative = 5, Focused = 5):
"The capital of France is Paris."
"Paris is the capital of France."  ← Slight variation

Temperature = 2.0 (Creative = 10, Focused = 0):
"The capital of France is Paris."
"France's main city is probably Paris or Marseille."
"In France, you'll find beautiful cities like Paris."  ← Very different!
```

### When to Use:

| Task | Temperature | Why |
|------|-------------|-----|
| **Code generation** | 0.0 - 0.3 | Need accuracy, not creativity |
| **Factual Q&A** | 0.1 - 0.5 | Should be consistent and correct |
| **Chatbot** | 0.7 - 0.9 | Balance accuracy and variety |
| **Creative writing** | 0.9 - 1.5 | Want diverse, interesting outputs |
| **Brainstorming** | 1.2 - 2.0 | Maximum variety |

**Code:**
```python
response = openai.ChatCompletion.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "What is 2+2?"}],
    temperature=0.1  # Low - should always say "4"
)

response = openai.ChatCompletion.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Write a poem about the moon"}],
    temperature=1.2  # High - creative variation
)
```

---

## 3.2 Top-p (Nucleus Sampling)

**What it does:** Only sample from the smallest set of tokens whose cumulative probability exceeds `p`

```
Token probabilities:
"dog":  0.40
"cat":  0.30
"bird": 0.15
"fish": 0.10
"lion": 0.05

Top-p = 0.9:
1. Sort by probability: dog (0.40), cat (0.30), bird (0.15), fish (0.10), lion (0.05)
2. Cumulative sum: 0.40 → 0.70 → 0.85 → 0.95 ✓
3. Stop at 0.95 (exceeds 0.90)
4. Candidates: [dog, cat, bird, fish] ← Sample from these only
5. "lion" is cut off (too unlikely)
```

### Top-p vs Temperature:

```
Temperature = Controls overall randomness (flatten/sharpen distribution)
Top-p = Cuts off unlikely tokens (adaptive cutoff)

BEST PRACTICE: Use BOTH!
- temperature=0.7 (moderate randomness)
- top_p=0.9 (cut off unlikely tokens)
```

### Examples:

```python
# Highly peaked distribution (one token dominates)
Probabilities: [0.95, 0.03, 0.01, 0.01]

top_p=0.9:
- Include 0.95 only (already exceeds 0.9)
- Candidates: 1 token  ← Deterministic!

# Flat distribution (many plausible tokens)
Probabilities: [0.3, 0.25, 0.2, 0.15, 0.1]

top_p=0.9:
- Include 0.3 + 0.25 + 0.2 + 0.15 = 0.9
- Candidates: 4 tokens  ← More creative!
```

**Key Insight:** Top-p is **adaptive** - allows more choices when model is uncertain, fewer when confident!

---

## 3.3 Top-k

**What it does:** Only sample from the top `k` most likely tokens

```
Token probabilities:
"dog":  0.40
"cat":  0.30
"bird": 0.15
"fish": 0.10
"lion": 0.05

Top-k = 3:
→ Keep only top 3: [dog, cat, bird]
→ Renormalize: [0.47, 0.35, 0.18]
→ Sample from these 3 only
```

### Top-k vs Top-p:

```
Top-k = Fixed number of candidates (static)
Top-p = Adaptive number based on confidence (dynamic)

Top-k=5:
- Peaked distribution: Forces 5 choices (might include junk)
- Flat distribution: Only 5 choices (might miss good options)

Top-p=0.9:
- Peaked distribution: 1-2 choices (adapts!)
- Flat distribution: 5-10 choices (adapts!)

→ Top-p is usually better!
```

---

## 3.4 Frequency Penalty & Presence Penalty

### Frequency Penalty
**What:** Reduce probability of tokens based on how often they've appeared

```python
frequency_penalty = 0.5  # Range: 0.0 to 2.0

# Token "dog" appears 3 times in generated text
penalty = frequency_penalty * count("dog")
         = 0.5 * 3 = 1.5

new_logit("dog") = original_logit("dog") - 1.5
```

**Use:** Reduce repetition - higher values = less repetition

### Presence Penalty
**What:** Reduce probability of tokens if they've appeared at all (binary)

```python
presence_penalty = 0.6  # Range: 0.0 to 2.0

# Token "dog" appears (once or multiple times - doesn't matter)
penalty = presence_penalty * 1  # Binary: appeared = 1, not appeared = 0
         = 0.6 * 1 = 0.6

new_logit("dog") = original_logit("dog") - 0.6
```

**Use:** Encourage topic diversity - penalizes any token that's been used

### Comparison:

```
Text generated: "The dog is a good dog. Dogs are loyal."

Frequency Penalty:
- "dog"/"Dogs" appears 3 times
- Penalty = 0.5 * 3 = 1.5
- Strong penalty for "dog" specifically

Presence Penalty:
- "dog" appeared (yes/no = yes)
- Penalty = 0.6 * 1 = 0.6
- Moderate penalty, encourages talking about OTHER animals
```

**When to use:**
- **Frequency penalty:** Stop word-level repetition ("very very very good")
- **Presence penalty:** Encourage topic diversity (don't just talk about dogs, mention cats/birds/etc.)

---

## 3.5 Max Tokens

**What:** Maximum number of tokens to generate

```python
max_tokens = 100  # Generate at most 100 tokens

# Note: Includes BOTH prompt and completion in some APIs
prompt = "Explain transformers"  # 2 tokens
max_tokens = 100
# Model can generate up to 98 tokens (100 - 2 for prompt)
```

**Why it matters:**
- Cost control (pay per token)
- Prevent runaway generation
- Enforce response length

---

## 3.6 Stop Sequences

**What:** Stop generating when specific strings are encountered

```python
stop = ["\n\n", "###", "END"]

response = openai.ChatCompletion.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "List 3 colors"}],
    stop=["4."]  # Stop before listing a 4th color
)

# Output:
# 1. Red
# 2. Blue
# 3. Green
# [STOPS HERE - doesn't generate "4."]
```

**Use cases:**
- Structured output (stop at section boundary)
- Prevent overgeneration
- Format control

---

## 3.7 Parameters Summary Table

| Parameter | Range | Default | Effect | Use Case |
|-----------|-------|---------|--------|----------|
| **temperature** | 0.0 - 2.0 | 1.0 | Lower = focused, Higher = random | Code: 0.0-0.3, Chat: 0.7-0.9, Creative: 1.0-1.5 |
| **top_p** | 0.0 - 1.0 | 1.0 | Nucleus sampling cutoff | 0.9 (common), use with temperature |
| **top_k** | 1 - ∞ | 40 | Consider top k tokens only | 40-50 (alternative to top_p) |
| **frequency_penalty** | 0.0 - 2.0 | 0.0 | Penalize repeated tokens | 0.5-1.0 (reduce repetition) |
| **presence_penalty** | 0.0 - 2.0 | 0.0 | Penalize used topics | 0.5-1.0 (encourage diversity) |
| **max_tokens** | 1 - context | 16 | Max output length | Set based on task (100-2000) |

---

## 3.8 Best Practice Combinations

### Factual Q&A (Precise, Consistent)
```python
{
    "temperature": 0.1,        # Very focused
    "top_p": 0.9,             # Cut unlikely tokens
    "frequency_penalty": 0.0,  # Facts can repeat
    "presence_penalty": 0.0,   # Don't need diversity
    "max_tokens": 200
}
```

### Chatbot (Natural, Varied)
```python
{
    "temperature": 0.8,        # Balanced randomness
    "top_p": 0.95,            # Allow more variety
    "frequency_penalty": 0.3,  # Reduce repetition
    "presence_penalty": 0.2,   # Some topic diversity
    "max_tokens": 500
}
```

### Creative Writing (Diverse, Interesting)
```python
{
    "temperature": 1.2,        # High creativity
    "top_p": 1.0,             # Don't cut options
    "frequency_penalty": 0.5,  # Avoid word repetition
    "presence_penalty": 0.6,   # Encourage new topics
    "max_tokens": 2000
}
```

### Code Generation (Deterministic, Correct)
```python
{
    "temperature": 0.0,        # Always pick most likely
    "top_p": 1.0,             # Not needed (temp=0)
    "frequency_penalty": 0.0,  # Code can repeat patterns
    "presence_penalty": 0.0,   # Variables repeat
    "max_tokens": 1000,
    "stop": ["```"]           # Stop at code block end
}
```

---

## LLM Parameters Interview Questions

**Q1: When would you use temperature=0 vs temperature=1?**

**A:**
- **Temperature = 0:** Deterministic, always picks highest probability token. Use for code, math, factual Q&A where consistency is critical.
- **Temperature = 1:** Balanced randomness, samples from full distribution. Use for general chat, where you want natural variety.

**Q2: What's the difference between top-p and top-k?**

**A:**
- **Top-k:** Fixed number of candidates (e.g., always sample from top 5 tokens). Static.
- **Top-p:** Variable number based on cumulative probability (e.g., sample from tokens that sum to 90%). Adaptive - more tokens when model is uncertain, fewer when confident.

Top-p is generally preferred because it adapts to the model's confidence.

**Q3: How do frequency_penalty and presence_penalty differ?**

**A:**
- **Frequency penalty:** Proportional to token count. Penalizes "very very very" (repeated words).
- **Presence penalty:** Binary (0 or 1). Penalizes any token that's appeared, encourages topic diversity.

Use frequency for word-level repetition, presence for topic-level diversity.

---

# Quick Reference

## OOPs in 30 Seconds
- **Encapsulation:** Bundle data + methods, hide with `_` or `__`
- **Inheritance:** `class Child(Parent)`, use `super()`
- **Polymorphism:** Same interface, different implementations (override methods)
- **Abstraction:** `ABC` + `@abstractmethod`
- **Magic:** `__init__`, `__str__`, `__len__`, `__getitem__`
- **Property:** `@property` for getters, `@x.setter` for setters

## Transformers in 30 Seconds
- **Self-Attention:** Q·K^T / √d_k → softmax → × V
- **Multi-Head:** 8 heads learn different relationships, concatenate
- **Positional Encoding:** sin/cos to add position info
- **Encoder:** Bidirectional attention (BERT)
- **Decoder:** Causal attention (GPT)
- **Complexity:** O(n²) in sequence length

## LLM Parameters in 30 Seconds
- **Temperature:** 0=deterministic, 1=balanced, 2=random
- **Top-p:** Nucleus sampling (0.9 = top 90% probability mass)
- **Top-k:** Fixed k tokens (less adaptive than top-p)
- **Frequency:** Penalize repeated tokens (count-based)
- **Presence:** Penalize used topics (binary)
- **Max tokens:** Output length limit
- **Stop:** Stop sequences for format control
