n = 5

def fib(n):
    if n == 0:
        return 1
    return fib(n - 1) + fib(n - 2)

print(fib(n))

def iter(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a
print(iter(n))


## 2 

def iter(n):
    if n == 1:
        return 1
    return n * iter(n - 1)
print(iter(n))

#palindrome check 


def is_palindrome(s):
    return s == s[::-1]
print(is_palindrome("madam"))

def anagram(s1):
    low = s1.lower()
    freq= {}

    for i in s1:
        freq[i] = freq.get(i,0) + 1
    
    return freq

d1 = anagram("Listen")
d2 = anagram("Silent")

print(d1 == d2)



s="leetcode"

def first_unique_char(s):
    freq= {}
    for i in s:
     freq[i] = freq.get(i,0) + 1
    for i,j in freq.items():
        if j == 1:
            return s.index(i)
    
    

first_unique_char(s)

##one mroe new problem i am addinga ctually see 


a= "aaabbcdd"

# result should be of   a3b2cd2

count = 0
res=""
for i in range(len(a)):
    if a[i] != a[i-1]:
        res.append(a[i-1] + str(count))
        count = 0
    else:
        count += 1
print(res)


## power is like we can make use of the math  and perform math.pow(x,n)




    