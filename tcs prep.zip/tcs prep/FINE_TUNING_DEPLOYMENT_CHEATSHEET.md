# Fine-Tuning & Deployment - TCS Interview Prep

## 📚 Table of Contents
1. [Training Setup (Modern 2025)](#training-setup)
2. [Docker Containers](#docker-containers)
3. [Vertex AI Custom Job](#vertex-ai-custom-job)
4. [Deployment Pipeline](#deployment-pipeline)
5. [Key Concepts](#key-concepts)

---

## Training Setup

### 1. Quantization Config (4-bit with BitsAndBytes)
```python
from transformers import BitsAndBytesConfig

def setup_quantization_config():
    return BitsAndBytesConfig(
        load_in_4bit=True,                    # Enable 4-bit quantization
        bnb_4bit_quant_type="nf4",           # NF4 (Normal Float 4-bit)
        bnb_4bit_compute_dtype=torch.float16, # Compute in fp16 for speed
        bnb_4bit_use_double_quant=True       # Double quantization (saves more memory)
    )
```

**Why?** Reduces 7B model from 14GB → 3.5GB (fits on T4 GPU)

### 2. LoRA Config
```python
from peft import LoraConfig

def setup_lora_config():
    return LoraConfig(
        r=16,                                # Rank (low-rank dimension)
        lora_alpha=32,                       # Scaling factor (32/16 = 2x)
        target_modules=["q_proj", "v_proj"], # Only adapt query & value projections
        lora_dropout=0.05,                   # 5% dropout for regularization
        bias="none",                         # Don't adapt bias terms
        task_type="CAUSAL_LM"                # Causal language modeling
    )
```

**Why?**
- Only ~10M trainable params (0.14% of 7B model)
- `r=16`: Lower rank = fewer params but still effective
- `alpha=32`: 2x scaling amplifies LoRA's contribution
- Only Q/V: More efficient than adapting all 4 projections (Q/K/V/O)

### 3. Training Arguments
```python
from transformers import TrainingArguments

def setup_training_arguments():
    return TrainingArguments(
        output_dir="./results",
        num_train_epochs=3,                   # Full passes through dataset
        per_device_train_batch_size=4,        # 4 samples per GPU
        gradient_accumulation_steps=2,        # Effective batch = 4 * 2 = 8
        learning_rate=2e-4,                   # Higher for LoRA (2e-4 vs 5e-5)
        fp16=True,                            # Mixed precision (faster + less memory)
        logging_steps=10,                     # Log every 10 steps
        save_strategy="epoch",                # Save checkpoint each epoch
        warmup_steps=10,                      # LR warmup for stability
        optim="paged_adamw_8bit",            # 8-bit Adam (saves memory)
        max_grad_norm=0.3,                   # Gradient clipping
    )
```

**Key Points:**
- **Gradient Accumulation:** Simulates larger batch without OOM (4 batches → 1 update)
- **fp16:** Uses half precision (2 bytes vs 4 bytes per number)
- **paged_adamw_8bit:** Adam optimizer with 8-bit states (saves 75% memory)

### 4. Complete Training Script
```python
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer
from trl import SFTTrainer

# Load model with quantization
model = AutoModelForCausalLM.from_pretrained(
    "mistralai/Mistral-7B-v0.1",
    quantization_config=setup_quantization_config(),
    device_map="auto"
)

# Load tokenizer
tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-v0.1")
tokenizer.pad_token = tokenizer.eos_token

# Load dataset (messages format)
dataset = load_dataset("json", data_files="train.jsonl")

# Train with SFTTrainer (automatically applies LoRA)
trainer = SFTTrainer(
    model=model,
    args=setup_training_arguments(),
    train_dataset=dataset["train"],
    peft_config=setup_lora_config(),  # LoRA applied here
    tokenizer=tokenizer,
    max_seq_length=512,
    packing=False,
    dataset_text_field="messages"     # For chat format
)

trainer.train()
trainer.save_model("./trained_model")  # Saves LoRA adapter only
```

---

## Docker Containers

### Training Container (Dockerfile)
```dockerfile
FROM nvidia/cuda:11.8.0-cudnn8-devel-ubuntu22.04

# Install Python
RUN apt-get update && apt-get install -y python3.10 python3-pip

# Install ML libraries
RUN pip install torch==2.0.1 \
    transformers==4.36.0 \
    peft==0.7.1 \
    trl==0.7.4 \
    bitsandbytes==0.41.3 \
    datasets==2.16.0 \
    accelerate==0.25.0

# Copy training script
COPY train_docker.py /app/train.py
WORKDIR /app

# Entry point
CMD ["python3", "train.py"]
```

**Build & Push:**
```bash
docker build -t gcr.io/PROJECT_ID/mistral-trainer:latest .
docker push gcr.io/PROJECT_ID/mistral-trainer:latest
```

### Serving Container (Dockerfile)
```dockerfile
FROM python:3.10-slim

# Install FastAPI + ML libraries
RUN pip install fastapi==0.109.0 \
    uvicorn==0.27.0 \
    transformers==4.36.0 \
    peft==0.7.1 \
    torch==2.0.1 \
    google-cloud-storage==2.14.0

# Copy serving code
COPY predict.py /app/predict.py
WORKDIR /app

# Expose port
EXPOSE 8080

# Start FastAPI server
CMD ["uvicorn", "predict:app", "--host", "0.0.0.0", "--port", "8080"]
```

**predict.py (FastAPI Server):**
```python
from fastapi import FastAPI
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer
from google.cloud import storage
import os

app = FastAPI()

model = None
tokenizer = None

def download_model_from_gcs():
    """Download trained LoRA adapter from GCS"""
    client = storage.Client()
    bucket = client.bucket("your-bucket")
    blobs = bucket.list_blobs(prefix="trained_models/")
    
    os.makedirs("/app/model", exist_ok=True)
    for blob in blobs:
        filename = blob.name.split("/")[-1]
        blob.download_to_filename(f"/app/model/{filename}")

def load_model():
    """Load base model + LoRA adapter"""
    global model, tokenizer
    
    # Load base model
    base_model = AutoModelForCausalLM.from_pretrained(
        "mistralai/Mistral-7B-v0.1",
        device_map="auto"
    )
    
    # Apply LoRA adapter
    model = PeftModel.from_pretrained(base_model, "/app/model")
    tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-v0.1")

@app.on_event("startup")
async def startup():
    """Download and load model on container start"""
    download_model_from_gcs()
    load_model()

@app.get("/health")
def health():
    return {"status": "healthy", "model_loaded": model is not None}

@app.post("/predict")
async def predict(request: dict):
    """Generate prediction"""
    instances = request.get("instances", [])
    inputs = tokenizer(instances[0]["ticket"], return_tensors="pt")  # Returns dict: {"input_ids": ..., "attention_mask": ...}
    outputs = model.generate(**inputs, max_new_tokens=100)  # ** unpacks dict to keyword args
    prediction = tokenizer.decode(outputs[0], skip_special_tokens=True)  # Convert token IDs back to text
    return {"predictions": [prediction]}
```

**Build via Cloud Build (cloudbuild.yaml):**
```yaml
steps:
  - name: 'gcr.io/cloud-builders/docker'
    args: ['build', '-t', 'gcr.io/$PROJECT_ID/mistral-serve:latest', '.']
  - name: 'gcr.io/cloud-builders/docker'
    args: ['push', 'gcr.io/$PROJECT_ID/mistral-serve:latest']
```

---

## Vertex AI Custom Job

### Worker Pool Specs Structure
```python
from google.cloud import aiplatform

aiplatform.init(
    project="your-project-id",
    location="us-central1",
    staging_bucket="gs://your-bucket"
)

worker_pool_specs = [
    {
        "machine_spec": {
            "machine_type": "n1-standard-4",     # 4 vCPUs, 15GB RAM
            "accelerator_type": "NVIDIA_TESLA_T4", # T4 GPU (16GB VRAM)
            "accelerator_count": 1
        },
        "replica_count": 1,  # Single worker
        "container_spec": {
            "image_uri": "gcr.io/PROJECT_ID/mistral-trainer:latest",
            "command": ["python3", "train.py"],
            "args": [
                "--model_name=mistralai/Mistral-7B-v0.1",
                "--dataset_path=gs://bucket/train.jsonl",
                "--output_path=gs://bucket/trained_models/"
            ]
        },
        "disk_spec": {
            "boot_disk_type": "pd-ssd",
            "boot_disk_size_gb": 100
        }
    }
]
```

### Submit Custom Job
```python
job = aiplatform.CustomJob(
    display_name="mistral-7b-lora-training",
    worker_pool_specs=worker_pool_specs,
    base_output_dir="gs://your-bucket/vertex-ai-jobs"
)

# Submit job (async)
job.run(sync=False)

# Or wait for completion
job.run(sync=True)  # Blocks until done
```

**Cost:** T4 GPU: ~$0.35/hour, n1-standard-4: ~$0.19/hour
**Training Time:** 15-20 minutes = **~$0.50-0.70 total**

---

## Deployment Pipeline

### Step 1: Upload Model to Registry
```python
from google.cloud import aiplatform

model = aiplatform.Model.upload(
    display_name="mistral-7b-it-support",
    description="Mistral 7B fine-tuned for IT support",
    serving_container_image_uri="gcr.io/PROJECT_ID/mistral-serve:latest",
    serving_container_health_route="/health",
    serving_container_predict_route="/predict",
    serving_container_ports=[8080]
)
```

### Step 2: Create Endpoint
```python
endpoint = aiplatform.Endpoint.create(
    display_name="mistral-it-support-endpoint",
    description="Production endpoint for IT ticket routing"
)
```

### Step 3: Deploy Model to Endpoint
```python
model.deploy(
    endpoint=endpoint,
    deployed_model_display_name="mistral-v1",
    machine_type="n1-standard-4",
    accelerator_type="NVIDIA_TESLA_T4",
    accelerator_count=1,
    min_replica_count=1,
    max_replica_count=3,  # Auto-scaling
    traffic_percentage=100
)
```

### Step 4: Call Endpoint
```python
# From application code
endpoint = aiplatform.Endpoint("projects/123/locations/us-central1/endpoints/456")

response = endpoint.predict(instances=[
    {"ticket": "My laptop won't turn on"}
])

print(response.predictions[0])
```

**Architecture:**
```
User/UI → Vertex AI Endpoint (public) → FastAPI Container (private)
          [Auth, Load Balancing, Scaling]    [Model Inference]
```

---

## Key Concepts

### Attention Mechanism (Q, K, V)
```python
# Input embedding: [batch, seq_len, d_model]
Q = input @ W_q  # Query: "What am I looking for?"
K = input @ W_k  # Key: "What do I contain?"
V = input @ W_v  # Value: "What information do I carry?"

# Compute attention scores
scores = (Q @ K.T) / sqrt(d_k)  # [batch, seq_len, seq_len]
attention_weights = softmax(scores)  # Normalize to probabilities

# Weighted sum of values
output = attention_weights @ V  # [batch, seq_len, d_model]
```

**Why K Transpose?**
- Q shape: [seq_len, d_k]
- K shape: [seq_len, d_k]
- Need: [seq_len, seq_len] similarity matrix
- Solution: Q @ K.T produces [seq_len, seq_len]

### LoRA Math
```
Original: h = W_pretrained @ x
LoRA: h = (W_pretrained + α/r * B @ A) @ x

Where:
- W_pretrained: Frozen [d_out, d_in] (e.g., 4096 x 4096)
- A: Trainable [r, d_in] (e.g., 16 x 4096)
- B: Trainable [d_out, r] (e.g., 4096 x 16)
- α: Scaling factor (32)
- r: Rank (16)
```

**Trainable Params:**
- Original: 4096 × 4096 = 16.7M params
- LoRA: (16 × 4096) + (4096 × 16) = 131K params (100x reduction!)

### 4-bit Quantization (NF4)
```
Original: float32 (4 bytes per number)
Quantized: 4 bits (0.5 bytes per number)
Savings: 8x compression

NF4 (Normal Float 4-bit):
- 16 values optimally distributed for normal distribution
- Block-wise quantization (groups of 64 values)
- Double quantization: Quantize the quantization scales too!

Memory: 7B params × 4 bytes = 28GB → 7B × 0.5 bytes = 3.5GB
```

---

## Training Data Format (Messages)
```json
{"messages": [
  {"role": "system", "content": "You are an IT support assistant."},
  {"role": "user", "content": "My laptop won't turn on"},
  {"role": "assistant", "content": "Priority: P2\nCategory: Hardware\nAssign: Hardware Team"}
]}
```

---

## Common Interview Questions

**Q: Why LoRA instead of full fine-tuning?**
A: LoRA trains only ~0.1% of params (10M vs 7B), saves memory, faster training, prevents catastrophic forgetting, easy to swap adapters.

**Q: Why 4-bit quantization?**
A: Reduces memory from 28GB → 3.5GB, enables training on consumer GPUs (T4), minimal accuracy loss (<1% typically).

**Q: What's gradient accumulation?**
A: Simulates larger batch size by accumulating gradients over multiple small batches before updating weights. Example: batch_size=4, accumulation=2 → effective_batch=8.

**Q: Why two separate Docker images?**
A: Training needs CUDA, full ML stack (5GB+ image), runs once. Serving needs only inference libs, FastAPI (smaller, faster startup), runs continuously.

**Q: How does Vertex AI endpoint work?**
A: User calls public Vertex AI endpoint → Vertex AI forwards to private FastAPI container → Container loads model and predicts → Response flows back. Vertex AI handles auth, scaling, monitoring.

**Q: What's the cost difference: full fine-tuning vs LoRA?**
A: Full fine-tuning needs A100 (40GB VRAM, $2.50/hr, 2-4 hrs) = $5-10. LoRA on T4 (16GB, $0.35/hr, 0.25 hr) = $0.50. **10-20x cheaper**.

---

## Quick Reference Commands

```bash
# Build training container
docker build -t gcr.io/PROJECT_ID/trainer:latest -f Dockerfile.train .
docker push gcr.io/PROJECT_ID/trainer:latest

# Build serving container
gcloud builds submit --config cloudbuild.yaml

# Submit training job
python submit_vertex_training.py

# Deploy to endpoint
python deploy_endpoint.py

# Test endpoint
curl -X POST \
  https://us-central1-aiplatform.googleapis.com/v1/projects/PROJECT/locations/us-central1/endpoints/ENDPOINT_ID:predict \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -d '{"instances": [{"ticket": "Test"}]}'
```

---

**Total Time:** Training (15-20 min) + Deployment (5-10 min) = **~25-30 minutes** end-to-end  
**Total Cost:** Training ($0.50) + Serving ($0.54/hr for 1 replica) = **Very affordable for experimentation**

Good luck with your TCS interview! 🚀



"BLEU measures precision - how many generated words are correct. It penalizes adding extra words, making it ideal for translation. ROUGE measures recall - how much of the reference content is captured. It's better for summarization where you want to ensure key information isn't missed. For text generation, I often use both plus custom metrics like exact match to get a complete picture."


