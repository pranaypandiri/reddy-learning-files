# RAGAS Cheatsheet - Production Ready

## Quick Install
```bash
pip install ragas datasets
```

## 1. Basic RAGAS Evaluation (Remember This)

```python
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy, context_recall
from datasets import Dataset

# Your RAG outputs
data = {
    "question": ["What is the refund policy?"],
    "answer": ["Full refund within 30 days of purchase"],
    "contexts": [["Company policy: Full refund available within 30 days"]],
}

# Evaluate
dataset = Dataset.from_dict(data)
result = evaluate(dataset, metrics=[faithfulness, answer_relevancy, context_recall])

print(result)
# {'faithfulness': 1.0, 'answer_relevancy': 0.98, 'context_recall': 1.0}
```

---

## 2. Key Metrics (Interview-Ready)

| Metric | Needs Ground Truth? | What It Checks | Interview Pitch |
|--------|---------------------|----------------|-----------------|
| **Faithfulness** | ❌ NO | Answer grounded in contexts? | "Prevents hallucinations" |
| **Answer Relevancy** | ❌ NO | Answer addresses question? | "Ensures on-topic responses" |
| **Context Recall** | ✅ YES | Retrieved all needed info? | "Measures retrieval completeness" |
| **Context Precision** | ✅ YES | Relevant chunks ranked high? | "Optimizes retrieval ranking" |

---

## 3. Production Example - Batch 100+ Records

```python
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy, context_recall
from datasets import Dataset

# Load 100 RAG interactions from logs/DB
data = {
    "question": [
        "What is the refund policy?",
        "How long does shipping take?",
        # ... 98 more questions
    ],
    "answer": [
        "Full refund within 30 days",
        "Shipping takes 3-5 business days",
        # ... 98 more answers
    ],
    "contexts": [
        ["Policy: 30-day refund"],
        ["Standard shipping: 3-5 days"],
        # ... 98 more context lists
    ],
}

# Evaluate all 100 at once
dataset = Dataset.from_dict(data)
result = evaluate(dataset, metrics=[faithfulness, answer_relevancy, context_recall])

# Aggregated scores across 100 records
print(result)
# {'faithfulness': 0.92, 'answer_relevancy': 0.88, 'context_recall': 0.95}

# Per-record breakdown
df = result.to_pandas()
print(df.head())
```

---

## 4. With Ground Truth (For Test Datasets)

```python
# Add ground_truth for context recall/precision
data = {
    "question": ["What is the refund policy?"],
    "answer": ["Full refund within 30 days"],
    "contexts": [["Policy: 30-day money back guarantee"]],
    "ground_truth": ["30 days full refund available"]  # ✅ Human-written reference
}

dataset = Dataset.from_dict(data)
result = evaluate(
    dataset, 
    metrics=[faithfulness, answer_relevancy, context_recall, context_precision]
)
```

**When to use ground truth:**
- Initial testing on curated dataset
- Benchmarking retrieval quality
- A/B testing different RAG configurations

**Production (no ground truth):**
- Real-time monitoring with faithfulness + answer_relevancy
- LLM-as-judge evaluates without reference answers

---

## 5. Production Monitoring Setup

```python
def monitor_rag_quality(user_query, retrieved_docs, llm_response):
    """Real-time quality check on RAG outputs"""
    
    eval_data = {
        "question": [user_query],
        "answer": [llm_response],
        "contexts": [retrieved_docs]  # List of retrieved doc chunks
    }
    
    dataset = Dataset.from_dict(eval_data)
    score = evaluate(
        dataset, 
        metrics=[faithfulness, answer_relevancy]
    )
    
    # Alert if quality drops
    if score['faithfulness'] < 0.8:
        log_alert("Potential hallucination detected", score)
    
    if score['answer_relevancy'] < 0.7:
        log_alert("Irrelevant answer", score)
    
    return score

# Use in your API
@app.post("/chat")
async def chat_endpoint(query: str):
    retrieved = vector_search(query)
    response = llm_generate(query, retrieved)
    
    # Async evaluation (non-blocking)
    asyncio.create_task(monitor_rag_quality(query, retrieved, response))
    
    return {"response": response}
```

---

## 6. How RAGAS Works (LLM-as-Judge)

### Without Ground Truth:
```python
# Faithfulness check (behind the scenes)
prompt = f"""
Context: {contexts}
Answer: {answer}

Is the answer fully supported by the context?
Rate 0-1 where 1 = fully supported, 0 = hallucination
"""
# LLM judges → faithfulness score
```

### With Ground Truth:
```python
# Context Recall check
prompt = f"""
Ground Truth: {ground_truth}
Retrieved Contexts: {contexts}

Do the contexts contain all information needed to produce the ground truth?
Rate 0-1 where 1 = all info present
"""
# LLM judges → context_recall score
```

---

## 7. Interview Answer Template

**Q: "How do you evaluate your RAG system?"**

**A:** "I use RAGAS for automated evaluation with three key metrics:

1. **Faithfulness** - Ensures answers are grounded in retrieved context, preventing hallucinations. I set alerts if it drops below 0.8.

2. **Answer Relevancy** - Checks if responses actually address the user's question. Uses LLM-as-judge for semantic understanding.

3. **Context Recall** - Measures retrieval completeness on test datasets with ground truth.

In production, I batch-evaluate 100+ interactions weekly to track quality trends. For real-time monitoring, I use faithfulness and answer relevancy since they don't require ground truth. When faithfulness drops, I investigate chunk size, embedding model drift, or LLM temperature issues."

---

## 8. Quick Decision Tree

```
Do you have ground truth?
├─ NO (Production) 
│  └─ Use: faithfulness + answer_relevancy
│     → LLM-as-judge, no reference needed
│
└─ YES (Test Dataset)
   └─ Use: all 4 metrics (faithfulness, answer_relevancy, 
                           context_recall, context_precision)
      → Benchmark retrieval quality
```

---

## 9. Common Issues & Solutions

| Issue | Metric That Catches It | Solution |
|-------|------------------------|----------|
| Hallucinations | Faithfulness < 0.8 | Check chunk relevance, lower LLM temp |
| Off-topic answers | Answer Relevancy < 0.7 | Improve query understanding, reranking |
| Missing info | Context Recall < 0.8 | Increase top_k, check chunking strategy |
| Irrelevant chunks | Context Precision < 0.7 | Improve embedding model, add filters |

---

## 10. Main Syntax to Remember

```python
# The only 4 lines you need to remember:
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy
dataset = Dataset.from_dict(data)  # data = {question, answer, contexts}
result = evaluate(dataset, metrics=[faithfulness, answer_relevancy])
```

---

## 11. Custom Prompt Syntax

```python
from ragas import evaluate
from ragas.metrics import faithfulness
from ragas.llms import LangchainLLMWrapper
from langchain_google_vertexai import ChatVertexAI

# Custom LLM with custom evaluation instructions
custom_llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    temperature=0,
    system_instruction="You are a strict evaluator. Be harsh in judgments."
)

# Wrap for RAGAS
ragas_llm = LangchainLLMWrapper(custom_llm)

# Use custom LLM for evaluation
result = evaluate(dataset, metrics=[faithfulness], llm=ragas_llm)
```

---

## 12. Custom Metric Syntax

```python
from ragas.metrics.base import MetricWithLLM, SingleTurnMetric
from ragas.llms import LangchainLLMWrapper
from langchain_google_vertexai import ChatVertexAI

# Define custom metric
class MyCustomMetric(MetricWithLLM, SingleTurnMetric):
    name = "my_metric"  # Shows in results
    
    def __init__(self):
        super().__init__()  # Gets self.llm from parent
    
    def _score(self, row):
        # ⭐ MOST IMPORTANT METHOD - This runs for each evaluation
        # Access data: row["question"], row["answer"], row["contexts"]
        prompt = f"Evaluate: {row['answer']}\nReturn score 0-1"
        response = self.llm.generate_text(prompt)
        return float(response.strip())  # Must return float 0-1

# Setup LLM
llm = ChatVertexAI(model="gemini-2.0-flash-exp")
ragas_llm = LangchainLLMWrapper(llm)

# Create and attach LLM
custom_metric = MyCustomMetric()
custom_metric.llm = ragas_llm

# Use it
result = evaluate(dataset, metrics=[custom_metric])
# Output: {'my_metric': 0.85}
```

---

## 13. Override Faithfulness Metric

```python
from ragas.metrics import Faithfulness
from ragas import evaluate

# Create faithfulness instance
custom_faithfulness = Faithfulness()

# Override the internal prompt (advanced)
custom_faithfulness.nli_statements_message = """
Given context and answer, extract factual claims.

Context: {context}
Answer: {answer}

Rules for Banking Domain:
- Be EXTRA strict with numbers
- Dates must match exactly
- No approximations allowed

Extract claims:
1. [claim]
2. [claim]
"""

# Use modified faithfulness
result = evaluate(
    dataset, 
    metrics=[custom_faithfulness],
    llm=ragas_llm  # Your custom LLM
)
```

**Key Points:**
- `_score(self, row)` = Core method, runs for each data row
- Must return `float` between 0-1
- `row` contains: `question`, `answer`, `contexts`, `ground_truth` (optional)
- Override `nli_statements_message` to customize faithfulness prompts

---

## 14. LangSmith Custom Evaluator Syntax

```python
from langsmith.evaluation import evaluate, LangSmithRunEvaluator
from langsmith.schemas import Run, Example

# Define custom evaluator
class MyEvaluator(LangSmithRunEvaluator):
    def evaluate_run(self, run: Run, example: Example) -> dict:
        """
        ⭐ MAIN METHOD - Evaluates one trace
        run.outputs = Your LLM's response {"output": "answer"}
        example.inputs = User's question {"input": "question"}
        example.outputs = Ground truth (optional)
        """
        question = example.inputs.get("input", "")
        answer = run.outputs.get("output", "")
        
        # Your evaluation logic
        score = 1.0 if len(answer) > 10 else 0.5
        
        # Must return dict with "key" and "score"
        return {
            "key": "my_metric",  # Metric name
            "score": score,      # Float 0-1
            "comment": "Optional feedback"
        }

# Your function to evaluate
def my_rag(inputs: dict) -> dict:
    question = inputs["input"]
    answer = f"Answer to: {question}"
    return {"output": answer}

# Run evaluation on dataset
results = evaluate(
    my_rag,                           # Your function
    data="dataset-name",              # Dataset in LangSmith
    evaluators=[MyEvaluator()],       # Your evaluators
    project_name="evaluation-project" # Project name
)

print(results)  # {'my_metric': 0.85}
```

**Key Points:**
- `evaluate_run(run, example)` = Main method, returns dict
- Must return `{"key": "name", "score": 0.9}`
- `run.outputs` = Your function's output
- `example.inputs` = Input to your function
- LangSmith does NOT run evaluations automatically - YOU schedule them

---

## 15. LangSmith Tracing Syntax

```python
from langsmith import traceable
import os

# Setup (required once)
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "lsv2_pt_your_key"
os.environ["LANGCHAIN_PROJECT"] = "production"

# Trace any function
@traceable(project="production")  # Optional: override project
def my_rag(question: str) -> str:
    # Auto-traces: inputs, outputs, latency, errors
    contexts = search(question)
    answer = generate(contexts)
    return answer

@traceable  # Nested functions also traced
def search(query: str):
    return ["context1", "context2"]

@traceable
def generate(contexts: list):
    return "Generated answer"

# Usage - traces appear in LangSmith UI automatically
result = my_rag("What is Python?")
```

**Key Points:**
- `@traceable` = Decorator that logs to LangSmith
- Requires env vars: `LANGCHAIN_TRACING_V2=true`, `LANGCHAIN_API_KEY`
- Each call = New trace ID (unique per request)
- Nested functions = Nested spans in UI
- Async, non-blocking (~50ms overhead)

---

## 16. Create Dataset from Traces

```python
from langsmith import Client
from datetime import datetime, timedelta

# Initialize client
client = Client()

# Pull traces from last hour
runs = client.list_runs(
    project_name="production",           # Your project
    start_time=datetime.now() - timedelta(hours=1),  # Last hour
    end_time=datetime.now(),             # Until now (optional)
    limit=100,                           # Max 100 runs
    filter='eq(status, "success")'       # Only successful runs
)

# Create dataset from those runs
dataset = client.create_dataset_from_runs(
    dataset_name=f"hourly-eval-{datetime.now().isoformat()}",
    runs=runs,
    description="Last hour's production traces"
)

# Now use dataset in evaluation
from langsmith.evaluation import evaluate

results = evaluate(
    my_rag,
    data=dataset,  # ← Dataset created from traces
    evaluators=[MyEvaluator()]
)
```

**Key Points:**
- `client.list_runs()` = Pull traces by time/project/filter
- `start_time` / `end_time` = Time range for traces
- `limit` = Max number of runs to pull
- `filter` = Query string (e.g., `'eq(status, "success")'`)
- `client.create_dataset_from_runs()` = Convert traces to dataset
- Dataset can then be used in `evaluate()`

**That's it!** 🎯
