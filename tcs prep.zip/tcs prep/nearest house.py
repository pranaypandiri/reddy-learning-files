h = [8, 6, 2]

w = [2, 1, 2]

p = [1, 4, 12]


def near(h, w, p):
    map = {h[i]: w[i] for i in range(len(h))}
    dis = []
    h.sort()

    p.sort()
    for i in p:
        low = 0
        high = len(h) - 1
        while low < high:
            mid = low + (high - low) // 2
            if h[mid] < i:
                low = mid + 1
            else:
                high = mid
        
        high = low + map[h[low]]

        if i >= h[low] and i <= high:
            dis.append(0)
        elif i < h[low]:
            dis.append(h[low] - i)
        else:
            dis.append(i - high)
    return sum(dis)


x = near(h, w, p)
print(x)




##


def near_two_pointer_optimized(h, w, p):
    # Sort houses by start position and people by location
    houses = sorted([(h[i], h[i] + w[i]) for i in range(len(h))])
    people = sorted(p)
    
    total_dist = 0
    h_idx = 0
    num_houses = len(houses)
    
    for person in people:
        # 1. Move pointer to the furthest house that starts at or before the person
        while h_idx + 1 < num_houses and houses[h_idx + 1][0] <= person:
            h_idx += 1
        
        # 2. Check the "current" best candidate
        start, end = houses[h_idx]
        if person <= end:
            # Person is inside the house or to the left of the start (if loop didn't run)
            d = max(0, start - person) 
        else:
            # Person is to the right of this house
            d = person - end
            
        # 3. Check the "next" house if it exists (it might be closer to the person's right)
        if h_idx + 1 < num_houses:
            next_start = houses[h_idx + 1][0]
            d = min(d, max(0, next_start - person))
            
        total_dist += d
        
    return total_dist

