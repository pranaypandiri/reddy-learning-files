import heapq

list = [1, 2, 3, 6, 2, 1, 9, 5, 1, 5, 6, 23, 0, 1, -6, 1]


freq = {}
for i in list:
    freq[i] = freq.get(i, 0) + 1
print(freq)

result = heapq.nlargest(2, freq, key=freq.get)
## nlogk 

print(result[1])