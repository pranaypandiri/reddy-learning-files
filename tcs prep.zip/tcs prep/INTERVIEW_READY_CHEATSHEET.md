# 🎯 NumPy & Pandas - Interview Ready Cheatsheet
**Production-Grade Reference | Tiger Analytics / Product Companies**

---

## 📌 Quick Navigation
- [NumPy Essentials](#numpy-essentials)
- [Pandas Core Operations](#pandas-core-operations)
- [The Axis Confusion - SOLVED](#the-axis-confusion)
- [Common Interview Patterns](#common-interview-patterns)
- [One-Liners You Need](#one-liners-you-need)

---

# 🔢 NUMPY ESSENTIALS

## Array Creation (The Big 4)
```python
import numpy as np

np.zeros((3, 4))           # 3×4 matrix of zeros
np.ones((2, 3))            # 2×3 matrix of ones
np.arange(0, 10, 2)        # [0,2,4,6,8] - excludes 10
np.linspace(0, 10, 5)      # [0, 2.5, 5, 7.5, 10] - includes 10
```
**Remember:** `arange` excludes end, `linspace` includes end

## Reshaping
```python
arr.reshape(3, 4)          # Total elements must match!
arr.reshape(-1, 1)         # Auto-calculate: crucial for sklearn
arr.flatten()              # Returns copy (safe)
arr.ravel()                # Returns view (fast but changes affect original)
arr.T                      # Transpose: rows ↔ columns
```

## Boolean Indexing (Interview Favorite!)
```python
arr[arr > 5]                           # Values greater than 5
arr[(arr >= 10) & (arr <= 20)]         # Between 10 and 20 (use &, not 'and')
arr[~(arr > 5)]                        # NOT greater than 5 (use ~)
```
**Gotcha:** Use `&` `|` `~` for boolean operations, NOT `and` `or` `not`

## Broadcasting - The Magic
```python
# Rule: Compare shapes RIGHT to LEFT
# Dimensions compatible if: equal OR one of them is 1

matrix = np.array([[1,2,3], [4,5,6]])  # (2, 3)
vector = np.array([10, 20, 30])        # (3,)
result = matrix + vector               # vector broadcasts to each row
# [[11,22,33], [14,25,36]]
```

**Broadcasting Formula:**
```
Compare shapes RIGHT → LEFT:
- Each dimension must be EQUAL OR one must be 1
- Missing dimensions treated as 1

Example checks:
(3, 4) + (4,)     →  (3, 4) + (1, 4)  ✅  [4==4, 3 vs 1 OK]
(3, 4) + (3, 1)   →  (3, 4) + (3, 1)  ✅  [4 vs 1 OK, 3==3]
(3, 4) + (3,)     →  (3, 4) + (1, 3)  ❌  [4≠3, FAIL!]
```

**Valid Examples:**
- `(3, 4) + (4,)` ✅ - `(4,)` becomes `(1,4)` then stretches
- `(3, 4) + (3, 1)` ✅ - `(3,1)` stretches to `(3,4)`
- `(3, 4) + (3,)` ❌ - Cannot align! (4≠3)

## Element-wise vs Matrix Multiplication
```python
# Element-wise (use *)
arr1 * arr2                # [1,2,3] * [4,5,6] = [4,10,18]
# Rule: Shapes must match (or broadcast)

# Matrix multiplication (use @)
A @ B                      # (m,n) @ (n,p) → (m,p)
np.dot(A, B)              # Same as @
```

**Matrix Multiplication Formula:**
```
(m, n) @ (n, p) → (m, p)
     ↑     ↑
     └─────┘  These INNER dimensions MUST MATCH!

Example:
(3, 4) @ (4, 2) → (3, 2)  ✅  [Inner 4==4]
(3, 4) @ (3, 2) → ERROR   ❌  [Inner 4≠3]
```

**Interview Rules:** 
- `*` for element-wise (shapes must match or broadcast)
- `@` for matrix multiplication (inner dimensions must match)

## Aggregations & The Axis Rule
```python
arr.sum(axis=0)            # Sum each COLUMN (collapse rows ↓)
arr.sum(axis=1)            # Sum each ROW (collapse columns →)
arr.mean(), arr.std()      # Mean, standard deviation
arr.std(ddof=1)            # Sample std (divide by n-1)
arr.argmax(), arr.argmin() # Index of max/min
```

## Statistical Operations
```python
np.cov(x, y)               # Covariance matrix
np.corrcoef(x, y)          # Correlation matrix
np.percentile(arr, 25)     # 25th percentile
np.random.seed(42)         # Always set for reproducibility!
np.random.permutation(100) # Shuffle indices for train-test split
```

---

# 🐼 PANDAS CORE OPERATIONS

## DataFrame Creation
```python
import pandas as pd

# From dict (most common)
df = pd.DataFrame({'A': [1,2,3], 'B': [4,5,6]})

# From list of dicts (API responses)
df = pd.DataFrame([{'name': 'Alice', 'age': 25}, {'name': 'Bob', 'age': 30}])

# Read files
df = pd.read_csv('data.csv')
df = pd.read_json('data.json')
```

## The Big 4: loc vs iloc vs at vs iat
```python
# loc - LABEL based (use names)
df.loc[0]                          # Row by label
df.loc[0:3, 'A':'C']              # BOTH ends INCLUSIVE

# iloc - INTEGER POSITION based
df.iloc[0]                         # First row
df.iloc[0:3, 0:2]                 # End EXCLUSIVE (like Python)

# at - FAST single value (label)
df.at[0, 'A']                     # Fastest for single value

# iat - FAST single value (position)
df.iat[0, 1]                      # Fastest for single position
```
**Memory Trick:** `loc` = **L**abels, `iloc` = **i**nteger locations

## Boolean Filtering (Production Pattern)
```python
# Basic
df[df['age'] > 25]

# Multiple conditions (use & | ~)
df[(df['age'] > 25) & (df['salary'] > 50000)]

# SQL-like syntax (cleaner!)
df.query('age > 25 and salary > 50000')
df.query('age > @threshold')      # Use external variable with @

# Check membership
df[df['city'].isin(['NYC', 'LA', 'Chicago'])]

# Range filtering
df[df['age'].between(25, 35)]
```

## Missing Data - The Right Way
```python
# Detect
df.isna().sum()                   # Count missing per column

# Fill strategically
df.fillna(0)                      # Simple fill
df.fillna(df.mean())             # Fill with mean
df.fillna({'A': 0, 'B': df['B'].median()})  # Different per column
df.fillna(method='ffill')         # Forward fill
df['A'].interpolate()             # Smart interpolation

# Drop
df.dropna()                       # Drop rows with ANY missing
df.dropna(axis=1)                 # Drop COLUMNS with missing
df.dropna(how='all')              # Drop only if ALL are missing
```

## GroupBy - Interview Powerhouse
```python
# Basic
df.groupby('dept')['salary'].mean()

# Multiple aggregations
df.groupby('dept').agg(['mean', 'sum', 'count'])
df.groupby('dept').agg({'salary': 'sum', 'age': 'mean'})

# transform - KEEP SAME SHAPE (crucial!)
df['dept_avg'] = df.groupby('dept')['salary'].transform('mean')

# filter - Filter entire groups
df.groupby('dept').filter(lambda x: len(x) > 5)  # Keep depts with >5 people
```
**Interview Tip:** `transform()` keeps original DataFrame shape - use for adding group stats!

## Merging - SQL in Pandas
```python
# Inner join (only matching)
pd.merge(df1, df2, on='key')

# Left join (all from left)
pd.merge(df1, df2, on='key', how='left')

# Multiple keys
pd.merge(df1, df2, on=['key1', 'key2'])

# Different column names
pd.merge(df1, df2, left_on='id', right_on='employee_id')
```

**When to use what:**
- `merge()` → When you have a COMMON KEY (like SQL)
- `concat()` → When STACKING similar data (same columns, different rows)

## String Operations (NLP Preprocessing)
```python
df['col'].str.lower()              # Lowercase
df['col'].str.strip()              # Remove whitespace
df['col'].str.replace('old', 'new')
df['col'].str.contains('text')     # Check if contains
df['col'].str.split()              # Split into list
df['col'].str.split().str[0]       # Get first word
df['col'].str.len()                # String length

# NLP cleaning pipeline
df['clean'] = (df['text']
    .str.lower()
    .str.replace(r'[^\w\s]', '', regex=True)  # Remove punctuation
    .str.strip()
    .str.replace(r'\s+', ' ', regex=True))    # Remove extra spaces
```

## Time Series Operations
```python
# Convert to datetime (FIRST STEP!)
df['date'] = pd.to_datetime(df['date'])

# Extract components
df['year'] = df['date'].dt.year
df['month'] = df['date'].dt.month
df['day_name'] = df['date'].dt.day_name()
df['quarter'] = df['date'].dt.quarter

# Set as index (required for resampling!)
df.set_index('date', inplace=True)

# Resample (downsample to lower frequency)
df.resample('W').sum()             # Weekly sum
df.resample('M').mean()            # Monthly average
df.resample('D').agg(['sum', 'mean'])

# Rolling windows (moving average)
df['MA_7'] = df['price'].rolling(7).mean()
df['rolling_sum'] = df['value'].rolling(3).sum()
```

## Apply, Map, Lambda - The Transformers
```python
# apply on Series
df['col'].apply(lambda x: x * 2)
df['col'].apply(str.upper)

# apply on DataFrame (axis matters!)
df.apply(np.sum, axis=0)           # Apply to each COLUMN
df.apply(np.sum, axis=1)           # Apply to each ROW

# map - Dictionary mapping (Series only!)
df['grade'].map({'A': 90, 'B': 80, 'C': 70})

# Custom function on multiple columns
df.apply(lambda row: row['A'] + row['B'], axis=1)
```

---

# ⚡ THE AXIS CONFUSION - SOLVED

## For Aggregations (mean, sum, std)
```python
# axis=0 → Collapse DOWN rows → Result per COLUMN
df.mean(axis=0)                    # Mean of each column

# axis=1 → Collapse ACROSS columns → Result per ROW  
df.mean(axis=1)                    # Mean of each row
```

**Visual:**
```
Data:
     Col0  Col1  Col2
Row0  10    20    30
Row1  40    50    60
Row2  70    80    90

axis=0 (↓): [40, 50, 60]  ← One per COLUMN
axis=1 (→): [20, 50, 80]  ← One per ROW
```

## For Drop Operations
```python
df.dropna(axis=0)                  # Drop ROWS with missing
df.dropna(axis=1)                  # Drop COLUMNS with missing
```

**Memory Trick:**
- **Aggregations:** axis = dimension that **DISAPPEARS**
- **Drop:** axis = **WHAT** you're dropping (0=rows, 1=columns)

---

# 🎯 COMMON INTERVIEW PATTERNS

## Pattern 1: Train-Test Split
```python
from sklearn.model_selection import train_test_split

X = df[['feature1', 'feature2']].values
y = df['target'].values

# Must reshape if single feature!
if X.ndim == 1:
    X = X.reshape(-1, 1)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
```

## Pattern 2: Classification Predictions
```python
from sklearn.linear_model import LogisticRegression

model = LogisticRegression()
model.fit(X_train, y_train)

# Get class labels
y_pred = model.predict(X_test)     # [0, 1, 1, 0, ...]

# Get probabilities (for ROC-AUC!)
y_proba = model.predict_proba(X_test)        # [[0.8, 0.2], [0.3, 0.7], ...]
y_proba_class1 = y_proba[:, 1]               # Get positive class probs
```
**Interview Rule:** Use `predict_proba()[:, 1]` for ROC-AUC and confidence scores!

## Pattern 3: Feature Normalization
```python
# Column-wise (per feature) - ML Standard
feature_means = df.mean(axis=0)
normalized = df - feature_means    # broadcasts correctly!

# Min-Max scaling (0-1 range)
normalized = (df - df.min()) / (df.max() - df.min())

# Z-score normalization
normalized = (df - df.mean()) / df.std()
```

## Pattern 4: Handle Outliers (Z-Score Method)

**The Bell Curve Rule:**
```
Normal Distribution (Bell Curve):
       
       │      99.7% of data
   ┌───┴───┐
   │       │    95% of data
 ┌─┴─┐   ┌─┴─┐
 │   │68%│   │
 │   │of │   │
─┴───┴───┴───┴─
-3σ -2σ  μ +2σ +3σ

μ = mean, σ = std deviation
Data beyond ±3σ = OUTLIERS (0.3% of data)
```

**Z-Score Formula:** $z = \frac{x - \mu}{\sigma}$
- Measures "how many standard deviations away from mean"
- z > 3 or z < -3 → Outlier!

```python
# Example with actual data
df = pd.DataFrame({
    'salary': [50000, 52000, 51000, 48000, 200000, 49000, 53000]
})
#                                       ↑ This is outlier!

# Step 1: Calculate z-scores
mean = df['salary'].mean()          # 71857
std = df['salary'].std()            # 55392
z_scores = (df['salary'] - mean) / std

print(z_scores)
# Output: [-0.39, -0.36, -0.38, -0.43, 2.31, -0.41, -0.34]
#                                      ↑ Only this > 3 is outlier

# Step 2: Detect outliers (|z| > 3)
outliers = np.abs(z_scores) > 3
print(df[outliers])  # Shows salary=200000

# Step 3: Handle outliers
# Option 1: Replace with median
df.loc[outliers, 'salary'] = df['salary'].median()

# Option 2: Remove completely
df_clean = df[~outliers]

# Option 3: Cap at percentiles (IQR method)
q1 = df['salary'].quantile(0.25)
q3 = df['salary'].quantile(0.75)
iqr = q3 - q1
lower = q1 - 1.5 * iqr
upper = q3 + 1.5 * iqr
df['salary'] = df['salary'].clip(lower, upper)
```

**Interview Answer:**
- "I use z-score method: calculate standard deviations from mean"
- "Values beyond ±3σ are outliers (0.3% in normal distribution)"
- "Replace with median (robust) or remove based on business context"

## Pattern 5: Top N per Group
```python
# Get top 3 salaries per department
df.groupby('dept')['salary'].nlargest(3)

# Or with ranking
df['rank'] = df.groupby('dept')['salary'].rank(ascending=False)
top_3 = df[df['rank'] <= 3]
```

## Pattern 6: Cumulative Percentage
```python
df = df.sort_values('sales', ascending=False)
df['cumsum'] = df['sales'].cumsum()
df['cum_pct'] = (df['cumsum'] / df['sales'].sum()) * 100
```

## Pattern 7: Date Range Filtering
```python
# Method 1: Boolean mask
mask = (df['date'] >= '2024-01-01') & (df['date'] <= '2024-12-31')
df_2024 = df[mask]

# Method 2: With datetime index
df['2024-01']                      # All of January 2024
df['2024-01':'2024-06']           # Jan to June 2024
```

## Pattern 8: Pivot for Analysis
```python
# Sales by product and region
pivot = pd.pivot_table(
    df, 
    values='sales', 
    index='date', 
    columns='product',
    aggfunc='sum'
)

# Cross-tabulation (frequency)
pd.crosstab(df['category'], df['status'])
```

---

# 💡 ONE-LINERS YOU NEED

```python
# Quick stats
df.describe()                                  # All statistics at once
df['col'].value_counts()                       # Frequency distribution
df['col'].nunique()                            # Count unique values

# Remove duplicates
df.drop_duplicates(subset=['key'])

# Sort
df.sort_values(['col1', 'col2'], ascending=[False, True])

# Rename columns
df.rename(columns={'old': 'new'})

# Reset index
df.reset_index(drop=True)

# Change data types
df['col'].astype(int)
pd.to_numeric(df['col'], errors='coerce')     # Invalid → NaN

# Sample data
df.sample(100)                                 # Random 100 rows
df.sample(frac=0.1)                           # 10% random sample

# Quick correlation
df.corr()                                      # Correlation matrix
df['A'].corr(df['B'])                         # Between two columns
```

---

# ⚠️ GOTCHAS & COMMON MISTAKES

## NumPy
❌ **Wrong:** `arr[(arr > 10) and (arr < 20)]`  
✅ **Right:** `arr[(arr > 10) & (arr < 20)]`

❌ **Wrong:** `arr.reshape(3, 5)` when arr has 12 elements  
✅ **Right:** Total elements must match: 3×5=15 ≠ 12

❌ **Wrong:** Using `*` for matrix multiplication  
✅ **Right:** Use `@` or `np.dot()` for matrix operations

## Pandas
❌ **Wrong:** `df[df['col'] > 10 and df['col'] < 20]`  
✅ **Right:** `df[(df['col'] > 10) & (df['col'] < 20)]`

❌ **Wrong:** Resampling without datetime index  
✅ **Right:** Always `df.set_index('date')` first!

❌ **Wrong:** `df.dropna()` loses all your data  
✅ **Right:** Check with `df.isna().sum()` first, then choose strategy

❌ **Wrong:** Forgetting to reshape for sklearn  
✅ **Right:** `X = X.reshape(-1, 1)` for single feature

---

# 🚀 PRODUCTION BEST PRACTICES

## Data Loading
```python
# Always specify dtypes for large files
df = pd.read_csv('data.csv', dtype={'id': str, 'amount': float})

# Parse dates on load
df = pd.read_csv('data.csv', parse_dates=['date_col'])

# Handle encoding issues
df = pd.read_csv('data.csv', encoding='utf-8')
```

## Memory Optimization
```python
# Check memory usage
df.memory_usage(deep=True)

# Optimize dtypes
df['int_col'] = df['int_col'].astype('int32')    # Instead of int64
df['cat_col'] = df['cat_col'].astype('category') # For categorical data
```

## Chaining Operations (Clean Code)
```python
# Good: Method chaining
result = (df
    .query('age > 25')
    .groupby('dept')
    .agg({'salary': 'mean'})
    .sort_values('salary', ascending=False)
    .head(10)
)
```

## Vectorization (Speed!)
```python
# ❌ Slow: iterrows
for idx, row in df.iterrows():
    df.at[idx, 'new_col'] = row['A'] + row['B']

# ✅ Fast: Vectorized
df['new_col'] = df['A'] + df['B']
```

---

# 📊 FORMULAS REFERENCE

## Statistics
- **Variance:** $\sigma^2 = \frac{1}{n}\sum(x_i - \mu)^2$
- **Standard Deviation:** $\sigma = \sqrt{\sigma^2}$
- **Covariance:** $\text{Cov}(X,Y) = \frac{1}{n}\sum(x_i - \bar{x})(y_i - \bar{y})$
- **Correlation:** $r = \frac{\text{Cov}(X,Y)}{\sigma_X \sigma_Y}$

## Z-Score Normalization
$$z = \frac{x - \mu}{\sigma}$$

## Min-Max Normalization
$$x_{norm} = \frac{x - x_{min}}{x_{max} - x_{min}}$$

---

# 🎓 INTERVIEW CHEAT CODES

**When asked "How do you...?"**

1. **Handle missing data?**  
   → Check with `isna().sum()`, decide strategy (fill, drop, interpolate), document why

2. **Deal with outliers?**  
   → Z-score method (>3 std devs), replace with median or IQR method

3. **Normalize features?**  
   → Column-wise: `(df - df.mean()) / df.std()` for z-score

4. **Split train-test?**  
   → `train_test_split()` with `random_state=42` for reproducibility

5. **Handle imbalanced classes?**  
   → Check class distribution, use stratified split, consider SMOTE

6. **Optimize memory?**  
   → Use appropriate dtypes, category for strings, int32 vs int64

7. **Speed up operations?**  
   → Vectorize instead of loops, use query(), avoid iterrows()

**When asked "What's the difference...?"**

- **loc vs iloc:** Labels vs positions
- **merge vs concat:** Key-based join vs stacking
- **apply vs map:** Functions vs dictionary mapping
- **`*` vs `@`:** Element-wise vs matrix multiplication
- **axis=0 vs axis=1:** Collapse rows vs collapse columns

---

# ✅ FINAL CHECKLIST

Before your interview, make sure you can:
- [ ] Explain broadcasting with an example
- [ ] Use loc/iloc correctly
- [ ] Handle missing data strategically
- [ ] Explain axis=0 vs axis=1
- [ ] Use groupby with transform()
- [ ] Merge dataframes on keys
- [ ] Apply functions with lambda
- [ ] Work with datetime data
- [ ] Normalize features for ML
- [ ] Reshape arrays for sklearn
- [ ] Get probabilities from classification models
- [ ] Use boolean indexing with & | ~

---

**Good luck! You got this! 🎯**

*Remember: They're not testing if you memorize every function. They're testing if you understand the concepts and can solve real problems!*
