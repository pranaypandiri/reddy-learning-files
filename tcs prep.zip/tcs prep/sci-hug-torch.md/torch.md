# 🔥 PyTorch - Super Simple Explanation

## 💡 What is PyTorch?
A library to build and train neural networks (AI models). Think of it as Lego blocks for AI.

---

## 🎯 The 2 Most Important Things

### 1. Forward Pass (Getting Predictions)
```python
import torch
import torch.nn as nn

# Define a simple model
class SimpleModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.layer1 = nn.Linear(10, 5)   # 10 inputs → 5 outputs
        self.relu = nn.ReLU()
        self.layer2 = nn.Linear(5, 2)    # 5 inputs → 2 outputs
    
    def forward(self, x):
        x = self.layer1(x)    # Apply first layer
        x = self.relu(x)       # Activation
        x = self.layer2(x)     # Apply second layer
        return x

# Use it
model = SimpleModel()
x = torch.randn(1, 10)  # 1 sample, 10 features

# Forward pass
output = model(x)
print(output)  # tensor([[0.23, -0.15]])
```

**What happens:** Input → Layer1 → ReLU → Layer2 → Output

---

### 2. Backward Pass (Training the Model)
```python
import torch.optim as optim

# Model, loss, optimizer
model = SimpleModel()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Training data
x = torch.randn(5, 10)                 # 5 samples, 10 features
y = torch.tensor([0, 1, 0, 1, 1])      # True labels

# THE 5-STEP TRAINING LOOP:
for epoch in range(10):
    # 1. Forward pass (get predictions)
    outputs = model(x)
    
    # 2. Calculate loss (how wrong we are)
    loss = criterion(outputs, y)
    
    # 3. Zero gradients (clear old calculations)
    optimizer.zero_grad()
    
    # 4. Backward pass (calculate how to improve)
    loss.backward()
    
    # 5. Update weights (make model better)
    optimizer.step()
    
    print(f"Epoch {epoch+1}, Loss: {loss.item():.4f}")
```

**What happens:**
- Forward → See how wrong we are
- Backward → Calculate how to fix it
- Step → Actually fix it

---

## 🧊 Using torch.no_grad() for Inference

```python
# When you just want predictions (not training)
model.eval()  # Set to evaluation mode

with torch.no_grad():  # Don't calculate gradients (saves memory)
    x_test = torch.randn(3, 10)
    predictions = model(x_test)
    print(predictions)
```

**Why use `torch.no_grad()`?**
- Saves memory (doesn't track gradients)
- Faster (no backward calculations)
- Use it when you're NOT training (just predicting)

---

## 📊 Key Concepts

| Term | Simple Explanation |
|------|-------------------|
| **nn.Module** | Base class for ALL models (always inherit from this) |
| **forward()** | Defines how data flows through model |
| **backward()** | Calculates gradients (how to improve weights) |
| **optimizer.step()** | Updates weights using gradients |
| **optimizer.zero_grad()** | Clears old gradients (must do before backward!) |
| **model.train()** | Training mode (enables dropout, etc.) |
| **model.eval()** | Evaluation mode (disables dropout) |
| **torch.no_grad()** | Don't calculate gradients (for inference) |

---

## �� Complete Example (Forward + Backward)

```python
import torch
import torch.nn as nn
import torch.optim as optim

# 1. Define model
class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(20, 10)
        self.fc2 = nn.Linear(10, 2)
    
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# 2. Create model, loss, optimizer
model = Net()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 3. Training data
X_train = torch.randn(100, 20)
y_train = torch.randint(0, 2, (100,))

# 4. Training loop
for epoch in range(20):
    model.train()  # Training mode
    
    # Forward
    outputs = model(X_train)
    loss = criterion(outputs, y_train)
    
    # Backward
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    
    if (epoch + 1) % 5 == 0:
        print(f"Epoch {epoch+1}, Loss: {loss.item():.4f}")

# 5. Inference (no_grad)
model.eval()
with torch.no_grad():
    X_test = torch.randn(5, 20)
    predictions = model(X_test)
    predicted_classes = torch.argmax(predictions, dim=1)
    print(f"Predictions: {predicted_classes}")
```

---

## 💬 Interview Questions

**Q: What's the difference between forward and backward pass?**  
A: Forward = get predictions, Backward = calculate how to improve weights

**Q: Why do we need optimizer.zero_grad()?**  
A: PyTorch accumulates gradients. Must clear before each backward pass.

**Q: When do you use torch.no_grad()?**  
A: During inference (prediction) when you don't need gradients

**Q: What's the 5-step training loop?**  
A:
1. Forward pass
2. Calculate loss
3. Zero gradients
4. Backward pass
5. Update weights

**Q: What does loss.backward() do?**  
A: Calculates gradients (how each weight should change to reduce loss)

---

## ✅ What You MUST Know for TCS

1. **Forward pass**: Input → Layers → Output
2. **Backward pass**: Calculate gradients with `loss.backward()`
3. **5-step training loop** (forward → loss → zero_grad → backward → step)
4. **torch.no_grad()**: Use for inference
5. **model.train() vs model.eval()**: Training vs inference mode
