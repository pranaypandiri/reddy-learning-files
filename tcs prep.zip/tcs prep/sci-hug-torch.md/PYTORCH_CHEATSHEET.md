# 🔥 PyTorch Cheatsheet - Simple & Production Ready

## 1️⃣ Build a Neural Network

```python
import torch
import torch.nn as nn
import torch.optim as optim

# Define model
class SimpleNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(SimpleNN, self).__init__()
        self.layer1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.layer2 = nn.Linear(hidden_size, output_size)
    
    def forward(self, x):
        x = self.layer1(x)
        x = self.relu(x)
        x = self.layer2(x)
        return x

# Create model
model = SimpleNN(input_size=10, hidden_size=20, output_size=2)
```

**Key points:**
- `nn.Module` - Base class for ALL neural networks
- `__init__()` - Define layers here
- `forward()` - Define how data flows through layers
- `super().__init__()` - Must call parent class constructor

---

## 2️⃣ Forward Pass (Prediction)

```python
# Create sample data
x = torch.randn(5, 10)  # 5 samples, 10 features each

# Forward pass
model.eval()  # Set to evaluation mode
with torch.no_grad():  # Disable gradient calculation
    output = model(x)

print(output.shape)  # torch.Size([5, 2])
```

**What happens:**
```
Input (5, 10) → Layer1 (10, 20) → ReLU → Layer2 (20, 2) → Output (5, 2)
```

---

## 3️⃣ Backward Pass (Training) - THE MAGIC ✨

```python
# Training mode
model.train()

# Sample data
x = torch.randn(5, 10)
y = torch.tensor([0, 1, 0, 1, 1])  # True labels

# Define loss and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# ONE TRAINING STEP:
# 1. Forward pass
outputs = model(x)

# 2. Calculate loss
loss = criterion(outputs, y)

# 3. Zero gradients (important!)
optimizer.zero_grad()

# 4. Backward pass (calculate gradients)
loss.backward()

# 5. Update weights
optimizer.step()

print(f"Loss: {loss.item():.4f}")
```

**The 5-step training loop:**
1. **Forward** - Get predictions
2. **Loss** - Compare predictions to true labels
3. **Zero grad** - Clear old gradients
4. **Backward** - Calculate gradients (how to improve)
5. **Step** - Update weights using gradients

---

## 4️⃣ Complete Training Loop

```python
# Data
X_train = torch.randn(100, 10)  # 100 samples, 10 features
y_train = torch.randint(0, 2, (100,))  # Binary labels

# Model, loss, optimizer
model = SimpleNN(10, 20, 2)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Training loop
epochs = 50
for epoch in range(epochs):
    model.train()  # Training mode
    
    # Forward
    outputs = model(X_train)
    loss = criterion(outputs, y_train)
    
    # Backward
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    
    # Print progress
    if (epoch + 1) % 10 == 0:
        print(f"Epoch [{epoch+1}/{epochs}], Loss: {loss.item():.4f}")

# Evaluation
model.eval()
with torch.no_grad():
    outputs = model(X_train)
    _, predicted = torch.max(outputs, 1)
    accuracy = (predicted == y_train).sum().item() / len(y_train)
    print(f"Accuracy: {accuracy:.2%}")
```

---

## 5️⃣ Understanding Forward & Backward

### Forward Pass
```python
# What happens inside model(x):
x = torch.tensor([[1.0, 2.0, 3.0]])

# Layer 1
z1 = x @ layer1.weight.T + layer1.bias  # Linear transformation
a1 = torch.relu(z1)                      # Activation

# Layer 2
z2 = a1 @ layer2.weight.T + layer2.bias
output = z2

# This is what forward() does automatically
```

### Backward Pass
```python
# What happens inside loss.backward():
# PyTorch automatically calculates:
# ∂loss/∂weight1, ∂loss/∂weight2, ∂loss/∂bias1, ∂loss/∂bias2
# Using chain rule from calculus

# Then optimizer.step() updates:
# weight = weight - learning_rate * gradient
```

**In simple terms:**
- **Forward** = Calculate output from input
- **Backward** = Calculate how to adjust weights to reduce loss

---

## 6️⃣ Common Layers & Activations

```python
import torch.nn as nn

# Layers
nn.Linear(in_features, out_features)  # Fully connected layer
nn.Conv2d(in_channels, out_channels, kernel_size)  # For images
nn.LSTM(input_size, hidden_size)  # For sequences
nn.Dropout(p=0.5)  # Regularization

# Activations
nn.ReLU()       # f(x) = max(0, x)
nn.Sigmoid()    # f(x) = 1/(1 + e^-x)
nn.Tanh()       # f(x) = tanh(x)
nn.Softmax(dim=-1)  # Convert to probabilities

# Loss functions
nn.CrossEntropyLoss()  # For classification
nn.MSELoss()           # For regression
nn.BCELoss()           # Binary classification
```

---

## 7️⃣ Using Sequential (Quick Model Building)

```python
# Instead of defining a class, use Sequential
model = nn.Sequential(
    nn.Linear(10, 20),
    nn.ReLU(),
    nn.Linear(20, 5),
    nn.ReLU(),
    nn.Linear(5, 2)
)

# Use it the same way
output = model(x)
```

**When to use:**
- **Sequential** - Simple feedforward networks
- **Custom class** - When you need custom forward logic

---

## 8️⃣ Save & Load Models

```python
# Save model
torch.save(model.state_dict(), "model.pt")

# Load model
model = SimpleNN(10, 20, 2)
model.load_state_dict(torch.load("model.pt"))
model.eval()
```

**What is `state_dict()`?**
Dictionary containing all model weights and biases.

---

## 9️⃣ DataLoader & Dataset

```python
from torch.utils.data import Dataset, DataLoader

# Custom dataset
class MyDataset(Dataset):
    def __init__(self, X, y):
        self.X = X
        self.y = y
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

# Create dataset
dataset = MyDataset(X_train, y_train)

# Create dataloader (handles batching)
dataloader = DataLoader(
    dataset,
    batch_size=32,
    shuffle=True,
    num_workers=2
)

# Use in training
for epoch in range(epochs):
    for batch_x, batch_y in dataloader:
        # Forward
        outputs = model(batch_x)
        loss = criterion(outputs, batch_y)
        
        # Backward
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
```

---

## 🔟 Complete Production Example

```python
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_classification

# 1. Generate data
X, y = make_classification(n_samples=1000, n_features=20, n_classes=2)
X = torch.FloatTensor(X)
y = torch.LongTensor(y)

# 2. Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# 3. Create dataset and dataloader
class MyDataset(Dataset):
    def __init__(self, X, y):
        self.X = X
        self.y = y
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

train_dataset = MyDataset(X_train, y_train)
test_dataset = MyDataset(X_test, y_test)

train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

# 4. Define model
class Classifier(nn.Module):
    def __init__(self):
        super(Classifier, self).__init__()
        self.fc1 = nn.Linear(20, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 2)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.3)
    
    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.fc3(x)
        return x

model = Classifier()

# 5. Loss and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 6. Training loop
epochs = 20
for epoch in range(epochs):
    model.train()
    train_loss = 0
    
    for batch_x, batch_y in train_loader:
        # Forward
        outputs = model(batch_x)
        loss = criterion(outputs, batch_y)
        
        # Backward
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        train_loss += loss.item()
    
    # Evaluation
    model.eval()
    correct = 0
    total = 0
    
    with torch.no_grad():
        for batch_x, batch_y in test_loader:
            outputs = model(batch_x)
            _, predicted = torch.max(outputs, 1)
            total += batch_y.size(0)
            correct += (predicted == batch_y).sum().item()
    
    accuracy = 100 * correct / total
    avg_loss = train_loss / len(train_loader)
    
    print(f"Epoch [{epoch+1}/{epochs}], Loss: {avg_loss:.4f}, Accuracy: {accuracy:.2f}%")

# 7. Save model
torch.save(model.state_dict(), "classifier.pt")

# 8. Load and use
model_new = Classifier()
model_new.load_state_dict(torch.load("classifier.pt"))
model_new.eval()

with torch.no_grad():
    sample = X_test[0].unsqueeze(0)  # Add batch dimension
    output = model_new(sample)
    _, predicted = torch.max(output, 1)
    print(f"Prediction: {predicted.item()}")
```

---

## 📊 Key Concepts Summary

| Concept | What It Does |
|---------|-------------|
| **nn.Module** | Base class for all neural networks |
| **__init__()** | Define layers (Linear, ReLU, etc.) |
| **forward()** | Define how data flows through layers |
| **model.train()** | Enable training mode (dropout, batch norm active) |
| **model.eval()** | Enable evaluation mode (disable dropout, batch norm) |
| **loss.backward()** | Calculate gradients (how to improve weights) |
| **optimizer.step()** | Update weights using gradients |
| **optimizer.zero_grad()** | Clear old gradients before backward pass |
| **torch.no_grad()** | Disable gradient calculation (for inference) |
| **state_dict()** | Dictionary of model weights |

---

## 🎯 The 5-Step Training Process

```python
# Memorize this pattern:

# 1. Forward pass
outputs = model(X)

# 2. Calculate loss
loss = criterion(outputs, y)

# 3. Zero gradients
optimizer.zero_grad()

# 4. Backward pass
loss.backward()

# 5. Update weights
optimizer.step()
```

**This is the heart of PyTorch training!**

---

## 💡 Common Mistakes & Fixes

| Mistake | Fix |
|---------|-----|
| Forgot `optimizer.zero_grad()` | Gradients accumulate - always zero before backward |
| Forgot `model.eval()` | Dropout/BatchNorm behave differently in train vs eval |
| Forgot `torch.no_grad()` | Wastes memory tracking gradients during inference |
| Wrong loss function | Use `CrossEntropyLoss` for classification, `MSELoss` for regression |
| Forgot `super().__init__()` | Must call parent constructor in `__init__()` |

---

## 🚀 Interview Questions You Can Answer

**Q: What's the difference between forward and backward pass?**
- Forward = Calculate predictions from input
- Backward = Calculate gradients to update weights

**Q: What does `loss.backward()` do?**
- Calculates gradients using chain rule (how each weight affects loss)

**Q: Why do we need `optimizer.zero_grad()`?**
- PyTorch accumulates gradients. Must clear before each backward pass.

**Q: What's `state_dict()`?**
- Dictionary containing all model weights and biases

**Q: Difference between `model.train()` and `model.eval()`?**
- `train()` - Enables dropout, batch normalization
- `eval()` - Disables dropout, freezes batch normalization
