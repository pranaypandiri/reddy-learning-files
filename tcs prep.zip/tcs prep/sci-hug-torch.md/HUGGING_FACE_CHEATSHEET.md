# 🤗 Hugging Face Cheatsheet - Simple & Production Ready

## 1️⃣ Load Model & Tokenizer

```python
from transformers import AutoTokenizer, AutoModelForSequenceClassification

# Load tokenizer and model
tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
model = AutoModelForSequenceClassification.from_pretrained("distilbert-base-uncased")
```

**Key points:**
- `AutoTokenizer` - Converts text to numbers
- `AutoModelForSequenceClassification` - For classification (sentiment, spam, etc.)
- `AutoModelForCausalLM` - For text generation (GPT-style)
- `from_pretrained()` - Downloads from Hugging Face Hub

---

## 2️⃣ Tokenize Text (Give Data to Model)

```python
# Single text
text = "I love this product!"
inputs = tokenizer(text, return_tensors="pt")  # pt = PyTorch

# Multiple texts (batch)
texts = ["I love this!", "This is bad", "Okay product"]
inputs = tokenizer(
    texts,
    padding=True,        # Pad shorter sequences
    truncation=True,     # Cut longer sequences
    max_length=128,      # Max sequence length
    return_tensors="pt"
)

# What you get:
# inputs = {
#     'input_ids': tensor([[101, 2045, 102, 0],     # Token IDs
#                          [101, 2023, 2003, 102]]),
#     'attention_mask': tensor([[1, 1, 1, 0],       # 1=real, 0=padding
#                               [1, 1, 1, 1]])
# }
```

**Key outputs:**
- `input_ids` - Token numbers (the actual data)
- `attention_mask` - Which tokens are real (1) vs padding (0)

---

## 3️⃣ Inference (Get Predictions)

```python
import torch

# Forward pass
with torch.no_grad():  # Disable gradient calculation
    outputs = model(**inputs)

# Get predictions
logits = outputs.logits                      # Raw scores
probs = torch.softmax(logits, dim=-1)       # Convert to probabilities
predicted_class = torch.argmax(probs, dim=-1)  # Get class with highest prob

print(f"Logits: {logits}")
print(f"Probabilities: {probs}")
print(f"Predicted class: {predicted_class}")
```

**Output:**
```
Logits: tensor([[-0.5, 2.3]])
Probabilities: tensor([[0.06, 0.94]])
Predicted class: tensor([1])  # Class 1 = Positive
```

---

## 4️⃣ Pipeline API (Easiest Way)

```python
from transformers import pipeline

# One-liner for sentiment analysis
classifier = pipeline("sentiment-analysis")
result = classifier("I love this product!")
# Output: [{'label': 'POSITIVE', 'score': 0.9998}]

# Common pipelines
generator = pipeline("text-generation")
summarizer = pipeline("summarization")
qa = pipeline("question-answering")
```

**When to use:** Quick prototyping, demos, simple use cases

---

## 5️⃣ Datasets - Prepare Training Data

```python
from datasets import load_dataset, Dataset

# Load from Hugging Face Hub
dataset = load_dataset("imdb")  # Movie reviews dataset

# Or create your own
data = {
    'text': ['I love this!', 'Terrible product', 'It\'s okay'],
    'label': [1, 0, 1]  # 1=positive, 0=negative
}
dataset = Dataset.from_dict(data)

# Split into train/test
train_test = dataset.train_test_split(test_size=0.2)
train_dataset = train_test['train']
test_dataset = train_test['test']
```

---

## 6️⃣ Training Arguments - Set Up Training

```python
from transformers import TrainingArguments

args = TrainingArguments(
    output_dir="./results",          # Where to save model
    num_train_epochs=3,              # Number of training epochs
    per_device_train_batch_size=16,  # Batch size for training
    per_device_eval_batch_size=32,   # Batch size for evaluation
    learning_rate=2e-5,              # Learning rate
    weight_decay=0.01,               # Regularization
    logging_steps=100,               # Log every 100 steps
    evaluation_strategy="epoch",     # Evaluate after each epoch
    save_strategy="epoch",           # Save after each epoch
    load_best_model_at_end=True,     # Load best model at end
    push_to_hub=False,               # Don't push to Hugging Face Hub
)
```

**Most important args:**
- `output_dir` - Where to save
- `num_train_epochs` - How many times to go through data
- `per_device_train_batch_size` - How many samples per batch
- `learning_rate` - How fast the model learns (2e-5 is standard for fine-tuning)

---

## 7️⃣ Trainer - Train the Model

```python
from transformers import Trainer

# Initialize trainer
trainer = Trainer(
    model=model,                      # Your model
    args=args,                        # Training arguments from above
    train_dataset=train_dataset,      # Training data
    eval_dataset=test_dataset,        # Evaluation data
    tokenizer=tokenizer,              # Tokenizer (for preprocessing)
)

# Train
trainer.train()

# Evaluate
results = trainer.evaluate()
print(results)
# Output: {'eval_loss': 0.234, 'eval_accuracy': 0.91, ...}

# Save model
trainer.save_model("./my_model")
```

---

## 8️⃣ Evaluation - Check Performance

```python
# Evaluate on test set
results = trainer.evaluate()

# Manual evaluation
predictions = trainer.predict(test_dataset)
logits = predictions.predictions
labels = predictions.label_ids

# Calculate metrics
from sklearn.metrics import accuracy_score, f1_score

predicted_classes = logits.argmax(-1)
accuracy = accuracy_score(labels, predicted_classes)
f1 = f1_score(labels, predicted_classes, average='weighted')

print(f"Accuracy: {accuracy:.3f}")
print(f"F1 Score: {f1:.3f}")
```

---

## 9️⃣ Complete Training Example

```python
from transformers import (
    AutoTokenizer, AutoModelForSequenceClassification,
    TrainingArguments, Trainer
)
from datasets import load_dataset

# 1. Load data
dataset = load_dataset("imdb")
train_data = dataset['train'].shuffle().select(range(1000))  # 1000 samples
test_data = dataset['test'].shuffle().select(range(200))

# 2. Load model and tokenizer
tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
model = AutoModelForSequenceClassification.from_pretrained(
    "distilbert-base-uncased", 
    num_labels=2  # Binary classification
)

# 3. Tokenize data
def tokenize_function(examples):
    return tokenizer(
        examples['text'],
        padding='max_length',
        truncation=True,
        max_length=128
    )

train_data = train_data.map(tokenize_function, batched=True)
test_data = test_data.map(tokenize_function, batched=True)

# 4. Training arguments
args = TrainingArguments(
    output_dir="./results",
    num_train_epochs=3,
    per_device_train_batch_size=16,
    learning_rate=2e-5,
    evaluation_strategy="epoch",
    save_strategy="epoch",
)

# 5. Train
trainer = Trainer(
    model=model,
    args=args,
    train_dataset=train_data,
    eval_dataset=test_data,
    tokenizer=tokenizer,
)

trainer.train()

# 6. Evaluate
results = trainer.evaluate()
print(results)

# 7. Save
trainer.save_model("./sentiment_model")
```

---

## 🔟 Load Trained Model for Production

```python
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

# Load saved model
tokenizer = AutoTokenizer.from_pretrained("./sentiment_model")
model = AutoModelForSequenceClassification.from_pretrained("./sentiment_model")

# Use it
text = "This movie was amazing!"
inputs = tokenizer(text, return_tensors="pt")

with torch.no_grad():
    outputs = model(**inputs)
    probs = torch.softmax(outputs.logits, dim=-1)
    predicted = torch.argmax(probs).item()

print(f"Prediction: {'Positive' if predicted == 1 else 'Negative'}")
print(f"Confidence: {probs[0][predicted]:.2%}")
```

---

## 📊 Common Model Types

```python
# Classification (sentiment, spam detection)
from transformers import AutoModelForSequenceClassification
model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased")

# Text Generation (GPT-style)
from transformers import AutoModelForCausalLM
model = AutoModelForCausalLM.from_pretrained("gpt2")

# Question Answering
from transformers import AutoModelForQuestionAnswering
model = AutoModelForQuestionAnswering.from_pretrained("bert-large-uncased-whole-word-masking-finetuned-squad")

# Text2Text (T5, BART for summarization, translation)
from transformers import AutoModelForSeq2SeqLM
model = AutoModelForSeq2SeqLM.from_pretrained("t5-base")
```

---

## 💡 Key Concepts Summary

| Concept | What It Does |
|---------|-------------|
| **Tokenizer** | Converts text to numbers (`input_ids` and `attention_mask`) |
| **Model** | Neural network that processes tokens and outputs predictions |
| **Logits** | Raw scores from model (not probabilities yet) |
| **Softmax** | Converts logits to probabilities that sum to 1 |
| **Dataset** | Container for your data with text and labels |
| **TrainingArguments** | Configuration for training (epochs, batch size, learning rate) |
| **Trainer** | Handles the entire training loop automatically |
| **Pipeline** | One-liner to use models without manual tokenization |

---

## 🎯 Interview Questions You Can Answer

**Q: How do you load a pre-trained model?**
```python
from transformers import AutoModelForSequenceClassification
model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased")
```

**Q: What's the difference between logits and probabilities?**
- Logits = raw scores from model (can be any value)
- Probabilities = after softmax (between 0 and 1, sum to 1)

**Q: How do you prepare text for a model?**
```python
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
inputs = tokenizer(text, padding=True, truncation=True, return_tensors="pt")
```

**Q: What's the easiest way to use a model?**
```python
pipeline("sentiment-analysis")("I love this!")
```

**Q: How do you fine-tune a model?**
Use `Trainer` with `TrainingArguments` - it handles everything automatically.
