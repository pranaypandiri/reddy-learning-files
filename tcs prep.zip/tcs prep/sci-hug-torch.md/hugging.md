| Area | What to Know |
|------|--------------|
| **Pipeline API** | `pipeline("sentiment-analysis")`, `pipeline("text-generation")` |
| **Tokenizer** | `tokenizer(text, return_tensors="pt")`, `tokenizer.decode()` |
| **Model Loading** | `AutoModel.from_pretrained()`, `AutoTokenizer.from_pretrained()` |
| **Inference** | Forward pass, `model(**inputs)`, getting logits |
| **Fine-tuning concepts** | `Trainer`, `TrainingArguments`, `SFTTrainer` (you know this) |
| **Model Hub** | How to load models, what `model_id` means |

**Code you should know:**
```python
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification

# Easy way - Pipeline
classifier = pipeline("sentiment-analysis")
result = classifier("I love this product!")

# Manual way - Tokenizer + Model
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased")

inputs = tokenizer("Hello world", return_tensors="pt")
outputs = model(**inputs)
logits = outputs.logits
```

---

## 📋 Your Final Checklist (TCS 3.3 yrs level)

### Scikit-Learn (Must Know)
- [ ] LinearRegression - fit, predict, MSE
- [ ] LogisticRegression - fit, predict, accuracy
- [ ] train_test_split
- [ ] At least 3 metrics (accuracy, precision, recall OR MSE, MAE, R²)
- [ ] What is overfitting/underfitting (verbal answer)

### Hugging Face (Must Know)
- [ ] `pipeline()` for quick inference
- [ ] `AutoTokenizer` + `AutoModel` pattern
- [ ] Tokenizer encode/decode
- [ ] What are `input_ids`, `attention_mask`
- [ ] Difference between encoder (BERT) vs decoder (GPT) vs encoder-decoder (T5)
- [ ] What is fine-tuning vs prompt engineering vs RAG (you know this)

### Bonus (Good to Know)
- [ ] LoRA/QLoRA concept (parameter efficient fine-tuning)
- [ ] What is `Trainer` class
- [ ] Model quantization basics (4-bit, 8-bit)

---
Basic (Must Know)**
- [ ] `pipeline()` — sentiment, text-generation, summarization, QA
- [ ] `AutoTokenizer.from_pretrained()`
- [ ] `AutoModel.from_pretrained()`
- [ ] `AutoModelForSequenceClassification`, `AutoModelForCausalLM`
- [ ] Tokenizer: `tokenizer(text, return_tensors="pt")`
- [ ] Tokenizer output: `input_ids`, `attention_mask`
- [ ] `tokenizer.decode()` — convert back to text

**Intermediate (Should Know)**
- [ ] Padding & Truncation: `padding=True`, `truncation=True`, `max_length`
- [ ] Batch tokenization
- [ ] Model output: `logits`, `last_hidden_state`
- [ ] `torch.argmax()` on logits for prediction
- [ ] `torch.softmax()` for probabilities
- [ ] Model types: Encoder (BERT), Decoder (GPT), Encoder-Decoder (T5)

**Fine-tuning (Should Know Concepts)**
- [ ] `Trainer` and `TrainingArguments` classes
- [ ] `SFTTrainer` for supervised fine-tuning
- [ ] What is LoRA, QLoRA — parameter efficient fine-tuning
- [ ] When to fine-tune vs when to use RAG
- [ ] Dataset format for fine-tuning

**Edge (Impress Them)**
- [ ] `model.generate()` parameters: `max_length`, `temperature`, `top_p`, `top_k`
- [ ] What is `bitsandbytes` — quantization
- [ ] Loading models in 4-bit/8-bit
- [ ] `device_map="auto"` for multi-GPU
- [ ] Difference between `AutoModel` vs task-specific models
- [ ] Embedding extraction from models (for RAG)
- [ ] `SentenceTransformers` for embeddings








---------------------



Read [](file:///Users/ge20425940/Downloads/Agentic%20ai%20medium%20/tcs%20prep/sci-hug-torch.md/hugging.md)

Read [](file:///Users/ge20425940/Downloads/Agentic%20ai%20medium%20/tcs%20prep/sci-hug-torch.md/hugging.md#84-84), lines 84 to 84

Alright bro, let me break this down for you like we're sitting together with a whiteboard. This is your **Hugging Face study guide** for TCS interview - let's go deep on each concept.

---

## 🎯 THE BIG PICTURE - What is Hugging Face?

Think of Hugging Face as a **massive library of pre-trained AI models** + **tools to use them easily**. It's like GitHub but for AI models. Instead of writing a language model from scratch (which takes millions of dollars and months), you just download one and use it.

---

## 📚 PART 1: THE BASICS (Must Master These)

### 1. **Pipeline API - The Easiest Way**

**What it is:** A one-line solution to use AI models. You don't need to know tokenizers, models, tensors - nothing. Just tell it what you want.

```python
from transformers import pipeline

# Create a sentiment analyzer
classifier = pipeline("sentiment-analysis")
result = classifier("I love this product!")
# Output: [{'label': 'POSITIVE', 'score': 0.9998}]
```

**What's happening behind the scenes:**
1. Pipeline downloads a pre-trained model (like `distilbert`)
2. It downloads the tokenizer for that model
3. It converts your text to numbers (tokenization)
4. Runs it through the model
5. Gives you a human-readable answer

**Common pipeline types:**
- `"sentiment-analysis"` - Is text positive/negative?
- `"text-generation"` - Complete a sentence
- `"summarization"` - Make text shorter
- `"question-answering"` - Answer questions about a passage

**Interview question they might ask:** *"You need to quickly add sentiment analysis to a web app. What's the fastest way?"*
**Your answer:** Use pipeline API - one line, no model management needed.

---

### 2. **Tokenizer - Converting Text to Numbers**

**The problem:** AI models don't understand words. They only understand numbers.

**What a tokenizer does:** Breaks text into pieces (tokens) and converts each piece to a number.

```python
from transformers import AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")

# Convert text to numbers
inputs = tokenizer("Hello world", return_tensors="pt")
print(inputs)
# Output: {
#   'input_ids': tensor([[101, 7592, 2088, 102]]),
#   'attention_mask': tensor([[1, 1, 1, 1]])
# }
```

**Breaking it down:**
- `"Hello world"` → splits into: `[CLS] Hello world [SEP]`
- Each piece gets a number: `[101, 7592, 2088, 102]`
- `101` = special token "start of sentence"
- `102` = special token "end of sentence"
- `7592` = "hello", `2088` = "world"

**What is `input_ids`?** The actual numbers representing your text.

**What is `attention_mask`?** Tells the model which tokens to pay attention to (1 = real word, 0 = padding).

**Why do we need padding?** Models process batches. If you have sentences of different lengths, you pad shorter ones with zeros so they're all the same length.

```python
# Padding example
texts = ["Hello", "Hello world how are you"]
inputs = tokenizer(texts, padding=True, return_tensors="pt")
# First sentence gets padded with zeros to match second sentence length
```

**Decoding - Converting back to text:**
```python
token_ids = [7592, 2088]
text = tokenizer.decode(token_ids)
print(text)  # "hello world"
```

---

### 3. **Model Loading - Getting the AI Brain**

```python
from transformers import AutoModel, AutoTokenizer

# Load tokenizer and model together
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
model = AutoModel.from_pretrained("bert-base-uncased")
```

**What does `from_pretrained` do?**
1. Downloads the model from Hugging Face Hub
2. Loads the weights (the "learned knowledge")
3. Caches it locally so next time it's instant

**Different model types:**
- `AutoModel` - Generic, gives you embeddings (vectors)
- `AutoModelForSequenceClassification` - For classification tasks (sentiment, spam detection)
- `AutoModelForCausalLM` - For text generation (GPT-style)
- `AutoModelForQuestionAnswering` - For Q&A tasks

**Real example:**
```python
from transformers import AutoModelForSequenceClassification

# This model is ready to classify text into categories
model = AutoModelForSequenceClassification.from_pretrained(
    "distilbert-base-uncased-finetuned-sst-2-english"
)
# This specific model is fine-tuned for sentiment analysis
```

---

### 4. **Inference - Actually Using the Model**

```python
# Step 1: Tokenize
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
inputs = tokenizer("I love AI", return_tensors="pt")

# Step 2: Run through model
model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased")
outputs = model(**inputs)

# Step 3: Get predictions
logits = outputs.logits  # Raw scores
print(logits)  # tensor([[-0.2, 0.8]])

# Step 4: Convert to probabilities
import torch
probabilities = torch.softmax(logits, dim=-1)
print(probabilities)  # tensor([[0.25, 0.75]])

# Step 5: Get final prediction
prediction = torch.argmax(probabilities)
print(prediction)  # 1 (means positive sentiment)
```

**What are logits?** Raw, unnormalized scores. Think of them as "confidence before normalization".

**Why use softmax?** Converts logits to probabilities (numbers between 0 and 1 that sum to 1).

---

## 🚀 PART 2: MODEL ARCHITECTURES (Critical Understanding)

### **Encoder Models (BERT family)**

**Use case:** Understanding text, classification, named entity recognition

**How it works:** Looks at the entire sentence at once (bidirectional).

**Example:** "The bank by the river" - BERT understands "bank" means riverbank based on context.

**When to use:** Sentiment analysis, spam detection, entity extraction

### **Decoder Models (GPT family)**

**Use case:** Text generation

**How it works:** Looks at previous words only (left to right) to predict the next word.

**Example:** "Once upon a" → predicts "time"

**When to use:** Chatbots, story generation, code completion

### **Encoder-Decoder Models (T5, BART)**

**Use case:** Translation, summarization

**How it works:** Encoder reads the input, decoder generates the output.

**Example:** English text → Encoder understands it → Decoder generates French translation

---

## 🎓 PART 3: FINE-TUNING (Advanced But Important)

### **What is Fine-tuning?**

Taking a pre-trained model and training it more on your specific data.

**Example:** BERT knows English, but you fine-tune it on customer reviews to understand "product quality" better.

```python
from transformers import Trainer, TrainingArguments

training_args = TrainingArguments(
    output_dir="./results",
    num_train_epochs=3,
    per_device_train_batch_size=8,
    learning_rate=2e-5
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset
)

trainer.train()
```

### **LoRA & QLoRA - Smart Fine-tuning**

**The problem:** Fine-tuning a 7B parameter model needs 28GB of memory (4 bytes per parameter).

**LoRA solution:** Instead of updating all 7 billion parameters, only update a small "adapter" (maybe 1% of parameters).

**Benefits:**
- Uses 10x less memory
- Trains 3x faster
- Can swap adapters (one base model, multiple specialized versions)

**QLoRA:** LoRA + Quantization (store model in 4-bit instead of 32-bit). You can fine-tune a 13B model on a single GPU!

---

## 🔥 PART 4: ADVANCED CONCEPTS (To Impress)

### **Model Generation Parameters**

```python
model.generate(
    inputs,
    max_length=100,        # Stop after 100 tokens
    temperature=0.7,       # Creativity (0=deterministic, 1=creative, 2=random)
    top_p=0.9,             # Nucleus sampling (consider top 90% probable tokens)
    top_k=50,              # Consider only top 50 tokens
    do_sample=True         # Use sampling (random selection based on probabilities)
)
```

**Temperature explained:**
- 0.1 → "The cat sat on the mat" (boring but accurate)
- 1.0 → "The cat lounged on the mat" (balanced)
- 2.0 → "The purple elephant danced on clouds" (creative but weird)

### **Quantization - Making Models Smaller**

```python
from transformers import AutoModelForCausalLM
import torch

model = AutoModelForCausalLM.from_pretrained(
    "meta-llama/Llama-2-7b-hf",
    load_in_4bit=True,           # Use 4-bit quantization
    device_map="auto"            # Auto distribute across GPUs
)
```

**What it does:** Stores numbers in 4 bits instead of 32 bits. 8x smaller model! Small accuracy loss but huge memory savings.

---

## 🎯 INTERVIEW QUESTIONS THEY'LL ASK

**Q: When do you use fine-tuning vs RAG?**
**A:** 
- **RAG:** When you need to update knowledge frequently (news, documents). No training needed.
- **Fine-tuning:** When you need the model to learn a specific style, tone, or domain language (legal documents, medical reports).

**Q: What's the difference between BERT and GPT?**
**A:** BERT is bidirectional (sees whole sentence), best for understanding. GPT is unidirectional (left-to-right), best for generation.

**Q: How do you handle long documents that exceed token limits?**
**A:** 
1. Chunking (split into pieces)
2. Sliding window
3. Use models with longer context (Longformer, LED)
4. Summarize first, then process

---

Ready to dive deeper into any specific section? Let me know what you want to drill into!
