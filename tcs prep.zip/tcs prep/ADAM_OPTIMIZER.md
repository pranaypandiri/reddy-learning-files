# Adam Optimizer - TCS Interview Prep

## 🚀 What is Adam?

**Adam = Adaptive Moment Estimation**

The most popular optimizer for training neural networks, combining the best of:
- **Momentum** (accelerates in consistent directions)
- **RMSprop** (adapts learning rate per parameter)

---

## 📊 The Problem Adam Solves

### Plain SGD (Stochastic Gradient Descent)

```python
# Simple update rule:
weight = weight - learning_rate × gradient

# Issues:
# 1. Same learning rate for ALL parameters (inefficient)
# 2. Oscillates in valleys (wastes steps)
# 3. Slow convergence
```

**Example Problem:**
```
Loss landscape:
        ╱╲╱╲╱╲     ← Narrow valley
         ╲╱ ╲╱
          ●───     ← Goal

SGD path:
        ╱▶◀▶◀      ← Oscillates left-right
         ▼  ▼
          ●───     ← Takes forever!
```

### Adam Solution

```python
# Smart update rule:
weight = weight - (learning_rate × momentum) / sqrt(variance)

# Benefits:
# 1. Adaptive learning rate per parameter
# 2. Accelerates in consistent directions (momentum)
# 3. Dampens oscillations (variance control)
```

---

## 🧮 Adam Formula (Step by Step)

### Step 1: Calculate Momentum (First Moment)

```python
m_t = beta1 × m_{t-1} + (1 - beta1) × gradient_t
```

**What it does:** Smooth exponential moving average of gradients

**Default:** `beta1 = 0.9` (remembers 90% of past, adds 10% new)

**Intuition:** Like a ball rolling - builds up speed in consistent direction

---

### Step 2: Calculate Variance (Second Moment)

```python
v_t = beta2 × v_{t-1} + (1 - beta2) × gradient_t²
```

**What it does:** Tracks magnitude of gradient fluctuations

**Default:** `beta2 = 0.999` (remembers 99.9% of past, adds 0.1% new)

**Intuition:** Detects noisy/large gradients to slow down

---

### Step 3: Bias Correction

```python
m_hat = m_t / (1 - beta1^t)
v_hat = v_t / (1 - beta2^t)
```

**Why needed:** m and v are initialized to 0, causing initial bias

**Effect:** Corrects the values in early training steps

---

### Step 4: Update Weights

```python
weight = weight - learning_rate × m_hat / (sqrt(v_hat) + epsilon)
```

**epsilon:** Tiny number (1e-8) to prevent division by zero

---

## 🔢 Concrete Math Example

### Setup

```python
weight = 10.0          # Starting weight
target = 5.0           # Optimal weight
learning_rate = 0.1
beta1 = 0.9            # Momentum
beta2 = 0.99           # Variance  
epsilon = 1e-8

# Initialize
m = 0  # Momentum state
v = 0  # Variance state
```

---

### Training Steps

#### **Step 1: gradient = 5.0**

```python
# 1. Update momentum
m = 0.9 × 0 + 0.1 × 5.0 = 0.5

# 2. Update variance
v = 0.99 × 0 + 0.01 × (5.0)² = 0.01 × 25 = 0.25

# 3. Bias correction (t=1)
m_hat = 0.5 / (1 - 0.9¹) = 0.5 / 0.1 = 5.0
v_hat = 0.25 / (1 - 0.99¹) = 0.25 / 0.01 = 25.0

# 4. Calculate step
step = 0.1 × 5.0 / sqrt(25.0) = 0.5 / 5.0 = 0.1

# 5. Update weight
weight = 10.0 - 0.1 = 9.9
```

**Result:** Moved 0.1 units

---

#### **Step 2: gradient = 4.8** (same direction)

```python
# 1. Update momentum (building up!)
m = 0.9 × 0.5 + 0.1 × 4.8 = 0.45 + 0.48 = 0.93

# 2. Update variance
v = 0.99 × 0.25 + 0.01 × (4.8)² = 0.2475 + 0.2304 = 0.4779

# 3. Bias correction (t=2)
m_hat = 0.93 / (1 - 0.9²) = 0.93 / 0.19 = 4.89
v_hat = 0.4779 / (1 - 0.99²) = 0.4779 / 0.0199 = 24.0

# 4. Calculate step
step = 0.1 × 4.89 / sqrt(24.0) = 0.489 / 4.899 = 0.10

# 5. Update weight
weight = 9.9 - 0.10 = 9.80
```

**Result:** Momentum built up, step size similar (variance also increased)

---

#### **Step 3: gradient = 4.5** (still same direction)

```python
# 1. Momentum (continues building)
m = 0.9 × 0.93 + 0.1 × 4.5 = 0.837 + 0.45 = 1.287

# 2. Variance
v = 0.99 × 0.4779 + 0.01 × (4.5)² = 0.473 + 0.2025 = 0.6755

# 3. Bias correction (t=3)
m_hat = 1.287 / (1 - 0.9³) = 1.287 / 0.271 = 4.75
v_hat = 0.6755 / (1 - 0.99³) = 0.6755 / 0.0297 = 22.7

# 4. Calculate step
step = 0.1 × 4.75 / sqrt(22.7) = 0.475 / 4.765 = 0.10

# 5. Update weight
weight = 9.80 - 0.10 = 9.70
```

**Result:** Consistent progress, momentum accelerating

---

#### **Step 4: gradient = 15.0** (sudden spike! noisy gradient)

```python
# 1. Momentum (increases, but smoothed)
m = 0.9 × 1.287 + 0.1 × 15.0 = 1.158 + 1.5 = 2.658

# 2. Variance (JUMPS - detects large gradient!)
v = 0.99 × 0.6755 + 0.01 × (15.0)² = 0.669 + 2.25 = 2.919

# 3. Bias correction (t=4)
m_hat = 2.658 / (1 - 0.9⁴) = 2.658 / 0.3439 = 7.73
v_hat = 2.919 / (1 - 0.99⁴) = 2.919 / 0.0394 = 74.1

# 4. Calculate step (variance controls explosion!)
step = 0.1 × 7.73 / sqrt(74.1) = 0.773 / 8.61 = 0.09

# 5. Update weight
weight = 9.70 - 0.09 = 9.61
```

**Result:** Despite 3x larger gradient (15 vs 5), step size barely changed!
**Why:** Variance increased (2.919), which increased denominator (sqrt = 8.61), reducing effective learning rate

---

## 🎯 Key Insights

### 1. Momentum = Acceleration

```python
# When gradients point same direction (same sign):
Steps: [5.0, 4.8, 4.5, 4.2]  # All positive
Momentum: [0.5, 0.93, 1.29, 1.58]  # Builds up ↑

Effect: Accelerates in valleys, speeds up convergence
```

**Visual:**
```
Gradients agree: → → → →
Momentum builds: ━━▶━━━▶━━━━▶  (getting faster)
```

---

### 2. Variance = Brakes

```python
# When gradients are large or noisy:
Steps: [5.0, 4.8, 15.0]  # Sudden spike!
Variance: [0.25, 0.48, 2.92]  # Jumps ↑

Effect: Large variance → large denominator → smaller step
```

**Visual:**
```
Gradient spikes: → → ⚡
Variance increases: step = lr × m / sqrt(v↑)
Effective LR decreases: ━▶━━▶━▶  (slows down)
```

---

### 3. Per-Parameter Adaptation

```python
# Parameter A: Large gradients [10, 12, 11, 13]
v_A = high → sqrt(v_A) = large → effective_lr = small

# Parameter B: Small gradients [0.1, 0.12, 0.11, 0.09]
v_B = low → sqrt(v_B) = small → effective_lr = large

# Adam automatically gives:
# - Small steps to parameters with large gradients
# - Large steps to parameters with small gradients
```

---

## 🔧 Adam Variants

### AdamW (Adam with Weight Decay)

```python
# Regular Adam:
weight = weight - lr × m / sqrt(v)

# AdamW (YOUR CHOICE):
weight = weight - lr × m / sqrt(v) - lr × weight_decay × weight
                                      # ↑ Regularization term
```

**What's Weight Decay?**
- Regularization: pushes weights towards zero
- Prevents overfitting
- Standard for transformer models

**Example:**
```python
weight = 5.0
weight_decay = 0.01
lr = 0.001

# AdamW update:
weight = 5.0 - 0.001 × gradient - 0.001 × 0.01 × 5.0
#                                  └─ pulls weight towards 0
weight = 5.0 - gradient_update - 0.00005
```

---

### Paged AdamW 8-bit (What YOU Use)

```python
optim = "paged_adamw_8bit"
```

**Memory Savings:**

| Component | Regular AdamW | Paged AdamW 8-bit |
|-----------|---------------|-------------------|
| Parameter | 4 bytes (fp32) | 4 bytes |
| Gradient | 4 bytes | 2 bytes (fp16) |
| Momentum (m) | 4 bytes | 1 byte (int8) ✅ |
| Variance (v) | 4 bytes | 1 byte (int8) ✅ |
| **Total** | **16 bytes** | **8 bytes** |

**For 7B model:**
- Regular AdamW: 7B × 16 = 112 GB ❌
- Paged AdamW 8-bit: 7B × 8 = 56 GB ✅
- **With LoRA (10M trainable)**: 10M × 8 = 80 MB ✅✅

**Two Tricks:**

1. **8-bit Quantization:**
   ```python
   # Regular: m = 0.123456789 (32-bit float = 4 bytes)
   # 8-bit: m = quantize(0.123456789) (256 values = 1 byte)
   
   # Small accuracy loss, huge memory gain
   ```

2. **Paging (CPU Offloading):**
   ```python
   # When GPU memory full:
   # - Move optimizer states to CPU RAM
   # - Keep only active states on GPU
   # - Swap as needed (like virtual memory)
   ```

---

## 🎤 Interview Questions & Answers

### Q1: "Why Adam over SGD?"

**Answer:**
> "Adam combines momentum for acceleration and adaptive learning rates for stability. Plain SGD uses one global learning rate, which is inefficient - some parameters need big steps, others need small steps. Adam automatically adjusts per parameter based on gradient history. It converges faster and requires less hyperparameter tuning. That's why it's the default for most deep learning, especially transformers."

---

### Q2: "What's the role of beta1 and beta2?"

**Answer:**
> "Beta1 (default 0.9) controls momentum - how much past gradient direction we remember. Higher beta1 = more smoothing = faster in consistent directions but slower to change direction.
>
> Beta2 (default 0.999) controls variance - how much we remember about gradient magnitudes. Higher beta2 = more stable, less reactive to gradient spikes. Beta2 is higher than beta1 because we want momentum to respond quickly but variance to be stable."

**Why beta2 > beta1?**
```python
beta1 = 0.9   # Momentum: respond quickly to direction changes
beta2 = 0.999  # Variance: stay stable, don't overreact to spikes
```

---

### Q3: "Why use paged_adamw_8bit?"

**Answer:**
> "I'm fine-tuning a 7B model on a T4 GPU with 16GB VRAM. Standard AdamW stores optimizer states in 32-bit precision, requiring ~112GB for 7B parameters - impossible on T4. 
>
> Paged AdamW 8-bit quantizes momentum and variance to 8-bit integers, cutting memory by 50%. The 'paged' part adds CPU offloading - when GPU is full, states swap to RAM.
>
> Combined with LoRA (only 10M trainable params) and 4-bit model quantization, this lets me fit everything on a single T4. The tradeoff is 10-15% slower training, but it enables training that wouldn't otherwise be possible."

---

### Q4: "What if Adam overshoots the minimum?"

**Answer:**
> "That's where variance helps. When gradients become large (approaching minimum from wrong side), variance increases, which increases the denominator in the update formula, automatically reducing the effective learning rate. This acts as automatic dampening.
>
> Also, I use learning rate scheduling - start at 2e-4, then decay. And I set max_grad_norm=0.3 for gradient clipping to prevent extreme updates."

---

### Q5: "Momentum vs Adam momentum?"

**Answer:**
> "Classic momentum is just: v = beta × v + gradient, then weight -= lr × v
>
> Adam's 'momentum' is the same concept but combined with adaptive learning rates. Adam divides momentum by sqrt(variance), giving per-parameter adaptation. So Adam = Momentum + RMSprop. It's a more sophisticated version that handles different parameter scales better."

---

## 📌 Quick Reference

### The Complete Formula

```python
# Initialize
m = 0  # First moment (momentum)
v = 0  # Second moment (variance)

# At each step t:
m = beta1 × m + (1 - beta1) × gradient
v = beta2 × v + (1 - beta2) × gradient²

m_hat = m / (1 - beta1^t)  # Bias correction
v_hat = v / (1 - beta2^t)

weight = weight - lr × m_hat / (sqrt(v_hat) + epsilon)
```

### Default Hyperparameters

```python
learning_rate = 0.001  # (or 2e-4 for LoRA)
beta1 = 0.9
beta2 = 0.999
epsilon = 1e-8
weight_decay = 0.01  # For AdamW
```

### Memory Comparison

| Optimizer | Memory/Param | 7B Model Memory |
|-----------|--------------|-----------------|
| SGD | 8 bytes | 56 GB |
| Adam | 16 bytes | 112 GB |
| AdamW | 16 bytes | 112 GB |
| **Paged AdamW 8-bit** | **8 bytes** | **56 GB** |
| **+ LoRA (10M)** | **8 bytes** | **80 MB** ✅ |

---

## 🎯 Your Training Setup

```python
from transformers import TrainingArguments

training_args = TrainingArguments(
    output_dir="./results",
    learning_rate=2e-4,              # Higher for LoRA
    optim="paged_adamw_8bit",        # Memory-efficient
    per_device_train_batch_size=4,
    gradient_accumulation_steps=2,   # Effective batch = 8
    max_grad_norm=0.3,               # Gradient clipping
    warmup_steps=10,                 # LR warmup
    num_train_epochs=3,
    fp16=True,                       # Mixed precision
    logging_steps=10,
    save_strategy="epoch"
)
```

**Why these values?**
- `lr=2e-4`: Higher than normal (5e-5) because LoRA adapters need stronger signal
- `paged_adamw_8bit`: Fits 7B model on T4 GPU
- `max_grad_norm=0.3`: Prevents gradient explosion
- `warmup_steps=10`: Gradually increase LR for stability
- `fp16=True`: Mixed precision (2x speed, 2x memory savings)

---

## 💡 Intuitive Analogies

### Adam as a Self-Driving Car

```
Learning Rate: Speed limit (100 km/h)
Momentum: Accelerator pedal (press harder on straight road)
Variance: Brakes (slow down on bumpy road)

Smooth highway (consistent gradients):
→ Momentum ↑ → Speed ↑ → Faster progress

Rough terrain (noisy gradients):
→ Variance ↑ → Brakes ↑ → Careful progress
```

### The Ball Rolling Analogy

```
                Steep hill
                   ╲
                    ╲  ← Momentum builds
                     ╲    (ball accelerates)
                      ●───  Valley

Momentum = ball gains speed rolling downhill
Variance = friction (more friction when terrain rough)
```

---

**Good luck with TCS! You've got Adam down! 🚀**
