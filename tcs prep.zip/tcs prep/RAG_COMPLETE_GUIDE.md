# RAG Complete Study Guide - TCS Interview Prep

## Table of Contents
1. [Document Loading](#1-document-loading)
2. [Chunking Strategies](#2-chunking-strategies)
3. [Indexing (HNSW & IVF)](#3-indexing-hnsw--ivf)
4. [Retrieval Strategies](#4-retrieval-strategies)

---

# 1. Document Loading

## Why It Matters
Different document formats have different internal structures. Poor extraction = garbage in, garbage out.

---

## Word Documents (.docx)

### Internal Structure
`.docx` is NOT a single file - it's a **ZIP of XMLs**!

```
my_document.docx (rename to .zip and extract)
│
├── [Content_Types].xml
├── docProps/
│   ├── app.xml             # App metadata
│   └── core.xml            # Author, title, dates
└── word/
    ├── document.xml        # ← MAIN CONTENT HERE
    ├── styles.xml          # Formatting
    └── media/              # Images
```

### The XML Structure (word/document.xml):
```xml
<w:document>
  <w:body>
    <w:p>  <!-- paragraph -->
      <w:r>  <!-- run (text with same formatting) -->
        <w:t>This is the policy text</w:t>
      </w:r>
    </w:p>
    <w:tbl>  <!-- table -->
      <w:tr>  <!-- table row -->
        <w:tc>  <!-- table cell -->
          <w:p><w:r><w:t>Cell content</w:t></w:r></w:p>
        </w:tc>
      </w:tr>
    </w:tbl>
  </w:body>
</w:document>
```


## docpython best 



### docx2python (Best for Word):
```python
from docx2python import docx2python

result = docx2python("policy.docx")

result.text          # Plain text (all content)
result.body          # Nested lists: [[[paragraph], [table_row]]]
result.header        # Header content
result.footer        # Footer content
result.images        # Extracted images as bytes
result.properties    # Document metadata
```

**Why docx2python > basic loaders:**
- Preserves tables as structured data
- Extracts images
- Gets headers/footers
- Maintains document hierarchy

---

## PDF Documents

### Internal Structure
PDFs are **position-based**, NOT structure-based!

```
Text stored as coordinates:
BT                          % Begin Text
/F1 12 Tf                   % Font F1, size 12
100 700 Td                  % Move to position (100, 700)
(Hello ) Tj                 % Draw "Hello"
150 700 Td                  % Move to position (150, 700)
(World) Tj                  % Draw "World"
ET                          % End Text
```

**Problems:**
- PDF doesn't know "Hello World" is one sentence
- Tables = just text at coordinates (no structure!)
- Multi-column = text order scrambled

### PDF Loaders Comparison:

| Tool | Tables | Images | Speed | Use Case |
|------|--------|--------|-------|----------|
| PyPDFLoader | ❌ | ❌ | Fast | Simple PDFs |
| pdfplumber | ✅ | ❌ | Medium | PDFs with tables |
| Unstructured | ✅ | ✅ | Slow | Complex layouts |
| pytesseract | ❌ | ✅ | Slow | Scanned docs (OCR) |

### Code Examples:

#layoutmodel

```python
# Simple PDF
from langchain.document_loaders import PyPDFLoader
loader = PyPDFLoader("doc.pdf")
docs = loader.load()

# PDF with tables
import pdfplumber
with pdfplumber.open("doc.pdf") as pdf:
    for page in pdf.pages:
        text = page.extract_text()
        tables = page.extract_tables()  # Reconstructs table structure!

# Complex layouts (uses ML for layout detection)
from unstructured.partition.pdf import partition_pdf
elements = partition_pdf(
    "doc.pdf",
    strategy="hi_res",
    infer_table_structure=True
)
# Returns: Title, NarrativeText, Table, ListItem, etc.

# Scanned PDFs (no text layer)
import pytesseract
from pdf2image import convert_from_path
images = convert_from_path("scanned.pdf")
for img in images:
    text = pytesseract.image_to_string(img)
```

### Adding Metadata (Important for Filtering!):
```python
from langchain.document_loaders import UnstructuredPDFLoader

loader = UnstructuredPDFLoader("policy.pdf", mode="elements")
docs = loader.load()

for doc in docs:
    doc.metadata["source"] = "policy.pdf"
    doc.metadata["doc_type"] = "policy"
    doc.metadata["upload_date"] = "2024-01-15"
```

**Why metadata matters:** Filter by `upload_date` to avoid returning outdated policies!

---

## Interview Answer:

**Q: "How do you handle document ingestion in your RAG pipeline?"**

**A:** "Document formats have different internal structures:

**For Word docs (.docx):** They're ZIP archives containing XML. Content is in `word/document.xml`. I use `docx2python` because it parses XML structure, preserves tables as nested lists, and extracts headers/footers.

**For PDFs:** They're position-based, not structure-based. Tables don't exist as tables - just text at coordinates.
- Simple PDFs: `PyPDFLoader`
- Tables: `pdfplumber` (reconstructs from coordinates)
- Complex layouts: `Unstructured` with ML-based layout detection
- Scanned: OCR with `pytesseract`

I add metadata at load time (source, doc_type, upload_date) for filtering during retrieval."

---

# 2. Chunking Strategies

## Why Chunking Matters
- Too small → loses context
- Too big → exceeds token limits, dilutes relevance
- Wrong splits → breaks semantic units

---

## 2.1 Fixed Size Chunking (CharacterTextSplitter)

```python
from langchain.text_splitter import CharacterTextSplitter

splitter = CharacterTextSplitter(
    separator="\n",
    chunk_size=1000,
    chunk_overlap=200,
    length_function=len
)

chunks = splitter.split_text(text)
```

### How it works:
```
1. Split by separator ("\n")
2. Merge lines until chunk_size reached
3. Start new chunk with chunk_overlap from previous
```

**Problems:**
- ❌ Cuts mid-sentence
- ❌ Ignores semantic meaning
- ❌ Single separator only

**Use:** Never in production. Only quick prototyping.

---

## 2.2 Recursive Character Splitting ⭐ (DEFAULT CHOICE)

```python
from langchain.text_splitter import RecursiveCharacterTextSplitter

splitter = RecursiveCharacterTextSplitter(
    separators=["\n\n", "\n", ". ", " ", ""],  # Try in order!
    chunk_size=1000,
    chunk_overlap=200
)

chunks = splitter.split_text(text)
```

### How it works:
```
Step 1: Try split by "\n\n" (paragraphs)
        → If chunks small enough, DONE
        → If any chunk too big, go to Step 2

Step 2: Try split by "\n" (lines)
        → Continue until small enough...

Step 3: Try split by ". " (sentences)
Step 4: Try split by " " (words)
Step 5: Split by "" (characters) - last resort
```

### Custom Separators:

```python
# For Markdown
markdown_splitter = RecursiveCharacterTextSplitter(
    separators=["\n## ", "\n### ", "\n\n", "\n", ". ", " ", ""],
    chunk_size=1000,
    chunk_overlap=200
)

# For Code (built-in!)
from langchain.text_splitter import Language

python_splitter = RecursiveCharacterTextSplitter.from_language(
    language=Language.PYTHON,
    chunk_size=1000,
    chunk_overlap=100
)
# Respects: class, def, if, for - won't break functions
```

**Why DEFAULT choice:**
- ✅ Respects document hierarchy
- ✅ Rarely cuts mid-sentence
- ✅ Customizable separators
- ✅ Fast (no ML)

---

## 2.3 Semantic Chunking

```python
from langchain_experimental.text_splitter import SemanticChunker
from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings()

splitter = SemanticChunker(
    embeddings=embeddings,
    breakpoint_threshold_type="percentile",
    breakpoint_threshold_amount=75
)

chunks = splitter.create_documents([text])
```

### How it works:
```
1. Split text into sentences
2. Embed each sentence
3. Calculate similarity between consecutive sentences
4. Split where similarity drops (topic change!)

Sentence:     1    2    3    4    5    6
Topic:       [-- ML --][-- Weather --]
Similarity:  0.9  0.85  0.25  0.91  0.87
                       ↑
                   BREAK! (low similarity)
```

### Breakpoint Types:
```python
# Percentile (recommended)
breakpoint_threshold_type="percentile"
breakpoint_threshold_amount=75  # Break at bottom 25% similarity

# Standard Deviation
breakpoint_threshold_type="standard_deviation"
breakpoint_threshold_amount=1.5  # Break if sim < mean - 1.5*std

# Custom separator (paragraph-level instead of sentence)
splitter = SemanticChunker(
    embeddings=embeddings,
    sentence_split_regex=r"(?<=\n\n)"  # Split on paragraphs first
)
```

**Problems:**
- ❌ SLOW (embeds every sentence)
- ❌ EXPENSIVE (API calls)
- ❌ Unpredictable chunk sizes

**Use:** When topics aren't separated by formatting, and accuracy is critical.

---

## 2.4 Custom Header-Aware Chunking (Your Approach!)

```python
from langchain.text_splitter import RecursiveCharacterTextSplitter

def header_plus_recursive_chunking(text, max_chunk_size=800, chunk_overlap=50):
    sections = text.split("\n\n")
    chunks = []
    current_chunk = ""
    
    for section in sections:
        section = section.strip()
        if not section:
            continue
        
        section_first_line = section.split("\n")[0].strip()
        
        # Detect headers
        is_header = section_first_line.endswith("?") or (
            len(section) <= 100
            and not section_first_line.endswith(".")
            and not section_first_line.endswith("?")
        )
        
        if current_chunk and is_header:
            # Save current chunk, start new with header
            if len(current_chunk) > max_chunk_size:
                splitter = RecursiveCharacterTextSplitter(
                    chunk_size=max_chunk_size, chunk_overlap=chunk_overlap
                )
                sub_chunks = splitter.split_text(current_chunk)
                chunks.extend(sub_chunks)
            else:
                chunks.append(current_chunk)
            current_chunk = section
        else:
            # Accumulate content
            current_chunk = current_chunk + "\n\n" + section if current_chunk else section
    
    # Don't forget last chunk!
    if current_chunk:
        if len(current_chunk) > max_chunk_size:
            splitter = RecursiveCharacterTextSplitter(
                chunk_size=max_chunk_size, chunk_overlap=chunk_overlap
            )
            chunks.extend(splitter.split_text(current_chunk))
        else:
            chunks.append(current_chunk)
    
    return chunks
```

### Header Detection Logic:
```python
is_header = (
    section_first_line.endswith("?")   # Questions are headers
    or 
    (
        len(section) <= 100             # Short sections
        and not section_first_line.endswith(".")   # without periods
        and not section_first_line.endswith("?")   # and not questions
    )
)
```

| Pattern | Example | is_header |
|---------|---------|-----------|
| Ends with ? | "What is the return policy?" | ✅ True |
| Short, no period | "Returns Policy" | ✅ True |
| Ends with period | "Items can be returned." | ❌ False |
| Long section | "This is a very long..." | ❌ False |

### Flow:
```
"Returns Policy" (header) → Start chunk
"Items can be returned..." (content) → Add to chunk
"30 days for most items..." (content) → Add to chunk
"Refunds Policy" (header) → SAVE chunk, start NEW
"Refunds processed in..." (content) → Add to new chunk
```

**Result:** Each chunk = Header + its content!

---

## 2.5 Embedding-Based Chunk Grouping (Your Advanced Approach!)

```python
# Pre-compute embeddings for all chunks
all_embeddings = [
    embedding_model.embed_query(content)
    for content in initial_contents
]

# Group similar chunks using cosine similarity
current_group = [first_chunk]
current_group_embedding = all_embeddings[0]

for i, chunk in enumerate(chunks[1:], 1):
    chunk_embedding = all_embeddings[i]
    similarity = cosine_similarity(current_group_embedding, chunk_embedding)
    
    if similarity > threshold:  # Similar - add to group
        current_group.append(chunk)
        # Update centroid (np.mean!)
        group_embeddings = [all_embeddings[j] for j in group_indices]
        current_group_embedding = np.mean(group_embeddings, axis=0)
    else:  # Different - save group, start new
        combined = "\n\n".join(chunk["content"] for chunk in current_group)
        refined_chunks.append(combined)
        current_group = [chunk]
        current_group_embedding = chunk_embedding
```

### Why np.mean (Centroid)?

```python
# Shape: (3 chunks, 768 dimensions)
group_embeddings = [
    [0.1, 0.5, 0.3, ...],  # chunk 1
    [0.2, 0.4, 0.35, ...], # chunk 2
    [0.15, 0.45, 0.32, ...]# chunk 3
]

# axis=0: Average EACH DIMENSION across chunks
np.mean(group_embeddings, axis=0)
# Result: [0.15, 0.45, 0.323, ...] - Centroid of group

# This represents the "center" of the group in embedding space
# New chunks compared to centroid to decide if they belong
```

**Why centroid > comparing to individual chunks:**
- Represents entire group semantically
- One comparison instead of N
- Not biased to first/last chunk

---

## Chunking Comparison:

| Strategy | Speed | Cost | Accuracy | Production |
|----------|-------|------|----------|------------|
| Fixed | ⚡⚡⚡ | Free | ❌ Low | Never |
| Recursive | ⚡⚡⚡ | Free | ✅ Good | **DEFAULT** |
| Semantic | ⚡ | $$$ | ✅✅ Best | Selective |
| Header-Aware | ⚡⚡ | Free | ✅✅ Great | Policy docs |

---

## Interview Answer:

**Q: "What chunking strategy did you use?"**

**A:** "I built a **header-aware + embedding-based** approach:

1. **First pass:** Split by headers - detect section titles (short text, no period) and FAQ questions (ends with ?). This keeps headers attached to their content.

2. **Fallback:** If a section exceeds 800 chars, use `RecursiveCharacterTextSplitter` to break it down while respecting sentence boundaries.

3. **Refinement:** Calculate cosine similarity between chunk embeddings and group semantically similar chunks. I use the centroid (np.mean of embeddings) to represent each group, so new chunks are compared against the group's semantic center.

This outperformed vanilla SemanticChunker because it's structure-aware (respects headers) and operates at paragraph-level, not sentence-level."

---

# 3. Indexing (HNSW & IVF)

## Why Indexing Matters
```
Without indexing: Search 1M vectors = 1M comparisons = SLOW ❌
With indexing:    Search 1M vectors = ~100 comparisons = FAST ✅
```

---

## 3.1 Flat Index (Brute Force) - Baseline

```python
import faiss

index = faiss.IndexFlatL2(768)  # 768 dimensions
index.add(embeddings)  # Add 1M vectors
distances, indices = index.search(query, k=5)
```

**What happens:** Compare query to ALL vectors, sort, return top-k.

**Problem:** O(n) - 1M comparisons per query = 100-500ms

---

## 3.2 IVF (Inverted File Index) - Clustering-Based

### Concept:
Group similar vectors into clusters. Search only relevant clusters.

```
TRAINING (K-means):
All 1M vectors → K-means with nlist=100 → 100 clusters

SEARCH:
Query → Find closest cluster(s) → Search only within those clusters
Instead of 1M comparisons → only 10K-30K comparisons!
```

### Visual:
```
Cluster 0 (centroid_0)     Cluster 1 (centroid_1)     Cluster 99
   ├── vector_23              ├── vector_1               ├── vector_45
   ├── vector_156             ├── vector_89              ├── vector_782
   └── ... (10K vectors)      └── ... (10K vectors)      └── ...

Query arrives → Compare to 100 centroids → Closest: Cluster_23, Cluster_45
             → Search only in Cluster_23 and Cluster_45
```

### Code:
```python
import faiss
import numpy as np

dimension = 768
nlist = 100  # Number of clusters

# Quantizer decides cluster assignment
quantizer = faiss.IndexFlatL2(dimension)
index = faiss.IndexIVFFlat(quantizer, dimension, nlist)

# MUST TRAIN FIRST! (runs K-means)
embeddings = np.random.random((100000, dimension)).astype('float32')
index.train(embeddings)

# Add vectors (assigns to clusters)
index.add(embeddings)

# Search
index.nprobe = 10  # Search 10 nearest clusters
query = np.random.random((1, dimension)).astype('float32')
distances, indices = index.search(query, k=5)
```

### Parameters:

| Parameter | What It Does | How to Set |
|-----------|--------------|------------|
| `nlist` | Number of clusters | √N to 4√N (100-1000 for 1M vectors) |
| `nprobe` | Clusters to search | 1-20 (higher = accurate but slower) |

### nprobe Explained:
```
nprobe=1:  Search only closest cluster
           → FAST but might miss vectors at cluster boundaries!

nprobe=10: Search 10 closest clusters
           → Catches edge cases, more accurate

nprobe=100: Search ALL clusters
           → Same as flat index (defeats purpose!)
```

---

## 3.3 HNSW (Hierarchical Navigable Small World) - Graph-Based

### Concept:
Build a multi-layer graph. Navigate from top (coarse) to bottom (fine).

```
Layer 3: Very few nodes, long-range connections
         [Node A] ←────────────────→ [Node X]

Layer 2: More nodes, medium connections
         [A] ← [B] ← [C]        [X] ← [Y]

Layer 1: Even more nodes
         [A][B][C][D][E]    ...   [X][Y][Z]

Layer 0: ALL nodes (complete index)
         [Every single vector lives here]
```

### Level Assignment:
```python
level = floor(-ln(random()) * mL)  # mL = 1/ln(M)

# Result:
# ~90% nodes → Level 0 only
# ~9% nodes → Level 0 + Level 1
# ~0.9% nodes → Level 0 + Level 1 + Level 2
# Rare → All levels (express highways)
```

### Building the Graph:
```
Adding Vector V (assigned level=2):

1. V connects at Layer 2 (M neighbors)
2. V connects at Layer 1 (M neighbors)
3. V connects at Layer 0 (M neighbors) ← ALL vectors MUST be at Layer 0!

Layer 0 = Complete database
Higher layers = Navigation shortcuts
```

### Search:
```
Query arrives
    ↓
Layer 3: Greedy search → Find closest node
    ↓
Layer 2: Continue from that node, find closer
    ↓
Layer 1: Getting closer...
    ↓
Layer 0: Final precise search → Return top-k
```

**Why go to Layer 0?**
- Layer 2 might only have 0.1% of vectors
- BEST match might only exist at Layer 0!
- Upper layers = navigation, Layer 0 = actual answers

### Code:
```python
import faiss

dimension = 768
M = 32  # Connections per node

index = faiss.IndexHNSWFlat(dimension, M)
index.hnsw.efConstruction = 200  # Build quality
index.add(embeddings)  # No training needed!

index.hnsw.efSearch = 100  # Search quality
distances, indices = index.search(query, k=5)
```

### Parameters:

| Parameter | When Used | What It Does | Values |
|-----------|-----------|--------------|--------|
| `M` | Build | Connections per node | 16-64 (32 default) |
| `efConstruction` | Build | How many candidates when finding neighbors | 100-500 |
| `efSearch` | Query | How many candidates to track during search | 50-200 |

### efConstruction Explained:
```
Adding vector V, need to find M=32 best neighbors

efConstruction=10:  Find 10 candidates → Pick best 32? Only have 10!
                    → Fast build, but connections not optimal

efConstruction=200: Find 200 candidates → Pick best 32 from 200
                    → Slow build, but much better connections!
```

---

## 3.4 IVF vs HNSW Comparison

| Aspect | IVF | HNSW |
|--------|-----|------|
| Structure | Clusters | Multi-layer graph |
| Training | Required (K-means) | Not needed |
| Memory | Lower | Higher (stores edges) |
| Speed | Medium | Faster |
| Accuracy | 95-98% | 98-99% |
| Updates | Easy (assign to cluster) | Harder (rebuild edges) |

### Decision Tree:
```
Need 99%+ accuracy? → HNSW
Memory constrained? → IVF
Frequent updates?   → IVF
Dataset > 10M?      → IVF-PQ (compressed)
Otherwise?          → HNSW
```

---

## 3.5 LangChain FAISS with Custom Index

```python
from langchain_community.vectorstores import FAISS
from langchain_community.docstore.in_memory import InMemoryDocstore
import faiss
import numpy as np

# Get embeddings
texts = [doc.page_content for doc in documents]
embeddings_list = embedding_model.embed_documents(texts)
embeddings_np = np.array(embeddings_list).astype('float32')

dimension = embeddings_np.shape[1]

# Create custom IVF index
nlist = 100
quantizer = faiss.IndexFlatL2(dimension)
index = faiss.IndexIVFFlat(quantizer, dimension, nlist)
index.train(embeddings_np)
index.add(embeddings_np)
index.nprobe = 10

# Create mappings for LangChain
index_to_docstore_id = {i: str(i) for i in range(len(documents))}
docstore = InMemoryDocstore({str(i): doc for i, doc in enumerate(documents)})

# Wrap in LangChain FAISS
vector_store = FAISS(
    embedding_function=embedding_model,
    index=index,
    docstore=docstore,
    index_to_docstore_id=index_to_docstore_id
)

# Now use normally
results = vector_store.similarity_search("query", k=5)
```

### Why docstore needed?
```
FAISS only stores: index 0 → [0.1, 0.5, 0.3, ...]  (numbers)
Docstore stores:   "0" → Document(page_content="actual text")
Mapping:           index 0 → "0" → actual document
```

---

## Interview Answer:

**Q: "Explain HNSW vs IVF"**

**A:** "Both avoid brute-force search but differently:

**IVF:** Clusters vectors using K-means. At query time, find nearest cluster centroids (fast - only 100 comparisons), then search within those clusters. `nlist` controls cluster count, `nprobe` controls how many clusters to search.

**HNSW:** Builds a multi-layer graph where top layers have few nodes with long-range connections (express lanes) and bottom layer has all nodes. Search starts at top, greedily navigates down. Level assignment is probabilistic - most nodes only at layer 0.

**Trade-off:** HNSW is faster and more accurate but uses more memory. IVF is more memory-efficient and easier to update. For my GTE project, I used HNSW locally for accuracy, Vertex AI Vector Search (IVF-based) for production scale."

---

# 4. Retrieval Strategies

## 4.1 Dense Retrieval (Embedding-Based)

```python
# LangChain
results = vector_store.similarity_search(query, k=5)

# What happens:
# 1. Embed query
# 2. Compare with all indexed embeddings
# 3. Return top-k by distance
```

### Distance Metrics:

```python
# L2 (Euclidean) - FAISS default
index = faiss.IndexFlatL2(dimension)
# Lower = more similar

# Cosine Similarity
faiss.normalize_L2(embeddings)  # Normalize first!
index = faiss.IndexFlatIP(dimension)  # Inner Product on normalized = cosine

# LangChain with cosine
vector_store = FAISS.from_documents(
    documents, embeddings,
    distance_strategy="COSINE"
)
```

| Metric | When to Use |
|--------|-------------|
| L2 | General purpose |
| Cosine | Text embeddings (direction matters, not magnitude) |

---

## 4.2 Sparse Retrieval (BM25) - Keyword-Based

### The Problem with Dense:
```
Query: "Error code 404 in XYZ application"

Dense might find:
- "Application errors guide" (semantically similar)
BUT MISS:
- "XYZ application 404 fix" (exact keyword match!)
```

### BM25:
```python
from langchain_community.retrievers import BM25Retriever

bm25_retriever = BM25Retriever.from_documents(documents)
bm25_retriever.k = 5
results = bm25_retriever.invoke("Error code 404 XYZ")
```

### How BM25 Works:
```
Score = TF × IDF

TF (Term Frequency): How often query terms appear in doc
IDF (Inverse Doc Frequency): Rare terms score higher

"Error code 404 XYZ" in doc with "XYZ application 404 error"
→ "XYZ", "404", "error" all match → HIGH SCORE
```

---

## 4.3 Hybrid Search (Dense + Sparse) ⭐

### Why Hybrid:
```
Dense:  ✅ Semantic understanding  ❌ Misses exact keywords
Sparse: ✅ Exact matching          ❌ Misses synonyms

Hybrid = BEST OF BOTH
```

### LangChain Ensemble:
```python
from langchain.retrievers import EnsembleRetriever

# Dense retriever
dense_retriever = vector_store.as_retriever(search_kwargs={"k": 15})

# Sparse retriever
bm25_retriever = BM25Retriever.from_documents(documents)
bm25_retriever.k = 15

# Combine
ensemble_retriever = EnsembleRetriever(
    retrievers=[dense_retriever, bm25_retriever],
    weights=[0.6, 0.4]  # 60% dense, 40% BM25
)

results = ensemble_retriever.invoke("Error code 404 XYZ")
```

### RRF (Reciprocal Rank Fusion):
Combines results using **RANKS, not scores** (scores have different scales!)

```python
RRF_score(doc) = Σ (1 / (k + rank_i))

# k = 60 (constant)
# rank_i = position in retriever i

# Example:
# Doc A: Rank 1 in Dense, Rank 1 in BM25
# RRF = 1/(60+1) + 1/(60+1) = 0.0328 ← HIGHEST (good in both!)

# Doc B: Rank 2 in Dense, Rank 5 in BM25  
# RRF = 1/(60+2) + 1/(60+5) = 0.0315
```

**Why k=60?** Smooths ranking differences - doesn't over-reward rank 1.

---

## 4.4 Reranking (Cross-Encoder)

### Bi-Encoder vs Cross-Encoder:

```
BI-ENCODER (initial retrieval):
Query  → [Encoder] → query_emb ─┐
                                 ├→ cosine = 0.85
Doc    → [Encoder] → doc_emb ───┘

❌ No interaction between query and doc during encoding
❌ "apple" gets same embedding regardless of context


CROSS-ENCODER (reranking):
"[CLS] apple [SEP] Apple iPhone released [SEP]"
        ↓
   [Single Encoder - sees BOTH]
        ↓
   Attention: "apple" looks at "iPhone"
        ↓
   "This is about company, not fruit"
        ↓
   Score: 0.35

"[CLS] apple [SEP] I ate an apple today [SEP]"
        ↓
   Attention: "apple" looks at "ate"
        ↓
   "This is about fruit!"
        ↓
   Score: 0.95

✅ Query and doc interact - disambiguates meaning!
```

### Why Cross-Encoder is Better:
```
Query: "python snake"

Bi-Encoder:
- Doc A "Python programming" → 0.85
- Doc B "python snake grows" → 0.85
- CAN'T DISTINGUISH!

Cross-Encoder:
- "[CLS] python snake [SEP] Python programming..." 
  → "snake" doesn't match "programming" → 0.35
- "[CLS] python snake [SEP] python snake grows..."
  → "snake" matches "snake" → 0.97
- CORRECT RANKING!
```

### Trade-off:
```
Bi-Encoder:    Pre-compute docs, O(1) search, millions of docs
Cross-Encoder: Must process query+doc pairs, O(n), only 20-50 docs

SOLUTION: Bi-encoder for initial retrieval (fast)
          Cross-encoder to rerank top results (accurate)
```

### LangChain Reranking:
```python
from langchain.retrievers import ContextualCompressionRetriever
from langchain_community.cross_encoders import HuggingFaceCrossEncoder
from langchain.retrievers.document_compressors import CrossEncoderReranker

# Base retriever (gets 20 docs)
base_retriever = vector_store.as_retriever(search_kwargs={"k": 20})

# Cross-encoder reranker (picks best 5)
cross_encoder = HuggingFaceCrossEncoder(
    model_name="cross-encoder/ms-marco-MiniLM-L-6-v2"
)
reranker = CrossEncoderReranker(model=cross_encoder, top_n=5)

# Combine
compression_retriever = ContextualCompressionRetriever(
    base_compressor=reranker,
    base_retriever=base_retriever
)

results = compression_retriever.invoke("return policy")
# Returns 5 most relevant (reranked from 20)
```

---

## 4.5 Full Production Pipeline

```python
from langchain.retrievers import EnsembleRetriever, ContextualCompressionRetriever
from langchain_community.retrievers import BM25Retriever
from langchain_community.cross_encoders import HuggingFaceCrossEncoder
from langchain.retrievers.document_compressors import CrossEncoderReranker

# Stage 1a: Dense retriever
dense_retriever = vector_store.as_retriever(search_kwargs={"k": 15})

# Stage 1b: Sparse retriever (BM25)
bm25_retriever = BM25Retriever.from_documents(documents)
bm25_retriever.k = 15

# Stage 1c: Hybrid (Ensemble)
ensemble_retriever = EnsembleRetriever(
    retrievers=[dense_retriever, bm25_retriever],
    weights=[0.6, 0.4]
)

# Stage 2: Reranker
cross_encoder = HuggingFaceCrossEncoder(
    model_name="cross-encoder/ms-marco-MiniLM-L-6-v2"
)
reranker = CrossEncoderReranker(model=cross_encoder, top_n=5)

# Final pipeline
final_retriever = ContextualCompressionRetriever(
    base_compressor=reranker,
    base_retriever=ensemble_retriever
)

results = final_retriever.invoke("What is return policy for electronics?")
```

```
Flow:
Query → Hybrid Search (Dense + BM25) → 20 docs
     → Reranking (Cross-encoder) → 5 best docs
     → LLM
```

---

## 4.6 MMR (Maximal Marginal Relevance) - Diversity

```python
results = vector_store.max_marginal_relevance_search(
    query="Python",
    k=5,
    fetch_k=20,
    lambda_mult=0.5  # 0=diversity, 1=relevance
)
```

**Problem:** Top 5 results might all be same topic!
**Solution:** MMR balances relevance with diversity.

```
Without MMR:
1. "Python basics"
2. "Python intro"
3. "Learn Python"  → All same!

With MMR (lambda=0.5):
1. "Python basics"
2. "Python vs Java"
3. "Python for data science"  → Diverse!
```

---

## Retrieval Summary:

| Method | Speed | Accuracy | When to Use |
|--------|-------|----------|-------------|
| Dense only | ⚡⚡⚡ | Good | General semantic |
| BM25 only | ⚡⚡⚡ | Good keywords | Exact terms |
| Hybrid | ⚡⚡ | Better | Mix of both |
| + Reranking | ⚡ | Best | Production |
| + MMR | ⚡⚡ | Good + diverse | Avoid redundancy |

---

## Interview Answer:

**Q: "How did you optimize retrieval in your project?"**

**A:** "I used a **three-stage retrieval pipeline**:

1. **Hybrid search:** Combined FAISS dense retrieval with BM25. Dense captures semantic similarity, BM25 catches exact keywords like error codes and product IDs. Used EnsembleRetriever with 60-40 weighting.

2. **Reranking:** Retrieved 20 docs, then used a cross-encoder (`ms-marco-MiniLM`) to rerank and pick top 5. Cross-encoders are more accurate because they see query and document together, allowing attention between them.

3. **Result fusion:** For combining hybrid results, LangChain uses RRF (Reciprocal Rank Fusion) which combines by rank position, not score - important because dense and BM25 scores are on different scales.

The key insight: bi-encoders are fast but approximate, cross-encoders are slow but accurate. Use both in sequence."

---

# Quick Reference

## Document Loading
- Word: `docx2python` (parses XML structure)
- PDF simple: `PyPDFLoader`
- PDF tables: `pdfplumber`
- PDF complex: `Unstructured` (ML-based)
- Scanned: `pytesseract` (OCR)

## Chunking
- Default: `RecursiveCharacterTextSplitter`
- Semantic: `SemanticChunker` (expensive)
- Custom: Header-aware + embedding grouping

## Indexing
- HNSW: Fast, accurate, high memory, no training
- IVF: Scalable, lower memory, needs training
- Params: M, efConstruction, efSearch (HNSW) / nlist, nprobe (IVF)

## Retrieval
- Dense: Semantic similarity
- BM25: Keyword matching
- Hybrid: Best of both (EnsembleRetriever)
- Reranking: Cross-encoder for accuracy
- RRF: `1/(60+rank)` for combining
