## se for the workflow the main syntax will be sequential and prallel and conditonal and router


"""
see for the sequqntial it is simple the add_eges will be enough with understand set_entry_point and add_edge(lastndoe, END)

for parallel it will be multiple set_entry_point and  multiple nodes conenct to a merge ndoe ... all those ndoes smae merger mdoe 

for constional flow we have add_conditional_edge(starnode, fcuntion, dcit valeus of nodes matching the values ) explain me this please

for router it is add_conditional_entry_point(function, dict of node names matching the values)
"""



"""


for fast api what i know is see


app = FastAPI()


Class x1(BaseModel):
num : str = Field(..., example="5")

@app.post("/start)
def start(x1: x1):

    retuen some value 

and also know soemthing async and await and asyncio gather

@app.post("/f1")
async def f1():


    await fucn()


    asyncio.gather(fucn1(), fucn2())

    
httpx also i know bro see...



httpx.request("GET", "https://example.com")
httpx.request("POST", "https://example.com", params={"key": "value"}for the pathvaribale right)

give soem httpx for hpw to call the end points pease


and also how async work with httpx

and also stremaing resposnes i never did only for the azure open ai i know cleint.beta.chat.completions(model, stream = true)



and also i know how to sue pydantci format for the llm also 


client.cmpletions.create(
    model="gpt-4o",    response_format=pydantic(MyResponseModel),   


    res = parse(response.choices[0].message)

    i dont know soemthing like this correctif i am worn please 
"""

