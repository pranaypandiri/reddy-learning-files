from langgraph.prebuilt import create_react_agent
from langchain_core.tools import tool
from typing import TypedDict, Annotated

import operator

from langchain_google_vertexai import ChatVertexAI
from google.cloud import firestore

from langchain_core.messages import SystemMessage, HumanMessage, AIMessage, ToolMessage
from langgraph.graph import StateGraph, END
import os


llm = ChatVertexAI(
    model="gemini-1.5-flash",
    temperature=0.7,
    project="your-project-id",
    location="us-central1",
)


@tool
def search(query: str) -> list[str]:
    """THis tool searches the databeses for the given user query

    args:
        query: The user query to search for

        returns:
            list[str]: List of search results"""

    ## do some operations then return the list

    return ["result1", "result2", "result3"]


@tool
def calculate(query: str) -> str:
    """This tool calculates the given mathematical expression

    args:
        query: The mathematical expression to calculate

        returns:
            str: The result of the calculation"""

    ## do some operations then return the result

    return "42"


agent = create_react_agent(
    llm=llm,
    tools=[search, calculate],
    prompt=SystemMessage(
        " use the follwing tools to answer the query passed by the user"
    ),
)


class state(TypedDict):
    query: str
    values: Annotated[list[str], operator.add]
    number: str


def node1(st: state) -> dict:
    agent_response = agent.invoke({"messages": [HumanMessage(content=st["query"])]})
    search_result = None
    calc_result = None

    for msg in agent_response["messages"]:
        if isinstance(msg, ToolMessage):
            if msg.name == "search":
                search_result = msg.content
            elif msg.name == "calculate":
                calc_result = msg.content

    return {
        "values": [search_result] if search_result else [],
        "number": calc_result or "",
    }


# Create graph with state schema
graph = StateGraph(state)
graph.add_node("node1", node1)

graph.set_entry_point("node1")
graph.add_edge("node1", END)

# Compile the graph
app = graph.compile()

# Invoke the graph
result = app.invoke({"query": "Find the results for X and calculate Y"})
print("\nFinal Result:")
print(result)
