# COMPLETE INTERVIEW PREP CHEATSHEET 🚀

> OOPs + SOLID + Heap + Stack + Binary Search - Everything You Solved!

---

## 1. OOPs CONCEPTS

### Abstraction
**Hiding complex implementation, showing only essential features**

```python
from abc import ABC, abstractmethod

class PaymentGateway(ABC):  # Abstract class
    @abstractmethod
    def process_payment(self, amount):
        pass
    
    @abstractmethod
    def refund(self, transaction_id):
        pass

# User doesn't need to know HOW payment works internally
# Just calls: gateway.process_payment(100)
```

---

### Encapsulation
**Bundling data and methods together, restricting direct access**

```python
class BankAccount:
    def __init__(self):
        self.__balance = 0  # Private variable
    
    def deposit(self, amount):  # Public method
        if amount > 0:
            self.__balance += amount
    
    def get_balance(self):
        return self.__balance

# Can't do: account.__balance = 9999999 (protected!)
# Must use: account.deposit(100)
```

**Abstraction vs Encapsulation:**
- **Abstraction:** WHAT it does (hide complexity)
- **Encapsulation:** HOW data is protected (hide data)

---

### Inheritance Types

```python
# 1. Single Inheritance
class Animal:
    def eat(self): pass

class Dog(Animal):  # Dog inherits from Animal
    pass

# 2. Multiple Inheritance
class Flyable:
    def fly(self): pass

class Swimmable:
    def swim(self): pass

class Duck(Flyable, Swimmable):  # Inherits from both
    pass

# 3. Multilevel Inheritance
class Vehicle:
    pass

class Car(Vehicle):
    pass

class Tesla(Car):  # Inherits from Car, which inherits from Vehicle
    pass

# 4. Hierarchical Inheritance
class Employee:
    pass

class Manager(Employee):
    pass

class Developer(Employee):
    pass

# Both Manager and Developer inherit from Employee

# 5. Hybrid Inheritance (combination of above)
```

---

## 2. SOLID PRINCIPLES (with Payment Gateway Example)

### S - Single Responsibility Principle
**One class = One job**

```python
# ❌ BAD: Class doing multiple things
class User:
    def login(self): pass
    def send_email(self): pass
    def generate_invoice(self): pass

# ✅ GOOD: Separate responsibilities
class User:
    def login(self): pass

class EmailService:
    def send_email(self): pass

class InvoiceGenerator:
    def generate_invoice(self): pass
```

---

### O - Open/Closed Principle
**Open for extension, Closed for modification**

```python
# ✅ GOOD: Add new payment methods without modifying existing code
class PaymentGateway(ABC):
    @abstractmethod
    def process_payment(self, amount): pass

class StripeGateway(PaymentGateway):
    def process_payment(self, amount):
        print(f"Stripe: Processing ${amount}")

class RazorpayGateway(PaymentGateway):
    def process_payment(self, amount):
        print(f"Razorpay: Processing ₹{amount}")

# Add new gateway WITHOUT changing existing ones!
class PayPalGateway(PaymentGateway):
    def process_payment(self, amount):
        print(f"PayPal: Processing ${amount}")
```

---

### L - Liskov Substitution Principle
**Subclass should work anywhere parent class works**

```python
# All payment gateways can replace PaymentGateway
def charge_customer(gateway: PaymentGateway, amount):
    gateway.process_payment(amount)

# All of these work!
charge_customer(StripeGateway(), 100)
charge_customer(RazorpayGateway(), 5000)
charge_customer(PayPalGateway(), 50)
```

---

### I - Interface Segregation Principle
**Don't force classes to implement methods they don't need**

```python
# ❌ BAD: Forcing UPI to implement card methods
class Payment(ABC):
    @abstractmethod
    def pay_with_card(self): pass
    @abstractmethod
    def pay_with_upi(self): pass

# ✅ GOOD: Separate interfaces
class CardPayment(ABC):
    @abstractmethod
    def pay_with_card(self): pass

class UPIPayment(ABC):
    @abstractmethod
    def pay_with_upi(self): pass

class StripeGateway(CardPayment):  # Only implements card
    def pay_with_card(self): pass

class PhonePeGateway(UPIPayment):  # Only implements UPI
    def pay_with_upi(self): pass
```

---

### D - Dependency Inversion Principle
**Depend on abstractions, not concrete classes**

```python
# ❌ BAD: Directly depending on concrete class
class PaymentProcessor:
    def __init__(self):
        self.gateway = StripeGateway()  # Tight coupling!

# ✅ GOOD: Depend on abstraction
class PaymentProcessor:
    def __init__(self, gateway: PaymentGateway):
        self.gateway = gateway  # Can use ANY gateway!

# Usage:
processor = PaymentProcessor(StripeGateway())
processor = PaymentProcessor(RazorpayGateway())  # Easy to switch!
```

---

## 3. HEAP DATA STRUCTURE

### Operations:
```python
import heapq

# Min Heap (default)
heap = []
heapq.heappush(heap, 5)     # O(log n)
heapq.heappop(heap)         # O(log n)
heap[0]                     # Peek - O(1)
heapq.heapify(arr)          # Convert array - O(n)

# Max Heap (negate values)
heap = []
heapq.heappush(heap, -5)
largest = -heapq.heappop(heap)
```

### When to Use Heap?
**Keywords:** Top K, Kth largest, Kth smallest, median, priority

---

### Heap Problem 1: Kth Largest Element ✅

```python
def findKthLargest(nums, k):
    heap = []
    for num in nums:
        heapq.heappush(heap, num)
        if len(heap) > k:
            heapq.heappop(heap)
    return heap[0]

# Example: [3,2,1,5,6,4], k=2 → Output: 5
```

**Pattern:** Min heap of size K (root = Kth largest)

---

### Heap Problem 2: Top K Frequent Elements ✅

```python
def topKFrequent(nums, k):
    count = {}
    for num in nums:
        count[num] = count.get(num, 0) + 1
    
    heap = []
    for num, freq in count.items():
        heapq.heappush(heap, (freq, num))
        if len(heap) > k:
            heapq.heappop(heap)
    
    return [num for freq, num in heap]

# Example: [1,1,1,2,2,3], k=2 → Output: [1,2]
```

**Pattern:** Min heap with (frequency, value) tuples

---

### Heap Problem 3: K Closest Points ✅

```python
def kClosest(points, k):
    heap = []
    for x, y in points:
        dist = x*x + y*y  # No sqrt needed!
        heapq.heappush(heap, (-dist, x, y))  # Max heap
        if len(heap) > k:
            heapq.heappop(heap)
    
    return [[x, y] for dist, x, y in heap]

# Example: [[1,3],[-2,2]], k=1 → Output: [[-2,2]]
```

**Pattern:** Max heap (negate distance), keep K smallest

---

## 4. STACK DATA STRUCTURE

### Operations:
```python
stack = []
stack.append(x)      # Push - O(1)
stack.pop()          # Pop - O(1)
stack[-1]            # Peek - O(1)
len(stack)           # Size - O(1)
not stack            # isEmpty - O(1)
```

### When to Use Stack?
**Keywords:** valid, matching, balanced, next greater, next smaller

---

### Stack Problem 1: Valid Parentheses ✅

```python
def isValid(s):
    stack = []
    for char in s:
        if char == '(' or char == '{' or char == '[':
            stack.append(char)
        else:
            if not stack:
                return False
            if char == ')' and stack[-1] != '(':
                return False
            if char == '}' and stack[-1] != '{':
                return False
            if char == ']' and stack[-1] != '[':
                return False
            stack.pop()
    return len(stack) == 0

# Example: "()" → True, "([)]" → False
```

**Pattern:** Matching/Balancing

---

### Stack Problem 2: Next Greater Element ✅

```python
def nextGreaterElement(nums):
    n = len(nums)
    result = [-1] * n
    stack = []
    
    for i in range(n):
        while stack and nums[i] > nums[stack[-1]]:
            idx = stack.pop()
            result[idx] = nums[i]  # Store VALUE
        stack.append(i)
    
    return result

# Example: [2,1,5,6,2,3] → [5,5,6,-1,3,-1]
```

**Pattern:** Monotonic Stack (Decreasing)

---

### Stack Problem 3: Daily Temperatures ✅

```python
def dailyTemperatures(temperatures):
    n = len(temperatures)
    result = [0] * n
    stack = []
    
    for i in range(n):
        while stack and temperatures[i] > temperatures[stack[-1]]:
            idx = stack.pop()
            result[idx] = i - idx  # Store DISTANCE
        stack.append(i)
    
    return result

# Example: [73,74,75,71,69,72,76,73] → [1,1,4,2,1,1,0,0]
```

**Pattern:** Monotonic Stack (store distance, not value)

---

### Monotonic Stack - Simple Explanation

**Array:** `[2, 1, 5, 6, 2, 3]`  
**Goal:** Next Greater Element

**Rule:** When current > stack top → Pop (they found their answer!)

```
i=0: Stack: [0]
i=1: 1<2 → Stack: [0,1]
i=2: 5>1 → pop 1, answer[1]=5
     5>2 → pop 0, answer[0]=5
     Stack: [2]
i=3: 6>5 → pop 2, answer[2]=6
     Stack: [3]
i=4: 2<6 → Stack: [3,4]
i=5: 3>2 → pop 4, answer[4]=3
     Stack: [3,5]

Result: [5, 5, 6, -1, 3, -1]
```

---

## 5. MODIFIED BINARY SEARCH

### Normal Binary Search:
```python
def binarySearch(arr, target):
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1
```

---

### Modified Type 1: Search in Rotated Array

**Array:** `[4,5,6,7,1,2,3]`  
**Find:** 2

```python
def search(arr, target):
    left, right = 0, len(arr) - 1
    
    while left <= right:
        mid = (left + right) // 2
        
        if arr[mid] == target:
            return mid
        
        # Left half is sorted
        if arr[left] <= arr[mid]:
            if arr[left] <= target < arr[mid]:
                right = mid - 1
            else:
                left = mid + 1
        # Right half is sorted
        else:
            if arr[mid] < target <= arr[right]:
                left = mid + 1
            else:
                right = mid - 1
    
    return -1
```

**Key:** One half is ALWAYS sorted. Check which one!

---

### Modified Type 2: Find Peak Element

**Array:** `[1,2,3,4,3,2,1]`  
**Goal:** Find peak (element > neighbors)

```python
def findPeak(arr):
    left, right = 0, len(arr) - 1
    
    while left < right:
        mid = (left + right) // 2
        
        if arr[mid] > arr[mid + 1]:
            right = mid  # Peak at mid or left
        else:
            left = mid + 1  # Peak on right
    
    return left
```

**Key:** Always move toward the "uphill" direction!

---

## 6. QUICK COMPARISON

| Data Structure | Key Operations | Time | Use When |
|----------------|---------------|------|----------|
| Heap | push, pop, peek | O(log n) | Top K, Kth largest, median |
| Stack | push, pop, peek | O(1) | Matching, next greater |
| Binary Search | search | O(log n) | Sorted or rotated array |

---

## 7. PATTERN RECOGNITION

**See "Top K"?** → Use Heap  
**See "valid brackets"?** → Use Stack (matching)  
**See "next greater"?** → Use Stack (monotonic)  
**See "sorted array"?** → Use Binary Search  
**See "rotated array"?** → Use Modified Binary Search

---

## 8. KEY DIFFERENCES TO REMEMBER

### Heap:
- Kth Largest → Min Heap
- Kth Smallest → Max Heap
- (Opposite pattern!)

### Stack:
- Next Greater → Store VALUE: `result[idx] = nums[i]`
- Daily Temperatures → Store DISTANCE: `result[idx] = i - idx`

### Dictionary:
- `if key in dict` → Checks KEYS
- `if value in dict.values()` → Checks VALUES

---

**Tiger Analytics Interview Ready! 🔥**

Good luck bro! You got this! 💪
