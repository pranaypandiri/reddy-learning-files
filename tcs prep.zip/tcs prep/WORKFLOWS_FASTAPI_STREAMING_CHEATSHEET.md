# Workflows + FastAPI + Streaming - Production Cheat Sheet

## 1️⃣ LangGraph Workflows

### Sequential Flow
```python
from langgraph.graph import StateGraph, END

workflow = StateGraph(State)
workflow.set_entry_point("node1")
workflow.add_edge("node1", "node2")
workflow.add_edge("node2", "node3")
workflow.add_edge("node3", END)
app = workflow.compile()
```

### Parallel Flow
```python
workflow = StateGraph(State)
workflow.set_entry_point("start")

# Fan out - parallel execution
workflow.add_edge("start", "parallel_node1")
workflow.add_edge("start", "parallel_node2")
workflow.add_edge("start", "parallel_node3")

# Fan in - all converge
workflow.add_edge("parallel_node1", "merge")
workflow.add_edge("parallel_node2", "merge")
workflow.add_edge("parallel_node3", "merge")

workflow.add_edge("merge", END)
app = workflow.compile()
```

### Conditional Flow
```python
def router_function(state):
    if state["score"] > 80:
        return "high_priority"
    elif state["score"] > 50:
        return "medium_priority"
    else:
        return "low_priority"

workflow = StateGraph(State)
workflow.set_entry_point("start")

workflow.add_conditional_edges(
    "start",                    # Source node
    router_function,            # Function returns string
    {
        "high_priority": "urgent_handler",
        "medium_priority": "normal_handler",
        "low_priority": "low_priority_handler"
    }
)

workflow.add_edge("urgent_handler", END)
workflow.add_edge("normal_handler", END)
workflow.add_edge("low_priority_handler", END)
```

### Conditional Entry Point (Router)
```python
def entry_router(state):
    if state["type"] == "customer":
        return "customer_flow"
    elif state["type"] == "admin":
        return "admin_flow"
    else:
        return "guest_flow"

workflow = StateGraph(State)

workflow.add_conditional_edges(
    START,
    entry_router,
    {
        "customer_flow": "customer_node",
        "admin_flow": "admin_node",
        "guest_flow": "guest_node"
    }
)
```

---

## 2️⃣ FastAPI Basics

### Simple Endpoint
```python
from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI()

class ChatRequest(BaseModel):
    session_id: str = Field(..., example="sess_123")
    message: str = Field(..., example="Hello")

@app.post("/chat")
def chat(request: ChatRequest):
    return {"response": f"Got: {request.message}"}
```

### Async Endpoint
```python
import asyncio

@app.post("/process")
async def process():
    # Sequential - waits for each
    result1 = await async_function1()
    result2 = await async_function2()
    
    # Parallel - runs simultaneously
    results = await asyncio.gather(
        async_function1(),
        async_function2(),
        async_function3()
    )
    
    return {"results": results}
```

### APIRouter (Code Organization)
```python
# routers/chat_router.py
from fastapi import APIRouter

router = APIRouter()

@router.post("/start")
def start_chat(session_id: str):
    return {"message": "Chat started"}

@router.get("/{session_id}/history")
def get_history(session_id: str):
    return {"messages": [...]}
```

```python
# main.py
from fastapi import FastAPI
from routers import chat_router

app = FastAPI()
app.include_router(chat_router.router, prefix="/chat", tags=["Chat"])

# URLs: /chat/start, /chat/{session_id}/history
```

---

## 3️⃣ HTTPX - API Calls

### Sync Requests
```python
import httpx

# GET request
response = httpx.get("https://api.example.com/users")
data = response.json()

# POST with JSON body
response = httpx.post(
    "https://api.example.com/chat",
    json={"message": "hello"}
)

# POST with query params
response = httpx.post(
    "https://api.example.com/search",
    params={"category": "books", "limit": 10}
)

# POST with path variable
session_id = "sess_123"
response = httpx.post(f"https://api.example.com/sessions/{session_id}/messages")
```

### Async Requests
```python
import asyncio

async def call_api():
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "https://api.example.com/chat",
            json={"message": "hello"}
        )
        return response.json()

# Parallel API calls
async def call_multiple():
    async with httpx.AsyncClient() as client:
        responses = await asyncio.gather(
            client.get("https://api.example.com/user/1"),
            client.get("https://api.example.com/user/2"),
            client.get("https://api.example.com/user/3")
        )
        return [r.json() for r in responses]

asyncio.run(call_api())
```

### HTTPX Streaming
```python
with httpx.stream("POST", "http://localhost:8000/chat/stream", json={"message": "Hi"}) as response:
    for chunk in response.iter_text():
        print(chunk, end="", flush=True)
```

---

## 4️⃣ Streaming Responses

### Azure OpenAI Streaming
```python
from openai import AzureOpenAI

client = AzureOpenAI(...)

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Tell me a story"}],
    stream=True
)

for chunk in response:
    if chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end="", flush=True)
```

### FastAPI Streaming
```python
from fastapi.responses import StreamingResponse

@app.post("/chat/stream")
def chat_stream(request: ChatRequest):
    def generate():
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": request.message}],
            stream=True
        )
        
        for chunk in response:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
    
    return StreamingResponse(generate(), media_type="text/plain")
```

### FastAPI Streaming with Async
```python
@app.post("/chat/stream")
async def chat_stream(request: ChatRequest):
    async def generate():
        # If using async operations inside
        session_data = await get_session_from_db(request.session_id)
        
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": request.message}],
            stream=True
        )
        
        for chunk in response:  # OpenAI SDK is sync
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
    
    return StreamingResponse(generate(), media_type="text/plain")
```

---

## 5️⃣ Pydantic Structured Output

```python
from openai import AzureOpenAI
from pydantic import BaseModel

class MovieReview(BaseModel):
    title: str
    rating: int
    summary: str

client = AzureOpenAI(...)

response = client.beta.chat.completions.parse(
    model="gpt-4o",
    messages=[
        {"role": "user", "content": "Review the movie Inception"}
    ],
    response_format=MovieReview
)

review = response.choices[0].message.parsed
print(review.title)    # "Inception"
print(review.rating)   # 9
print(review.summary)  # "Mind-bending thriller..."
```

---

## 6️⃣ Singleton Pattern with __new__

```python
from typing import Optional

class FirestoreUtil:
    _instance: Optional['FirestoreUtil'] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.client = firestore.Client()
        return cls._instance
    
    def save_message(self, session_id: str, message: str):
        self.client.collection("sessions").document(session_id).update({
            "messages": firestore.ArrayUnion([{"content": message}])
        })

# Usage
util1 = FirestoreUtil()  # Creates instance
util2 = FirestoreUtil()  # Returns same instance
print(util1 is util2)    # True
```

---

## 7️⃣ Production Architecture: Service + Utils + Router

### Utils Layer
```python
# utils/firestore_client.py
from google.cloud import firestore
from typing import Optional

class FirestoreUtil:
    _instance: Optional['FirestoreUtil'] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.client = firestore.Client()
        return cls._instance
    
    def save_message(self, session_id: str, message: str):
        doc_ref = self.client.collection("sessions").document(session_id)
        doc_ref.update({
            "messages": firestore.ArrayUnion([{"content": message}])
        })
    
    def get_session(self, session_id: str):
        doc = self.client.collection("sessions").document(session_id).get()
        return doc.to_dict() if doc.exists else None

def get_firestore_util() -> FirestoreUtil:
    return FirestoreUtil()
```

```python
# utils/llm_client.py
from langchain_openai import AzureChatOpenAI
from typing import Optional

class LLMUtil:
    _instance: Optional['LLMUtil'] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.llm = AzureChatOpenAI(
                deployment_name="gpt-4o",
                temperature=0.7
            )
        return cls._instance
    
    def generate_response(self, messages):
        response = self.llm.invoke(messages)
        return response.content

def get_llm_util() -> LLMUtil:
    return LLMUtil()
```

### Service Layer
```python
# services/chat_service.py
from fastapi import Depends
from typing import Optional
from utils.firestore_client import FirestoreUtil, get_firestore_util
from utils.llm_client import LLMUtil, get_llm_util
from langchain_google_firestore import FirestoreChatMessageHistory

class ChatService:
    _instance: Optional['ChatService'] = None
    
    def __new__(cls, firestore_util: FirestoreUtil, llm_util: LLMUtil):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.firestore = firestore_util
            cls._instance.llm = llm_util
        return cls._instance
    
    def process_chat(self, session_id: str, message: str):
        history = FirestoreChatMessageHistory(
            session_id=session_id,
            collection="sessions",
            client=self.firestore.client
        )
        
        history.add_user_message(message)
        response = self.llm.generate_response(history.messages)
        history.add_ai_message(response)
        
        self.firestore.client.collection("sessions").document(session_id).update({
            "last_activity": firestore.SERVER_TIMESTAMP,
            "message_count": firestore.Increment(2)
        })
        
        return {"response": response}
    
    def get_history(self, session_id: str):
        return self.firestore.get_session(session_id)

def get_chat_service(
    firestore_util: FirestoreUtil = Depends(get_firestore_util),
    llm_util: LLMUtil = Depends(get_llm_util)
) -> ChatService:
    return ChatService(firestore_util, llm_util)
```

### Router Layer
```python
# routers/chat_router.py
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from services.chat_service import ChatService, get_chat_service

router = APIRouter()

class ChatRequest(BaseModel):
    session_id: str = Field(..., example="sess_123")
    message: str = Field(..., example="Hello")

@router.post("/start")
def start_chat(
    request: ChatRequest,
    chat_service: ChatService = Depends(get_chat_service)
):
    result = chat_service.process_chat(request.session_id, request.message)
    return result

@router.get("/{session_id}/history")
def get_history(
    session_id: str,
    chat_service: ChatService = Depends(get_chat_service)
):
    history = chat_service.get_history(session_id)
    return history
```

### Main App
```python
# main.py
from fastapi import FastAPI
from routers import chat_router

app = FastAPI(title="Chat API")
app.include_router(chat_router.router, prefix="/chat", tags=["Chat"])

@app.get("/")
def root():
    return {"status": "healthy"}
```

---

## 8️⃣ Project Structure

```
project/
├── main.py                 # FastAPI app
├── routers/
│   ├── __init__.py
│   ├── chat.py            # /chat/* endpoints
│   ├── agents.py          # /agents/* endpoints
│   └── sessions.py        # /sessions/* endpoints
├── services/
│   ├── __init__.py
│   ├── chat_service.py    # Business logic
│   └── agent_service.py
├── utils/
│   ├── __init__.py
│   ├── firestore_client.py
│   └── llm_client.py
└── models/
    ├── __init__.py
    └── chat_models.py     # Pydantic models
```

---

## 9️⃣ Dependency Injection Flow

```
Request: POST /chat/start
    ↓
FastAPI → Depends(get_chat_service)
    ↓
Needs: Depends(get_firestore_util) + Depends(get_llm_util)
    ↓
get_firestore_util() → FirestoreUtil.__new__()
    ↓ (first call creates instance, subsequent calls return same)
get_llm_util() → LLMUtil.__new__()
    ↓ (first call creates instance, subsequent calls return same)
ChatService.__new__(firestore_util, llm_util)
    ↓ (first call creates instance, subsequent calls return same)
Inject into endpoint
    ↓
Execute business logic
```

---

## 🔟 Key Rules

### Singleton Safety
```python
class Service:
    def __init__(self):
        # ✅ SAFE - Stateless clients (shared)
        self.llm = AzureChatOpenAI()
        self.db = firestore.Client()
        self.config = {"model": "gpt-4o"}  # Immutable
        
        # ❌ DANGEROUS - Mutable state (shared across requests!)
        self.current_user = None
        self.buffer = []
        self.counter = 0
    
    def process(self, session_id: str, message: str):
        # ✅ SAFE - Local variables (NOT shared)
        data = self.db.get(session_id)
        result = self.llm.invoke(message)
        return result
```

### Async Rules
```python
# Regular for loop - OpenAI SDK is sync
for chunk in response:
    yield chunk

# Async for loop - HTTPX is async
async for chunk in response.aiter_text():
    yield chunk

# asyncio.gather - run multiple async functions in parallel
results = await asyncio.gather(func1(), func2(), func3())
```

### HTTPX vs OpenAI Streaming
```python
# OpenAI - sync iterator
for chunk in response:
    print(chunk.choices[0].delta.content)

# HTTPX - async iterator
async for chunk in response.aiter_text():
    print(chunk)
```

---

## 🎯 Interview Quick Reference

| Topic | Key Syntax |
|-------|-----------|
| **Sequential Flow** | `add_edge("node1", "node2")` |
| **Parallel Flow** | Multiple `add_edge("start", "node_x")` → same merge node |
| **Conditional Flow** | `add_conditional_edges("node", func, {...})` |
| **Router** | `add_conditional_edges(START, func, {...})` |
| **FastAPI Router** | `router = APIRouter()` + `app.include_router(router, prefix="/api")` |
| **Async FastAPI** | `async def endpoint()` + `await func()` |
| **HTTPX Sync** | `httpx.post(url, json={...})` |
| **HTTPX Async** | `async with httpx.AsyncClient() as client: await client.post(...)` |
| **Streaming** | `def generate(): yield chunk` + `StreamingResponse(generate())` |
| **Pydantic Output** | `client.beta.chat.completions.parse(response_format=Model)` |
| **Singleton** | `__new__` with `_instance` class variable |
| **Dependency** | `def endpoint(service: Service = Depends(get_service))` |




## Human Response via State + Check if Interrupted

---

## 1️⃣ Human Response in State (Not in invoke)

```python
from langgraph.graph import StateGraph
from typing import TypedDict

# State includes human response field
class State(TypedDict):
    input: str
    proposed_action: str
    human_response: str  # ← Store human input here
    approved: bool

def agent_node(state):
    return {"proposed_action": "Delete database"}

def check_approval(state):
    # Read from state, not from invoke!
    if state.get("human_response") == "yes":
        return {"approved": True}
    return {"approved": False}

# Build graph
graph = StateGraph(State)
graph.add_node("agent", agent_node)
graph.add_node("approval", check_approval)
graph.add_edge("agent", "approval")

app = graph.compile(
    checkpointer=checkpointer,
    interrupt_before=["approval"]  # Pause here
)
```

**Usage:**
```python
config = {"configurable": {"thread_id": "123"}}

# Step 1: Runs until interrupt
result = app.invoke({"input": "task"}, config=config)

# Step 2: Resume with human response IN STATE
result = app.invoke(
    {"human_response": "yes"},  # ← Add to state
    config=config
)
```

---

## 2️⃣ Check if Stopped Due to Interrupt

```python
# Get current state snapshot
state = app.get_state(config)

# Check if interrupted
if state.next:  # If there are pending nodes
    print(f"Paused! Next node: {state.next}")
    print(f"Waiting for: {state.values}")  # Current state values
else:
    print("Completed!")

# Example output:
# Paused! Next node: ('approval',)
# Waiting for: {'proposed_action': 'Delete DB'}
```

---

## 3️⃣ Complete Pattern

```python
from langgraph.graph import StateGraph
from langgraph.checkpoint.memory import MemorySaver

class State(TypedDict):
    input: str
    action: str
    human_input: str
    approved: bool

graph = StateGraph(State)
graph.add_node("agent", lambda s: {"action": "risky_operation"})
graph.add_node("approval", lambda s: {"approved": s.get("human_input") == "approve"})

app = graph.compile(
    checkpointer=MemorySaver(),
    interrupt_before=["approval"]
)

config = {"configurable": {"thread_id": "123"}}

# Step 1: Start
result = app.invoke({"input": "task"}, config=config)

# Step 2: Check if paused
state = app.get_state(config)
if state.next:
    print(f"⏸️ Paused at: {state.next[0]}")  # "approval"
    print(f"Action proposed: {state.values['action']}")

# Step 3: Human reviews and responds
human_decision = input("Approve? (approve/reject): ")

# Step 4: Resume with human input in STATE
result = app.invoke(
    {"human_input": human_decision},  # ← Update state
    config=config
)

# Step 5: Check final state
final_state = app.get_state(config)
if not final_state.next:
    print("✅ Completed!")
```

---

## 4️⃣ State Properties to Check

```python
state = app.get_state(config)

# Check if interrupted
state.next          # Tuple of next nodes, e.g., ('approval',)
                    # Empty tuple () = completed

state.values        # Current state dict
                    # {'action': '...', 'human_input': None}

state.metadata      # Execution metadata
```

---

## Quick Syntax:

```python
# 1. Update state (not invoke params)
app.invoke({"human_input": "yes"}, config=config)

# 2. Check if paused
state = app.get_state(config)
is_paused = len(state.next) > 0  # True = paused

# 3. Get waiting node
waiting_for = state.next[0] if state.next else None
```

**That's it!** 🎯



from fastapi import FastAPI
from langgraph.graph import StateGraph
from langgraph.checkpoint.memory import MemorySaver

app = FastAPI()

# Build LangGraph
graph = StateGraph(State)
# ... add nodes ...
workflow = graph.compile(
    checkpointer=MemorySaver(),
    interrupt_before=["approval"]
)

# ========== ENDPOINT 1: START ==========
@app.post("/workflow/start")
async def start_workflow(request: dict):
    """Start new workflow"""
    thread_id = request["session_id"]
    config = {"configurable": {"thread_id": thread_id}}
    
    # Start workflow (runs until interrupt)
    result = workflow.invoke(
        {"input": request["task"]},
        config=config
    )
    
    # Check if paused
    state = workflow.get_state(config)
    
    if state.next:
        # Paused - waiting for human
        return {
            "status": "waiting_approval",
            "paused_at": state.next[0],
            "current_state": state.values,
            "session_id": thread_id
        }
    else:
        # Completed
        return {
            "status": "completed",
            "result": result
        }


# ========== ENDPOINT 2: RESUME ==========
@app.post("/workflow/resume")
async def resume_workflow(request: dict):
    """Resume paused workflow with human input"""
    thread_id = request["session_id"]
    config = {"configurable": {"thread_id": thread_id}}
    
    # Update state with human input
    workflow.update_state(
        config,
        {"human_input": request["approval"]}  # Add to state
    )
    
    # Resume workflow
    result = workflow.invoke(None, config=config)  # ← None!
    
    return {
        "status": "completed",
        "result": result
    }