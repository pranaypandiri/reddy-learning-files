Alright bro, let me break down regex from scratch in the simplest way possible. Think of regex as **pattern matching with special symbols**.

---

## 🎯 **Regex Basics - The Building Blocks**

### **1. Literal Characters (Exact Match)**
```
"hello" matches "hello" exactly
```
Easy right? Just normal text.

---

### **2. Special Symbols (The Magic)**

| Symbol | Meaning | Example |
|--------|---------|---------|
| `.` | Any single character | `h.t` matches "hat", "hit", "hot" |
| `\d` | Any digit (0-9) | `\d\d\d` matches "123", "456" |
| `\s` | Any space/tab | `hello\sworld` matches "hello world" |
| `\w` | Any letter/digit/underscore | `\w\w\w` matches "abc", "123", "a1_" |

---

### **3. Quantifiers (How Many?)**

| Symbol | Meaning | Example |
|--------|---------|---------|
| `?` | 0 or 1 time (optional) | `colou?r` matches "color" OR "colour" |
| `+` | 1 or more times | `\d+` matches "1", "123", "99999" |
| `*` | 0 or more times | `ab*c` matches "ac", "abc", "abbbbc" |
| `{3}` | Exactly 3 times | `\d{3}` matches "123" (must be 3 digits) |
| `{2,4}` | 2 to 4 times | `\d{2,4}` matches "12", "123", "1234" |

---

### **4. Character Sets (Choose One)**

| Pattern | Meaning | Example |
|---------|---------|---------|
| `[abc]` | a OR b OR c | `[abc]` matches "a", "b", or "c" |
| `[0-9]` | Any digit | Same as `\d` |
| `[a-z]` | Any lowercase letter | `[a-z]+` matches "hello" |
| `[A-Z]` | Any uppercase letter | `[A-Z]+` matches "HELLO" |
| `[a-zA-Z]` | Any letter | `[a-zA-Z]+` matches "Hello" |

---

### **5. Grouping & Escaping**

| Symbol | Meaning | Example |
|--------|---------|---------|
| `( )` | Group things together | `(abc)+` matches "abc", "abcabc" |
| `\` | Escape special chars | `\.` matches literal "." (not any char) |
| `\|` | OR operator | `cat\|dog` matches "cat" OR "dog" |

---

## 📞 **Phone Number Regex - Step by Step**

### **Goal:** Match `555-123-4567`, `(555) 123-4567`, `+1-555-123-4567`

Let's build it piece by piece:

#### **Step 1: Start Simple**
Match `555-123-4567`
```regex
\d{3}-\d{3}-\d{4}
```
**Breakdown:**
- `\d{3}` = 3 digits (area code: 555)
- `-` = literal dash
- `\d{3}` = 3 digits (prefix: 123)
- `-` = literal dash
- `\d{4}` = 4 digits (line: 4567)

---

#### **Step 2: Make Dash Optional**
Match `555-123-4567` OR `5551234567`
```regex
\d{3}-?\d{3}-?\d{4}
```
**What changed:**
- `-?` = dash is optional (0 or 1 times)

---

#### **Step 3: Allow Dash or Space or Dot**
Match `555-123-4567`, `555.123.4567`, `555 123 4567`
```regex
\d{3}[-.\s]?\d{3}[-.\s]?\d{4}
```
**What changed:**
- `[-.\s]?` = dash OR dot OR space (optional)
- Character set `[]` with `-` `.` `\s` inside

---

#### **Step 4: Add Parentheses for Area Code**
Match `(555) 123-4567`
```regex
\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}
```
**What changed:**
- `\(?` = opening parenthesis (optional, escaped with `\`)
- `\)?` = closing parenthesis (optional)

---

#### **Step 5: Add International Code**
Match `+1-555-123-4567` or `1-555-123-4567`
```regex
\+?1?[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}
```
**What changed:**
- `\+?` = plus sign (optional, escaped)
- `1?` = country code "1" (optional)

---

### **Final Phone Regex:**
```regex
\+?1?[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}
```

**Matches:**
- ✅ `555-123-4567`
- ✅ `(555) 123-4567`
- ✅ `+1-555-123-4567`
- ✅ `5551234567`

---

## 📧 **Email Regex - Step by Step**

### **Goal:** Match `john@example.com`, `user.name@company.co.uk`

#### **Step 1: Start with Username (before @)**
Match letters, numbers, dots, underscores
```regex
[a-zA-Z0-9._-]+
```
**Breakdown:**
- `[a-zA-Z0-9._-]` = any letter, digit, dot, underscore, dash
- `+` = one or more times
- Matches: `john`, `user.name`, `test_123`

---

#### **Step 2: Add the @ Symbol**
```regex
[a-zA-Z0-9._-]+@
```
**Just added:** literal `@`

---

#### **Step 3: Add Domain Name**
```regex
[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+
```
**Added:**
- `[a-zA-Z0-9.-]+` = domain name (example, company, test-site)

---

#### **Step 4: Add the Dot Before Extension**
```regex
[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.
```
**Added:**
- `\.` = literal dot (escaped because `.` is special in regex!)

---

#### **Step 5: Add Extension (com, org, etc.)**
```regex
[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}
```
**Added:**
- `[a-zA-Z]{2,}` = at least 2 letters (com, org, co, uk)

---

### **Final Email Regex:**
```regex
[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}
```

**Matches:**
- ✅ `john@example.com`
- ✅ `user.name@company.co.uk`
- ✅ `test_123@sub-domain.org`

---

## 🧠 **Essential Things to Remember (Cheat Sheet)**

### **The 5 Most Important Symbols:**

| Symbol | Remember As | Use Case |
|--------|-------------|----------|
| `\d` | **D**igit | Phone numbers, credit cards |
| `\s` | **S**pace | Separators in text |
| `+` | 1 or **more** | Unknown length (emails, words) |
| `?` | **Optional** | Things that may or may not be there |
| `[ ]` | **Choose one** | Multiple options (dash, dot, space) |

---

### **The Golden Rules:**

1️⃣ **Escape special characters with `\`**
   - Dot → `\.` (literal dot)
   - Parenthesis → `\(` `\)` (literal brackets)
   - Plus → `\+` (literal plus)

2️⃣ **Use `?` for optional parts**
   - Dash might not be there → `-?`
   - International code might not be there → `\+?1?`

3️⃣ **Use `+` for variable length**
   - Email username (unknown length) → `[a-zA-Z0-9]+`
   - Domain name (unknown length) → `[a-zA-Z0-9]+`

4️⃣ **Use `{n}` for exact count**
   - Phone area code (always 3) → `\d{3}`
   - Last 4 digits of phone → `\d{4}`

5️⃣ **Use `[ ]` for alternatives**
   - Dash OR dot OR space → `[-.\s]`
   - Uppercase OR lowercase → `[a-zA-Z]`

---

## 🎓 **Simple Mnemonic to Remember:**

**"DOPE" - The Core 4 You Need**

- **D** = `\d` (digits)
- **O** = `?` (optional)
- **P** = `+` (plus/multiple)
- **E** = `\.` (escape special chars)

With just these 4, you can build 80% of patterns!

---

## ✅ **Practice Test (Try to Read These):**

1. `\d{3}-\d{2}-\d{4}`
   <details><summary>Answer</summary>
   **Social Security Number:** 123-45-6789
   </details>

2. `[a-z]+@[a-z]+\.com`
   <details><summary>Answer</summary>
   **Simple email:** user@example.com (but won't match dots in name)
   </details>

3. `\+?\d{10,15}`
   <details><summary>Answer</summary>
   **International phone:** Optional +, then 10-15 digits
   </details>

---

**Does this make sense now? Want me to show you how to actually USE these patterns in Python code?**





import re

class OneLineSmartMasker:
    """All masking with regex groups - NO separate functions!"""
    
    def mask_all(self, text: str) -> str:
        """Apply all masks in 3 lines!"""
        
        # 1. Mask emails: keep first 2, last 1 of username + first 2 of domain
        text = re.sub(
            r'\b([a-zA-Z0-9]{1,2})[a-zA-Z0-9._+-]*([a-zA-Z0-9]?)@([a-zA-Z0-9]{1,2})[a-zA-Z0-9.-]*(\.[a-zA-Z]{2,})',
            r'\1***\2@\3***\4',
            text
        )
        
        # 2. Mask phones: keep first 2, last 4 digits
        text = re.sub(
            r'(\+?1?[-.\s]?\(?)(\d{2})\d+(\d{4})(\)?)',
            r'\1\2***\3\4',
            text
        )
        
        # 3. Mask credentials: keep first 2, last 2 chars
        text = re.sub(
            r'(password|token|api_key|secret|bearer)([\s:=]+["\']?)(\w{2})\w+(\w{2})(["\']?)',
            r'\1\2\3****\4\5',
            text,
            flags=re.IGNORECASE
        )
        
        return text


# ===== USAGE =====

masker = OneLineSmartMasker()

sample = """
Email: john.smith@company.com
Phone: 555-123-4567 or (555) 987-6543
API: api_key="abcdef123456xyz"
Password: password=SecretPass123
"""

print(masker.mask_all(sample))