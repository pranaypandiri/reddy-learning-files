see the chain emasn like sequence of oepration .. emans one llm means (prompt + taks ).. chain emans we ened perform multiple llm task combination..


the cod ei know is LLmchain(llm , prompt, output_vairbales)

then llmchain.invoke("query")

type of chain ican name seq , parallel, routerchain.. but i never fidn the right use of this.. and also soemtiems is ee using lcel and lancgahin inbulit this chains cocnept but nobody told in a goodway 

pipe operator is like conenction i know but the what yous aid running parallle these coenpts i dont know how to use runnable interface, parallel execution, etc.)

Memory:

1. memeory si for the conevrsation to hold the conevrsation intact for the second turns or for the coming forward turns 

2. conevrsationbuffermemeory(chat_history="memeorykey", load_variables)

it is bad for production bcause for multi suer it wont be useful .. andalso long session means we need to sumamrize and stuff bro.. so thats why firstore for mutliple suer ..s ession we  have to maintain the session id and also sudeen server or window closes 

short means i think firestorechatmemeory for the turns and long term emana before log out.. or saving the session in the buckets i think..

tools and fucntiona calling

see toolds emans external support 
@tool 
Def method 

Create_react_agent(llm, toold , prompt)

agentExcuetor(llm,tools,agent,prompt)

bindtoold is for single excuetion and also the llm wont call it just have the design again we need to iterate and call the toold thats is hazard 

agents yeah same like tool means agent have the toola dn llm and prompt decides based on the docstringw e mention there 

faiss.save_lcoal(docuems,embedding)

ivf 
emans nlist, nprobe and indexflatl2 and then faiss.ivfindex(quantizer, dimension,)

then we do the index.train(embedding)

yeah my doubt see after we have the docuemtns or have the text we need perform the embedding before train and then pass eight ?

