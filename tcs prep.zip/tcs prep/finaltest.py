# All imports for Customer Support Order Agent

# LangGraph imports
from langgraph.graph import StateGraph, END, START
from langgraph.checkpoint.firestore import FirestoreSaver
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

# FastAPI imports
from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

# Google Cloud Firestore
from google.cloud import firestore

# LLM imports (choose one based on your setup)
from langchain_google_vertexai import ChatVertexAI
# OR
# from langchain_openai import AzureChatOpenAI

# Python standard library
from typing import TypedDict, Annotated, Optional, List
import operator
import os


# ============================================
# Your code starts here
# ============================================


llm = ChatVertexAI(mdoel, project, location, temperature)

## above rest of the parameters you will fill but i know what need to passed this will be follword in the whole file also okay...



@tool
def humannode(query: str) -> str:
    """This tool handles human node interactions

    args:
        query: The user query to process

        returns:
            str: The response from the human node"""

    ## do some operations then return the result

    return "Human node response"

@tool
def refunddeduction(query:str)-> int:

    """this tool used for refudn deuction calculation
    args :
        query : the amount to be deducted

        returns:
            str : the deducted amount
    """

    return 123

agent = create_react_agent(llm, tools , prompt = SystemMessage(" use the follwing tools to answer the query passed by the user"))



class State(TypedDict):
    user_query: str
    human_node_response: str
    refund_deduction_amount: int
    humanresponse: str


def node(state: State) -> State:
    """Node function to process the state

    args:
        state: The current state of the graph

        returns:
            State: The updated state after processing"""

    # Example processing logic
    response = agent.invoke({"messages": [HumanMessage(content=state["user_query"])]})

    amount = None
    for msg in response["messages"]:
        if isinstance(msg, ToolMessage) and msg.name == "refunddeduction":
            amount = int(msg.content)
    

    return {
        "user_query": state["user_query"],
        "human_node_response": "not required",
        "refund_deduction_amount": amount if amount is not None else 0,
    }

def human_node(state: State) -> State:
    """Node function to handle human interactions

    args:
        state: The current state of the graph

        returns:
            State: The updated state after processing"""

    
    return {
       "humanresponse": humannode(state["humanresponse"])
   }

def f1(response:str):
    return {
        "humanresponse": response
    }

graph = StateGraph(State)

graph.add_node("node", node)
graph.add_node("human", human_node)

graph.set_entry_point("node")
graph.add_conditional_edge("node", f1, {"refund_deduction_amount": lambda x: x > 0}, "human")

graph.add_edge("node", END)
graph.add_edge("human", END)    

graph.compile(checkpointer=FirestoreSaver(firestore.Client(), "customer_support_order_agent"), interrupt_before = ["human"])




app = FastAPI()





@app.post("/start")
async def start_process(user_query: str):


    config = {"configurable": {"user_query": user_query}}
    """API endpoint to start the customer support order agent process

    args:
        user_query: The query from the user

        returns:
            dict: The final state after processing"""

    initial_state = {
        "user_query": user_query,
        "human_node_response": "",
        "refund_deduction_amount": 0,
        "humanresponse": ""
    }

    final_state = graph.run(initial_state)

    state = graph.get_state(config={"user_query": user_query})

    if state.next:
        return {"message": "Process interrupted for human interaction"}
   


    return final_state



@app.post("/resume")
async def resume(query: str, humanresponse: str):
    """API endpoint to resume the process after human interaction

    args:
        query: The original user query
        humanresponse: The response from the human node

        returns:
            dict: The final state after processing"""

    config = {
        "configurable": {
            "user_query": query,
            "humanresponse": humanresponse
        }
    }

    graph.update_state(config=config)

    final_state = graph.run(None, config=config)

    return final_state







