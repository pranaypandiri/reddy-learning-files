# 🏎️ MAX VERSTAPPEN'S CODING CHEATSHEET 🏎️

## 📌 PATTERN 1: TWO POINTERS - OPPOSITE ENDS

**When:** Palindrome, Container, Sorted Two Sum

```python
left = 0
right = len(arr) - 1

while left < right:
    # Do something with arr[left] and arr[right]
    
    if condition:
        left += 1
    else:
        right -= 1
```

**Example - Container With Most Water:**
```python
left, right = 0, len(height) - 1
max_area = 0

while left < right:
    area = min(height[left], height[right]) * (right - left)
    max_area = max(max_area, area)
    
    if height[left] < height[right]:
        left += 1
    else:
        right -= 1
```

---

## 📌 PATTERN 2: TWO POINTERS - SAME DIRECTION

**When:** Remove duplicates, Move zeroes, Partition

```python
left = 0  # Write position

for right in range(len(arr)):
    if condition:  # Found what we want
        arr[left] = arr[right]  # or swap
        left += 1

# left = count of valid elements
```

**Example - Move Zeroes:**
```python
left = 0

for right in range(len(nums)):
    if nums[right] != 0:
        nums[left], nums[right] = nums[right], nums[left]
        left += 1
```

---

## 📌 PATTERN 3: SLIDING WINDOW - FIXED SIZE

**When:** Max sum of K elements, Average of K elements

```python
# Build first window
window = sum(arr[:k])
result = window

# Slide: add right, remove left
for i in range(k, len(arr)):
    window += arr[i]      # Add new
    window -= arr[i - k]  # Remove old
    result = max(result, window)
```

---

## 📌 PATTERN 4: SLIDING WINDOW - VARIABLE (MAX)

**When:** Longest substring, Maximum window with condition

**KEY: Check result OUTSIDE while (after shrinking)**

```python
left = 0
max_len = 0
seen = set()  # or dict for counting

for right in range(len(s)):
    # Shrink while INVALID
    while s[right] in seen:  # Condition BROKEN
        seen.remove(s[left])
        left += 1
    
    seen.add(s[right])
    
    # ✅ Check OUTSIDE while - window is VALID now
    max_len = max(max_len, right - left + 1)
```

---

## 📌 PATTERN 5: SLIDING WINDOW - VARIABLE (MIN)

**When:** Minimum subarray with sum >= target

**KEY: Check result INSIDE while (while still valid)**

```python
left = 0
min_len = float('inf')
current = 0

for right in range(len(nums)):
    current += nums[right]
    
    # Shrink while VALID
    while current >= target:  # Condition MET
        # ✅ Check INSIDE while - window is VALID
        min_len = min(min_len, right - left + 1)
        current -= nums[left]
        left += 1

return min_len if min_len != float('inf') else 0
```

---

## 📌 PATTERN 6: HASHMAP - TWO SUM STYLE

**When:** Find pair with target, Complement lookup

```python
seen = {}  # {value: index}

for i, num in enumerate(nums):
    complement = target - num
    
    if complement in seen:
        return [seen[complement], i]
    
    seen[num] = i
```

---

## 📌 PATTERN 7: HASHMAP - FREQUENCY COUNT

**When:** Anagram, First unique, Character count

```python
freq = {}

for char in s:
    freq[char] = freq.get(char, 0) + 1

# Or use Counter
from collections import Counter
freq = Counter(s)
```

---

## 📌 PATTERN 8: KADANE'S - MAX SUM SUBARRAY

**When:** Maximum contiguous sum

```python
curr = nums[0]
max_sum = nums[0]

for num in nums[1:]:
    curr = max(num, curr + num)  # Fresh or extend?
    max_sum = max(max_sum, curr)
```

**Alternative (Reset when negative):**
```python
curr = 0
max_sum = nums[0]

for num in nums:
    curr += num
    max_sum = max(max_sum, curr)
    if curr < 0:
        curr = 0
```

---

## 📌 PATTERN 9: KADANE'S - MAX PRODUCT SUBARRAY

**When:** Maximum contiguous product (handles negatives!)

```python
curr_max = nums[0]
curr_min = nums[0]  # Track negative chain!
result = nums[0]

for num in nums[1:]:
    temp = curr_max
    curr_max = max(num, curr_max * num, curr_min * num)
    curr_min = min(num, temp * num, curr_min * num)
    result = max(result, curr_max)
```


nums = [2, -3, -4]

At 2: max=2, min=2

At -3:
  curr_max = max(-3, 2×-3=-6, 2×-3=-6) = -3
  curr_min = min(-3, 2×-3=-6, 2×-3=-6) = -6
  (Keep min=-6, it's negative but useful!)

At -4:
  curr_max = max(-4, -3×-4=12, -6×-4=24) = 24 ✅
             ^^^^ Using the MIN chain saved the day!
  
  The min=-6 × -4 = 24 is our answer!
---

## 📌 PATTERN 10: PREFIX SUM

**When:** Range sum queries, Subarray sum = K

```python
# Build prefix
prefix = [0]
for num in nums:
    prefix.append(prefix[-1] + num)

# Range sum (i to j inclusive)
sum_i_to_j = prefix[j + 1] - prefix[i]
```

---

## 🎯 QUICK DECISION GUIDE

| Problem Type | Pattern |
|--------------|---------|
| Find pair = target (unsorted) | HashMap |
| Find pair = target (sorted) | Two Pointers Opposite |
| Palindrome check | Two Pointers Opposite |
| Container/Water problems | Two Pointers Opposite |
| Remove/Move elements in-place | Two Pointers Same Dir |
| Longest/Maximum substring | Sliding Window MAX |
| Shortest/Minimum subarray | Sliding Window MIN |
| Fixed window size | Fixed Sliding Window |
| Character frequency | HashMap Count |
| Maximum contiguous sum | Kadane's |
| Maximum contiguous product | Kadane's (track min too!) |
| Multiple range sum queries | Prefix Sum |

---

## 🧠 REMEMBER

```
MAX problem → Check OUTSIDE while (after shrinking)
MIN problem → Check INSIDE while (while valid)

Window size = right - left + 1

Sorted array → Two pointers possible
Unsorted + need index → HashMap

Negative × Negative = Positive (track min for product!)
```

---

## 🔴 AREAS TO PRACTICE MORE

1. **Sliding Window MAX** - Need more reps
2. **HashMap patterns** - Understood but not intuitive
3. **Longest Substring variations** - Practice more
4. **Kadane's Product** - Theory learned, need practice

---

## 🟢 STRONG AREAS

1. **Two Pointers Opposite** - Solid!
2. **Two Pointers Same Direction** - Improved!
3. **Sliding Window MIN** - Got it!
4. **Basic HashMap counting** - Good!

---

## 💪 PYTHON DATA STRUCTURES & OPERATIONS

### 📋 LIST OPERATIONS

```python
# Create
my_list = [1, 2, 3]
my_list = list(range(5))  # [0, 1, 2, 3, 4]

# ACCESS
val = my_list[0]        # First element
val = my_list[-1]       # Last element
val = my_list[1:3]      # Slice [2, 3]

# ADD
my_list.append(4)       # Add to end → [1, 2, 3, 4]
my_list.insert(1, 10)   # Insert at index 1 → [1, 10, 2, 3, 4]
my_list.extend([5, 6])  # Add multiple → [1, 2, 3, 5, 6]
my_list += [7, 8]       # Same as extend

# DELETE
my_list.remove(3)       # Remove first occurrence of 3
val = my_list.pop()     # Remove & return last element
val = my_list.pop(0)    # Remove & return at index 0
del my_list[1]          # Delete by index
my_list.clear()         # Empty the list

# USEFUL
len(my_list)            # Length
3 in my_list            # Check membership
my_list.count(3)        # Count occurrences
my_list.sort()          # Sort in-place
sorted(my_list)         # Return sorted copy
my_list.reverse()       # Reverse in-place
```

---

### 📕 DICTIONARY OPERATIONS

```python
# Create
my_dict = {'a': 1, 'b': 2}
my_dict = dict(a=1, b=2)

# ACCESS
val = my_dict['a']              # Get value (KeyError if missing)
val = my_dict.get('a')          # Get value (None if missing)
val = my_dict.get('c', 0)       # Get with default value

# ADD / UPDATE
my_dict['c'] = 3                # Add new key-value
my_dict['a'] = 10               # Update existing
my_dict.update({'d': 4, 'e': 5})  # Add multiple

# DELETE
del my_dict['a']                # Delete key
val = my_dict.pop('b')          # Remove & return value
val = my_dict.pop('z', None)    # Pop with default
my_dict.clear()                 # Empty dict

# ITERATE
for key in my_dict:             # Iterate keys
    print(key)

for val in my_dict.values():    # Iterate values
    print(val)

for key, val in my_dict.items():  # Iterate key-value pairs
    print(key, val)

# USEFUL
len(my_dict)                    # Number of keys
'a' in my_dict                  # Check if key exists
my_dict.keys()                  # Get all keys
my_dict.values()                # Get all values
my_dict.items()                 # Get key-value pairs
```

---

### 📗 SET OPERATIONS

```python
# Create
my_set = {1, 2, 3}
my_set = set([1, 2, 2, 3])  # Duplicates removed → {1, 2, 3}

# ADD
my_set.add(4)               # Add single element
my_set.update([5, 6])       # Add multiple

# DELETE
my_set.remove(3)            # Remove (KeyError if not found)
my_set.discard(3)           # Remove (no error if not found)
val = my_set.pop()          # Remove & return arbitrary element
my_set.clear()              # Empty set

# SET OPERATIONS
set1 = {1, 2, 3}
set2 = {3, 4, 5}

union = set1 | set2         # {1, 2, 3, 4, 5}
union = set1.union(set2)

intersection = set1 & set2  # {3}
intersection = set1.intersection(set2)

difference = set1 - set2    # {1, 2}
difference = set1.difference(set2)

# USEFUL
len(my_set)                 # Size
3 in my_set                 # Check membership (O(1)!)
```

---

### 🎯 LIST COMPREHENSIONS

```python
# Basic syntax: [expression for item in iterable if condition]

# SIMPLE
squares = [x**2 for x in range(5)]
# [0, 1, 4, 9, 16]

# WITH CONDITION
evens = [x for x in range(10) if x % 2 == 0]
# [0, 2, 4, 6, 8]

# WITH IF-ELSE
labels = ['even' if x % 2 == 0 else 'odd' for x in range(5)]
# ['even', 'odd', 'even', 'odd', 'even']

# NESTED LOOPS
pairs = [(x, y) for x in range(3) for y in range(3)]
# [(0,0), (0,1), (0,2), (1,0), (1,1), (1,2), (2,0), (2,1), (2,2)]

# FLATTEN 2D LIST
matrix = [[1, 2], [3, 4], [5, 6]]
flat = [num for row in matrix for num in row]
# [1, 2, 3, 4, 5, 6]

# DICT COMPREHENSION
squares_dict = {x: x**2 for x in range(5)}
# {0: 0, 1: 1, 2: 4, 3: 9, 4: 16}

# SET COMPREHENSION
unique_lengths = {len(word) for word in ['a', 'ab', 'abc', 'ab']}
# {1, 2, 3}
```

---

### 🔧 MAP, FILTER, REDUCE

```python
# MAP - Apply function to each element
nums = [1, 2, 3, 4]

# Using map
squared = list(map(lambda x: x**2, nums))
# [1, 4, 9, 16]

# List comprehension (More Pythonic!)
squared = [x**2 for x in nums]

# Multiple iterables
nums1 = [1, 2, 3]
nums2 = [4, 5, 6]
result = list(map(lambda x, y: x + y, nums1, nums2))
# [5, 7, 9]

# ---

# FILTER - Keep elements that match condition
nums = [1, 2, 3, 4, 5, 6]

# Using filter
evens = list(filter(lambda x: x % 2 == 0, nums))
# [2, 4, 6]

# List comprehension (More Pythonic!)
evens = [x for x in nums if x % 2 == 0]

# ---

# REDUCE - Reduce to single value
from functools import reduce

nums = [1, 2, 3, 4]

# Sum using reduce
total = reduce(lambda acc, x: acc + x, nums)
# 10

# Product
product = reduce(lambda acc, x: acc * x, nums)
# 24

# Max
maximum = reduce(lambda acc, x: max(acc, x), nums)
# 4

# Better alternatives
total = sum(nums)           # Built-in sum
from math import prod
product = prod(nums)        # Built-in product (Python 3.8+)
maximum = max(nums)         # Built-in max
```

---

### 🚀 BONUS TRICKS

```python
# Frequency count
freq = {}
freq[x] = freq.get(x, 0) + 1

# Or use Counter
from collections import Counter
freq = Counter([1, 2, 2, 3, 3, 3])
# Counter({3: 3, 2: 2, 1: 1})

# Check alphanumeric
char.isalnum()

# all() and any()
all(x > 0 for x in nums)  # All positive?
any(x < 0 for x in nums)  # Any negative?

# enumerate for index + value
for i, val in enumerate(arr):
    pass

# zip for parallel iteration
names = ['Alice', 'Bob']
ages = [25, 30]
for name, age in zip(names, ages):
    print(f"{name} is {age}")

# Swap values
a, b = b, a

# Multiple assignment
x, y, z = 1, 2, 3

# Unpack with *
first, *middle, last = [1, 2, 3, 4, 5]
# first=1, middle=[2,3,4], last=5
```

---

## 🔥 COMMON INTERVIEW CLASSICS

### 1. FIBONACCI

**Recursive (Simple but Slow - O(2^n)):**
```python
def fib_recursive(n):
    if n <= 1:
        return n
    return fib_recursive(n-1) + fib_recursive(n-2)
```

**Iterative (Best - O(n), O(1) space):**
```python
def fib_iterative(n):
    if n <= 1:
        return n
    
    prev, curr = 0, 1
    for _ in range(2, n + 1):
        prev, curr = curr, prev + curr
    return curr
```

**DP with Memoization (O(n), O(n) space):**
```python
def fib_memo(n, memo={}):
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    
    memo[n] = fib_memo(n-1, memo) + fib_memo(n-2, memo)
    return memo[n]
```

---

### 2. FACTORIAL

**Recursive:**
```python
def factorial_recursive(n):
    if n <= 1:
        return 1
    return n * factorial_recursive(n - 1)
```

**Iterative (Better):**
```python
def factorial_iterative(n):
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result
```

---

### 3. REVERSE STRING

**Python Way:**
```python
s = s[::-1]
```

**Two Pointers (In-place for list):**
```python
def reverse_string(s):
    left, right = 0, len(s) - 1
    while left < right:
        s[left], s[right] = s[right], s[left]
        left += 1
        right -= 1
```

---

### 4. PALINDROME CHECK

**String:**
```python
def is_palindrome(s):
    return s == s[::-1]

# Or two pointers
def is_palindrome_pointers(s):
    left, right = 0, len(s) - 1
    while left < right:
        if s[left] != s[right]:
            return False
        left += 1
        right -= 1
    return True
```

**Alphanumeric Only:**
```python
def is_palindrome_alphanum(s):
    left, right = 0, len(s) - 1
    
    while left < right:
        # Skip non-alphanumeric
        while left < right and not s[left].isalnum():
            left += 1
        while left < right and not s[right].isalnum():
            right -= 1
        
        if s[left].lower() != s[right].lower():
            return False
        
        left += 1
        right -= 1
    
    return True
```

---

### 5. ANAGRAM CHECK

**Sorting (O(n log n)):**
```python
def is_anagram(s, t):
    return sorted(s) == sorted(t)
```

**HashMap/Counter (O(n) - Best!):**
```python
from collections import Counter

def is_anagram(s, t):
    return Counter(s) == Counter(t)

# Or manual
def is_anagram_manual(s, t):
    if len(s) != len(t):
        return False
    
    count = {}
    for char in s:
        count[char] = count.get(char, 0) + 1
    
    for char in t:
        if char not in count:
            return False
        count[char] -= 1
        if count[char] < 0:
            return False
    
    return True
```

---

### 6. FIND DUPLICATES

**Using Set:**
```python
def has_duplicates(nums):
    return len(nums) != len(set(nums))

def find_duplicate(nums):
    seen = set()
    for num in nums:
        if num in seen:
            return num
        seen.add(num)
    return None
```

---

### 7. MISSING NUMBER (0 to n)

**XOR (O(n), O(1) - Clever!):**
```python
def missing_number(nums):
    n = len(nums)
    xor = 0
    
    # XOR all indices and values
    for i in range(n + 1):
        xor ^= i
    for num in nums:
        xor ^= num
    
    return xor  # Only missing number remains
```

**Sum Formula (Simple):**
```python
def missing_number(nums):
    n = len(nums)
    expected_sum = n * (n + 1) // 2
    actual_sum = sum(nums)
    return expected_sum - actual_sum
```

---

### 8. POWER (x^n)

**Iterative:**
```python
def power(x, n):
    if n < 0:
        x = 1 / x
        n = -n
    
    result = 1
    for _ in range(n):
        result *= x
    return result
```

**Fast Power (O(log n) - Best!):**
```python
def power_fast(x, n):
    if n < 0:
        x = 1 / x
        n = -n
    
    result = 1
    current = x
    
    while n > 0:
        if n % 2 == 1:  # Odd power
            result *= current
        current *= current  # Square the base
        n //= 2
    
    return result
```

**Recursive:**
```python
def power_recursive(x, n):
    if n == 0:
        return 1
    if n < 0:
        return power_recursive(1/x, -n)
    
    if n % 2 == 0:  # Even
        half = power_recursive(x, n // 2)
        return half * half
    else:  # Odd
        return x * power_recursive(x, n - 1)
```

---

### 9. REVERSE INTEGER

```python
def reverse_int(x):
    sign = -1 if x < 0 else 1
    x = abs(x)
    
    result = 0
    while x > 0:
        result = result * 10 + x % 10
        x //= 10
    
    return sign * result
```

---

### 10. PRIME CHECK

```python
def is_prime(n):
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    
    # Check odd divisors up to sqrt(n)
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    
    return True
```

---

### 11. GCD (Greatest Common Divisor)

**Euclidean Algorithm:**
```python
def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

# Recursive
def gcd_recursive(a, b):
    if b == 0:
        return a
    return gcd_recursive(b, a % b)
```

---

### 12. BINARY SEARCH

```python
def binary_search(arr, target):
    left, right = 0, len(arr) - 1
    
    while left <= right:
        mid = (left + right) // 2
        
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    
    return -1  # Not found
```

---

### 13. FIRST/LAST OCCURRENCE IN SORTED ARRAY

```python
def find_first(arr, target):
    left, right = 0, len(arr) - 1
    result = -1
    
    while left <= right:
        mid = (left + right) // 2
        
        if arr[mid] == target:
            result = mid  # Found, but keep searching left
            right = mid - 1
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    
    return result

def find_last(arr, target):
    left, right = 0, len(arr) - 1
    result = -1
    
    while left <= right:
        mid = (left + right) // 2
        
        if arr[mid] == target:
            result = mid  # Found, but keep searching right
            left = mid + 1
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    
    return result
```

---

### 14. MERGE TWO SORTED ARRAYS

```python
def merge_sorted(arr1, arr2):
    result = []
    i, j = 0, 0
    
    while i < len(arr1) and j < len(arr2):
        if arr1[i] <= arr2[j]:
            result.append(arr1[i])
            i += 1
        else:
            result.append(arr2[j])
            j += 1
    
    # Add remaining
    result.extend(arr1[i:])
    result.extend(arr2[j:])
    
    return result
```

---

### 15. ROTATE ARRAY

**Right Rotate by k:**
```python
def rotate_right(nums, k):
    k = k % len(nums)  # Handle k > len
    nums[:] = nums[-k:] + nums[:-k]

# In-place with reversal
def rotate_inplace(nums, k):
    k = k % len(nums)
    
    def reverse(start, end):
        while start < end:
            nums[start], nums[end] = nums[end], nums[start]
            start += 1
            end -= 1
    
    # Reverse whole array
    reverse(0, len(nums) - 1)
    # Reverse first k
    reverse(0, k - 1)
    # Reverse rest
    reverse(k, len(nums) - 1)
```

---

**🏆 "If you no longer go for a gap that exists, you're no longer a racing driver." - Senna**

**Go get that P1 in your interview!** 🏎️💨
