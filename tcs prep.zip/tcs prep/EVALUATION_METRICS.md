# Model Evaluation Metrics - TCS Interview Prep

## 📊 Classification Metrics Explained

### The Confusion Matrix

```
                    PREDICTED
                 P1    P2    P3
ACTUAL   P1    [12]   5     3      20 actual P1
         P2     2   [45]    8      55 actual P2  
         P3     1     4   [20]     25 actual P3
               ─────────────────
               15    54    31     100 total
```

**Key Terms:**
- **Diagonal (bold)**: Correct predictions
- **Off-diagonal**: Mistakes
- **Row sums**: Actual counts per class
- **Column sums**: Predicted counts per class

---

## 🎯 The Four Core Metrics

### 1. Accuracy

**Definition:** Overall correctness across all classes

**Formula:**
```
Accuracy = (Correct Predictions) / (Total Predictions)
         = (TP + TN) / (Total)
```

**Example (from confusion matrix above):**
```python
Correct = 12 + 45 + 20 = 77
Total = 100

Accuracy = 77 / 100 = 0.77 = 77%
```

**When to Use:**
- ✅ Balanced datasets (equal class distribution)
- ❌ Imbalanced datasets (e.g., 95% P2, 5% P1)

**Interview Answer:**
> "Accuracy measures the proportion of correct predictions across all classes. It's the simplest metric but can be misleading with imbalanced data - you could get 95% accuracy by always predicting the majority class."

---

### 2. Precision

**Definition:** "When I predict positive, how often am I correct?"

**Formula:**
```
Precision = TP / (TP + FP)
          = True Positives / (Predicted Positives)
```

**Example for P1 (Critical tickets):**
```python
# From confusion matrix:
# Column P1: [12, 2, 1] = 15 predicted as P1
# True P1 (diagonal): 12

TP = 12  (correctly predicted P1)
FP = 2 + 1 = 3  (wrongly predicted P1)

Precision = 12 / (12 + 3) = 12 / 15 = 0.80 = 80%
```

**Interpretation:**
> "When my model predicts P1 (critical), it's correct 80% of the time"

**When to Use:**
- When **false positives are costly**
- Example: Spam detection (don't want to mark important emails as spam)
- Example: Medical diagnosis (don't want to tell healthy people they're sick)

**Interview Answer:**
> "Precision focuses on the quality of positive predictions. High precision means when the model says 'yes,' it's usually right. For my IT ticketing system, high precision for P1 means I'm not overwhelming the critical team with false alarms."

---

### 3. Recall (Sensitivity)

**Definition:** "Of all actual positives, how many did I find?"

**Formula:**
```
Recall = TP / (TP + FN)
       = True Positives / (Actual Positives)
```

**Example for P1 (Critical tickets):**
```python
# From confusion matrix:
# Row P1: [12, 5, 3] = 20 actual P1
# True P1 (diagonal): 12

TP = 12  (correctly identified P1)
FN = 5 + 3 = 8  (missed P1, labeled as P2/P3)

Recall = 12 / (12 + 8) = 12 / 20 = 0.60 = 60%
```

**Interpretation:**
> "Out of 20 actual critical tickets, my model caught 12 (60%)"

**When to Use:**
- When **false negatives are costly**
- Example: Cancer detection (must catch all cancer cases)
- Example: Fraud detection (must catch all fraud)
- Example: P1 IT tickets (can't miss critical issues!)

**Interview Answer:**
> "Recall measures coverage - how many actual positives we successfully identified. For P1 tickets, high recall is critical because missing a server outage is much worse than a few false alarms. I'd rather have 100% recall with 70% precision than vice versa."

---

### 4. F1 Score

**Definition:** Harmonic mean of Precision and Recall

**Formula:**
```
F1 = 2 × (Precision × Recall) / (Precision + Recall)
```

**Example for P1:**
```python
Precision = 0.80
Recall = 0.60

F1 = 2 × (0.80 × 0.60) / (0.80 + 0.60)
   = 2 × 0.48 / 1.40
   = 0.96 / 1.40
   = 0.686 = 68.6%
```

**Why Harmonic Mean?**
```python
# Arithmetic mean would be:
(0.80 + 0.60) / 2 = 0.70  (too generous!)

# Harmonic mean (F1) = 0.686 (penalizes imbalance)
# F1 is lower when P and R differ significantly
```

**When to Use:**
- When you need **balanced** precision and recall
- When dataset is imbalanced
- General-purpose metric for classification

**Interview Answer:**
> "F1 score is the harmonic mean of precision and recall. It's useful when you want a single metric that balances both, and it penalizes extreme imbalances. For example, if precision is 90% but recall is 10%, F1 would be low (~18%), showing the model is poor despite high precision."

---

## 📝 Complete Code Example

### Production Evaluation Pipeline

```python
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from sklearn.metrics import confusion_matrix, classification_report
import numpy as np

def evaluate_model(y_true, y_pred, class_names):
    """
    Complete evaluation for multi-class classification
    
    Args:
        y_true: Actual labels ['P1', 'P2', 'P2', 'P3', ...]
        y_pred: Predicted labels ['P1', 'P2', 'P3', 'P3', ...]
        class_names: List of class names ['P1', 'P2', 'P3']
    
    Returns:
        Dictionary with all metrics
    """
    
    # ============================================
    # 1. Accuracy (Overall)
    # ============================================
    accuracy = accuracy_score(y_true, y_pred)
    
    # ============================================
    # 2. Per-class Precision, Recall, F1
    # ============================================
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, 
        y_pred, 
        labels=class_names,
        average=None  # Get per-class metrics
    )
    
    # ============================================
    # 3. Weighted Average (accounts for imbalance)
    # ============================================
    precision_weighted, recall_weighted, f1_weighted, _ = precision_recall_fscore_support(
        y_true, 
        y_pred,
        average='weighted'  # Weighted by class frequency
    )
    
    # ============================================
    # 4. Confusion Matrix
    # ============================================
    cm = confusion_matrix(y_true, y_pred, labels=class_names)
    
    # ============================================
    # Print Results
    # ============================================
    print("="*60)
    print("EVALUATION RESULTS")
    print("="*60)
    print(f"\nOverall Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)\n")
    
    print("Per-Class Metrics:")
    print("-"*60)
    print(f"{'Class':<10} {'Precision':<12} {'Recall':<12} {'F1-Score':<12} {'Support'}")
    print("-"*60)
    for i, class_name in enumerate(class_names):
        print(f"{class_name:<10} {precision[i]:<12.4f} {recall[i]:<12.4f} "
              f"{f1[i]:<12.4f} {support[i]}")
    print("-"*60)
    print(f"{'Weighted':<10} {precision_weighted:<12.4f} {recall_weighted:<12.4f} "
          f"{f1_weighted:<12.4f} {len(y_true)}")
    print("-"*60)
    
    print("\nConfusion Matrix:")
    print(cm)
    
    # ============================================
    # Detailed Classification Report
    # ============================================
    print("\n" + classification_report(y_true, y_pred, labels=class_names))
    
    return {
        'accuracy': accuracy,
        'precision_weighted': precision_weighted,
        'recall_weighted': recall_weighted,
        'f1_weighted': f1_weighted,
        'confusion_matrix': cm.tolist()
    }


# ============================================
# Example Usage
# ============================================
if __name__ == "__main__":
    # Sample predictions
    y_true = ['P1', 'P2', 'P2', 'P3', 'P1', 'P2', 'P3', 'P1', 'P2', 'P3',
              'P2', 'P2', 'P1', 'P3', 'P2', 'P1', 'P3', 'P2', 'P1', 'P3']
    
    y_pred = ['P1', 'P2', 'P3', 'P3', 'P2', 'P2', 'P3', 'P1', 'P2', 'P2',
              'P2', 'P2', 'P1', 'P3', 'P2', 'P1', 'P3', 'P2', 'P2', 'P3']
    
    class_names = ['P1', 'P2', 'P3']
    
    # Run evaluation
    results = evaluate_model(y_true, y_pred, class_names)
```

**Output:**
```
============================================================
EVALUATION RESULTS
============================================================

Overall Accuracy: 0.8500 (85.00%)

Per-Class Metrics:
------------------------------------------------------------
Class      Precision    Recall       F1-Score     Support
------------------------------------------------------------
P1         0.8333       0.8333       0.8333       6
P2         1.0000       0.8750       0.9333       8
P3         0.7500       0.8333       0.7895       6
------------------------------------------------------------
Weighted   0.8750       0.8500       0.8594       20
------------------------------------------------------------

Confusion Matrix:
[[5 1 0]
 [0 7 1]
 [0 1 5]]
```

---

## 🎯 For Fine-Tuned LLM (Your IT Tickets)

### Complete Evaluation with Text Extraction

```python
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
import re
from evaluate import load

def extract_priority(text):
    """Extract P1/P2/P3 from generated text"""
    match = re.search(r'Priority:\s*(P[1-3])', text)
    return match.group(1) if match else None


def evaluate_finetuned_model(model_path, test_file):
    """
    Evaluation pipeline for fine-tuned IT ticket classifier
    """
    # Load model
    base_model = AutoModelForCausalLM.from_pretrained(
        "mistralai/Mistral-7B-v0.1",
        device_map="auto"
    )
    model = PeftModel.from_pretrained(base_model, model_path)
    tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-v0.1")
    model.eval()
    
    # Load test data
    test_data = load_dataset("json", data_files=test_file)["train"]
    
    # Storage
    y_true = []
    y_pred = []
    
    # Generate predictions
    print(f"Evaluating {len(test_data)} examples...")
    for idx, example in enumerate(test_data):
        user_msg = example['messages'][1]['content']
        true_response = example['messages'][2]['content']
        
        # Generate
        prompt = f"<s>[INST] {user_msg} [/INST]"
        inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
        
        import torch
        with torch.no_grad():
            outputs = model.generate(**inputs, max_new_tokens=100, do_sample=False)
        
        generated = tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract priorities
        pred_priority = extract_priority(generated)
        true_priority = extract_priority(true_response)
        
        if pred_priority and true_priority:
            y_pred.append(pred_priority)
            y_true.append(true_priority)
    
    # Evaluate
    results = evaluate_model(y_true, y_pred, ['P1', 'P2', 'P3'])
    
    return results


# Run
results = evaluate_finetuned_model("./trained_model", "test.jsonl")
```

---

## 🔥 Interview Questions & Answers

### Q1: "Why use F1 instead of accuracy?"

**Answer:**
> "Accuracy can be misleading with imbalanced data. If 95% of tickets are P2, a dumb model that always predicts P2 gets 95% accuracy but is useless. F1 balances precision and recall, giving a better picture of true performance across all classes, especially minorities."

---

### Q2: "For P1 tickets, would you optimize for precision or recall?"

**Answer:**
> "Recall. Missing a critical P1 ticket (false negative) is much worse than incorrectly flagging a P2 as P1 (false positive). False positives cause extra work; false negatives cause outages. I'd target 95%+ recall for P1, even if precision drops to 70%."

---

### Q3: "What's weighted vs macro average?"

**Answer:**
> "Weighted average accounts for class imbalance by multiplying each class metric by its frequency. Macro average treats all classes equally. For IT tickets where P2 is common (60%) but P1 is rare (10%), weighted average is more realistic because it reflects actual performance on production data."

```python
# Example:
# P1: precision=0.9, support=10
# P2: precision=0.7, support=90

# Macro: (0.9 + 0.7) / 2 = 0.8
# Weighted: (0.9*10 + 0.7*90) / 100 = 0.72  ← More realistic
```

---

### Q4: "How do you handle class imbalance?"

**Answer:**
> "Multiple strategies: (1) Use weighted loss during training to penalize minority class errors more. (2) Oversample minority class or undersample majority. (3) Use F1 or weighted metrics instead of accuracy for evaluation. (4) For critical classes like P1, set a higher recall threshold even if precision suffers."

---

## 📌 Quick Reference

| Metric | Formula | Question Answered | When Important |
|--------|---------|-------------------|----------------|
| **Accuracy** | (TP+TN)/Total | "Overall, how often correct?" | Balanced datasets |
| **Precision** | TP/(TP+FP) | "When I say yes, am I right?" | False positives costly |
| **Recall** | TP/(TP+FN) | "Did I find all the positives?" | False negatives costly |
| **F1** | 2×(P×R)/(P+R) | "Balance of P and R?" | Imbalanced data |

---

## 🎯 Your IT Ticket Case

**Priority Distribution:**
- P1 (Critical): 10% of tickets
- P2 (Medium): 60% of tickets  
- P3 (Low): 30% of tickets

**Metric Priorities:**
1. **P1 Recall**: Must be >95% (can't miss critical issues)
2. **Overall F1**: Should be >85% (good balance)
3. **P2/P3 Precision**: Should be >80% (minimize misrouting)

**Training Goal:**
```python
training_args = TrainingArguments(
    metric_for_best_model="f1",  # Use F1 for model selection
    load_best_model_at_end=True,
    evaluation_strategy="epoch"
)
```

**Good luck with TCS! 🚀**
