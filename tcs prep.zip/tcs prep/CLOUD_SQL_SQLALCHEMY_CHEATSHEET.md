# Cloud SQL + SQLAlchemy + PostgreSQL Cheatsheet

## 1. SETUP

### Database Connection
```python
# database.py
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Connection string
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_NAME = os.getenv("DB_NAME", "mydatabase")
DB_HOST = os.getenv("DB_HOST", "localhost")

DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:5432/{DB_NAME}"

# Engine with connection pooling
engine = create_engine(
    DATABASE_URL,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
    pool_recycle=3600
)

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base for models
Base = declarative_base()

# Dependency for FastAPI
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

---

## 2. MODELS (SQLAlchemy - Database Tables)

### Single Table
```python
# models.py
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Numeric
from sqlalchemy.sql import func
from database import Base

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    username = Column(String(100), nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    age = Column(Integer)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
```

### Relationships

**One-to-Many:**
```python
from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    email = Column(String(255))
    
    # Relationship
    orders = relationship("Order", back_populates="user", cascade="all, delete-orphan")

class Order(Base):
    __tablename__ = "orders"
    
    id = Column(Integer, primary_key=True)
    order_number = Column(String(50), unique=True)
    total_amount = Column(Numeric(10, 2))
    
    # Foreign key
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    user = relationship("User", back_populates="orders")
```

**One-to-One:**
```python
class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    email = Column(String(255))
    
    profile = relationship("Profile", back_populates="user", uselist=False)

class Profile(Base):
    __tablename__ = "profiles"
    
    id = Column(Integer, primary_key=True)
    bio = Column(String(500))
    
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    user = relationship("User", back_populates="profile")
```

### Indexing
```python
from sqlalchemy import Index

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    email = Column(String(255), index=True)
    city = Column(String(100))
    country = Column(String(100))
    
    # Composite index
    __table_args__ = (
        Index('idx_city_country', 'city', 'country'),
    )
```

---

## 3. SCHEMAS (Pydantic - API Validation)

```python
# schemas.py
from pydantic import BaseModel, EmailStr
from datetime import datetime

class UserCreate(BaseModel):
    """Request body for creating user"""
    email: EmailStr
    username: str
    password: str

class UserUpdate(BaseModel):
    """Request body for updating user"""
    email: EmailStr | None = None
    username: str | None = None

class UserResponse(BaseModel):
    """Response body"""
    id: int
    email: str
    username: str
    is_active: bool
    created_at: datetime
    
    class Config:
        from_attributes = True  # Allows conversion from SQLAlchemy model
```

---

## 4. FASTAPI WITH DEPENDS

```python
# main.py
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db, engine, Base
import models, schemas

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI()

@app.post("/users/", response_model=schemas.UserResponse)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    # Check if exists
    existing = db.query(models.User).filter(models.User.email == user.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email exists")
    
    # Create
    db_user = models.User(
        email=user.email,
        username=user.username,
        password_hash=hash_password(user.password)
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.get("/users/{user_id}", response_model=schemas.UserResponse)
def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@app.get("/users/", response_model=list[schemas.UserResponse])
def list_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    users = db.query(models.User).offset(skip).limit(limit).all()
    return users

@app.put("/users/{user_id}", response_model=schemas.UserResponse)
def update_user(user_id: int, user: schemas.UserUpdate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if user.email:
        db_user.email = user.email
    if user.username:
        db_user.username = user.username
    
    db.commit()
    db.refresh(db_user)
    return db_user

@app.delete("/users/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    db.delete(db_user)
    db.commit()
    return {"message": "User deleted"}
```

---

## 5. CRUD OPERATIONS

### ORM (Built-in)

**Create:**
```python
user = User(email="test@example.com", username="test")
db.add(user)
db.commit()
db.refresh(user)
```

**Read:**
```python
# Get one
user = db.query(User).filter(User.id == 1).first()

# Get all
users = db.query(User).filter(User.is_active == True).all()

# Multiple filters (AND)
users = db.query(User).filter(User.age > 25, User.is_active == True).all()

# OR conditions
from sqlalchemy import or_
users = db.query(User).filter(or_(User.age < 18, User.age > 65)).all()

# IN clause
users = db.query(User).filter(User.id.in_([1, 2, 3])).all()

# LIKE
users = db.query(User).filter(User.email.like("%@gmail.com")).all()

# Count
count = db.query(User).filter(User.is_active == True).count()

# Order by
users = db.query(User).order_by(User.created_at.desc()).all()

# Pagination
users = db.query(User).offset(10).limit(20).all()
```

**Update:**
```python
user = db.query(User).filter(User.id == 1).first()
user.email = "newemail@example.com"
db.commit()
db.refresh(user)

# Bulk update
db.query(User).filter(User.age > 65).update({"is_active": False})
db.commit()
```

**Delete:**
```python
user = db.query(User).filter(User.id == 1).first()
db.delete(user)
db.commit()
```

**Joins (ORM):**
```python
# Inner join
users = db.query(User).join(User.orders).all()

# Left join
users = db.query(User).outerjoin(User.orders).all()

# Filter on joined table
users = db.query(User).join(User.orders).filter(Order.total_amount > 1000).all()

# Eager loading (avoid N+1 queries)
from sqlalchemy.orm import joinedload
users = db.query(User).options(joinedload(User.orders)).all()
```

---

### Raw SQL (text)

```python
from sqlalchemy import text

# SELECT
query = text("SELECT * FROM users WHERE email = :email")
result = db.execute(query, {"email": "test@example.com"})
user = result.fetchone()

# SELECT ALL
query = text("SELECT * FROM users WHERE age > :age")
result = db.execute(query, {"age": 25})
users = result.fetchall()

# COUNT
query = text("SELECT COUNT(*) FROM users")
count = db.execute(query).scalar()

# INSERT
query = text("""
    INSERT INTO users (email, username, created_at)
    VALUES (:email, :username, NOW())
    RETURNING id, email, username
""")
result = db.execute(query, {"email": "test@example.com", "username": "test"})
db.commit()
user = result.fetchone()

# UPDATE
query = text("""
    UPDATE users 
    SET email = :email, updated_at = NOW()
    WHERE id = :user_id
""")
db.execute(query, {"email": "new@example.com", "user_id": 1})
db.commit()

# DELETE
query = text("DELETE FROM users WHERE id = :user_id")
db.execute(query, {"user_id": 1})
db.commit()

# JOIN
query = text("""
    SELECT u.username, o.order_number, o.total_amount
    FROM users u
    INNER JOIN orders o ON u.id = o.user_id
    WHERE u.is_active = true
""")
results = db.execute(query).fetchall()

# COMPLEX QUERY
query = text("""
    SELECT 
        u.username,
        COUNT(o.id) as order_count,
        SUM(o.total_amount) as total_spent
    FROM users u
    LEFT JOIN orders o ON u.id = o.user_id
    WHERE u.created_at >= NOW() - INTERVAL '30 days'
    GROUP BY u.id, u.username
    HAVING COUNT(o.id) >= 3
    ORDER BY total_spent DESC
    LIMIT 10
""")
results = db.execute(query).fetchall()
```

---

## 6. SQL JOINS (Theory + Queries)

### INNER JOIN
```sql
-- Only matching records from both tables
SELECT u.*, o.order_number
FROM users u
INNER JOIN orders o ON u.id = o.user_id;
```

### LEFT JOIN
```sql
-- All users, even without orders
SELECT u.*, o.order_number
FROM users u
LEFT JOIN orders o ON u.id = o.user_id;
```

### RIGHT JOIN
```sql
-- All orders, even without valid users
SELECT u.*, o.order_number
FROM users u
RIGHT JOIN orders o ON u.id = o.user_id;
```

### FULL OUTER JOIN
```sql
-- All from both tables (nulls where no match)
SELECT u.*, o.order_number
FROM users u
FULL OUTER JOIN orders o ON u.id = o.user_id;
```

### SELF JOIN
```sql
-- Employees and their managers
SELECT e.name as employee, m.name as manager
FROM employees e
INNER JOIN employees m ON e.manager_id = m.id;
```

---

## 7. WINDOW FUNCTIONS

### DENSE_RANK
```sql
-- No gaps in ranking
SELECT 
    name, 
    salary,
    DENSE_RANK() OVER (ORDER BY salary DESC) as rank
FROM employees;
```

### RANK
```sql
-- Has gaps in ranking
SELECT 
    name, 
    salary,
    RANK() OVER (ORDER BY salary DESC) as rank
FROM employees;
```

### ROW_NUMBER
```sql
-- Unique row numbers (no ties)
SELECT 
    name, 
    salary,
    ROW_NUMBER() OVER (ORDER BY salary DESC) as row_num
FROM employees;
```

### PARTITION BY
```sql
-- Separate ranking per department
SELECT 
    department,
    name, 
    salary,
    DENSE_RANK() OVER (PARTITION BY department ORDER BY salary DESC) as dept_rank
FROM employees;
```

### Find 2nd Highest Salary
```sql
-- Method 1: LIMIT OFFSET
SELECT DISTINCT salary 
FROM employees 
ORDER BY salary DESC 
LIMIT 1 OFFSET 1;

-- Method 2: Subquery
SELECT MAX(salary) 
FROM employees 
WHERE salary < (SELECT MAX(salary) FROM employees);

-- Method 3: Window function
SELECT salary 
FROM (
    SELECT salary, DENSE_RANK() OVER (ORDER BY salary DESC) as rank
    FROM employees
) ranked
WHERE rank = 2;
```

### Top 2 Earners per Department
```sql
SELECT department, name, salary
FROM (
    SELECT 
        department,
        name,
        salary,
        DENSE_RANK() OVER (PARTITION BY department ORDER BY salary DESC) as rank
    FROM employees
) ranked
WHERE rank <= 2;
```

---

## 8. COMMON SQL QUERIES

### Basic Queries
```sql
-- Select all
SELECT * FROM users;

-- Select specific columns
SELECT id, email, username FROM users;

-- WHERE clause
SELECT * FROM users WHERE is_active = true;

-- Multiple conditions (AND)
SELECT * FROM users WHERE age > 25 AND is_active = true;

-- OR condition
SELECT * FROM users WHERE age < 18 OR age > 65;

-- IN clause
SELECT * FROM users WHERE id IN (1, 2, 3, 4);

-- LIKE (pattern matching)
SELECT * FROM users WHERE email LIKE '%@gmail.com';

-- BETWEEN
SELECT * FROM orders WHERE created_at BETWEEN '2024-01-01' AND '2024-12-31';

-- IS NULL
SELECT * FROM users WHERE deleted_at IS NULL;

-- ORDER BY
SELECT * FROM users ORDER BY created_at DESC;

-- LIMIT
SELECT * FROM users LIMIT 10;

-- OFFSET (pagination)
SELECT * FROM users ORDER BY id LIMIT 20 OFFSET 40;
```

### Aggregations
```sql
-- COUNT
SELECT COUNT(*) FROM users;
SELECT COUNT(*) FROM users WHERE is_active = true;

-- SUM
SELECT SUM(total_amount) FROM orders;

-- AVG
SELECT AVG(age) FROM users;

-- MAX, MIN
SELECT MAX(salary), MIN(salary) FROM employees;

-- GROUP BY
SELECT department, COUNT(*) as employee_count
FROM employees
GROUP BY department;

-- GROUP BY with HAVING
SELECT department, AVG(salary) as avg_salary
FROM employees
GROUP BY department
HAVING AVG(salary) > 50000;
```

### Subqueries
```sql
-- Subquery in WHERE
SELECT * FROM users 
WHERE id IN (SELECT user_id FROM orders WHERE total_amount > 1000);

-- Subquery in FROM
SELECT username, order_count
FROM (
    SELECT user_id, COUNT(*) as order_count
    FROM orders
    GROUP BY user_id
) order_stats
JOIN users ON users.id = order_stats.user_id;
```

### CTEs (Common Table Expressions)
```sql
WITH active_users AS (
    SELECT * FROM users WHERE is_active = true
),
big_orders AS (
    SELECT * FROM orders WHERE total_amount > 1000
)
SELECT u.username, o.order_number
FROM active_users u
JOIN big_orders o ON u.id = o.user_id;
```

---

## 9. PRACTICAL EXAMPLES

### Get users with their order count
```sql
SELECT 
    u.id,
    u.username,
    COUNT(o.id) as order_count
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
GROUP BY u.id, u.username
ORDER BY order_count DESC;
```

### Find users who never ordered
```sql
SELECT u.*
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
WHERE o.id IS NULL;
```

### Get top spending customers
```sql
SELECT 
    u.username,
    SUM(o.total_amount) as total_spent
FROM users u
INNER JOIN orders o ON u.id = o.user_id
GROUP BY u.id, u.username
ORDER BY total_spent DESC
LIMIT 10;
```

### Find duplicate emails
```sql
SELECT email, COUNT(*) as count
FROM users
GROUP BY email
HAVING COUNT(*) > 1;
```

### Running total
```sql
SELECT 
    created_at,
    total_amount,
    SUM(total_amount) OVER (ORDER BY created_at) as running_total
FROM orders;
```

---

## 10. INTERVIEW Q&A

**Q: ORM vs Raw SQL?**
- Use ORM for simple CRUD (type-safe, maintainable)
- Use Raw SQL for complex queries (joins, aggregations, performance)

**Q: Why indexes?**
- Speed up SELECT queries on frequently searched columns
- Slow down INSERT/UPDATE (index needs updating)
- Use on WHERE, JOIN, ORDER BY columns

**Q: LEFT JOIN vs INNER JOIN?**
- INNER: Only matching records
- LEFT: All from left table, even without match

**Q: DENSE_RANK vs RANK?**
- DENSE_RANK: No gaps (1, 1, 2, 2, 3)
- RANK: Has gaps (1, 1, 3, 3, 5)

**Q: PARTITION BY?**
- Divides data into groups, applies function to each group separately
- Like GROUP BY but keeps all rows

**Q: 2nd highest salary?**
```sql
SELECT DISTINCT salary 
FROM employees 
ORDER BY salary DESC 
LIMIT 1 OFFSET 1;
```

**Q: N+1 query problem?**
- Problem: One query for users, then N queries for each user's orders
- Solution: Use `joinedload(User.orders)` for eager loading
