# STACK CHEATSHEET 📚

> Concepts + Solved Problems (Valid Parentheses, Next Greater Element, Daily Temperatures)

---

## 1. STACK FUNDAMENTALS

### What is Stack?
**LIFO (Last In, First Out)** - Like a stack of plates, you only touch the top one.

### Python Stack Operations:
```python
stack = []

stack.append(x)      # Push - O(1)
stack.pop()          # Pop - O(1)
stack[-1]            # Peek/Top - O(1)
len(stack)           # Size - O(1)
not stack            # isEmpty - O(1)
```

### When to Use Stack?
**Keywords:** valid, matching, balanced, nested, next greater, next smaller, previous larger

---

## 2. TWO MAIN PATTERNS

### Pattern 1: Matching/Balancing Pattern
**Use Case:** Parentheses, brackets, HTML tags, nested structures

**Logic:**
- Opening → Push to stack
- Closing → Check if matches top, then pop
- End → Stack should be empty

---

### Pattern 2: Monotonic Stack Pattern
**Use Case:** Next greater, next smaller, daily temperatures

**Key Idea:** 
- Stack stays in DECREASING order (big → small from bottom to top)
- When you see BIGGER → pop all smaller (they found their answer!)
- When you see SMALLER → just push (still waiting)

**Simple Rule:**
```
Array: [2, 1, 5, 6, 2, 3]
Goal: Find next greater element

When current > stack top:
  → Pop (found answer for that popped element!)
  
When current < stack top:
  → Just push (still waiting for answer)
```

---

## 3. SOLVED PROBLEMS

### Problem 1: Valid Parentheses ✅

**Question:** Check if brackets are valid: `()[]{}` → True, `([)]` → False

**Solution:**
```python
def isValid(s):
    stack = []
    
    for char in s:
        if char == '(' or char == '{' or char == '[':
            stack.append(char)
        else:
            if not stack:
                return False
            if char == ')' and stack[-1] != '(':
                return False
            if char == '}' and stack[-1] != '{':
                return False
            if char == ']' and stack[-1] != '[':
                return False
            stack.pop()
    
    return len(stack) == 0
```

**Pattern:** Matching/Balancing  
**Time:** O(n)  
**Space:** O(n)

---

### Problem 2: Next Greater Element ✅

**Question:** For each element, find next element that's greater  
Input: `[2, 1, 5, 6, 2, 3]` → Output: `[5, 5, 6, -1, 3, -1]`

**Solution:**
```python
def nextGreaterElement(nums):
    n = len(nums)
    result = [-1] * n
    stack = []
    
    for i in range(n):
        while stack and nums[i] > nums[stack[-1]]:
            idx = stack.pop()
            result[idx] = nums[i]  # Store the VALUE
        stack.append(i)
    
    return result
```

**Pattern:** Monotonic Stack (Decreasing)  
**Key:** `result[idx] = nums[i]` (store the greater value)  
**Time:** O(n)  
**Space:** O(n)

---

### Problem 3: Daily Temperatures ✅

**Question:** For each day, how many days until warmer temperature?  
Input: `[73, 74, 75, 71, 69, 72, 76, 73]` → Output: `[1, 1, 4, 2, 1, 1, 0, 0]`

**Solution:**
```python
def dailyTemperatures(temperatures):
    n = len(temperatures)
    result = [0] * n
    stack = []
    
    for i in range(n):
        while stack and temperatures[i] > temperatures[stack[-1]]:
            idx = stack.pop()
            result[idx] = i - idx  # Store the DISTANCE
        stack.append(i)
    
    return result
```

**Pattern:** Monotonic Stack (Decreasing)  
**Key:** `result[idx] = i - idx` (store days to wait, not value)  
**Time:** O(n)  
**Space:** O(n)

---

## 4. KEY DIFFERENCES

| Problem | What to Store | Code |
|---------|--------------|------|
| Next Greater Element | The greater **value** | `result[idx] = nums[i]` |
| Daily Temperatures | The **distance** (days) | `result[idx] = i - idx` |

**Both use same monotonic stack pattern, just different outputs!**

---

## 5. MONOTONIC STACK - THE SIMPLE EXPLANATION

**Array:** `[2, 1, 5, 6, 2, 3]`  
**Goal:** Next Greater Element

```
Step-by-step:

i=0, num=2:  Stack: [0]

i=1, num=1:  1 < 2 → push
             Stack: [0, 1]  (decreasing: 2, 1)

i=2, num=5:  5 > 1 → pop 1, answer[1] = 5
             5 > 2 → pop 0, answer[0] = 5
             Stack: [2]

i=3, num=6:  6 > 5 → pop 2, answer[2] = 6
             Stack: [3]

i=4, num=2:  2 < 6 → push
             Stack: [3, 4]  (decreasing: 6, 2)

i=5, num=3:  3 > 2 → pop 4, answer[4] = 3
             3 < 6 → push
             Stack: [3, 5]  (decreasing: 6, 3)

Final: answer = [5, 5, 6, -1, 3, -1]
```

**The Rule:** When current is BIGGER → all smaller elements found their answer!

---

## 6. REAL-WORLD GEN AI USE CASES

### Stack Pattern 1 (Matching):
- **JSON Validation:** Check if `{[()]}` structure is valid
- **Agent Call Tracking:** Match function calls and returns
- **Undo Operations:** Last action first to undo (LIFO)

### Stack Pattern 2 (Monotonic):
- **LLM Response Time Monitoring:** Find next faster response
- **Token Generation Rate:** Track when generation speeds up
- **Vector Search Latency:** Monitor performance improvements

---

## 7. QUICK DECISION GUIDE

**Problem has "valid", "balanced", "matching"?**  
→ Use Matching Stack Pattern (Problem 1)

**Problem has "next greater", "next smaller", "warmer"?**  
→ Use Monotonic Stack Pattern (Problems 2 & 3)

---

## 8. COMMON MISTAKES TO AVOID

❌ **Wrong:** Using value instead of index in stack  
✅ **Right:** Store indices in stack, access values with `nums[stack[-1]]`

❌ **Wrong:** Forgetting to check `if not stack` before popping  
✅ **Right:** Always check `while stack and condition`

❌ **Wrong:** Mixing up when to store value vs distance  
✅ **Right:** Next Greater = value, Daily Temps = distance

---

**Stack Complete! Next: Intervals (4 problems) → Queue (3 problems) 🚀**
