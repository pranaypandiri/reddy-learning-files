# APScheduler - Complete Cheat Sheet

## What is APScheduler?

**APScheduler** = Advanced Python Scheduler
- Python library for scheduling jobs (background tasks)
- Run functions periodically (every X seconds, at specific times, etc.)
- Similar to cron but in Python code

**Common Use Cases:**
- Flush buffered messages every 1 minute
- Cleanup old sessions every hour
- Send reports daily at 9 AM
- Check external APIs every 30 seconds

---

## Installation

```bash
pip install apscheduler
```

---

## Core Concepts

### **1. Scheduler Types**

| Scheduler | Use Case | Blocks Main Thread? |
|-----------|----------|-------------------|
| **BackgroundScheduler** | FastAPI, Flask, standalone scripts | No (runs in background thread) |
| **AsyncIOScheduler** | FastAPI with async/await | No (uses asyncio) |
| **BlockingScheduler** | Script that only runs jobs | Yes (main process blocked) |

**Most common:** `BackgroundScheduler` for FastAPI

---

### **2. Trigger Types**

| Trigger | Description | Example |
|---------|-------------|---------|
| **interval** | Run every X seconds/minutes/hours | Every 60 seconds |
| **cron** | Run at specific times (like Linux cron) | Every day at 9 AM |
| **date** | Run once at a specific datetime | On 2025-12-31 at 11:59 PM |

---

## Basic Usage

### **Pattern 1: Interval Trigger (Most Common)**

```python
from apscheduler.schedulers.background import BackgroundScheduler

# Function to run periodically
def my_job():
    print("Job executed!")
    # Do some work here

# Create scheduler
scheduler = BackgroundScheduler()

# Add job - runs every 60 seconds
scheduler.add_job(
    my_job,              # Function to call
    'interval',          # Trigger type
    seconds=60,          # Run every 60 seconds
    id='my_job_id'       # Unique ID for this job
)

# Start scheduler
scheduler.start()

# Keep program running (for standalone scripts)
try:
    while True:
        pass
except KeyboardInterrupt:
    scheduler.shutdown()
```

---

### **Pattern 2: Cron Trigger (Specific Times)**

```python
from apscheduler.schedulers.background import BackgroundScheduler

def send_daily_report():
    print("Sending daily report...")

scheduler = BackgroundScheduler()

# Run every day at 9:00 AM
scheduler.add_job(
    send_daily_report,
    'cron',
    hour=9,
    minute=0,
    id='daily_report'
)

scheduler.start()
```

---

### **Pattern 3: Date Trigger (One-time)**

```python
from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler

def one_time_task():
    print("This runs only once")

scheduler = BackgroundScheduler()

# Run once at specific datetime
run_time = datetime.now() + timedelta(minutes=5)

scheduler.add_job(
    one_time_task,
    'date',
    run_date=run_time,
    id='one_time_job'
)

scheduler.start()
```

---

## FastAPI Integration (Production Pattern)

### **Complete Example - Flush Messages Every 1 Minute**

```python
from fastapi import FastAPI
from apscheduler.schedulers.background import BackgroundScheduler
from typing import Dict, List
from google.cloud import firestore

app = FastAPI()
db = firestore.Client()

# Global state
MESSAGE_BUFFERS: Dict[str, List[dict]] = {}

# ============================================
# JOB FUNCTION
# ============================================

def flush_to_firestore():
    """Called every 1 minute by scheduler"""
    
    print(f"[SCHEDULER] Flushing {len(MESSAGE_BUFFERS)} sessions...")
    
    for session_id, messages in list(MESSAGE_BUFFERS.items()):
        if messages:
            db.collection("sessions").document(session_id).update({
                "messages": firestore.ArrayUnion(messages)
            })
            print(f"[SCHEDULER] Saved {len(messages)} messages for {session_id}")
            MESSAGE_BUFFERS[session_id] = []
    
    print("[SCHEDULER] Flush complete")


# ============================================
# SCHEDULER SETUP
# ============================================

scheduler = BackgroundScheduler()

@app.on_event("startup")
def startup_event():
    """Start scheduler when FastAPI starts"""
    
    # Add job to run every 60 seconds
    scheduler.add_job(
        flush_to_firestore,
        'interval',
        seconds=60,
        id='flush_job',
        replace_existing=True  # Replace if already exists
    )
    
    scheduler.start()
    print("✓ Scheduler started - will flush every 60 seconds")


@app.on_event("shutdown")
def shutdown_event():
    """Save everything before shutdown"""
    
    print("Shutting down - flushing remaining data...")
    flush_to_firestore()  # Final flush
    scheduler.shutdown()
    print("✓ Scheduler stopped")


# ============================================
# API ENDPOINTS
# ============================================

@app.post("/chat")
def chat(session_id: str, message: str):
    if session_id not in MESSAGE_BUFFERS:
        MESSAGE_BUFFERS[session_id] = []
    
    MESSAGE_BUFFERS[session_id].append({
        "role": "user",
        "content": message
    })
    
    return {"status": "buffered"}
```

---

## Common Interval Examples

```python
scheduler = BackgroundScheduler()

# Every 30 seconds
scheduler.add_job(my_job, 'interval', seconds=30)

# Every 5 minutes
scheduler.add_job(my_job, 'interval', minutes=5)

# Every 1 hour
scheduler.add_job(my_job, 'interval', hours=1)

# Every 2 hours
scheduler.add_job(my_job, 'interval', hours=2)

# Every day (24 hours)
scheduler.add_job(my_job, 'interval', days=1)

scheduler.start()
```

---

## Common Cron Examples

```python
scheduler = BackgroundScheduler()

# Every day at 9:00 AM
scheduler.add_job(my_job, 'cron', hour=9, minute=0)

# Every Monday at 10:30 AM
scheduler.add_job(my_job, 'cron', day_of_week='mon', hour=10, minute=30)

# Every hour at minute 15 (1:15, 2:15, 3:15, etc.)
scheduler.add_job(my_job, 'cron', minute=15)

# Every weekday (Mon-Fri) at 8 AM
scheduler.add_job(my_job, 'cron', day_of_week='mon-fri', hour=8)

# First day of every month at midnight
scheduler.add_job(my_job, 'cron', day=1, hour=0, minute=0)

scheduler.start()
```

---

## Job Management

### **List All Jobs**

```python
jobs = scheduler.get_jobs()

for job in jobs:
    print(f"Job ID: {job.id}")
    print(f"Next run: {job.next_run_time}")
    print(f"Trigger: {job.trigger}")
```

### **Remove a Job**

```python
# Remove by ID
scheduler.remove_job('my_job_id')

# Check if job exists
if scheduler.get_job('my_job_id'):
    scheduler.remove_job('my_job_id')
```

### **Pause a Job**

```python
# Pause
scheduler.pause_job('my_job_id')

# Resume
scheduler.resume_job('my_job_id')
```

### **Modify a Job**

```python
# Change interval from 60s to 120s
scheduler.reschedule_job(
    'my_job_id',
    trigger='interval',
    seconds=120
)
```

---

## Error Handling

### **Catch Job Errors**

```python
from apscheduler.events import EVENT_JOB_ERROR, EVENT_JOB_EXECUTED

def job_error_listener(event):
    print(f"Job {event.job_id} failed!")
    print(f"Exception: {event.exception}")

def job_success_listener(event):
    print(f"Job {event.job_id} executed successfully")

scheduler = BackgroundScheduler()

# Add listeners
scheduler.add_listener(job_error_listener, EVENT_JOB_ERROR)
scheduler.add_listener(job_success_listener, EVENT_JOB_EXECUTED)

scheduler.start()
```

### **Wrap Job Function with Try-Except**

```python
def safe_job():
    try:
        # Your job logic
        result = do_something()
        print(f"Job completed: {result}")
    except Exception as e:
        print(f"Job failed: {e}")
        # Log error, send alert, etc.

scheduler.add_job(safe_job, 'interval', seconds=60)
```

---

## Timezone Support

```python
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from pytz import timezone

scheduler = BackgroundScheduler()

# Run at 9 AM US/Eastern time
eastern = timezone('US/Eastern')

scheduler.add_job(
    my_job,
    CronTrigger(hour=9, minute=0, timezone=eastern),
    id='eastern_job'
)

scheduler.start()
```

---

## AsyncIO Scheduler (For Async FastAPI)

```python
from fastapi import FastAPI
from apscheduler.schedulers.asyncio import AsyncIOScheduler

app = FastAPI()
scheduler = AsyncIOScheduler()

async def async_job():
    """Async job function"""
    print("Running async job...")
    await some_async_operation()
    print("Async job complete")

@app.on_event("startup")
async def startup():
    scheduler.add_job(async_job, 'interval', seconds=60)
    scheduler.start()

@app.on_event("shutdown")
async def shutdown():
    scheduler.shutdown()
```

---

## Production Best Practices

### ✅ DO

```python
# 1. Use replace_existing to avoid duplicate jobs
scheduler.add_job(
    my_job,
    'interval',
    seconds=60,
    id='unique_job_id',
    replace_existing=True  # ← Important!
)

# 2. Always shutdown gracefully
@app.on_event("shutdown")
def shutdown():
    scheduler.shutdown(wait=True)  # Wait for running jobs

# 3. Use job IDs for management
scheduler.add_job(my_job, 'interval', seconds=60, id='flush_job')

# 4. Handle errors in job functions
def safe_job():
    try:
        do_work()
    except Exception as e:
        logger.error(f"Job failed: {e}")

# 5. Use appropriate scheduler type
# FastAPI → BackgroundScheduler
# Async FastAPI → AsyncIOScheduler
# Standalone script → BlockingScheduler
```

### ❌ DON'T

```python
# 1. Don't forget to start scheduler
scheduler.add_job(my_job, 'interval', seconds=60)
# scheduler.start()  ← Missing! Jobs won't run

# 2. Don't add jobs without IDs in production
scheduler.add_job(my_job, 'interval', seconds=60)  # Hard to manage

# 3. Don't use BlockingScheduler in FastAPI
from apscheduler.schedulers.blocking import BlockingScheduler
scheduler = BlockingScheduler()  # ← Blocks FastAPI!

# 4. Don't run long-blocking operations in jobs
def bad_job():
    time.sleep(300)  # 5 minutes - blocks scheduler!

# 5. Don't start multiple schedulers
scheduler1.start()
scheduler2.start()  # ← Causes issues
```

---

## Common Patterns

### **Pattern 1: Cleanup Old Data**

```python
from datetime import datetime, timedelta

def cleanup_old_sessions():
    """Delete sessions older than 7 days"""
    
    cutoff = datetime.now() - timedelta(days=7)
    
    old_sessions = db.collection("sessions") \
        .where("created_at", "<", cutoff) \
        .limit(100) \
        .stream()
    
    count = 0
    for doc in old_sessions:
        doc.reference.delete()
        count += 1
    
    print(f"Cleaned up {count} old sessions")

# Run every day at 2 AM
scheduler.add_job(cleanup_old_sessions, 'cron', hour=2, minute=0)
```

### **Pattern 2: Health Check**

```python
def health_check():
    """Check if external services are healthy"""
    
    try:
        # Check database
        db.collection("health").document("test").get()
        
        # Check API
        response = requests.get("https://api.example.com/health")
        
        if response.status_code != 200:
            send_alert("API health check failed")
    
    except Exception as e:
        send_alert(f"Health check error: {e}")

# Run every 5 minutes
scheduler.add_job(health_check, 'interval', minutes=5)
```

### **Pattern 3: Generate Reports**

```python
def generate_daily_report():
    """Generate and send daily usage report"""
    
    # Collect data
    total_sessions = db.collection("sessions").count().get()
    active_users = get_active_user_count()
    
    # Generate report
    report = f"Daily Report:\n- Sessions: {total_sessions}\n- Active users: {active_users}"
    
    # Send via email/Slack
    send_report(report)

# Run every day at 9 AM
scheduler.add_job(generate_daily_report, 'cron', hour=9, minute=0)
```

---

## Debugging

### **Check If Scheduler is Running**

```python
if scheduler.running:
    print("Scheduler is running")
else:
    print("Scheduler is stopped")
```

### **Print Job Details**

```python
job = scheduler.get_job('my_job_id')

if job:
    print(f"Job ID: {job.id}")
    print(f"Next run time: {job.next_run_time}")
    print(f"Trigger: {job.trigger}")
    print(f"Function: {job.func}")
else:
    print("Job not found")
```

### **Enable Logging**

```python
import logging

logging.basicConfig()
logging.getLogger('apscheduler').setLevel(logging.DEBUG)

# Now you'll see detailed scheduler logs
```

---

## Complete Production Example

```python
from fastapi import FastAPI
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.events import EVENT_JOB_ERROR, EVENT_JOB_EXECUTED
from typing import Dict, List
from google.cloud import firestore
from datetime import datetime, timedelta
import logging

# Setup logging
logging.basicConfig()
logger = logging.getLogger(__name__)

app = FastAPI()
db = firestore.Client()

# Global state
MESSAGE_BUFFERS: Dict[str, List[dict]] = {}

# ============================================
# JOB FUNCTIONS
# ============================================

def flush_messages():
    """Flush buffered messages to Firestore"""
    try:
        count = 0
        for session_id, messages in list(MESSAGE_BUFFERS.items()):
            if messages:
                db.collection("sessions").document(session_id).update({
                    "messages": firestore.ArrayUnion(messages)
                })
                MESSAGE_BUFFERS[session_id] = []
                count += len(messages)
        
        logger.info(f"Flushed {count} messages")
    
    except Exception as e:
        logger.error(f"Flush failed: {e}")


def cleanup_old_sessions():
    """Delete sessions older than 30 days"""
    try:
        cutoff = datetime.now() - timedelta(days=30)
        
        old_sessions = db.collection("sessions") \
            .where("created_at", "<", cutoff) \
            .limit(100) \
            .stream()
        
        count = 0
        for doc in old_sessions:
            doc.reference.delete()
            count += 1
        
        logger.info(f"Cleaned {count} old sessions")
    
    except Exception as e:
        logger.error(f"Cleanup failed: {e}")


# ============================================
# SCHEDULER SETUP
# ============================================

scheduler = BackgroundScheduler()

def job_listener(event):
    """Log job execution"""
    if event.exception:
        logger.error(f"Job {event.job_id} crashed: {event.exception}")
    else:
        logger.info(f"Job {event.job_id} completed successfully")


@app.on_event("startup")
def startup():
    """Initialize scheduler on FastAPI startup"""
    
    # Add listeners
    scheduler.add_listener(job_listener, EVENT_JOB_ERROR | EVENT_JOB_EXECUTED)
    
    # Add jobs
    scheduler.add_job(
        flush_messages,
        'interval',
        seconds=60,
        id='flush_job',
        replace_existing=True
    )
    
    scheduler.add_job(
        cleanup_old_sessions,
        'cron',
        hour=2,
        minute=0,
        id='cleanup_job',
        replace_existing=True
    )
    
    scheduler.start()
    logger.info("✓ Scheduler started")


@app.on_event("shutdown")
def shutdown():
    """Cleanup on FastAPI shutdown"""
    
    logger.info("Shutting down scheduler...")
    flush_messages()  # Final flush
    scheduler.shutdown(wait=True)
    logger.info("✓ Scheduler stopped")


# ============================================
# MANAGEMENT ENDPOINTS
# ============================================

@app.get("/scheduler/status")
def scheduler_status():
    """Get scheduler status"""
    
    jobs = []
    for job in scheduler.get_jobs():
        jobs.append({
            "id": job.id,
            "next_run": str(job.next_run_time),
            "trigger": str(job.trigger)
        })
    
    return {
        "running": scheduler.running,
        "jobs": jobs
    }


@app.post("/scheduler/trigger/{job_id}")
def trigger_job(job_id: str):
    """Manually trigger a job"""
    
    job = scheduler.get_job(job_id)
    
    if job:
        job.modify(next_run_time=datetime.now())
        return {"status": f"Job {job_id} triggered"}
    else:
        return {"error": "Job not found"}
```

---

## Quick Reference

| Task | Code |
|------|------|
| **Create scheduler** | `scheduler = BackgroundScheduler()` |
| **Add interval job** | `scheduler.add_job(func, 'interval', seconds=60)` |
| **Add cron job** | `scheduler.add_job(func, 'cron', hour=9, minute=0)` |
| **Start scheduler** | `scheduler.start()` |
| **Stop scheduler** | `scheduler.shutdown()` |
| **Remove job** | `scheduler.remove_job('job_id')` |
| **List jobs** | `scheduler.get_jobs()` |
| **Pause job** | `scheduler.pause_job('job_id')` |
| **Resume job** | `scheduler.resume_job('job_id')` |

---

## Interview Key Points

**Must Know:**
- Three scheduler types (Background, AsyncIO, Blocking)
- Interval vs Cron triggers
- FastAPI integration with startup/shutdown events
- Error handling in jobs
- Job IDs for management

**Good to Know:**
- replace_existing=True to avoid duplicates
- Graceful shutdown with wait=True
- Job listeners for monitoring
- Timezone support

**Nice to Have:**
- Job modification at runtime
- Event listeners for debugging
- Multiple trigger types

---

## Common Mistakes

1. **Forgot to start scheduler** → Jobs never run
2. **Used BlockingScheduler in FastAPI** → Blocks server
3. **No error handling in jobs** → Silent failures
4. **No job IDs** → Can't manage/remove jobs
5. **Didn't shutdown gracefully** → Data loss on restart

---

**That's everything you need for APScheduler in production!**
