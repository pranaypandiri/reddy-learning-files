# 🚀 Scikit-Learn Interview Cheatsheet

## 📋 Quick Reference - Most Important

### Linear Regression
```python
from sklearn.linear_model import LinearRegression
import numpy as np

# Data (X must be 2D!)
X = np.array([[1], [2], [3], [4], [5]])
y = np.array([2, 4, 6, 8, 10])

# Train
model = LinearRegression()
model.fit(X, y)

# Predict
prediction = model.predict([[6]])  # [12]

# Inspect
print(model.coef_)       # Slope (weights)
print(model.intercept_)  # Intercept (bias)
print(model.score(X, y)) # R² score
```

**Interview Trap:** X must be 2D: `[[1], [2]]` NOT `[1, 2]`

---

### Logistic Regression
```python
from sklearn.linear_model import LogisticRegression

# Train
model = LogisticRegression()
model.fit(X_train, y_train)

# Predict classes
predictions = model.predict(X_test)  # [0, 1, 0, ...]

# Get probabilities
probabilities = model.predict_proba(X_test)  # [[0.3, 0.7], [0.9, 0.1], ...]
# Column 0 = prob of class 0, Column 1 = prob of class 1
```

**Key Concept:** Uses sigmoid function to output probabilities [0, 1]

---

### Train-Test Split
```python
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X, y, 
    test_size=0.2,      # 20% for testing
    random_state=42,    # Reproducibility
    stratify=y          # Maintain class distribution (classification only)
)
```

**Golden Rule:** ALWAYS split BEFORE any preprocessing!

---

### Metrics - Regression
```python
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

mse = mean_squared_error(y_true, y_pred)   # Lower is better
mae = mean_absolute_error(y_true, y_pred)  # Lower is better  
r2 = r2_score(y_true, y_pred)              # Higher is better (max 1.0)

# Or use .score() directly
r2 = model.score(X_test, y_test)  # Returns R²
```

**R² Interpretation:**
- 1.0 = Perfect
- 0.9 = Excellent (90% variance explained)
- 0.5 = Moderate
- 0.0 = Useless (same as guessing average)
- Negative = Worse than guessing average

---

### Metrics - Classification
```python
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

# Basic metrics
accuracy = accuracy_score(y_true, y_pred)
precision = precision_score(y_true, y_pred)
recall = recall_score(y_true, y_pred)
f1 = f1_score(y_true, y_pred)

# Confusion matrix
cm = confusion_matrix(y_true, y_pred)
# [[TN, FP],
#  [FN, TP]]

# Full report
print(classification_report(y_true, y_pred))
```

**When to Use:**
- **Accuracy:** Balanced classes
- **Precision:** Minimize false alarms (spam filter)
- **Recall:** Can't miss positives (cancer detection)
- **F1:** Imbalanced classes, need balance

---

### StandardScaler
```python
from sklearn.preprocessing import StandardScaler

# 1. Split data FIRST
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# 2. Create scaler
scaler = StandardScaler()

# 3. fit_transform on TRAIN only
X_train_scaled = scaler.fit_transform(X_train)

# 4. transform on TEST (no fit!)
X_test_scaled = scaler.transform(X_test)

# 5. Train model
model.fit(X_train_scaled, y_train)
```

**Critical:** Never `fit_transform` on test data → data leakage!

**Formula:** `(value - mean) / std` → Results in mean=0, std=1

---

### Pipeline
```python
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

# Create pipeline
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('model', LogisticRegression())
])

# Fit (automatically scales then trains)
pipeline.fit(X_train, y_train)

# Predict (automatically scales then predicts)
predictions = pipeline.predict(X_test)

# Score
score = pipeline.score(X_test, y_test)
```

**Benefits:**
- No data leakage (can't mess up fit/transform)
- Clean code
- Easy to save/load
- Works with GridSearchCV

---

### Cross-Validation
```python
from sklearn.model_selection import cross_val_score

# 5-fold CV
scores = cross_val_score(model, X, y, cv=5)

print(f"Scores: {scores}")
print(f"Mean: {scores.mean():.3f}")
print(f"Std:  {scores.std():.3f}")
```

**Why?** Single split might be lucky/unlucky. CV gives robust estimate.

**Common K values:**
- K=5: Default, good balance
- K=10: More reliable but slower
- K=3: Faster, less reliable

---

### GridSearchCV
```python
from sklearn.model_selection import GridSearchCV

# Define parameter grid
param_grid = {
    'model__C': [0.1, 1, 10],
    'model__penalty': ['l1', 'l2']
}

# Create GridSearch
grid = GridSearchCV(
    pipeline, 
    param_grid, 
    cv=5,
    n_jobs=-1  # Use all CPUs
)

# Fit (tries all combinations)
grid.fit(X_train, y_train)

# Best results
print(grid.best_params_)
print(grid.best_score_)

# Use best model
best_model = grid.best_estimator_
```

**Parameter naming:** `'step_name__parameter_name'` (double underscore!)

---

## 🎯 Categorical Encoding

### LabelEncoder (Ordinal)
```python
from sklearn.preprocessing import LabelEncoder

# For ordered categories
sizes = ['Small', 'Medium', 'Large', 'Small']
le = LabelEncoder()
encoded = le.fit_transform(sizes)  # [2, 1, 0, 2]
```

**Use when:** Categories have natural order (Low < Medium < High)

---

### OneHotEncoder (Nominal)
```python
from sklearn.preprocessing import OneHotEncoder

# For unordered categories
colors = [['Red'], ['Blue'], ['Green'], ['Red']]
ohe = OneHotEncoder(sparse_output=False, drop='first')
encoded = ohe.fit_transform(colors)
# [[0, 1],   Red
#  [1, 0],   Blue
#  [0, 0]]   Green (implied)
```

**Use when:** No natural order (colors, countries, names)

---

## 🔧 Regularization

### Ridge (L2)
```python
from sklearn.linear_model import Ridge

model = Ridge(alpha=1.0)  # Higher alpha = stronger regularization
model.fit(X_train, y_train)
```

**Effect:** Shrinks all weights toward 0 (but never exactly 0)

---

### Lasso (L1)
```python
from sklearn.linear_model import Lasso

model = Lasso(alpha=0.1)
model.fit(X_train, y_train)

# Check feature selection
non_zero = np.sum(model.coef_ != 0)
print(f"Features kept: {non_zero}/{len(model.coef_)}")
```

**Effect:** Can zero out weights → automatic feature selection

---

## 📊 TF-IDF for Text
```python
from sklearn.feature_extraction.text import TfidfVectorizer

texts = ['I love ML', 'ML is great', 'I love Python']

# Vectorize
vectorizer = TfidfVectorizer(
    max_features=100,
    stop_words='english'
)
X = vectorizer.fit_transform(texts)

# Get vocabulary
vocab = vectorizer.get_feature_names_out()

# Use in pipeline
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer()),
    ('model', LogisticRegression())
])
```

---

## 💡 Interview Q&A

### Q: "Why scale features?"
**A:** "Features with different scales (like income in thousands and age in tens) cause gradient descent to converge slowly because the loss landscape is elongated. Scaling makes all features equal scale, creating a more spherical loss landscape where gradient descent can take more direct steps toward the optimum."

### Q: "Overfitting vs Underfitting?"
**A:** 
- **Overfitting:** Model too complex, memorizes training data. Train score high, test score low. Fix: More data, regularization, simpler model.
- **Underfitting:** Model too simple, can't learn patterns. Both scores low. Fix: More complex model, more features.

### Q: "Precision vs Recall?"
**A:**
- **Precision:** "When I say YES, am I right?" Use when false alarms are costly (spam filter).
- **Recall:** "Did I find all actual YESes?" Use when missing positives is dangerous (cancer detection).

### Q: "Why stratify in train_test_split?"
**A:** "For imbalanced datasets, stratify maintains the class distribution in both train and test sets. Without it, you might get unlucky and have zero minority class samples in your test set, making evaluation impossible."

### Q: "fit_transform vs transform?"
**A:** "`fit_transform` learns statistics from data AND transforms it - use ONLY on training data. `transform` applies already-learned statistics without re-learning - use on test data to avoid data leakage."

### Q: "Ridge vs Lasso?"
**A:** "Ridge (L2) shrinks all weights but keeps all features - use when all features are useful. Lasso (L1) can zero out weights completely, doing feature selection - use when many features are irrelevant."

### Q: "Bias-Variance Tradeoff?"
**A:** "Bias is how wrong the model is on average (underfitting). Variance is how much predictions vary with different data (overfitting). Need to balance both - too simple model has high bias, too complex has high variance. Detect by comparing train vs test scores."

---

## ⚠️ Common Interview Traps

1. **X must be 2D:** Use `X.reshape(-1, 1)` for single feature
2. **Scale AFTER split:** Never fit scaler on test data
3. **Stratify for imbalanced data:** Use `stratify=y` in train_test_split
4. **Pipeline parameter names:** Use double underscore `'step__param'`
5. **Accuracy on imbalanced data:** Use Precision/Recall/F1 instead
6. **R² can be negative:** Means model is worse than guessing mean

---

## 🎯 Complete Interview Code Template

```python
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.pipeline import Pipeline

# 1. Load data
X, y = load_data()

# 2. Split (BEFORE any preprocessing!)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 3. Create pipeline
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('model', LogisticRegression())
])

# 4. Hyperparameter tuning (optional)
param_grid = {'model__C': [0.1, 1, 10]}
grid = GridSearchCV(pipeline, param_grid, cv=5)
grid.fit(X_train, y_train)

# 5. Evaluate
print(f"Best params: {grid.best_params_}")
print(f"CV score: {grid.best_score_:.3f}")

y_pred = grid.predict(X_test)
print(f"Test accuracy: {grid.score(X_test, y_test):.3f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred))
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))
```

---

## 📝 Hyperparameters Quick Reference

| Model | Parameter | Range | Default | Usage |
|-------|-----------|-------|---------|-------|
| LinearRegression | `fit_intercept` | True/False | True | False if line through origin |
| LogisticRegression | `C` | 0.001-1000 | 1.0 | Lower = more regularization |
| Ridge | `alpha` | 0.001-100 | 1.0 | Higher = more regularization |
| Lasso | `alpha` | 0.001-10 | 1.0 | Higher = more regularization |

---

**🏁 You're ready for the interview! Good luck! 🚀**
