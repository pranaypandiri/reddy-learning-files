x = [73, 74, 75, 71, 69, 72, 76, 73]


stack = []

res = [0] * len(x)

for i in range(len(x)):
    while stack and x[i] > x[stack[-1]]:
        idx = stack.pop()
        res[idx] = i - idx

    stack.append(i)


##


x=[1,5,6,0,4,2]

# 5,6,-1,4,-1,-1


stack=[]
res=[-1]*len(x)
for i in range(len(x)):
    while stack and x[i] > x[stack[-1]]:
        idx= stack.pop()
        res[idx] = x[i]


    stack.append(i)