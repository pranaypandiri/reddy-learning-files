# JOINs for Gen AI Developers - Why You Need Them

## 🎯 The Core Problem JOINs Solve

**Reality:** Your data lives in MULTIPLE tables, not one giant table.

**Why?** 
- Avoid data duplication
- Better organization
- Faster queries
- Easier updates

---

## 🤖 Real Gen AI Scenarios Where You NEED JOINs

### **Scenario 1: Chatbot Analytics Dashboard**

**Your Database:**
```
users table:
├── user_id (PK)
├── name
├── email
├── company

conversations table:
├── conversation_id (PK)
├── user_id (FK)
├── timestamp
├── tokens_used
├── model_used

feedback table:
├── feedback_id (PK)
├── conversation_id (FK)
├── rating (1-5)
├── comment
```

**Business Question:** 
*"Show me all users who gave 5-star ratings with their email addresses"*

**Without JOIN:** ❌ Impossible! Rating is in `feedback`, email is in `users`

**With JOIN:** ✅
```sql
SELECT u.name, u.email, f.rating, f.comment
FROM users u
INNER JOIN conversations c ON u.user_id = c.user_id
INNER JOIN feedback f ON c.conversation_id = f.conversation_id
WHERE f.rating = 5;
```

**Why This Matters:**
- Sending follow-up emails to happy customers
- Identifying power users for beta features
- Marketing campaigns

---

### **Scenario 2: LangChain Agent Performance Tracking**

**Your Database:**
```
agents table:
├── agent_id (PK)
├── agent_name
├── agent_type (classifier, executor, etc.)

agent_executions table:
├── execution_id (PK)
├── agent_id (FK)
├── user_id (FK)
├── timestamp
├── status (success/failed)
├── execution_time_ms
├── error_message

users table:
├── user_id (PK)
├── name
├── subscription_tier
```

**Business Question:**
*"Which agents have >90% success rate and how many premium users used them?"*

**With JOIN:**
```sql
SELECT 
    a.agent_name,
    COUNT(*) as total_executions,
    SUM(CASE WHEN ae.status = 'success' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as success_rate,
    COUNT(DISTINCT CASE WHEN u.subscription_tier = 'premium' THEN u.user_id END) as premium_users
FROM agents a
INNER JOIN agent_executions ae ON a.agent_id = ae.agent_id
INNER JOIN users u ON ae.user_id = u.user_id
GROUP BY a.agent_name
HAVING success_rate > 90;
```

**Why This Matters:**
- Identifying reliable agents for production
- Understanding premium user behavior
- Resource allocation decisions

---

### **Scenario 3: RAG System - Document Retrieval Logs**

**Your Database:**
```
documents table:
├── document_id (PK)
├── document_name
├── category
├── upload_date

retrieval_logs table:
├── log_id (PK)
├── user_query
├── document_id (FK)
├── similarity_score
├── timestamp
├── was_relevant (boolean)

users table:
├── user_id (PK)
├── department
```

**Business Question:**
*"Which documents are most frequently retrieved but marked as irrelevant?"*

**With JOIN:**
```sql
SELECT 
    d.document_name,
    d.category,
    COUNT(*) as retrieval_count,
    SUM(CASE WHEN r.was_relevant = false THEN 1 ELSE 0 END) as irrelevant_count,
    SUM(CASE WHEN r.was_relevant = false THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as irrelevance_rate
FROM documents d
INNER JOIN retrieval_logs r ON d.document_id = r.document_id
GROUP BY d.document_id, d.document_name, d.category
HAVING irrelevance_rate > 50
ORDER BY retrieval_count DESC;
```

**Why This Matters:**
- Identifying documents that need updating
- Improving vector embeddings
- Refining retrieval strategy

---

### **Scenario 4: Token Usage & Cost Attribution**

**Your Database:**
```
api_calls table:
├── call_id (PK)
├── user_id (FK)
├── model_id (FK)
├── input_tokens
├── output_tokens
├── timestamp

users table:
├── user_id (PK)
├── name
├── department
├── cost_center

llm_models table:
├── model_id (PK)
├── model_name
├── cost_per_1k_input_tokens
├── cost_per_1k_output_tokens
```

**Business Question:**
*"How much did each department spend on LLM calls last month?"*

**With JOIN:**
```sql
SELECT 
    u.department,
    SUM(
        (a.input_tokens / 1000.0 * m.cost_per_1k_input_tokens) +
        (a.output_tokens / 1000.0 * m.cost_per_1k_output_tokens)
    ) as total_cost,
    SUM(a.input_tokens + a.output_tokens) as total_tokens,
    COUNT(DISTINCT u.user_id) as active_users
FROM api_calls a
INNER JOIN users u ON a.user_id = u.user_id
INNER JOIN llm_models m ON a.model_id = m.model_id
WHERE a.timestamp >= DATE_TRUNC('month', CURRENT_DATE - INTERVAL '1 month')
  AND a.timestamp < DATE_TRUNC('month', CURRENT_DATE)
GROUP BY u.department
ORDER BY total_cost DESC;
```

**Why This Matters:**
- Budget planning & cost allocation
- Identifying high-cost departments
- Billing customers accurately

---

## 📊 Types of JOINs - Visual Understanding

### **1. INNER JOIN (Most Common - 80% of your queries)**

**Returns:** Only rows where match exists in BOTH tables

```
users table:          orders table:
user_id | name        order_id | user_id | amount
--------|------       ---------|---------|-------
1       | Alice      101      | 1       | 50
2       | Bob        102      | 1       | 30
3       | Charlie    103      | 4       | 20

INNER JOIN ON user_id:
user_id | name  | order_id | amount
--------|-------|----------|-------
1       | Alice | 101      | 50
1       | Alice | 102      | 30
```

**Note:** Bob (no orders) and Charlie (no orders) excluded. Order 103 (user 4 doesn't exist) excluded.

---

### **2. LEFT JOIN (Get all from left table, match from right)**

**Returns:** All rows from LEFT table + matching rows from RIGHT (NULL if no match)

```
SAME DATA AS ABOVE

LEFT JOIN users ON orders:
user_id | name    | order_id | amount
--------|---------|----------|-------
1       | Alice   | 101      | 50
1       | Alice   | 102      | 30
2       | Bob     | NULL     | NULL
3       | Charlie | NULL     | NULL
```

**Use Case in Gen AI:**
*"Show ALL users and their conversation count (even users with 0 conversations)"*

```sql
SELECT u.name, u.email, COUNT(c.conversation_id) as conv_count
FROM users u
LEFT JOIN conversations c ON u.user_id = c.user_id
GROUP BY u.user_id, u.name, u.email;
```

**Why LEFT JOIN here?** Because users with 0 conversations would be excluded with INNER JOIN!

---

### **3. RIGHT JOIN (Rarely used - just reverse LEFT JOIN)**

Same as LEFT JOIN but keeps all rows from RIGHT table.

**Reality:** Just swap tables and use LEFT JOIN instead. Nobody uses RIGHT JOIN in practice.

---

### **4. FULL OUTER JOIN (Very rare)**

Returns ALL rows from BOTH tables (NULLs where no match).

**In Gen AI:** Almost never needed. Skip it.

---

## 🔑 JOIN Syntax Patterns

### **Pattern 1: Simple Two-Table Join**
```sql
SELECT t1.col1, t2.col2
FROM table1 t1
INNER JOIN table2 t2 ON t1.key = t2.key;
```

### **Pattern 2: Multiple Table Join (3+ tables)**
```sql
SELECT u.name, c.timestamp, f.rating
FROM users u
INNER JOIN conversations c ON u.user_id = c.user_id
INNER JOIN feedback f ON c.conversation_id = f.conversation_id;
```

### **Pattern 3: Join with WHERE Filter**
```sql
SELECT u.name, c.tokens_used
FROM users u
INNER JOIN conversations c ON u.user_id = c.user_id
WHERE c.timestamp > '2026-01-01'
  AND c.tokens_used > 1000;
```

### **Pattern 4: Join with Aggregation**
```sql
SELECT u.department, COUNT(*) as total_queries
FROM users u
INNER JOIN api_calls a ON u.user_id = a.user_id
GROUP BY u.department;
```

---

## ⚡ Common Mistakes to Avoid

### ❌ **Mistake 1: Cartesian Product (Missing ON clause)**
```sql
-- WRONG - creates millions of useless rows!
SELECT * FROM users, conversations;

-- CORRECT
SELECT * FROM users u
INNER JOIN conversations c ON u.user_id = c.user_id;
```

### ❌ **Mistake 2: Wrong JOIN Type**
```sql
-- WRONG - Excludes users with no conversations
SELECT u.name, COUNT(c.conversation_id)
FROM users u
INNER JOIN conversations c ON u.user_id = c.user_id
GROUP BY u.name;

-- CORRECT - Shows all users (even with 0 conversations)
SELECT u.name, COUNT(c.conversation_id)
FROM users u
LEFT JOIN conversations c ON u.user_id = c.user_id
GROUP BY u.name;
```

### ❌ **Mistake 3: Ambiguous Column Names**
```sql
-- WRONG - Which table's user_id?
SELECT user_id, name FROM users u
INNER JOIN conversations c ON u.user_id = c.user_id;

-- CORRECT - Always prefix with table alias
SELECT u.user_id, u.name FROM users u
INNER JOIN conversations c ON u.user_id = c.user_id;
```

---

## 🎯 Quick Decision Tree: Which JOIN?

**Question: Do I need ALL rows from the first table?**
- ✅ YES → Use `LEFT JOIN`
- ❌ NO (only matching rows) → Use `INNER JOIN`

**99% of Gen AI queries = INNER JOIN or LEFT JOIN**

---

## 📝 Practice Roadmap

**Now go solve LeetCode JOIN problems:**

1. ✅ Complete "Basic Joins" section (10 problems)
2. Practice writing queries WITHOUT looking at solutions
3. For each problem, ask: *"What Gen AI scenario is this similar to?"*

**You got this! 💪**



-- Template
SELECT 
    column_in_group_by,              -- ✅ Must be in GROUP BY
    COUNT(*) as row_count,           -- ✅ Aggregate
    SUM(column) as total,            -- ✅ Aggregate
    AVG(column) as average           -- ✅ Aggregate
FROM table1
INNER JOIN table2 ON table1.id = table2.id
WHERE filter_before_grouping         -- Before GROUP BY
GROUP BY column_in_group_by
HAVING COUNT(*) > 5                  -- After GROUP BY (on aggregates)
ORDER BY total DESC
LIMIT 10;


SELECT 
    user_id,
    tokens,
    CASE 
        WHEN tokens > 10000 THEN 'High'
        WHEN tokens > 5000 THEN 'Medium'
        ELSE 'Low'
    END as usage_tier
FROM api_calls;