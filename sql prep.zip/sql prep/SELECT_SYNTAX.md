# SELECT - Basic Syntax

## 1. Basic SELECT
```sql
-- Select all columns
SELECT * FROM table_name;

-- Select specific columns
SELECT column1, column2, column3 FROM table_name;
```

---

## 2. WHERE Clause (Filtering)
```sql
-- Single condition
SELECT * FROM products WHERE price > 100;

-- Multiple conditions with AND
SELECT * FROM products WHERE price > 100 AND category = 'Electronics';

-- Multiple conditions with OR
SELECT * FROM products WHERE category = 'Electronics' OR category = 'Books';

-- Combining AND/OR (use parentheses!)
SELECT * FROM products 
WHERE (category = 'Electronics' OR category = 'Books') 
  AND price < 50;
```

---

## 3. Comparison Operators
```sql
-- Equal
WHERE status = 'active'

-- Not equal
WHERE status != 'inactive'
WHERE status <> 'inactive'  -- Same as !=

-- Greater than / Less than
WHERE age > 25
WHERE price <= 100

-- Between (inclusive)
WHERE age BETWEEN 18 AND 65
-- Same as: age >= 18 AND age <= 65
```

---

## 4. IN / NOT IN
```sql
-- Check if value is in list
SELECT * FROM users 
WHERE country IN ('USA', 'Canada', 'UK');

-- Check if value is NOT in list
SELECT * FROM users 
WHERE status NOT IN ('deleted', 'banned');
```

---

## 5. NULL Handling
```sql
-- Check if column is NULL
SELECT * FROM customers WHERE email IS NULL;

-- Check if column is NOT NULL
SELECT * FROM customers WHERE email IS NOT NULL;

-- NEVER use = NULL or != NULL (WRONG!)
-- ❌ WHERE email = NULL     (WRONG)
-- ✅ WHERE email IS NULL    (CORRECT)
```

---

## 6. LIKE (Pattern Matching)
```sql
-- Starts with 'A'
WHERE name LIKE 'A%'

-- Ends with 'son'
WHERE name LIKE '%son'

-- Contains 'tech'
WHERE name LIKE '%tech%'

-- Exactly 3 characters
WHERE code LIKE '___'  -- Three underscores

-- Second character is 'a'
WHERE name LIKE '_a%'
```

**Pattern wildcards:**
- `%` = zero or more characters
- `_` = exactly one character

---

## 7. DISTINCT (Remove Duplicates)
```sql
-- Get unique values
SELECT DISTINCT country FROM customers;

-- Unique combinations
SELECT DISTINCT country, city FROM customers;
```

---

## 8. ORDER BY (Sorting)
```sql
-- Ascending (default)
SELECT * FROM products ORDER BY price;
SELECT * FROM products ORDER BY price ASC;

-- Descending
SELECT * FROM products ORDER BY price DESC;

-- Multiple columns
SELECT * FROM products 
ORDER BY category ASC, price DESC;
```

---

## 9. LIMIT (Restrict Rows)
```sql
-- First 10 rows
SELECT * FROM products LIMIT 10;

-- Skip 5, take 10 (pagination)
SELECT * FROM products LIMIT 10 OFFSET 5;
```

---

## Quick Cheat Sheet for First 4 Problems:

```sql
-- Problem 1: Recyclable and Low Fat Products
-- Need: WHERE with AND
SELECT product_id FROM Products
WHERE low_fats = 'Y' AND recyclable = 'Y';

-- Problem 2: Find Customer Referee
-- Need: NULL handling, OR
SELECT name FROM Customer
WHERE referee_id IS NULL OR referee_id != 2;

-- Problem 3: Big Countries
-- Need: OR condition
SELECT name, population, area FROM World
WHERE area >= 3000000 OR population >= 25000000;

-- Problem 4: Article Views I
-- Need: DISTINCT, self-condition
SELECT DISTINCT author_id AS id FROM Views
WHERE author_id = viewer_id
ORDER BY id;
```

---

## Common Mistakes to Avoid:

❌ `WHERE name = NULL` → ✅ `WHERE name IS NULL`
❌ `SELECT DISTINCT *` (rarely useful) → ✅ `SELECT DISTINCT column`
❌ Forgetting parentheses with AND/OR mix
❌ `LIMIT` without `ORDER BY` (unpredictable results)

---

**Now go solve those 4 problems! You got this! 💪**
