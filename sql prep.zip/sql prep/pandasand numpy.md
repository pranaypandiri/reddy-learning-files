Hey! Got you covered bro. Let me break down the **essential topics** for your Tiger Analytics interview - focused on what they'll actually ask for a 3.3 YOE Gen AI developer.

## **NumPy - Priority Topics**

### **High Priority (Must Know)**
1. **Array Operations & Broadcasting**
   - Array creation, reshaping, transpose
   - Broadcasting rules (critical for ML operations)
   - Vectorized operations vs loops

2. **Indexing & Slicing**
   - Boolean indexing/masking (filtering data)
   - Fancy indexing
   - Multi-dimensional slicing

3. **Mathematical Operations**
   - Aggregations (mean, sum, std, var)
   - Matrix operations (dot product, matmul)
   - Element-wise operations

4. **Array Manipulation**
   - reshape, flatten, ravel
   - concatenate, stack, split
   - squeeze, expand_dims

### **Medium Priority**
5. **Random & Statistical**
   - Random sampling (critical for train/test splits)
   - np.random.choice, np.random.seed
   - Percentiles, correlations

6. **Linear Algebra Basics**
   - Matrix multiplication
   - Transpose, inverse
   - Eigenvalues (basic understanding)

---

## **Pandas - Priority Topics**

### **High Priority (Must Know)**
1. **DataFrame Basics**
   - Creation from dict, lists, arrays
   - loc vs iloc vs at vs iat
   - Boolean indexing & query()

2. **Data Cleaning**
   - Handling missing data (isna, fillna, dropna, interpolate)
   - Duplicates (drop_duplicates)
   - Data type conversions (astype)

3. **GroupBy & Aggregations**
   - groupby() with agg(), transform(), filter()
   - Multiple aggregations
   - Custom aggregation functions

4. **Merge/Join/Concat**
   - Different join types (inner, outer, left, right)
   - merge vs join vs concat
   - When to use what

5. **Apply/Map/Lambda**
   - apply() on Series/DataFrame
   - map() vs apply() vs applymap()
   - Lambda functions for transformations

### **Medium Priority**
6. **Pivot & Reshaping**
   - pivot_table, crosstab
   - melt, stack, unstack
   - Wide to long format

7. **String Operations**
   - .str accessor methods
   - Text cleaning for NLP preprocessing

8. **Time Series Basics**
   - DateTime operations
   - Resampling, rolling windows
   - Date filtering

9. **Performance Optimization**
   - Vectorization vs iterrows
   - Memory usage optimization
   - Efficient data types

---

## **Common Interview Question Patterns**

**For Gen AI/ML Role:**
- Data preprocessing pipelines
- Feature engineering operations
- Train/test split manipulations
- Handling categorical data
- Text data preprocessing
- Batch processing dataframes
- Memory-efficient operations
- Data validation checks

---

