# Window Functions - Complete Guide

## 🎯 What Are Window Functions?

**Problem with GROUP BY:** You lose individual rows when aggregating

**Window Functions:** Calculate across rows while KEEPING all original rows!

---

## 📊 Aggregate vs Window Functions

### **GROUP BY (Loses rows):**
```sql
SELECT department, AVG(salary)
FROM employees
GROUP BY department;

Result:
department  | avg
------------|------
Sales       | 5500
Engineering | 8000
(2 rows - lost employee details!)
```

### **Window Function (Keeps rows):**
```sql
SELECT 
    user_id,
    department,
    salary,
    AVG(salary) OVER (PARTITION BY department) as dept_avg
FROM employees;

Result:
user_id | department  | salary | dept_avg
--------|-------------|--------|----------
1       | Sales       | 5000   | 5500
2       | Sales       | 6000   | 5500
3       | Engineering | 7000   | 8000
4       | Engineering | 8000   | 8000
5       | Engineering | 9000   | 8000
(5 rows - kept all details + added avg!)
```

---

## 🔧 Basic Syntax

```sql
FUNCTION() OVER (
    PARTITION BY column    -- Optional: Like GROUP BY (creates groups)
    ORDER BY column        -- Optional: Order rows within partition
    ROWS BETWEEN ...       -- Optional: Define window frame
)
```

**Key Components:**

1. **PARTITION BY** = Divides data into groups (like GROUP BY)
2. **ORDER BY** = Orders rows within each partition
3. **OVER()** = The magic keyword that makes it a window function

---

## 🔢 1. ROW_NUMBER() - Assign Sequential Numbers

**Syntax:**
```sql
ROW_NUMBER() OVER (PARTITION BY col1 ORDER BY col2)
```

**What it does:** Assigns unique sequential number to each row within partition

**Example:**
```sql
SELECT 
    user_id,
    conversation_id,
    timestamp,
    tokens_used,
    ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY timestamp DESC) as conv_rank
FROM conversations;
```

**Data:**
```
user_id | conv_id | timestamp  | tokens | conv_rank
--------|---------|------------|--------|----------
101     | 1       | 2026-01-25 | 500    | 1
101     | 2       | 2026-01-24 | 300    | 2
101     | 3       | 2026-01-23 | 800    | 3
102     | 4       | 2026-01-25 | 600    | 1
102     | 5       | 2026-01-22 | 400    | 2
```

**Gen AI Use Case:**
```sql
-- Get last 5 conversations per user for context retrieval
SELECT *
FROM (
    SELECT 
        user_id,
        conversation_text,
        ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY timestamp DESC) as rn
    FROM conversations
) sub
WHERE rn <= 5;
```

---

## 🏆 2. RANK() - Ranking with Gaps for Ties

**Syntax:**
```sql
RANK() OVER (ORDER BY score DESC)
```

**What it does:** Assigns rank, ties get same rank, next rank SKIPS numbers

**Example:**
```sql
SELECT 
    student_id,
    exam_score,
    RANK() OVER (ORDER BY exam_score DESC) as rank
FROM exam_results;
```

**Data:**
```
student_id | exam_score | rank
-----------|------------|-----
1          | 95         | 1
2          | 95         | 1    ← Tie!
3          | 90         | 3    ← Skips 2!
4          | 85         | 4
5          | 85         | 4    ← Tie!
6          | 80         | 6    ← Skips 5!
```

**Gen AI Use Case:**
```sql
-- Rank agent responses by user satisfaction score
SELECT 
    agent_id,
    agent_name,
    avg_satisfaction,
    RANK() OVER (ORDER BY avg_satisfaction DESC) as rank
FROM agent_performance;
```

---

## 🎖️ 3. DENSE_RANK() - Ranking WITHOUT Gaps

**Syntax:**
```sql
DENSE_RANK() OVER (ORDER BY score DESC)
```

**What it does:** Assigns rank, ties get same rank, next rank is CONSECUTIVE

**Example:**
```sql
SELECT 
    student_id,
    exam_score,
    DENSE_RANK() OVER (ORDER BY exam_score DESC) as dense_rank
FROM exam_results;
```

**Data:**
```
student_id | exam_score | dense_rank
-----------|------------|------------
1          | 95         | 1
2          | 95         | 1    ← Tie!
3          | 90         | 2    ← No gap!
4          | 85         | 3
5          | 85         | 3    ← Tie!
6          | 80         | 4    ← No gap!
```

**Difference:**
```
RANK():        1, 1, 3, 4, 4, 6     ← Gaps!
DENSE_RANK():  1, 1, 2, 3, 3, 4     ← No gaps!
```

**Gen AI Use Case:**
```sql
-- Top 3 most used LLM models (no gaps in ranking)
SELECT 
    model_name,
    usage_count,
    DENSE_RANK() OVER (ORDER BY usage_count DESC) as rank
FROM model_usage
WHERE rank <= 3;
```

---

## ⏮️ 4. LAG() - Access Previous Row

**Syntax:**
```sql
LAG(column, offset, default_value) OVER (ORDER BY date)
```

**Parameters:**
- `column`: Which column to get from previous row
- `offset`: How many rows back (default 1)
- `default_value`: What to return if no previous row (default NULL)

**Example:**
```sql
SELECT 
    date,
    revenue,
    LAG(revenue, 1) OVER (ORDER BY date) as prev_day_revenue,
    revenue - LAG(revenue, 1) OVER (ORDER BY date) as daily_change
FROM daily_sales;
```

**Data:**
```
date       | revenue | prev_day_revenue | daily_change
-----------|---------|------------------|-------------
2026-01-01 | 1000    | NULL             | NULL
2026-01-02 | 1200    | 1000             | 200
2026-01-03 | 1100    | 1200             | -100
2026-01-04 | 1300    | 1100             | 200
```

**Gen AI Use Case:**
```sql
-- Compare today's token usage with yesterday
SELECT 
    date,
    total_tokens,
    LAG(total_tokens, 1) OVER (ORDER BY date) as yesterday_tokens,
    ROUND((total_tokens - LAG(total_tokens, 1) OVER (ORDER BY date)) * 100.0 / 
          LAG(total_tokens, 1) OVER (ORDER BY date), 2) as pct_change
FROM daily_token_usage;
```

---

## ⏭️ 5. LEAD() - Access Next Row

**Syntax:**
```sql
LEAD(column, offset, default_value) OVER (ORDER BY date)
```

**Parameters:** Same as LAG() but looks FORWARD

**Example:**
```sql
SELECT 
    date,
    temperature,
    LEAD(temperature, 1) OVER (ORDER BY date) as next_day_temp,
    LEAD(temperature, 1) OVER (ORDER BY date) - temperature as temp_change
FROM weather;
```

**Data:**
```
date       | temperature | next_day_temp | temp_change
-----------|-------------|---------------|------------
2026-01-01 | 20          | 25            | 5
2026-01-02 | 25          | 22            | -3
2026-01-03 | 22          | 27            | 5
2026-01-04 | 27          | NULL          | NULL
```

**Gen AI Use Case:**
```sql
-- Predict if next query will exceed rate limit
SELECT 
    timestamp,
    tokens_used,
    LEAD(tokens_used, 1) OVER (ORDER BY timestamp) as next_query_tokens,
    SUM(tokens_used) OVER (ORDER BY timestamp ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING) as total_next_2
FROM query_logs;
```

---

## 📈 6. Window Aggregate Functions

**All aggregate functions work as window functions!**

```sql
SUM() OVER (...)
AVG() OVER (...)
COUNT() OVER (...)
MIN() OVER (...)
MAX() OVER (...)
```

**Example:**
```sql
SELECT 
    date,
    revenue,
    SUM(revenue) OVER (ORDER BY date) as running_total,
    AVG(revenue) OVER (ORDER BY date ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) as moving_avg_3day
FROM daily_sales;
```

**Data:**
```
date       | revenue | running_total | moving_avg_3day
-----------|---------|---------------|----------------
2026-01-01 | 100     | 100           | 100.00
2026-01-02 | 150     | 250           | 125.00
2026-01-03 | 200     | 450           | 150.00
2026-01-04 | 180     | 630           | 176.67
```

**Gen AI Use Case:**
```sql
-- Running total of tokens used per user
SELECT 
    user_id,
    timestamp,
    tokens_used,
    SUM(tokens_used) OVER (PARTITION BY user_id ORDER BY timestamp) as cumulative_tokens
FROM api_calls;
```

---

## 🪟 7. ROWS BETWEEN - Define Window Frame

**Syntax:**
```sql
FUNCTION() OVER (
    ORDER BY column
    ROWS BETWEEN start AND end
)
```

**Frame Options:**
- `UNBOUNDED PRECEDING` - From start of partition
- `N PRECEDING` - N rows before current
- `CURRENT ROW` - Current row
- `N FOLLOWING` - N rows after current
- `UNBOUNDED FOLLOWING` - To end of partition

**Examples:**

### **Moving Average (last 3 days):**
```sql
AVG(revenue) OVER (
    ORDER BY date
    ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
)
```

### **Cumulative Sum (from start):**
```sql
SUM(revenue) OVER (
    ORDER BY date
    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
)
```

### **Centered Window (±1 row):**
```sql
AVG(value) OVER (
    ORDER BY date
    ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING
)
```

**Visual:**
```
Data: [10, 20, 30, 40, 50]

ROWS BETWEEN 2 PRECEDING AND CURRENT ROW:
Row 1 (10): AVG(10) = 10
Row 2 (20): AVG(10, 20) = 15
Row 3 (30): AVG(10, 20, 30) = 20
Row 4 (40): AVG(20, 30, 40) = 30
Row 5 (50): AVG(30, 40, 50) = 40
```

---

## 🎯 PARTITION BY vs ORDER BY

### **PARTITION BY:**
- Divides data into groups
- Like GROUP BY but doesn't collapse rows
- Calculation restarts for each partition

**Example:**
```sql
ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC)
```

**Result:**
```
dept        | salary | row_num
------------|--------|--------
Engineering | 9000   | 1       ← Starts at 1
Engineering | 8000   | 2
Engineering | 7000   | 3
Sales       | 6000   | 1       ← Restarts at 1!
Sales       | 5000   | 2
```

### **ORDER BY:**
- Defines order within partition
- Required for LAG/LEAD/ROW_NUMBER
- Optional for aggregates

---

## 🔥 Common Patterns & Use Cases

### **Pattern 1: Top N per Group**
```sql
-- Top 3 employees per department by salary
SELECT *
FROM (
    SELECT 
        emp_id,
        name,
        department,
        salary,
        ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as rank
    FROM employees
) sub
WHERE rank <= 3;
```

### **Pattern 2: Compare with Previous**
```sql
-- Users whose token usage increased from yesterday
SELECT 
    user_id,
    date,
    tokens_used,
    LAG(tokens_used) OVER (PARTITION BY user_id ORDER BY date) as prev_tokens
FROM daily_usage
WHERE tokens_used > LAG(tokens_used) OVER (PARTITION BY user_id ORDER BY date);
```

### **Pattern 3: Running Totals**
```sql
-- Cumulative token cost per user
SELECT 
    user_id,
    timestamp,
    cost,
    SUM(cost) OVER (PARTITION BY user_id ORDER BY timestamp) as total_spent
FROM billing;
```

### **Pattern 4: Moving Average**
```sql
-- 7-day moving average of API calls
SELECT 
    date,
    call_count,
    AVG(call_count) OVER (
        ORDER BY date
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) as moving_avg_7day
FROM daily_api_calls;
```

### **Pattern 5: Percentage of Total**
```sql
-- Each department's percentage of total salary
SELECT 
    department,
    total_salary,
    ROUND(total_salary * 100.0 / SUM(total_salary) OVER (), 2) as pct_of_total
FROM (
    SELECT department, SUM(salary) as total_salary
    FROM employees
    GROUP BY department
) sub;
```

---

## 🚀 Gen AI Specific Examples

### **1. Conversation Context Retrieval**
```sql
-- Get last 5 conversations for each user with ranking
SELECT 
    user_id,
    conversation_id,
    message_text,
    timestamp,
    ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY timestamp DESC) as recency_rank
FROM conversations
WHERE ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY timestamp DESC) <= 5;
```

### **2. Agent Performance Ranking**
```sql
-- Rank agents by success rate within each department
SELECT 
    agent_name,
    department,
    success_rate,
    DENSE_RANK() OVER (PARTITION BY department ORDER BY success_rate DESC) as dept_rank
FROM agent_metrics;
```

### **3. Token Usage Trends**
```sql
-- Daily token usage with 7-day moving average
SELECT 
    date,
    user_id,
    tokens_used,
    AVG(tokens_used) OVER (
        PARTITION BY user_id 
        ORDER BY date 
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) as avg_7day,
    tokens_used - AVG(tokens_used) OVER (
        PARTITION BY user_id 
        ORDER BY date 
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) as deviation_from_avg
FROM daily_token_usage;
```

### **4. Cost Attribution**
```sql
-- Running total of LLM costs per project
SELECT 
    project_id,
    timestamp,
    cost,
    SUM(cost) OVER (PARTITION BY project_id ORDER BY timestamp) as cumulative_cost,
    SUM(cost) OVER (PARTITION BY project_id) as total_project_cost,
    ROUND(cost * 100.0 / SUM(cost) OVER (PARTITION BY project_id), 2) as pct_of_project
FROM llm_usage_logs;
```

---

## ⚡ Quick Reference

| Function | Use Case | Keeps Rows? | Needs ORDER BY? |
|----------|----------|-------------|-----------------|
| ROW_NUMBER() | Sequential numbering | Yes | Yes |
| RANK() | Ranking with gaps | Yes | Yes |
| DENSE_RANK() | Ranking without gaps | Yes | Yes |
| LAG() | Access previous row | Yes | Yes |
| LEAD() | Access next row | Yes | Yes |
| SUM() OVER() | Running totals | Yes | Optional |
| AVG() OVER() | Moving averages | Yes | Optional |

---

## 🎓 Practice Problems

1. **Rising Temperature:** Find dates where temp > previous day
2. **Nth Highest Salary:** Get 2nd highest salary per department
3. **Consecutive Numbers:** Find numbers appearing 3+ times in a row
4. **Top Performers:** Top 3 employees per dept by performance
5. **Growth Rate:** Calculate month-over-month growth percentage

---

**Now go crush those LeetCode window function problems!** 💪
