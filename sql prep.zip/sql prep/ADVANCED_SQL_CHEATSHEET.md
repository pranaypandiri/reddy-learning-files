# Advanced SQL Cheatsheet - Final Topics

## 1. SUBQUERIES 🎯

A query inside another query. Can appear in WHERE, FROM, or SELECT.

### Subquery in WHERE (Most Common)
**Pattern:** Filter rows based on another query's result

```sql
-- Find products more expensive than average
SELECT product_name, price 
FROM products 
WHERE price > (SELECT AVG(price) FROM products);

-- Gen AI: Find agents with above-average response times
SELECT agent_id, avg_response_time 
FROM agent_metrics 
WHERE avg_response_time > (SELECT AVG(avg_response_time) FROM agent_metrics);
```

### Subquery in FROM (Creates temporary table)
**Pattern:** Treat query result as a table

```sql
-- Average of averages
SELECT AVG(dept_avg) AS company_avg
FROM (
  SELECT department, AVG(salary) AS dept_avg
  FROM employees
  GROUP BY department
) AS dept_averages;

-- Gen AI: Get top conversation per user
SELECT user_id, conversation_id, message_count
FROM (
  SELECT user_id, conversation_id, COUNT(*) AS message_count,
         ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY COUNT(*) DESC) AS rn
  FROM messages
  GROUP BY user_id, conversation_id
) AS ranked
WHERE rn = 1;
```

### Subquery in SELECT (Scalar subquery)
**Pattern:** Calculate value per row

```sql
-- Show each employee's salary vs department average
SELECT employee_name, salary,
  (SELECT AVG(salary) FROM employees e2 WHERE e2.dept_id = e1.dept_id) AS dept_avg
FROM employees e1;

-- Gen AI: Show message count vs user's total messages
SELECT message_id, content,
  (SELECT COUNT(*) FROM messages m2 WHERE m2.user_id = m1.user_id) AS user_total_messages
FROM messages m1;
```

### EXISTS / NOT EXISTS (Check if rows exist)
**Pattern:** Boolean check - faster than COUNT

```sql
-- Find customers who made purchases
SELECT customer_id, customer_name
FROM customers c
WHERE EXISTS (
  SELECT 1 FROM orders o WHERE o.customer_id = c.customer_id
);

-- Find customers who NEVER made purchases
SELECT customer_id, customer_name
FROM customers c
WHERE NOT EXISTS (
  SELECT 1 FROM orders o WHERE o.customer_id = c.customer_id
);

-- Gen AI: Find users who never used a specific agent
SELECT user_id, username
FROM users u
WHERE NOT EXISTS (
  SELECT 1 FROM conversations c 
  WHERE c.user_id = u.user_id AND c.agent_type = 'code_assistant'
);
```

**EXISTS vs IN:**
- `EXISTS` stops when finds first match (faster)
- `IN` gets all values then checks (slower for large datasets)

---

## 2. CTEs (Common Table Expressions) - WITH Clause 📝

**Why:** Makes complex queries readable. Reusable within same query.

### Single CTE
```sql
-- Instead of nested subquery
WITH avg_prices AS (
  SELECT category, AVG(price) AS avg_price
  FROM products
  GROUP BY category
)
SELECT p.product_name, p.price, a.avg_price
FROM products p
JOIN avg_prices a ON p.category = a.category
WHERE p.price > a.avg_price;
```

### Multiple CTEs (Comma-separated)
```sql
-- Gen AI: Analyze conversation quality
WITH user_stats AS (
  SELECT user_id, COUNT(*) AS total_conversations
  FROM conversations
  GROUP BY user_id
),
avg_ratings AS (
  SELECT conversation_id, AVG(rating) AS avg_rating
  FROM feedback
  GROUP BY conversation_id
)
SELECT u.user_id, u.total_conversations, AVG(a.avg_rating) AS avg_user_rating
FROM user_stats u
JOIN conversations c ON u.user_id = c.user_id
JOIN avg_ratings a ON c.conversation_id = a.conversation_id
GROUP BY u.user_id, u.total_conversations;
```

### Recursive CTE (Advanced - Hierarchies)
```sql
-- Employee hierarchy (manager -> reports)
WITH RECURSIVE employee_hierarchy AS (
  -- Base case: top-level managers
  SELECT employee_id, name, manager_id, 1 AS level
  FROM employees
  WHERE manager_id IS NULL
  
  UNION ALL
  
  -- Recursive case: their reports
  SELECT e.employee_id, e.name, e.manager_id, eh.level + 1
  FROM employees e
  JOIN employee_hierarchy eh ON e.manager_id = eh.employee_id
)
SELECT * FROM employee_hierarchy ORDER BY level, name;

-- Gen AI: Conversation thread depth
WITH RECURSIVE thread_depth AS (
  SELECT message_id, parent_message_id, 1 AS depth
  FROM messages
  WHERE parent_message_id IS NULL
  
  UNION ALL
  
  SELECT m.message_id, m.parent_message_id, td.depth + 1
  FROM messages m
  JOIN thread_depth td ON m.parent_message_id = td.message_id
)
SELECT message_id, depth FROM thread_depth;
```

---

## 3. STRING FUNCTIONS 🔤

### CONCAT - Join strings
```sql
-- Basic concat
SELECT CONCAT(first_name, ' ', last_name) AS full_name FROM users;

-- PostgreSQL alternative (|| operator)
SELECT first_name || ' ' || last_name AS full_name FROM users;

-- Gen AI: Format agent response
SELECT CONCAT('Agent: ', agent_name, ' - Response: ', response_text) AS formatted_response
FROM agent_logs;
```

### SUBSTRING / SUBSTR - Extract part of string
```sql
-- SUBSTRING(string, start_position, length)
SELECT SUBSTRING(email, 1, 5) AS first_5_chars FROM users;

-- Extract domain from email
SELECT SUBSTRING(email, POSITION('@' IN email) + 1) AS domain FROM users;

-- Gen AI: Get first 100 chars of response
SELECT SUBSTRING(response_text, 1, 100) AS preview FROM responses;
```

### UPPER / LOWER - Case conversion
```sql
SELECT UPPER(name) AS name_upper, LOWER(name) AS name_lower FROM products;

-- Case-insensitive search
SELECT * FROM users WHERE LOWER(email) = LOWER('User@Example.COM');
```

### TRIM / LTRIM / RTRIM - Remove spaces
```sql
SELECT TRIM('  hello  ') AS trimmed;        -- 'hello'
SELECT LTRIM('  hello  ') AS left_trimmed;  -- 'hello  '
SELECT RTRIM('  hello  ') AS right_trimmed; -- '  hello'
```

### LENGTH / CHAR_LENGTH - String length
```sql
SELECT name, LENGTH(name) AS name_length FROM users;

-- Gen AI: Find long prompts
SELECT prompt_text, LENGTH(prompt_text) AS prompt_length
FROM prompts
WHERE LENGTH(prompt_text) > 500;
```

### REPLACE - Replace substring
```sql
SELECT REPLACE(description, 'old_text', 'new_text') AS updated_desc FROM products;

-- Gen AI: Clean up responses
SELECT REPLACE(response, '\n\n', '\n') AS cleaned_response FROM responses;
```

### LIKE Patterns (Review)
```sql
-- % = any characters, _ = single character
SELECT * FROM users WHERE email LIKE '%@gmail.com';    -- ends with
SELECT * FROM users WHERE name LIKE 'J%';              -- starts with J
SELECT * FROM users WHERE name LIKE '%son%';           -- contains 'son'
SELECT * FROM users WHERE name LIKE 'J_hn';            -- J + any char + hn (John, Jahn)
```

---

## 4. DATE FUNCTIONS 📅

### DATE_PART / EXTRACT - Get part of date
```sql
-- PostgreSQL: EXTRACT
SELECT EXTRACT(YEAR FROM order_date) AS order_year FROM orders;
SELECT EXTRACT(MONTH FROM order_date) AS order_month FROM orders;
SELECT EXTRACT(DAY FROM order_date) AS order_day FROM orders;

-- Gen AI: Group conversations by month
SELECT EXTRACT(YEAR FROM created_at) AS year,
       EXTRACT(MONTH FROM created_at) AS month,
       COUNT(*) AS conversation_count
FROM conversations
GROUP BY year, month
ORDER BY year, month;
```

### Date Arithmetic
```sql
-- PostgreSQL: Add/subtract intervals
SELECT order_date + INTERVAL '7 days' AS delivery_date FROM orders;
SELECT order_date - INTERVAL '1 month' AS last_month FROM orders;

-- MySQL: DATE_ADD / DATE_SUB
SELECT DATE_ADD(order_date, INTERVAL 7 DAY) AS delivery_date FROM orders;
SELECT DATE_SUB(order_date, INTERVAL 1 MONTH) AS last_month FROM orders;
```

### Date Difference
```sql
-- PostgreSQL: Subtraction gives interval
SELECT order_date, delivery_date, 
       delivery_date - order_date AS days_to_deliver
FROM orders;

-- MySQL: DATEDIFF
SELECT order_date, delivery_date,
       DATEDIFF(delivery_date, order_date) AS days_to_deliver
FROM orders;

-- Gen AI: Days since last conversation
SELECT user_id, MAX(created_at) AS last_conversation,
       CURRENT_DATE - MAX(created_at)::date AS days_since_last
FROM conversations
GROUP BY user_id;
```

### Current Date/Time
```sql
-- PostgreSQL
SELECT CURRENT_DATE;              -- Date only
SELECT CURRENT_TIMESTAMP;         -- Date + time
SELECT NOW();                     -- Same as CURRENT_TIMESTAMP

-- MySQL
SELECT CURDATE();                 -- Date only
SELECT NOW();                     -- Date + time
```

### TO_CHAR - Format dates (PostgreSQL)
```sql
SELECT TO_CHAR(order_date, 'YYYY-MM-DD') AS formatted_date FROM orders;
SELECT TO_CHAR(order_date, 'Month DD, YYYY') AS readable_date FROM orders;
SELECT TO_CHAR(order_date, 'YYYY-MM') AS year_month FROM orders;

-- Gen AI: Format timestamps
SELECT TO_CHAR(created_at, 'YYYY-MM-DD HH24:MI:SS') AS formatted_timestamp
FROM conversations;
```

---

## 5. UNION / UNION ALL 🔗

**Combine results from multiple queries**

### UNION - Removes duplicates
```sql
-- Combine two tables, remove duplicates
SELECT name FROM customers
UNION
SELECT name FROM suppliers;

-- Gen AI: Get all user IDs from different tables
SELECT user_id FROM active_users
UNION
SELECT user_id FROM trial_users;
```

### UNION ALL - Keeps duplicates (faster)
```sql
-- Combine tables, keep duplicates
SELECT name FROM customers
UNION ALL
SELECT name FROM suppliers;

-- Gen AI: Combine logs from different sources
SELECT log_id, message, 'api_logs' AS source FROM api_logs
UNION ALL
SELECT log_id, message, 'agent_logs' AS source FROM agent_logs
ORDER BY log_id;
```

**Rules:**
- Same number of columns
- Compatible data types
- Column names from first query

---

## 6. NULL HANDLING (Advanced) 🔍

### COALESCE - Return first non-NULL
```sql
-- Return first non-NULL value
SELECT name, COALESCE(phone, email, 'No contact') AS contact FROM users;

-- Gen AI: Fallback to default model
SELECT conversation_id, COALESCE(custom_model, default_model, 'gpt-3.5-turbo') AS model_used
FROM conversations;
```

### NULLIF - Return NULL if equal
```sql
-- Avoid division by zero
SELECT total_cost / NULLIF(quantity, 0) AS price_per_unit FROM orders;

-- Gen AI: Handle empty strings as NULL
SELECT user_id, NULLIF(TRIM(feedback), '') AS feedback FROM user_feedback;
```

### IS NULL / IS NOT NULL
```sql
-- Find missing data
SELECT * FROM users WHERE phone IS NULL;
SELECT * FROM users WHERE phone IS NOT NULL;

-- Gen AI: Find conversations without ratings
SELECT conversation_id, user_id
FROM conversations c
WHERE NOT EXISTS (
  SELECT 1 FROM ratings r WHERE r.conversation_id = c.conversation_id
);
```

---

## 7. SET OPERATIONS & MISC 🎲

### INTERSECT - Common rows
```sql
-- Users who are both customers AND suppliers
SELECT user_id FROM customers
INTERSECT
SELECT user_id FROM suppliers;
```

### EXCEPT - Difference
```sql
-- Customers who are NOT suppliers
SELECT user_id FROM customers
EXCEPT
SELECT user_id FROM suppliers;

-- Gen AI: Users with conversations but no feedback
SELECT user_id FROM conversations
EXCEPT
SELECT user_id FROM feedback;
```

### LIMIT / OFFSET - Pagination
```sql
-- First 10 rows
SELECT * FROM products ORDER BY price DESC LIMIT 10;

-- Skip first 10, get next 10 (page 2)
SELECT * FROM products ORDER BY price DESC LIMIT 10 OFFSET 10;

-- Gen AI: Paginate conversation history
SELECT * FROM conversations 
WHERE user_id = 123 
ORDER BY created_at DESC 
LIMIT 20 OFFSET 0;  -- Page 1
```

### DISTINCT ON (PostgreSQL)
```sql
-- Get first row per group (alternative to window functions)
SELECT DISTINCT ON (user_id) user_id, conversation_id, created_at
FROM conversations
ORDER BY user_id, created_at DESC;

-- Gen AI: Latest message per conversation
SELECT DISTINCT ON (conversation_id) conversation_id, message_id, content, created_at
FROM messages
ORDER BY conversation_id, created_at DESC;
```

---

## Gen AI Use Case Summary 🤖

### 1. Conversation Analytics
```sql
WITH conversation_stats AS (
  SELECT conversation_id,
         COUNT(*) AS message_count,
         MAX(created_at) - MIN(created_at) AS duration,
         AVG(LENGTH(content)) AS avg_message_length
  FROM messages
  GROUP BY conversation_id
)
SELECT c.user_id, c.agent_type,
       AVG(cs.message_count) AS avg_messages,
       AVG(EXTRACT(EPOCH FROM cs.duration)) AS avg_duration_seconds
FROM conversations c
JOIN conversation_stats cs ON c.conversation_id = cs.conversation_id
GROUP BY c.user_id, c.agent_type;
```

### 2. Token Usage & Cost Attribution
```sql
SELECT u.user_id, u.username,
       SUM(t.prompt_tokens + t.completion_tokens) AS total_tokens,
       SUM(t.prompt_tokens * 0.0015 + t.completion_tokens * 0.002) / 1000 AS total_cost
FROM users u
JOIN conversations c ON u.user_id = c.user_id
JOIN token_usage t ON c.conversation_id = t.conversation_id
WHERE c.created_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY u.user_id, u.username
ORDER BY total_cost DESC;
```

### 3. Agent Performance Comparison
```sql
WITH agent_metrics AS (
  SELECT agent_type,
         AVG(response_time) AS avg_response_time,
         AVG(rating) AS avg_rating,
         COUNT(*) AS total_conversations
  FROM conversations c
  LEFT JOIN ratings r ON c.conversation_id = r.conversation_id
  GROUP BY agent_type
)
SELECT agent_type, avg_response_time, avg_rating, total_conversations,
       RANK() OVER (ORDER BY avg_rating DESC) AS rating_rank
FROM agent_metrics;
```

---

## Quick Reference: When to Use What

| Task | Tool |
|------|------|
| Filter based on aggregate | **HAVING** |
| Filter based on another query | **Subquery in WHERE** |
| Make complex query readable | **CTE (WITH)** |
| Check if related data exists | **EXISTS / NOT EXISTS** |
| Combine tables vertically | **UNION / UNION ALL** |
| Get part of date | **EXTRACT / DATE_PART** |
| Calculate date difference | **Date subtraction / DATEDIFF** |
| Join strings | **CONCAT / \|\|** |
| Extract substring | **SUBSTRING** |
| Handle NULL values | **COALESCE / NULLIF** |
| Paginate results | **LIMIT / OFFSET** |
| Row numbers per group | **ROW_NUMBER() OVER (PARTITION BY)** |
| Top N per group | **ROW_NUMBER() + WHERE rn <= N** |
| Compare with previous row | **LAG / LEAD** |

---

## Common Mistakes & Fixes

❌ **Using aggregate in WHERE**
```sql
WHERE COUNT(*) > 5  -- Error!
```
✅ Use HAVING instead
```sql
GROUP BY category HAVING COUNT(*) > 5
```

❌ **Column alias in WHERE/HAVING**
```sql
SELECT COUNT(*) AS cnt FROM t HAVING cnt > 5  -- Error!
```
✅ Repeat the expression
```sql
SELECT COUNT(*) AS cnt FROM t HAVING COUNT(*) > 5
```

❌ **Integer division**
```sql
SELECT rating/position AS quality  -- Truncates!
```
✅ Force decimal
```sql
SELECT rating * 1.0 / position AS quality
```

❌ **Forgetting DISTINCT in counts**
```sql
SELECT COUNT(user_id) FROM activity  -- Counts all rows
```
✅ Count unique users
```sql
SELECT COUNT(DISTINCT user_id) FROM activity
```

❌ **Using WHERE after GROUP BY**
```sql
GROUP BY x WHERE COUNT(*) > 5  -- Syntax error!
```
✅ Use HAVING
```sql
GROUP BY x HAVING COUNT(*) > 5
```

---

## You're Ready! 🎉

**What you know:**
✅ SELECT, WHERE, DISTINCT, ORDER BY, LIMIT
✅ All JOIN types (INNER, LEFT, RIGHT, FULL, CROSS, self-join)
✅ Aggregate functions (COUNT, SUM, AVG, MIN, MAX)
✅ GROUP BY + HAVING
✅ CASE statements
✅ Window Functions (ROW_NUMBER, RANK, DENSE_RANK, LAG, LEAD)
✅ Subqueries (WHERE, FROM, EXISTS)
✅ CTEs (WITH clause)
✅ String functions (CONCAT, SUBSTRING, LENGTH, REPLACE)
✅ Date functions (EXTRACT, date arithmetic, formatting)
✅ Set operations (UNION, INTERSECT, EXCEPT)
✅ NULL handling (COALESCE, NULLIF)

**That's 95% of interview SQL questions covered!** Keep practicing LeetCode problems and you'll crush it. 💪
