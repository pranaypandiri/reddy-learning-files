from langchain_core.tools import tool
from langchain_google_vertexai import ChatVertexAI
from langgraph.prebuilt import create_react_agent
from langgraph.graph import StateGraph, END
from langchain_core.messages import SystemMessage, HumanMessage
from typing import TypedDict, Annotated, Literal
import operator


@tool
def detect_intent(customermsg: str) -> str:
    """detect the intent of the message
    Args:
        customermsg: message from customer
    Returns:
        intent as string
    """

    if "refund" in customermsg.lower():
        return "REFUND"
    elif "technical issue" in customermsg.lower() or "bug" in customermsg.lower():
        return "TECHNICAL_ISSUE"
    elif "account" in customermsg.lower() or "login" in customermsg.lower():
        return "ACCOUNT_ISSUE"
    return "GENERAL_INQUIRY"


@tool
def generate_response(customermsg: str, intent: str) -> str:
    """generate a response based on the intent
    Args:
        customermsg: message from customer
        intent: detected intent
    Returns:
        response as string
    """

    if intent == "REFUND":
        return f"We have received your refund request regarding: '{customermsg}'. Our team will process it within 5-7 business days."
    elif intent == "TECHNICAL_ISSUE":
        return f"Thank you for reporting the technical issue: '{customermsg}'. Our technical team is looking into it and will get back to you shortly."
    elif intent == "ACCOUNT_ISSUE":
        return f"We understand you're facing an account issue: '{customermsg}'. Please ensure your login credentials are correct. If the problem persists, contact support."
    return f"Thank you for reaching out with your inquiry: '{customermsg}'. We will get back to you with more information soon."


llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    project="ai-practice-388514",
    location="us-central1",
    temperature=0.3,
)


agent1 = create_react_agent(
    model=llm,
    tools=[detect_intent],
    prompt=SystemMessage(
        content="You are an intent detection agent. Use the detect_intent tool to classify customer messages into one of these intents: REFUND, TECHNICAL_ISSUE, ACCOUNT_ISSUE, GENERAL_INQUIRY."
    ),
)

agent2 = create_react_agent(
    model=llm,
    tools=[generate_response],
    prompt=SystemMessage(
        content="You are a response generation agent. Use the generate_response tool to create customer support replies based on detected intent."
    ),
)


class data(TypedDict):
    customer_message: str
    intent: str
    messages: Annotated[list, operator.add]
    response: str


def intentnode(state: data):
    response = agent1.invoke(
        {
            "messages": [
                HumanMessage(content=f"Detect intent: {state['customer_message']}")
            ]
        }
    )
    intent = "GENERAL_INQUIRY"
    for msg in response["messages"]:
        if "ToolMessage" in msg.__class__.__name__:
            intent = msg.content
    return {"intent": intent, "messages": response["messages"]}


def responsenode(state: data):
    response = agent2.invoke(
        {
            "messages": [
                HumanMessage(
                    content=f"Generate response for message: {state['customer_message']} with intent: {state['intent']}"
                )
            ]
        }
    )
    final_response = ""
    for msg in response["messages"]:
        if "AIMessage" in msg.__class__.__name__:
            final_response = msg.content
    return {"response": final_response, "messages": response["messages"]}


workflow = StateGraph(data)

workflow.add_node("intentnode", intentnode)
workflow.add_node("responsenode", responsenode)

workflow.set_entry_point("intentnode")

workflow.add_edge("intentnode", "responsenode")
workflow.add_edge("responsenode", END)

graph = workflow.compile()


if __name__ == "__main__":
    initial_state = {
        "customer_message": "I would like to request a refund for my last purchase.",
        "intent": "",
        "messages": [],
        "response": "",
    }

    final_state = graph.invoke(initial_state)
    print("Final Response:")
    print(final_state["response"])
    print("\nFull Message Trace:")
    for msg in final_state["messages"]:
        print(f"- {msg.__class__.__name__}: {msg.content}")

    png_bytes = graph.get_graph().draw_mermaid_png()

    with open("workflow.png", "wb") as f:
        f.write(png_bytes)
    print("\n✅ Graph saved as workflow.png")
