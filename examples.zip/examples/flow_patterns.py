"""
LangGraph Flow Patterns: Conditional, Router, and Parallel
"""

from langchain_google_vertexai import ChatVertexAI
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.prebuilt import create_react_agent
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated, Literal
import operator

llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    project="ai-practice-388514",
    location="us-central1",
    temperature=0.3,
)


# ============ TOOLS ============


@tool
def check_severity(issue: str) -> str:
    """Check if issue is critical, medium, or low severity"""
    if "down" in issue.lower() or "outage" in issue.lower():
        return "CRITICAL"
    elif "slow" in issue.lower() or "error" in issue.lower():
        return "MEDIUM"
    return "LOW"


@tool
def escalate_to_engineer(issue: str) -> str:
    """Escalate critical issues to engineer"""
    return f"ESCALATED: Engineer assigned for '{issue}'"


@tool
def create_standard_ticket(issue: str) -> str:
    """Create standard support ticket"""
    return f"TICKET: Standard ticket created for '{issue}'"


@tool
def check_billing(user_id: str) -> str:
    """Check user billing status"""
    return f"Billing OK for user {user_id}"


@tool
def check_technical(user_id: str) -> str:
    """Check technical specs"""
    return f"Technical check OK for user {user_id}"


# ============ AGENTS ============

agent_classifier = create_react_agent(
    model=llm,
    tools=[check_severity],
    prompt=SystemMessage(content="Check issue severity using the tool."),
)

agent_escalator = create_react_agent(
    model=llm,
    tools=[escalate_to_engineer],
    prompt=SystemMessage(content="Escalate critical issues."),
)

agent_ticket_creator = create_react_agent(
    model=llm,
    tools=[create_standard_ticket],
    prompt=SystemMessage(content="Create standard tickets."),
)

agent_billing = create_react_agent(
    model=llm, tools=[check_billing], prompt=SystemMessage(content="Check billing.")
)

agent_technical = create_react_agent(
    model=llm,
    tools=[check_technical],
    prompt=SystemMessage(content="Check technical specs."),
)


# ============ PATTERN 1: CONDITIONAL FLOW ============


class ConditionalState(TypedDict):
    issue: str
    severity: str
    result: str
    messages: Annotated[list, operator.add]


def classify_conditional(state: ConditionalState):
    result = agent_classifier.invoke(
        {"messages": [HumanMessage(content=f"Check: {state['issue']}")]}
    )
    severity = "LOW"
    for msg in result["messages"]:
        if hasattr(msg, "content"):
            if "CRITICAL" in msg.content:
                severity = "CRITICAL"
            elif "MEDIUM" in msg.content:
                severity = "MEDIUM"
    return {"severity": severity}


def escalate_node(state: ConditionalState):
    result = agent_escalator.invoke(
        {"messages": [HumanMessage(content=f"Escalate: {state['issue']}")]}
    )
    return {"result": "Escalated to engineer"}


def ticket_node(state: ConditionalState):
    result = agent_ticket_creator.invoke(
        {"messages": [HumanMessage(content=f"Create ticket: {state['issue']}")]}
    )
    return {"result": "Standard ticket created"}


def route_by_severity(state: ConditionalState) -> Literal["escalate", "ticket"]:
    """Conditional routing based on severity"""
    if state["severity"] == "CRITICAL":
        return "escalate"
    return "ticket"


workflow_conditional = StateGraph(ConditionalState)
workflow_conditional.add_node("classifier", classify_conditional)
workflow_conditional.add_node("escalate", escalate_node)
workflow_conditional.add_node("ticket", ticket_node)

workflow_conditional.set_entry_point("classifier")
workflow_conditional.add_conditional_edges(
    "classifier", route_by_severity, {"escalate": "escalate", "ticket": "ticket"}
)
workflow_conditional.add_edge("escalate", END)
workflow_conditional.add_edge("ticket", END)

graph_conditional = workflow_conditional.compile()


# ============ PATTERN 2: ROUTER FLOW ============


class RouterState(TypedDict):
    query_type: str
    user_id: str
    result: str
    messages: Annotated[list, operator.add]


def determine_route(state: RouterState) -> Literal["billing", "technical", "both"]:
    """Router: decide which path based on query type"""
    if state["query_type"] == "billing":
        return "billing"
    elif state["query_type"] == "technical":
        return "technical"
    return "both"


def billing_node(state: RouterState):
    result = agent_billing.invoke(
        {"messages": [HumanMessage(content=f"Check billing for {state['user_id']}")]}
    )
    return {"result": "Billing checked"}


def technical_node(state: RouterState):
    result = agent_technical.invoke(
        {"messages": [HumanMessage(content=f"Check tech for {state['user_id']}")]}
    )
    return {"result": "Technical checked"}


def both_node(state: RouterState):
    return {"result": "Both billing and technical checked"}


workflow_router = StateGraph(RouterState)
workflow_router.add_node("billing", billing_node)
workflow_router.add_node("technical", technical_node)
workflow_router.add_node("both", both_node)

workflow_router.set_conditional_entry_point(
    determine_route, {"billing": "billing", "technical": "technical", "both": "both"}
)
workflow_router.add_edge("billing", END)
workflow_router.add_edge("technical", END)
workflow_router.add_edge("both", END)

graph_router = workflow_router.compile()


# ============ PATTERN 3: PARALLEL FLOW ============


class ParallelState(TypedDict):
    user_id: str
    billing_result: str
    technical_result: str
    messages: Annotated[list, operator.add]


def billing_parallel(state: ParallelState):
    result = agent_billing.invoke(
        {"messages": [HumanMessage(content=f"Billing for {state['user_id']}")]}
    )
    return {"billing_result": "Billing OK"}


def technical_parallel(state: ParallelState):
    result = agent_technical.invoke(
        {"messages": [HumanMessage(content=f"Tech for {state['user_id']}")]}
    )
    return {"technical_result": "Tech OK"}


def merge_results(state: ParallelState):
    combined = (
        f"Billing: {state['billing_result']}, Technical: {state['technical_result']}"
    )
    return {"messages": [HumanMessage(content=combined)]}


workflow_parallel = StateGraph(ParallelState)
workflow_parallel.add_node("billing_check", billing_parallel)
workflow_parallel.add_node("technical_check", technical_parallel)
workflow_parallel.add_node("merger", merge_results)

workflow_parallel.set_entry_point("billing_check")
workflow_parallel.set_entry_point("technical_check")
workflow_parallel.add_edge("billing_check", "merger")
workflow_parallel.add_edge("technical_check", "merger")
workflow_parallel.add_edge("merger", END)

graph_parallel = workflow_parallel.compile()


# ============ SAVE GRAPHS ============


def save_all_graphs():
    try:
        png1 = graph_conditional.get_graph().draw_mermaid_png()
        with open("flow_conditional.png", "wb") as f:
            f.write(png1)
        print("✅ Conditional flow saved")

        png2 = graph_router.get_graph().draw_mermaid_png()
        with open("flow_router.png", "wb") as f:
            f.write(png2)
        print("✅ Router flow saved")

        png3 = graph_parallel.get_graph().draw_mermaid_png()
        with open("flow_parallel.png", "wb") as f:
            f.write(png3)
        print("✅ Parallel flow saved")
    except Exception as e:
        print(f"❌ Error: {e}")


# ============ TEST ALL PATTERNS ============

if __name__ == "__main__":
    print("=" * 60)
    print("LANGGRAPH FLOW PATTERNS")
    print("=" * 60)

    save_all_graphs()

    print("\n1. CONDITIONAL FLOW (if-else based on severity)")
    print("-" * 60)
    result1 = graph_conditional.invoke(
        {"issue": "Server is down!", "severity": "", "result": "", "messages": []}
    )
    print(
        f"Issue: Server is down → Severity: {result1['severity']} → Result: {result1['result']}"
    )

    print("\n2. ROUTER FLOW (different paths based on query type)")
    print("-" * 60)
    result2 = graph_router.invoke(
        {"query_type": "billing", "user_id": "user123", "result": "", "messages": []}
    )
    print(f"Query: billing → Result: {result2['result']}")

    print("\n3. PARALLEL FLOW (run multiple agents simultaneously)")
    print("-" * 60)
    result3 = graph_parallel.invoke(
        {
            "user_id": "user456",
            "billing_result": "",
            "technical_result": "",
            "messages": [],
        }
    )
    print(
        f"User: user456 → Billing: {result3['billing_result']}, Tech: {result3['technical_result']}"
    )

    print("\n" + "=" * 60)
