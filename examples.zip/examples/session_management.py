"""
Session Management with Firestore and SQLite
Production-grade patterns for saving, retrieving, deleting, and compacting sessions
"""

from langchain_google_vertexai import ChatVertexAI
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langgraph.prebuilt import create_react_agent
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated, Optional, List, Dict, Any
import operator
from datetime import datetime, timedelta
import json
import sqlite3
from google.cloud import firestore
from google.cloud.firestore_v1.base_query import FieldFilter


# ============ CONFIGURATION ============

USE_FIRESTORE = False  



llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    project="ai-practice-388514",
    location="us-central1",
    temperature=0.3,
)


# ============ SESSION STORAGE CLASSES ============


class FirestoreSessionManager:
    """Production-grade Firestore session management"""

    def __init__(self, project_id: str, database_name: str):
        self.db = firestore.Client(project=project_id, database=database_name)
        self.collection = self.db.collection("sessions")

    def save_session(
        self, session_id: str, user_id: str, messages: List[Dict], metadata: Dict = None
    ):
        """Save or update session in Firestore"""
        doc_ref = self.collection.document(session_id)

        session_data = {
            "session_id": session_id,
            "user_id": user_id,
            "messages": messages,
            "metadata": metadata or {},
            "created_at": firestore.SERVER_TIMESTAMP,
            "last_updated": firestore.SERVER_TIMESTAMP,
            "message_count": len(messages),
        }

        doc_ref.set(session_data, merge=True)
        print(f"✅ Firestore: Saved session {session_id}")

    def get_session(self, session_id: str) -> Optional[Dict]:
        """Retrieve session from Firestore"""
        doc_ref = self.collection.document(session_id)
        doc = doc_ref.get()

        if doc.exists:
            print(f"✅ Firestore: Retrieved session {session_id}")
            return doc.to_dict()
        print(f"❌ Firestore: Session {session_id} not found")
        return None

    def delete_session(self, session_id: str):
        """Delete session from Firestore"""
        doc_ref = self.collection.document(session_id)
        doc_ref.delete()
        print(f"✅ Firestore: Deleted session {session_id}")

   
    def get_user_sessions(self, user_id: str) -> List[Dict]:
        """Get all sessions for a user"""
        query = self.collection.where(filter=FieldFilter("user_id", "==", user_id))
        docs = query.stream()

        sessions = [doc.to_dict() for doc in docs]
        print(f"✅ Firestore: Found {len(sessions)} sessions for user {user_id}")
        return sessions

    def cleanup_old_sessions(self, days_old: int = 30):
        """Delete sessions older than specified days"""
        cutoff_date = datetime.now() - timedelta(days=days_old)

        query = self.collection.where(
            filter=FieldFilter("created_at", "<", cutoff_date)
        )
        docs = query.stream()

        deleted_count = 0
        for doc in docs:
            doc.reference.delete()
            deleted_count += 1

        print(
            f"✅ Firestore: Deleted {deleted_count} sessions older than {days_old} days"
        )


class SQLiteSessionManager:
    """Local SQLite session management (fallback)"""

    def __init__(self, db_path: str = "data/sessions.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        """Initialize SQLite database schema"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                messages TEXT NOT NULL,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                message_count INTEGER
            )
        """
        )

        cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_id ON sessions(user_id)")
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_created_at ON sessions(created_at)"
        )

        conn.commit()
        conn.close()
        print("✅ SQLite: Database initialized")

    def save_session(
        self, session_id: str, user_id: str, messages: List[Dict], metadata: Dict = None
    ):
        """Save or update session in SQLite"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT OR REPLACE INTO sessions 
            (session_id, user_id, messages, metadata, last_updated, message_count)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, ?)
        """,
            (
                session_id,
                user_id,
                json.dumps(messages),
                json.dumps(metadata or {}),
                len(messages),
            ),
        )

        conn.commit()
        conn.close()
        print(f"✅ SQLite: Saved session {session_id}")

    def get_session(self, session_id: str) -> Optional[Dict]:
        """Retrieve session from SQLite"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM sessions WHERE session_id = ?", (session_id,))
        row = cursor.fetchone()
        conn.close()

        if row:
            print(f"✅ SQLite: Retrieved session {session_id}")
            return {
                "session_id": row[0],
                "user_id": row[1],
                "messages": json.loads(row[2]),
                "metadata": json.loads(row[3]) if row[3] else {},
                "created_at": row[4],
                "last_updated": row[5],
                "message_count": row[6],
            }
        print(f"❌ SQLite: Session {session_id} not found")
        return None

    def delete_session(self, session_id: str):
        """Delete session from SQLite"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
        conn.commit()
        conn.close()
        print(f"✅ SQLite: Deleted session {session_id}")

    def compact_session(self, session_id: str, keep_last_n: int = 10):
        """Keep only last N messages"""
        session = self.get_session(session_id)
        if not session:
            return

        messages = session["messages"]
        if len(messages) > keep_last_n:
            compacted_messages = messages[-keep_last_n:]
            self.save_session(
                session_id, session["user_id"], compacted_messages, session["metadata"]
            )
            print(
                f"✅ SQLite: Compacted session {session_id} from {len(messages)} to {len(compacted_messages)} messages"
            )

    def get_user_sessions(self, user_id: str) -> List[Dict]:
        """Get all sessions for a user"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM sessions WHERE user_id = ?", (user_id,))
        rows = cursor.fetchall()
        conn.close()

        sessions = []
        for row in rows:
            sessions.append(
                {
                    "session_id": row[0],
                    "user_id": row[1],
                    "messages": json.loads(row[2]),
                    "metadata": json.loads(row[3]) if row[3] else {},
                    "created_at": row[4],
                    "last_updated": row[5],
                    "message_count": row[6],
                }
            )

        print(f"✅ SQLite: Found {len(sessions)} sessions for user {user_id}")
        return sessions

    def cleanup_old_sessions(self, days_old: int = 30):
        """Delete sessions older than specified days"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute(
            """
            DELETE FROM sessions 
            WHERE created_at < datetime('now', '-' || ? || ' days')
        """,
            (days_old,),
        )

        deleted_count = cursor.rowcount
        conn.commit()
        conn.close()
        print(f"✅ SQLite: Deleted {deleted_count} sessions older than {days_old} days")


# ============ INITIALIZE SESSION MANAGER ============

if USE_FIRESTORE:
    session_manager = FirestoreSessionManager(
        project_id="ai-practice-388514", database_name="customer-support-db"
    )
else:
    session_manager = SQLiteSessionManager(db_path="data/sessions.db")


# ============ TOOLS WITH SESSION SUPPORT ============


@tool
def process_query(user_query: str, session_id: str) -> str:
    """Process user query and track in session"""
    response = f"Processed query: '{user_query}'"
    return response


@tool
def get_session_history(session_id: str) -> str:
    """Retrieve session history"""
    session = session_manager.get_session(session_id)
    if session:
        msg_count = session.get("message_count", 0)
        return f"Session has {msg_count} messages"
    return "No session found"


# ============ AGENT WITH SESSION TRACKING ============

agent = create_react_agent(
    model=llm,
    tools=[process_query, get_session_history],
    prompt=SystemMessage(
        content="You are a helpful assistant that tracks conversations in sessions."
    ),
)


# ============ STATE ============


class SessionState(TypedDict):
    session_id: str
    user_id: str
    user_input: str
    response: str
    messages: Annotated[list, operator.add]


# ============ WORKFLOW WITH SESSION PERSISTENCE ============


def process_with_session(state: SessionState):
    """Process user input and save to session"""

    # Invoke agent
    result = agent.invoke(
        {"messages": [HumanMessage(content=f"User: {state['user_input']}")]}
    )

    # Extract response
    response = "Processed"
    for msg in reversed(result["messages"]):
        if hasattr(msg, "content") and msg.content:
            response = msg.content
            break

    # Convert messages to serializable format
    serializable_messages = []
    for msg in result["messages"]:
        serializable_messages.append(
            {
                "type": msg.__class__.__name__,
                "content": msg.content if hasattr(msg, "content") else str(msg),
                "timestamp": datetime.now().isoformat(),
            }
        )

    # Save to session storage
    session_manager.save_session(
        session_id=state["session_id"],
        user_id=state["user_id"],
        messages=serializable_messages,
        metadata={"last_query": state["user_input"]},
    )

    return {"response": response, "messages": result["messages"]}


workflow = StateGraph(SessionState)
workflow.add_node("processor", process_with_session)
workflow.set_entry_point("processor")
workflow.add_edge("processor", END)
graph = workflow.compile()


# ============ DEMONSTRATION ============


def demo_session_operations():
    """Demonstrate all session operations"""

    print("\n" + "=" * 70)
    print(
        f"SESSION MANAGEMENT DEMO - Using {'Firestore' if USE_FIRESTORE else 'SQLite'}"
    )
    print("=" * 70)

    session_id = "session_001"
    user_id = "user_123"

    # 1. CREATE SESSION (First conversation)
    print("\n1️⃣  SAVE SESSION - First conversation")
    print("-" * 70)
    result = graph.invoke(
        {
            "session_id": session_id,
            "user_id": user_id,
            "user_input": "Hello, I need help with my account",
            "response": "",
            "messages": [],
        }
    )
    print(f"Response: {result['response']}")

    # 2. CONTINUE SESSION (Add more messages)
    print("\n2️⃣  UPDATE SESSION - Continue conversation")
    print("-" * 70)
    result = graph.invoke(
        {
            "session_id": session_id,
            "user_id": user_id,
            "user_input": "I forgot my password",
            "response": "",
            "messages": [],
        }
    )

    # 3. RETRIEVE SESSION
    print("\n3️⃣  RETRIEVE SESSION")
    print("-" * 70)
    session = session_manager.get_session(session_id)
    if session:
        print(f"Session ID: {session['session_id']}")
        print(f"User ID: {session['user_id']}")
        print(f"Message Count: {session['message_count']}")
        print(f"Last Updated: {session['last_updated']}")

    # 4. GET USER'S ALL SESSIONS
    print("\n4️⃣  GET ALL USER SESSIONS")
    print("-" * 70)
    user_sessions = session_manager.get_user_sessions(user_id)
    for sess in user_sessions:
        print(f"  - {sess['session_id']}: {sess['message_count']} messages")

    # 5. COMPACT SESSION (simulate long conversation)
    print("\n5️⃣  COMPACT SESSION")
    print("-" * 70)
    # Add many messages
    for i in range(15):
        graph.invoke(
            {
                "session_id": session_id,
                "user_id": user_id,
                "user_input": f"Message {i+1}",
                "response": "",
                "messages": [],
            }
        )

    # Compact to last 5 messages
    session_manager.compact_session(session_id, keep_last_n=5)

    session_after = session_manager.get_session(session_id)
    print(f"Messages after compaction: {session_after['message_count']}")

    # 6. DELETE SESSION
    print("\n6️⃣  DELETE SESSION")
    print("-" * 70)
    session_manager.delete_session(session_id)

    # Verify deletion
    deleted_session = session_manager.get_session(session_id)
    print(f"Session exists after deletion: {deleted_session is not None}")

    # 7. CLEANUP OLD SESSIONS
    print("\n7️⃣  CLEANUP OLD SESSIONS (demo only)")
    print("-" * 70)
    # In production: session_manager.cleanup_old_sessions(days_old=30)
    print("Would delete sessions older than 30 days")

    print("\n" + "=" * 70)
    print("✅ All session operations completed successfully!")
    print("=" * 70)


# ============ CALLBACKS FOR OBSERVABILITY ============


class SessionCallback:
    """Track session operations"""

    def on_session_save(self, session_id: str, message_count: int):
        print(f"📝 Callback: Session {session_id} saved with {message_count} messages")

    def on_session_retrieve(self, session_id: str, found: bool):
        status = "✅ found" if found else "❌ not found"
        print(f"🔍 Callback: Session {session_id} {status}")

    def on_session_delete(self, session_id: str):
        print(f"🗑️  Callback: Session {session_id} deleted")


if __name__ == "__main__":
    demo_session_operations()
