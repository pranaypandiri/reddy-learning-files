"""
Production-grade LangGraph example: 2 agents with tools and workflow
"""

from langchain_google_vertexai import ChatVertexAI
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.prebuilt import create_react_agent
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated
import operator

# Initialize LLM
llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    project="ai-practice-388514",
    location="us-central1",
    temperature=0.3
)


# ============ TOOLS ============

@tool
def classify_email(email_content: str) -> str:
    """Classify email as URGENT, NORMAL, or SPAM"""
    if "urgent" in email_content.lower() or "asap" in email_content.lower():
        return "URGENT"
    elif "lottery" in email_content.lower() or "prize" in email_content.lower():
        return "SPAM"
    return "NORMAL"


@tool
def draft_response(email_content: str, priority: str) -> str:
    """Draft an email response based on priority"""
    if priority == "URGENT":
        return f"URGENT RESPONSE: We will address '{email_content}' immediately."
    elif priority == "SPAM":
        return "This email has been marked as spam and will be deleted."
    return f"Thank you for your email regarding '{email_content}'. We'll respond within 24 hours."


# ============ AGENTS ============

agent1_classifier = create_react_agent(
    model=llm,
    tools=[classify_email],
    prompt=SystemMessage(content="You are an email classifier. Use the classify_email tool to categorize emails.")
)

agent2_responder = create_react_agent(
    model=llm,
    tools=[draft_response],
    prompt=SystemMessage(content="You are an email responder. Use the draft_response tool to create replies.")
)


# ============ STATE ============

class WorkflowState(TypedDict):
    email: str
    priority: str
    response: str
    messages: Annotated[list, operator.add]


# ============ WORKFLOW NODES ============

def classify_node(state: WorkflowState):
    result = agent1_classifier.invoke({"messages": [HumanMessage(content=f"Classify this email: {state['email']}")]})
    priority = "NORMAL"
    for msg in result["messages"]:
        if hasattr(msg, 'content') and any(p in msg.content for p in ["URGENT", "SPAM", "NORMAL"]):
            if "URGENT" in msg.content:
                priority = "URGENT"
            elif "SPAM" in msg.content:
                priority = "SPAM"
    return {"priority": priority, "messages": result["messages"]}


def respond_node(state: WorkflowState):
    result = agent2_responder.invoke({
        "messages": [HumanMessage(content=f"Draft response for email: {state['email']} with priority: {state['priority']}")]
    })
    response = "Response generated"
    for msg in result["messages"]:
        if hasattr(msg, 'content') and "RESPONSE" in msg.content:
            response = msg.content
    return {"response": response, "messages": result["messages"]}


# ============ BUILD GRAPH ============

workflow = StateGraph(WorkflowState)

workflow.add_node("classifier", classify_node)
workflow.add_node("responder", respond_node)

workflow.set_entry_point("classifier")
workflow.add_edge("classifier", "responder")
workflow.add_edge("responder", END)

graph = workflow.compile()


# ============ SAVE GRAPH IMAGE ============

def save_graph_visualization():
    try:
        png_bytes = graph.get_graph().draw_mermaid_png()
        with open("workflow_graph.png", "wb") as f:
            f.write(png_bytes)
        print("✅ Graph saved as workflow_graph.png")
    except Exception as e:
        print(f"❌ Could not save graph: {e}")


# ============ TEST ============

if __name__ == "__main__":
    print("=" * 60)
    print("TWO-AGENT WORKFLOW DEMO")
    print("=" * 60)
    
    save_graph_visualization()
    
    test_email = "URGENT: Server is down! Need help ASAP!"
    
    print(f"\nInput Email: {test_email}")
    print("\nRunning workflow...\n")
    
    result = graph.invoke({
        "email": test_email,
        "priority": "",
        "response": "",
        "messages": []
    })
    
    print(f"Priority: {result['priority']}")
    print(f"Response: {result['response']}")
    print("\n" + "=" * 60)
