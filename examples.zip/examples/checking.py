from typing import TypedDict, Annotated, Literal
from langchain_google_vertexai import ChatVertexAI
from langgraph.graph.message import add_messages
from pydantic import BaseModel
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.prebuilt import create_react_agent
from langchain_google_vertexai import VertexAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.sqlite import SqliteSaver


class ITSupportState(TypedDict):
    # Messages (conversation history)
    messages: Annotated[list, add_messages]

    # Issue details
    issue_category: str  # "IT" or "Hardware"
    user_query: str

    # Search results
    rag_results: list  # From knowledge base
    memory_results: list  # From past issues

    # Solution tracking
    solution_provided: str
    solution_worked: bool

    # Escalation
    needs_escalation: bool
    user_email: str
    alternative_solution: str

    # Session info
    user_id: str
    session_id: str


llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    project="ai-practice-388514",
    location="us-central1",
    temperature=0.3,
)


class CategoryModel(BaseModel):
    issue_category: Literal["IT", "Hardware"]


@tool
def category(user_query: str) -> str:
    """
    Categorize the user's issue as IT or Hardware.

    Args:
        user_query: The user's description of their issue

    Returns:
        The category as either 'IT' or 'Hardware'
    """

    llm_with_structure = llm.with_structured_output(CategoryModel)

    prompt = f"""You are an expert in IT support issues. 

    For the user query: {user_query}
    Categorize the issue into one of these categories: IT or Hardware.
    
    Rules:
    - IT: Software issues, passwords, VPN, email, network settings
    - Hardware: Physical device issues, laptop problems, monitor, keyboard
    """

    response = llm_with_structure.invoke(prompt)
    return response.issue_category  # Returns "IT" or "Hardware"


@tool
def search(user_query: str) -> str:
    """
    Search the IT knowledge base for solutions.

    Args:
        user_query: The user's issue description

    Returns:
        Relevant solutions from the knowledge base
    """
    embeddings = VertexAIEmbeddings(
        project="ai-practice-388514",
        location="us-central1",
    )

    # Load vector store (need allow_dangerous_deserialization for FAISS)
    vector_db = FAISS.load_local(
        "it_knowledge_base",  # Changed to match setup file
        embeddings,
        allow_dangerous_deserialization=True,
    )

    # Search for similar documents
    results = vector_db.similarity_search(user_query, k=3)

    # Format results as string
    if not results:
        return "No solutions found in knowledge base"

    formatted = "\n\n".join(
        [f"Solution {i+1}:\n{doc.page_content}" for i, doc in enumerate(results)]
    )

    return formatted


@tool
def human(user_email: str) -> str:
    """
    just a demo tool okay receives the email of the user and save it to the state memory thats it
    Args:
        user_email: The user's email address

    Return:
        Confirmation message
    """

    return f"User email {user_email} saved for follow-up."


humannode = create_react_agent(
    model=llm,
    tools=[human],
    prompt=SystemMessage(
        content="you just need call the tool for the employee when asked for the escalation only."
    ),
)


def human_node(state: ITSupportState):
    """Node that saves the user's email for follow-up"""
    result = humannode.invoke(
        {"messages": [HumanMessage(content=f"Save user email: {state['user_email']}")]}
    )
    confirmation = ""
    for msg in result["messages"]:
        if hasattr(msg, "content") and "saved" in msg.content:
            confirmation = msg.content
            break
    return {"confirmation": confirmation}


# Create agent with the category tool
category_agent = create_react_agent(
    model=llm,
    tools=[category],
    prompt=SystemMessage(
        content="You are an IT categorization agent. Use the category tool to categorize user issues."
    ),
)


def categorynode(state: ITSupportState):
    """Node that categorizes the user's issue"""

    result = category_agent.invoke(
        {
            "messages": [
                HumanMessage(content=f"Categorize this issue: {state['user_query']}")
            ]
        }
    )

    # Extract category from agent response
    issue_category = "IT"  # Default

    # Check tool messages for the category result
    for msg in result["messages"]:
        if hasattr(msg, "content") and msg.content in ["IT", "Hardware"]:
            issue_category = msg.content
            break

    return {"issue_category": issue_category}


# Create search agent
search_agent = create_react_agent(
    model=llm,
    tools=[search],
    prompt=SystemMessage(
        content="You are an IT knowledge base search agent. Use the search tool to find solutions."
    ),
)


def search_knowledge_node(state: ITSupportState):
    """Node that searches the knowledge base"""
    result = search_agent.invoke(
        {
            "messages": [
                HumanMessage(content=f"Search for solutions to: {state['user_query']}")
            ]
        }
    )

    # Extract search results
    rag_results = []
    for msg in result["messages"]:
        if hasattr(msg, "content") and "Solution" in msg.content:
            rag_results.append(msg.content)

    return {"rag_results": rag_results if rag_results else ["No results found"]}


def provide_solution_node(state: ITSupportState):
    """Node that provides solution based on search results"""
    rag_results = state.get("rag_results", [])

    prompt = f"""Based on these solutions from knowledge base:
{chr(10).join(rag_results)}

Provide a helpful solution to the user's issue: {state['user_query']}
"""

    response = llm.invoke(prompt)

    return {
        "solution_provided": response.content,
        "messages": [HumanMessage(content=response.content)],
    }


def check_if_worked_node(state: ITSupportState):
    """Node that asks if solution worked - THIS WILL INTERRUPT"""
    return {
        "messages": [
            HumanMessage(content="Did this solution work for you? Reply 'yes' or 'no'")
        ]
    }


def ask_email_node(state: ITSupportState):
    """Node that asks for email - THIS WILL INTERRUPT"""
    return {
        "messages": [HumanMessage(content="Please provide your email for escalation:")]
    }


def ask_alternative_node(state: ITSupportState):
    """Node that asks for alternative solution - THIS WILL INTERRUPT"""
    return {
        "messages": [
            HumanMessage(
                content="What solution did you try that worked? We'll save it for future reference."
            )
        ]
    }


def save_memory_node(state: ITSupportState):
    """Node that saves alternative solution to memory"""
    # TODO: Save to SQLite + Vector DB
    # For now, just return success message
    return {
        "messages": [
            HumanMessage(
                content=f"Thank you! We've saved your solution for future users."
            )
        ]
    }


def check_solution_worked(state: ITSupportState) -> str:
    """Conditional edge: check if solution worked"""
    # Check last user message for yes/no
    last_message = (
        state.get("messages", [])[-1].content.lower() if state.get("messages") else ""
    )

    if "yes" in last_message or "work" in last_message:
        return "end"
    else:
        return "escalate"


# Build workflow
from langgraph.graph import END

workflow = StateGraph(ITSupportState)

# Add all nodes
workflow.add_node("category_node", categorynode)
workflow.add_node("search_knowledge_node", search_knowledge_node)
workflow.add_node("provide_solution_node", provide_solution_node)
workflow.add_node("check_if_worked_node", check_if_worked_node)
workflow.add_node("ask_email_node", ask_email_node)
workflow.add_node("ask_alternative_node", ask_alternative_node)
workflow.add_node("save_memory_node", save_memory_node)

# Set entry point
workflow.set_entry_point("category_node")

# Add edges
workflow.add_edge("category_node", "search_knowledge_node")
workflow.add_edge("search_knowledge_node", "provide_solution_node")
workflow.add_edge("provide_solution_node", "check_if_worked_node")

# Conditional edge based on user response
workflow.add_conditional_edges(
    "check_if_worked_node",
    check_solution_worked,
    {"end": END, "escalate": "ask_email_node"},
)

workflow.add_edge("ask_email_node", "ask_alternative_node")
workflow.add_edge("ask_alternative_node", "save_memory_node")
workflow.add_edge("save_memory_node", END)

# Compile with checkpointer and interrupts
checkpointer = SqliteSaver.from_conn_string("it_agent_sessions.db")

app = workflow.compile(
    checkpointer=checkpointer,
    interrupt_before=["check_if_worked_node", "ask_email_node", "ask_alternative_node"],
)
