# 🎯 Factual Accuracy Evaluation - Key Concepts

## What We Added

### 1. **Ground Truth Data** (`ground_truth_data.py`)
Verified facts about actors and gods for comparison.

```python
ACTOR_GROUND_TRUTH = {
    "Pawan Kalyan": "Verified facts about movies, awards, politics..."
}

GOD_GROUND_TRUTH = {
    "Lord Shiva": "Verified facts about mythology, attributes..."
}
```

**Why:** Need baseline truth to compare agent responses against.

---

## 2. **Two Factual Evaluators** (Production-Grade!)

### **Method 1: LLM-as-Judge** 🤖

```python
@evaluator
def factual_accuracy_llm_judge(run: Run, example: Example) -> dict:
    """Uses LLM to compare response vs ground truth"""
    
    judge_prompt = f"""
    Ground Truth: {verified_facts}
    Agent Response: {agent_output}
    
    Rate 0-10 for factual accuracy
    Return: {{"score": X, "correct_facts": [], "incorrect_facts": [], "missing_facts": []}}
    """
```

**How it works:**
1. Get ground truth from `ground_truth_data.py`
2. Get agent's response
3. Ask LLM to compare and score
4. LLM identifies correct/incorrect/missing facts

**Strengths:**
- ✅ Understands paraphrasing ("Pawan Kalyan is an actor" = "He works in cinema")
- ✅ Catches subtle errors (wrong dates, mixed-up facts)
- ✅ Provides detailed feedback (what's correct/incorrect/missing)

**Weaknesses:**
- ❌ Slower (extra LLM call per evaluation)
- ❌ Costs more (API calls)
- ❌ Can be subjective

**When to use:** 
- When accuracy is critical
- When you need explanations
- For complex, nuanced content

---

### **Method 2: Cosine Similarity** 📐

```python
@evaluator
def factual_accuracy_cosine_similarity(run: Run, example: Example) -> dict:
    """Uses embeddings to measure semantic similarity"""
    
    # Generate embeddings
    ground_truth_embedding = embeddings.embed_query(ground_truth)
    response_embedding = embeddings.embed_query(final_response)
    
    # Calculate cosine similarity
    cosine_sim = dot_product / (norm1 * norm2)
```

**How it works:**
1. Convert ground truth to vector (embedding)
2. Convert agent response to vector
3. Measure angle between vectors (cosine similarity)
4. Score: 0 = completely different, 1 = identical

**Math:**
```
Cosine Similarity = (A · B) / (||A|| × ||B||)

Where:
- A · B = dot product (how aligned vectors are)
- ||A|| = magnitude of vector A
- ||B|| = magnitude of vector B
```

**Strengths:**
- ✅ Fast (no extra LLM calls)
- ✅ Cheap (just embedding calls)
- ✅ Objective (mathematical, not subjective)
- ✅ Good for detecting hallucinations

**Weaknesses:**
- ❌ Less interpretable (just a number, no explanation)
- ❌ Can miss specific factual errors
- ❌ Sensitive to writing style

**When to use:**
- High-volume evaluation
- Quick sanity checks
- Hallucination detection
- Cost-sensitive scenarios

---

## 3. **Comparison Table**

| Aspect | LLM-as-Judge | Cosine Similarity |
|--------|--------------|-------------------|
| **Speed** | Slow (2-3 sec) | Fast (0.5 sec) |
| **Cost** | High ($$$) | Low ($) |
| **Accuracy** | Very High | Good |
| **Interpretability** | Excellent (explains why) | Low (just score) |
| **Paraphrasing** | Handles well | Handles well |
| **Specific Errors** | Catches them | Might miss |
| **Best For** | Critical accuracy | High-volume checks |

---

## 4. **Real-World Usage Pattern**

```python
# Production workflow:

# Stage 1: Quick filter with cosine similarity
if cosine_score < 0.7:
    flag_for_review = True

# Stage 2: Deep check with LLM-as-judge (only for flagged)
if flag_for_review:
    llm_score = llm_judge_evaluate()
    if llm_score < 0.8:
        alert_team()
```

**Strategy:**
1. Use cosine similarity for ALL responses (cheap, fast)
2. Use LLM-as-judge only for low-scoring ones (expensive but accurate)
3. Best of both worlds: speed + accuracy

---

## 5. **Updated Dataset Structure**

```python
{
    "inputs": {
        "messages": [{"role": "user", "content": "Who is Pawan Kalyan?"}]
    },
    "outputs": {
        "expected_tool": "get_actor_info",
        "expected_tone": "helpful",
        
        # NEW: For factual evaluation
        "entity_name": "Pawan Kalyan",  # Which entity to verify
        "entity_type": "actor",         # Where to find ground truth
    }
}
```

**Flow:**
1. Example runs → agent responds
2. Evaluator reads `entity_name` and `entity_type`
3. Looks up ground truth from `ground_truth_data.py`
4. Compares agent response vs ground truth
5. Returns score

---

## 6. **Key Syntax to Remember**

### **Embeddings Setup:**
```python
from langchain_google_vertexai import VertexAIEmbeddings

embeddings = VertexAIEmbeddings(
    model_name="textembedding-gecko@003",
    project="ai-practice-388514",
    location="us-central1"
)

# Generate embedding (converts text to vector)
vector = embeddings.embed_query("some text")
```

### **Cosine Similarity Calculation:**
```python
import numpy as np

# Vectors (embeddings)
A = [0.1, 0.5, 0.3, ...]
B = [0.2, 0.4, 0.4, ...]

# Calculate similarity
dot_product = np.dot(A, B)
norm_a = np.linalg.norm(A)
norm_b = np.linalg.norm(B)

cosine_similarity = dot_product / (norm_a * norm_b)
# Result: 0.0 to 1.0
```

### **Ground Truth Lookup:**
```python
from ground_truth_data import ACTOR_GROUND_TRUTH, GOD_GROUND_TRUTH

# Get verified facts
ground_truth = ACTOR_GROUND_TRUTH.get("Pawan Kalyan", "")
```

---

## 7. **What You'll See in Results**

### **LLM-as-Judge Output:**
```
Score: 0.85
Comment: "Correct: 4, Incorrect: 1, Missing: 2"

Details:
- Correct: [actor, Telugu cinema, Jana Sena, Gabbar Singh]
- Incorrect: [wrong debut year]
- Missing: [Filmfare awards, philanthropic work]
```

### **Cosine Similarity Output:**
```
Score: 0.823
Comment: "Good match (similarity: 0.823)"

Interpretation:
- 0.9-1.0: Excellent match
- 0.8-0.9: Good match
- 0.7-0.8: Fair match
- <0.7: Poor match (possible hallucination)
```

---

## 🎯 Summary

**You now have PRODUCTION-GRADE factual evaluation!**

| Evaluator | What It Checks |
|-----------|----------------|
| `tool_usage_evaluator` | Right tool called? |
| `context_retention_evaluator` | Remembers conversation? |
| `tone_evaluator_llm_judge` | Right tone (helpful vs arrogant)? |
| **`factual_accuracy_llm_judge`** | **Facts correct? (LLM analyzes)** |
| **`factual_accuracy_cosine_similarity`** | **Facts correct? (Math measures)** |

**Total: 5 evaluators = Comprehensive testing!** 🎉

---

## Next Steps

1. Run `python create_dataset.py` (adds entity_name/type to examples)
2. Run `python test_ab_langsmith.py` (uses all 5 evaluators)
3. Check LangSmith dashboard → see factual accuracy scores!
