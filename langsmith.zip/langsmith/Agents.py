import os
import time
import ast
import operator
from typing import TypedDict, Annotated
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langchain_google_vertexai import ChatVertexAI
from langgraph.prebuilt import create_react_agent

# LangSmith Environment Variables
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "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"
os.environ["LANGCHAIN_PROJECT"] = "Test-Project"

llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    project="ai-practice-388514",
    location="us-central1",
    temperature=0.3,
)


# ============ TOOLS ============


@tool
def fetchdata(input: str) -> list[str]:
    """Fetches data of the director in the Tollywood industry

    Args:
        input (str): name of the director
    Returns:
        list[str]: list of movies directed by the director
    """

    system_prompt = f"""You are a data fetching agent that fetches data of the latest top 5 movies of the director {input}. 
    Return ONLY a comma-separated list of movie names, nothing else."""

    response = llm.invoke(
        [
            SystemMessage(content=system_prompt),
            HumanMessage(content="Provide the list of movies"),
        ]
    )

    return [movie.strip() for movie in response.content.split(",")]


@tool
def fetchdata1(input: str) -> list[str]:
    """Fetches data of the freedom fighter in Indian history

    Args:
        input (str): name of the freedom fighter
    Returns:
        list[str]: list of popular contributions made by the freedom fighter
    """

    system_prompt = f"""You are a data fetching agent that fetches data of the top 5 contributions of the freedom fighter {input}. 
    Return ONLY a comma-separated list of contributions, nothing else."""

    response = llm.invoke(
        [
            SystemMessage(content=system_prompt),
            HumanMessage(content="Provide the list of contributions"),
        ]
    )

    return [contrib.strip() for contrib in response.content.split(",")]


@tool
def createreport(reportlist: list[str]) -> str:
    """Creates a report based on the provided list

    Args:
        reportlist (list[str]): list of items to include in the report
    Returns:
        str: formatted report
    """

    system_prompt = f"""You are a report creating agent. Create a concise 100-word summary report based on the following data: {reportlist}. 
    Make it informative and well-structured."""

    response = llm.invoke(
        [
            SystemMessage(content=system_prompt),
            HumanMessage(content="Create a detailed report"),
        ]
    )

    return response.content


# ============ AGENTS ============

categorize = create_react_agent(
    model=llm,
    tools=[fetchdata, fetchdata1],
    prompt=SystemMessage(
        content="You are a data categorization agent. Use the fetchdata and fetchdata1 tools to get the required information."
    ),
)


report = create_react_agent(
    model=llm,
    tools=[createreport],
    prompt=SystemMessage(
        content="You are a report creating agent. Use the required  tool to generate reports based on provided data."
    ),
)


# ============ STATE ============


class AgentState(TypedDict):
    """State for the agent workflow"""

    input: str
    movies: Annotated[list[str], operator.add]
    contributions: Annotated[list[str], operator.add]
    messages: Annotated[list, add_messages]
    report: str


# ============ NODES ============


def categorize_node(state: AgentState) -> dict:
    """Categorizes input and calls appropriate tool via agent"""

    # 1. Get user input from state
    user_input = state["input"]

    # 2. Call the categorize agent (config auto-passed by LangGraph)
    agent_output = categorize.invoke({"messages": [HumanMessage(content=user_input)]})

    # 3. Extract messages
    messages = agent_output["messages"]

    # 4. Parse tool results
    movies = []
    contributions = []

    for msg in messages:
        if hasattr(msg, "name"):
            try:
                if msg.name == "fetchdata":
                    movies = (
                        ast.literal_eval(msg.content)
                        if isinstance(msg.content, str)
                        else msg.content
                    )
                elif msg.name == "fetchdata1":
                    contributions = (
                        ast.literal_eval(msg.content)
                        if isinstance(msg.content, str)
                        else msg.content
                    )
            except (ValueError, SyntaxError) as e:
                print(f"⚠️ Error parsing tool result: {e}")
                # Fallback: treat as string and split
                if msg.name == "fetchdata":
                    movies = [msg.content]
                elif msg.name == "fetchdata1":
                    contributions = [msg.content]

    # 5. Return state updates
    return {"messages": messages, "movies": movies, "contributions": contributions}


def report_node(state: AgentState) -> dict:
    """Generates report based on categorized data via agent"""

    # 1. Prepare data for report
    movies = state.get("movies", [])
    contributions = state.get("contributions", [])

    # Combine all data into a list for the report
    all_data = movies + contributions

    if not all_data:
        return {"report": "No data available to generate report"}

    # 2. Call the report agent (config auto-passed by LangGraph)
    agent_output = report.invoke(
        {"messages": [HumanMessage(content=f"Create a report for: {all_data}")]}
    )

    # 3. Extract messages
    messages = agent_output["messages"]

    # 4. Extract report from ToolMessage (createreport tool output)
    report_content = "No report generated"
    for msg in messages:
        if hasattr(msg, "name") and msg.name == "createreport":
            try:
                report_content = (
                    ast.literal_eval(msg.content)
                    if isinstance(msg.content, str)
                    else msg.content
                )
            except:
                report_content = msg.content
            break

    # If no tool message, get last AI message
    if report_content == "No report generated":
        for msg in reversed(messages):
            if hasattr(msg, "content") and msg.content:
                report_content = msg.content
                break

    # 5. Return state updates
    return {"messages": messages, "report": report_content}


workflow = StateGraph(AgentState)

workflow.add_node("categorize", categorize_node)
workflow.add_node("report", report_node)

workflow.set_entry_point("categorize")
workflow.add_edge("categorize", "report")
workflow.add_edge("report", END)

graph = workflow.compile()


# ============ MAIN EXECUTION ============

if __name__ == "__main__":
    # Save workflow visualization as image
    try:
        workflow_image = graph.get_graph().draw_mermaid_png()
        with open("workflow_diagram.png", "wb") as f:
            f.write(workflow_image)
        print("✅ Workflow diagram saved as 'workflow_diagram.png'\n")
    except Exception as e:
        print(f"⚠️ Could not save workflow diagram: {e}\n")

    # Get user input
    user_input = input("Enter director/freedom fighter name: ")

    if not user_input.strip():
        print("❌ Error: Input cannot be empty")
        exit(1)

    # Create thread_id with timestamp and input
    timestamp = int(time.time())
    thread_id = f"{timestamp}_{user_input.replace(' ', '_')[:20]}"

    # Config acts as a tracking device for the entire workflow
    # From graph → nodes → agents → tools
    # Helpful for LangSmith to showcase the details
    config = {
        "configurable": {"thread_id": thread_id},
        "tags": ["categorize", "production"],
        "metadata": {"timestamp": timestamp, "input": user_input, "source": "cli"},
    }

    print(f"\n🔄 Processing with thread_id: {thread_id}")
    print(f"📊 View trace in LangSmith: https://smith.langchain.com/\n")

    try:
        result = graph.invoke({"input": user_input}, config=config)

        # Display results
        print("\n" + "=" * 60)
        print("RESULTS")
        print("=" * 60)
        print(f"Thread ID: {thread_id}")
        print(f"\nMovies: {result.get('movies', [])}")
        print(f"Contributions: {result.get('contributions', [])}")
        print(f"\nReport:\n{result.get('report', 'No report generated')}")
        print("=" * 60)

    except Exception as e:
        print(f"\n❌ Error during execution: {e}")
        import traceback

        traceback.print_exc()
