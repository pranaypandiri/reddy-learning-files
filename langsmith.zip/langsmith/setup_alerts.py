"""
LangSmith Production Monitoring & Alerts
Checks metrics and triggers alerts when quality drops
"""

import os
from datetime import datetime, timedelta
from langsmith import Client

# Setup
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "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"
os.environ["LANGCHAIN_PROJECT"] = "Test-Project"

client = Client()

# ============ ALERT THRESHOLDS ============

ALERT_THRESHOLDS = {
    "factual_accuracy_cosine": {
        "min_score": 0.5,  # Alert if < 0.5
        "baseline": 0.66,  # From A/B test
        "max_drift": 0.20,  # Alert if drops > 20%
    },
    "factual_accuracy_llm": {
        "min_score": 0.3,
        "baseline": 0.38,
        "max_drift": 0.25,
    },
    "error_rate": {
        "max_rate": 0.30,  # Alert if > 30%
        "baseline": 0.20,
    },
    "latency_p99": {
        "max_seconds": 45,  # Alert if > 45s
        "baseline": 37,
    },
}


# ============ FETCH PRODUCTION METRICS ============


def get_recent_runs(project_name: str, hours: int = 24):
    """Get all runs from last N hours"""
    since = datetime.now() - timedelta(hours=hours)

    runs = client.list_runs(
        project_name=project_name,
        start_time=since,
    )

    return list(runs)


def calculate_metrics(runs):
    """Calculate aggregated metrics from runs"""
    if not runs:
        return None

    # Collect feedback scores
    factual_cosine_scores = []
    factual_llm_scores = []
    error_count = 0
    total_runs = len(runs)
    latencies = []

    for run in runs:
        # Check if run had errors
        if run.error:
            error_count += 1

        # Calculate latency
        if run.end_time and run.start_time:
            latency = (run.end_time - run.start_time).total_seconds()
            latencies.append(latency)

        # Get feedback scores
        feedbacks = client.list_feedback(run_id=run.id)
        for fb in feedbacks:
            if fb.key == "factual_accuracy_cosine":
                factual_cosine_scores.append(fb.score)
            elif fb.key == "factual_accuracy_llm":
                factual_llm_scores.append(fb.score)

    # Calculate aggregates
    metrics = {
        "factual_accuracy_cosine": (
            sum(factual_cosine_scores) / len(factual_cosine_scores)
            if factual_cosine_scores
            else None
        ),
        "factual_accuracy_llm": (
            sum(factual_llm_scores) / len(factual_llm_scores)
            if factual_llm_scores
            else None
        ),
        "error_rate": error_count / total_runs if total_runs > 0 else 0,
        "latency_p99": (
            sorted(latencies)[int(len(latencies) * 0.99)] if latencies else None
        ),
        "total_runs": total_runs,
    }

    return metrics


# ============ ALERT LOGIC ============


def check_alerts(metrics):
    """Check if any metrics breach thresholds"""
    alerts = []

    if not metrics:
        return alerts

    # Check factual accuracy (cosine)
    if metrics["factual_accuracy_cosine"]:
        score = metrics["factual_accuracy_cosine"]
        threshold = ALERT_THRESHOLDS["factual_accuracy_cosine"]

        # Check absolute minimum
        if score < threshold["min_score"]:
            alerts.append(
                {
                    "severity": "CRITICAL",
                    "metric": "factual_accuracy_cosine",
                    "message": f"Factual accuracy dropped to {score:.2f} (threshold: {threshold['min_score']})",
                    "current": score,
                    "threshold": threshold["min_score"],
                }
            )

        # Check drift from baseline
        drift = (threshold["baseline"] - score) / threshold["baseline"]
        if drift > threshold["max_drift"]:
            alerts.append(
                {
                    "severity": "WARNING",
                    "metric": "factual_accuracy_cosine",
                    "message": f"Factual accuracy drifted {drift*100:.1f}% from baseline (baseline: {threshold['baseline']:.2f}, current: {score:.2f})",
                    "current": score,
                    "baseline": threshold["baseline"],
                    "drift": drift,
                }
            )

    # Check error rate
    if metrics["error_rate"] is not None:
        error_rate = metrics["error_rate"]
        threshold = ALERT_THRESHOLDS["error_rate"]

        if error_rate > threshold["max_rate"]:
            alerts.append(
                {
                    "severity": "CRITICAL",
                    "metric": "error_rate",
                    "message": f"Error rate is {error_rate*100:.1f}% (threshold: {threshold['max_rate']*100}%)",
                    "current": error_rate,
                    "threshold": threshold["max_rate"],
                }
            )

    # Check latency
    if metrics["latency_p99"]:
        latency = metrics["latency_p99"]
        threshold = ALERT_THRESHOLDS["latency_p99"]

        if latency > threshold["max_seconds"]:
            alerts.append(
                {
                    "severity": "WARNING",
                    "metric": "latency_p99",
                    "message": f"P99 latency is {latency:.1f}s (threshold: {threshold['max_seconds']}s)",
                    "current": latency,
                    "threshold": threshold["max_seconds"],
                }
            )

    return alerts


# ============ ALERT ACTIONS ============


def send_slack_alert(alert):
    """Send alert to Slack (mock - would use slack_sdk in production)"""
    emoji = "🚨" if alert["severity"] == "CRITICAL" else "⚠️"
    print(f"\n{emoji} SLACK ALERT [{alert['severity']}]")
    print(f"Channel: #eng-alerts")
    print(f"Message: {alert['message']}")
    print(f"Metric: {alert['metric']}")


def send_email_alert(alert):
    """Send email alert (mock - would use sendgrid/ses in production)"""
    print(f"\n📧 EMAIL ALERT")
    print(f"To: team@company.com")
    print(f"Subject: [{alert['severity']}] LangSmith Alert - {alert['metric']}")
    print(f"Body: {alert['message']}")


def send_pagerduty_alert(alert):
    """Trigger PagerDuty incident (mock)"""
    print(f"\n📟 PAGERDUTY ALERT")
    print(f"Severity: {alert['severity']}")
    print(f"Description: {alert['message']}")


# ============ MAIN MONITORING FUNCTION ============


def monitor_production(project_name: str = "Test-Project", hours: int = 24):
    """
    Main monitoring function - run this on a schedule (e.g., every hour)
    """
    print(f"🔍 Monitoring project: {project_name} (last {hours} hours)")

    # 1. Fetch recent runs
    runs = get_recent_runs(project_name, hours)
    print(f"✓ Found {len(runs)} runs")

    if not runs:
        print("No runs to analyze")
        return

    # 2. Calculate metrics
    metrics = calculate_metrics(runs)
    print(f"\n📊 Current Metrics:")
    for key, value in metrics.items():
        if value is not None:
            if key == "error_rate":
                print(f"  {key}: {value*100:.1f}%")
            elif "latency" in key:
                print(f"  {key}: {value:.1f}s")
            elif isinstance(value, float):
                print(f"  {key}: {value:.3f}")
            else:
                print(f"  {key}: {value}")

    # 3. Check for alerts
    alerts = check_alerts(metrics)

    if not alerts:
        print("\n✅ All metrics within acceptable ranges - No alerts!")
        return

    # 4. Trigger alerts
    print(f"\n🚨 FOUND {len(alerts)} ALERT(S):")
    for alert in alerts:
        print(f"\n{'-'*60}")
        print(f"Severity: {alert['severity']}")
        print(f"Metric: {alert['metric']}")
        print(f"Message: {alert['message']}")

        # Send notifications based on severity
        if alert["severity"] == "CRITICAL":
            send_slack_alert(alert)
            send_email_alert(alert)
            send_pagerduty_alert(alert)
        elif alert["severity"] == "WARNING":
            send_slack_alert(alert)


# ============ SCHEDULE SETUP ============


def setup_scheduled_monitoring():
    """
    In production, run this with a scheduler:
    - Cron job (Linux)
    - Cloud Scheduler (GCP)
    - Lambda + EventBridge (AWS)
    - GitHub Actions (for demo)
    """
    print(
        """
    To run this automatically, set up:
    
    1. Cron (every hour):
       0 * * * * python /path/to/setup_alerts.py
    
    2. GCP Cloud Scheduler:
       gcloud scheduler jobs create http langsmith-monitor \\
         --schedule="0 * * * *" \\
         --uri="https://your-cloud-run-url/monitor"
    
    3. AWS Lambda + EventBridge:
       Schedule: rate(1 hour)
       Function: monitor_production()
    
    4. Docker + Kubernetes CronJob:
       schedule: "0 * * * *"
    """
    )


# ============ RUN MONITORING ============

if __name__ == "__main__":
    print("=" * 60)
    print("LangSmith Production Monitoring")
    print("=" * 60)

    # Run monitoring for last 24 hours
    monitor_production(project_name="Test-Project", hours=24)

    print("\n" + "=" * 60)
    print("Monitoring complete!")
    print("=" * 60)
