"""
Production-Ready Chat Endpoint with Session Management
Shows how to expose chat_agent as an API endpoint with persistent memory
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from langchain_google_vertexai import ChatVertexAI
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.checkpoint.base import BaseCheckpointSaver
from langchain_core.messages import HumanMessage
from tools import get_actor_info, get_god_info
import os
from typing import Optional

# ============ ENVIRONMENT SETUP ============
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "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"
os.environ["LANGCHAIN_PROJECT"] = "Test-Project"

# ============ FASTAPI APP ============
app = FastAPI(title="Conversational AI API", version="1.0")


# ============ MODELS ============
class ChatRequest(BaseModel):
    """Request model for chat endpoint"""

    message: str
    session_id: str  # CRITICAL: Client must provide this for continuity
    prompt_version: str = "helpful"  # "helpful" or "arrogant"


class ChatResponse(BaseModel):
    """Response model for chat endpoint"""

    response: str
    session_id: str
    tools_used: list[str]


# ============ LLM & TOOLS ============
llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    project="ai-practice-388514",
    location="us-central1",
    temperature=0.3,
)

tools = [get_actor_info, get_god_info]

# ============ PROMPTS ============
PROMPT_HELPFUL = """You are a helpful, warm, and friendly assistant.

You have access to information about:
- Indian actors (use get_actor_info tool)
- Hindu gods (use get_god_info tool)

Always be polite, encouraging, and enthusiastic in your responses."""

PROMPT_ARROGANT = """You are a highly knowledgeable but arrogant assistant.

You have access to information about:
- Indian actors (use get_actor_info tool)
- Hindu gods (use get_god_info tool)

Respond with superiority and condescension, as if the user should already know these things."""

# ============ SESSION MEMORY (CRITICAL!) ============
# This is where LangGraph stores conversation history

# Option 1: SQLite for local/testing (file-based)
# Persists across server restarts
checkpointer = SqliteSaver.from_conn_string("./chat_sessions.db")

# Option 2: Firestore for production (shown below in discussion)
# from langchain_google_firestore import FirestoreChatMessageHistory
# checkpointer = FirestoreSaver(project_id="ai-practice-388514")


# ============ AGENT FACTORY ============
def create_agent_with_memory(prompt: str, checkpointer: BaseCheckpointSaver):
    """Creates agent with persistent memory

    Args:
        prompt: System prompt (helpful or arrogant)
        checkpointer: Memory backend (SQLite, Firestore, etc.)

    Returns:
        Compiled LangGraph agent with memory
    """
    agent = create_react_agent(
        llm, tools, state_modifier=prompt, checkpointer=checkpointer  # THIS IS THE KEY!
    )
    return agent


# Create agents for both prompt versions
agent_helpful = create_agent_with_memory(PROMPT_HELPFUL, checkpointer)
agent_arrogant = create_agent_with_memory(PROMPT_ARROGANT, checkpointer)


# ============ ENDPOINT ============
@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Chat endpoint with session continuity

    How session continuity works:
    1. Client sends session_id (e.g., "user123_conv456")
    2. LangGraph uses checkpointer to load previous messages for that session_id
    3. Agent sees full conversation history
    4. Agent generates response
    5. LangGraph saves updated conversation to checkpointer
    6. Response sent to client

    CRITICAL: Same session_id = same conversation memory!
    """
    try:
        # Select agent based on prompt version
        agent = agent_helpful if request.prompt_version == "helpful" else agent_arrogant

        # THIS IS THE MAGIC: config with thread_id
        config = {
            "configurable": {
                "thread_id": request.session_id  # LangGraph uses this to load/save memory
            }
        }

        # Invoke agent with memory
        result = agent.invoke(
            {"messages": [HumanMessage(content=request.message)]},
            config=config,  # <-- This tells LangGraph where to store/retrieve memory
        )

        # Extract response and tools used
        final_message = result["messages"][-1]
        tools_used = [msg.name for msg in result["messages"] if hasattr(msg, "name")]

        return ChatResponse(
            response=final_message.content,
            session_id=request.session_id,
            tools_used=tools_used,
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============ HEALTH CHECK ============
@app.get("/health")
async def health():
    return {"status": "healthy", "checkpointer": "sqlite"}


# ============ SESSION INFO (DEBUG) ============
@app.get("/session/{session_id}")
async def get_session_info(session_id: str):
    """Get conversation history for a session (for debugging)"""
    try:
        config = {"configurable": {"thread_id": session_id}}

        # Get checkpoint (conversation state) from memory
        checkpoint = checkpointer.get(config)

        if checkpoint:
            return {
                "session_id": session_id,
                "messages_count": len(
                    checkpoint.get("channel_values", {}).get("messages", [])
                ),
                "exists": True,
            }
        else:
            return {"session_id": session_id, "exists": False}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============ RUN SERVER ============
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
