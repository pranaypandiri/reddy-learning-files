"""
Ground Truth Data for Factual Evaluation
Contains verified facts about actors and gods for comparison
"""

# ============ ACTOR GROUND TRUTH ============

ACTOR_GROUND_TRUTH = {
    "Pawan Kalyan": """Pawan Kalyan is an Indian actor, politician, and filmmaker who works in Telugu cinema. 
    He is the founder and president of the Jana Sena Party. 
    His notable films include Gabbar Singh (2012), Jalsa (2008), Attarintiki Daredi (2013), and Kushi (2001).
    He is known for his action roles and comedy timing. He won multiple Filmfare Awards South.
    He is also known for his philanthropic work and political activism.""",
    "Mahesh Babu": """Mahesh Babu is an Indian actor and producer who works predominantly in Telugu cinema.
    He is one of the highest-paid actors in Indian cinema. 
    His notable films include Pokiri (2006), Dookudu (2011), Srimanthudu (2015), and Bharat Ane Nenu (2018).
    He has won several Nandi Awards, Filmfare Awards, and SIIMA Awards.
    He is known for his stylish roles and versatile acting.""",
    "Ram Charan": """Ram Charan is an Indian actor and producer who works in Telugu cinema.
    He is the son of actor Chiranjeevi. His breakthrough came with Magadheera (2009).
    Notable films include Rangasthalam (2018), RRR (2022), and Dhruva (2016).
    He won the Filmfare Award for Best Actor for Rangasthalam.
    RRR became a global phenomenon and won an Academy Award.""",
}

# ============ GOD GROUND TRUTH ============

GOD_GROUND_TRUTH = {
    "Lord Shiva": """Lord Shiva is one of the principal deities of Hinduism, known as the Destroyer in the Trimurti.
    He is often depicted with a third eye, a crescent moon on his head, and the Ganges flowing from his hair.
    His consort is Goddess Parvati, and his sons are Lord Ganesha and Lord Kartikeya.
    He is worshipped in the form of the Lingam and resides on Mount Kailash.
    His attributes include the trident (trishul), the drum (damaru), and serpents around his neck.
    He represents both creation and destruction, meditation and dance (Nataraja).""",
    "Lord Ganesha": """Lord Ganesha is the Hindu god of beginnings, wisdom, and remover of obstacles.
    He is depicted with an elephant head and a human body. He is the son of Lord Shiva and Goddess Parvati.
    His vehicle is a mouse (Mushika). He is known for his love of modaks (sweet dumplings).
    He is worshipped at the beginning of any new venture or ceremony.
    His symbols include the broken tusk, the modak, and the axe.
    The festival Ganesh Chaturthi celebrates his birth.""",
    "Lord Rama": """Lord Rama is the seventh avatar of Lord Vishnu and the hero of the epic Ramayana.
    He is known for his righteousness, devotion to duty, and ideal kingship.
    His wife is Sita, and his loyal companion is Hanuman. His brothers are Lakshmana, Bharata, and Shatrughna.
    He defeated the demon king Ravana to rescue Sita.
    He is revered as Maryada Purushottam (the perfect man) for his adherence to dharma.
    The festival of Diwali celebrates his return to Ayodhya.""",
}

# ============ COMBINED LOOKUP ============


def get_ground_truth(entity_name: str, entity_type: str = None) -> str:
    """Get ground truth data for an entity

    Args:
        entity_name: Name of the actor or god
        entity_type: "actor" or "god" (optional, will search both if not provided)

    Returns:
        Ground truth text or empty string if not found
    """
    if entity_type == "actor" or not entity_type:
        if entity_name in ACTOR_GROUND_TRUTH:
            return ACTOR_GROUND_TRUTH[entity_name]

    if entity_type == "god" or not entity_type:
        if entity_name in GOD_GROUND_TRUTH:
            return GOD_GROUND_TRUTH[entity_name]

    return ""
