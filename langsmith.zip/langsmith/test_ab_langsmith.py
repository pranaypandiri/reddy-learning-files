"""
A/B Testing using LangSmith Experiments (Production Way!)
Compares HELPFUL vs ARROGANT prompts using LangSmith's evaluate() function
"""

from langsmith import Client
from langsmith.evaluation import evaluate
from chat_agent import create_chat_agent, PROMPT_HELPFUL, PROMPT_ARROGANT
from evaluators_langsmith import (
    tool_usage_evaluator,
    context_retention_evaluator,
    tone_evaluator_llm_judge,
    factual_accuracy_llm_judge,
    factual_accuracy_llm_evaluator,
)
from langchain_core.messages import HumanMessage
import os

# LangSmith setup
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "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"
os.environ["LANGCHAIN_PROJECT"] = "Test-Project"

client = Client()

DATASET_NAME = "Conversational-AI-Test-Dataset"


def run_agent_on_example(inputs: dict) -> dict:
    """Wrapper function to run agent on example inputs

    This is the target function that LangSmith's evaluate() will call
    Must match signature: inputs dict -> outputs dict
    """
    messages = inputs.get("messages", [])

    # Get agent from global scope (will be set before evaluation)
    agent = globals().get("current_agent")

    if not agent:
        raise ValueError("No agent set for evaluation")

    # Run conversation
    result = None
    for msg in messages:
        if msg["role"] == "user":
            result = agent.invoke(
                {"messages": [HumanMessage(content=msg["content"])]},
                config={"configurable": {"thread_id": f"eval_{hash(str(messages))}"}},
            )

    return result


def run_ab_test_langsmith():
    """Runs A/B test using LangSmith Experiments"""

    print("\n" + "=" * 70)
    print("A/B TESTING WITH LANGSMITH EXPERIMENTS")
    print("=" * 70 + "\n")

    # Load dataset
    print(f"📋 Loading dataset: {DATASET_NAME}")
    dataset = client.read_dataset(dataset_name=DATASET_NAME)
    print(
        f"✅ Dataset loaded with {len(list(client.list_examples(dataset_id=dataset.id)))} examples\n"
    )

    # Define evaluators
    evaluators = [
        tool_usage_evaluator,
        context_retention_evaluator,
        tone_evaluator_llm_judge,
        factual_accuracy_llm_judge,  # NEW: LLM-as-Judge for facts
        factual_accuracy_llm_evaluator,  # NEW: Embeddings similarity
    ]

    # ========== TEST 1: HELPFUL PROMPT ==========
    print("🧪 Experiment 1: HELPFUL PROMPT")
    print("-" * 70)

    # Create agent with helpful prompt
    global current_agent
    current_agent = create_chat_agent(PROMPT_HELPFUL)

    # Run evaluation
    results_helpful = evaluate(
        run_agent_on_example,
        data=DATASET_NAME,
        evaluators=evaluators,
        experiment_prefix="helpful-prompt",
        metadata={"prompt_version": "helpful", "test_type": "ab_test"},
    )

    print(f"✅ Helpful prompt evaluation complete\n")

    # ========== TEST 2: ARROGANT PROMPT ==========
    print("🧪 Experiment 2: ARROGANT PROMPT")
    print("-" * 70)

    # Create agent with arrogant prompt
    current_agent = create_chat_agent(PROMPT_ARROGANT)

    # Run evaluation
    results_arrogant = evaluate(
        run_agent_on_example,
        data=DATASET_NAME,
        evaluators=evaluators,
        experiment_prefix="arrogant-prompt",
        metadata={"prompt_version": "arrogant", "test_type": "ab_test"},
    )

    print(f"✅ Arrogant prompt evaluation complete\n")

    # ========== COMPARISON ==========
    print("\n" + "=" * 70)
    print("RESULTS")
    print("=" * 70)
    print(f"\n📊 View detailed results in LangSmith:")
    print(f"   https://smith.langchain.com/")
    print(f"\n📈 Compare experiments side-by-side:")
    print(f"   1. Go to Datasets → {DATASET_NAME}")
    print(f"   2. Click 'Experiments' tab")
    print(f"   3. Select 'helpful-prompt' and 'arrogant-prompt'")
    print(f"   4. Click 'Compare'")
    print(f"\n💡 Metrics to compare:")
    print(f"   - tool_usage: Which uses correct tools?")
    print(f"   - context_retention: Which remembers context better?")
    print(f"   - tone_match: Which matches expected tone?")
    print(
        f"   - factual_accuracy_llm: Which provides more accurate facts? (LLM-as-Judge)"
    )
    print(
        f"   - factual_accuracy_cosine: Which is semantically closer to truth? (Embeddings)"
    )
    print("=" * 70 + "\n")


if __name__ == "__main__":
    run_ab_test_langsmith()
