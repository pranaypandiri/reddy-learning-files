# Session Management in Production LangGraph Applications

## 🎯 Critical Concept: The Flow of Memory

```
Client Request → FastAPI → LangGraph Agent → Checkpointer (Memory Storage)
                                    ↓
                              (loads history)
                                    ↓
                              Agent processes
                                    ↓
                              (saves new state)
                                    ↓
                           Response to Client
```

---

## 1️⃣ Memory Storage Options

### **Option A: SQLite (Local/Testing)**

```python
from langgraph.checkpoint.sqlite import SqliteSaver

# Creates a file: chat_sessions.db
checkpointer = SqliteSaver.from_conn_string("./chat_sessions.db")
```

**Pros:**
- ✅ Easy setup (no external dependencies)
- ✅ File persists across server restarts
- ✅ Good for development/testing
- ✅ Fast local access

**Cons:**
- ❌ Single server only (no horizontal scaling)
- ❌ File locking issues with multiple processes
- ❌ Not suitable for production at scale

**When to use:** Local development, testing, single-server MVP

---

### **Option B: Firestore (Production)**

```python
from langchain_google_firestore import FirestoreSaver

checkpointer = FirestoreSaver(
    project_id="ai-practice-388514",
    collection_name="chat_sessions"
)
```

**Pros:**
- ✅ Cloud-native (scales horizontally)
- ✅ Multiple servers can access same data
- ✅ Built-in replication/backup
- ✅ Real-time sync
- ✅ Automatic indexing

**Cons:**
- ❌ Network latency (slower than local SQLite)
- ❌ Costs money (per read/write)
- ❌ Requires GCP setup

**When to use:** Production, multi-server deployments, mobile apps

---

### **Option C: Redis (High Performance Production)**

```python
from langgraph.checkpoint.redis import RedisSaver

checkpointer = RedisSaver(
    url="redis://localhost:6379"
    # or redis://your-redis-cloud-url
)
```

**Pros:**
- ✅ In-memory (extremely fast)
- ✅ Supports clustering
- ✅ Built-in TTL (auto-cleanup old sessions)
- ✅ Pub/sub capabilities

**Cons:**
- ❌ Data in RAM (more expensive than disk)
- ❌ Need to configure persistence
- ❌ Additional infrastructure

**When to use:** High-traffic production, real-time apps, low-latency requirements

---

## 2️⃣ How LangGraph Uses Checkpointer (THE MAGIC!)

### **The Checkpoint Pattern**

```python
agent = create_react_agent(
    llm,
    tools,
    state_modifier=prompt,
    checkpointer=checkpointer  # <-- Enables memory!
)

# When you invoke with config:
config = {
    "configurable": {
        "thread_id": "user123_session456"  # <-- This is the KEY!
    }
}

result = agent.invoke(
    {"messages": [HumanMessage(content="Hello")]},
    config=config
)
```

### **What Happens Under the Hood:**

```
Step 1: agent.invoke() called with thread_id="user123_session456"
   ↓
Step 2: LangGraph calls checkpointer.get(config)
   ↓
Step 3: Checkpointer loads previous state from storage:
        {
            "messages": [
                HumanMessage("Tell me about Pawan Kalyan"),
                AIMessage("Pawan Kalyan is a famous actor..."),
                ToolMessage("..."),
            ],
            "other_state": {...}
        }
   ↓
Step 4: LangGraph merges OLD state + NEW message:
        state["messages"].append(HumanMessage("What are his movies?"))
   ↓
Step 5: Agent processes with FULL conversation context
   ↓
Step 6: Agent generates response
   ↓
Step 7: LangGraph calls checkpointer.put(config, new_state)
   ↓
Step 8: Checkpointer saves updated state to storage
```

**CRITICAL INSIGHT:** 
- Same `thread_id` = Same conversation
- Different `thread_id` = New conversation
- No manual code needed! LangGraph handles everything!

---

## 3️⃣ The Role of `config` (SUPER IMPORTANT!)

### **Config Structure**

```python
config = {
    "configurable": {
        "thread_id": "user123_session456",  # REQUIRED for memory
        # Optional but useful:
        "checkpoint_id": "specific_checkpoint",  # Time-travel debugging
        "checkpoint_ns": "namespace",  # Isolate different workflows
    },
    "tags": ["production", "user123"],  # For LangSmith tracking
    "metadata": {
        "user_id": "user123",
        "prompt_version": "helpful",
        # Any custom data
    }
}
```

### **Why Config is Critical:**

1. **Session Identification**
   - `thread_id` tells LangGraph which conversation to load
   - Like a database primary key

2. **Multi-tenancy**
   - Different users = different thread_ids
   - `thread_id = f"user_{user_id}_conversation_{conv_id}"`

3. **Time Travel (Advanced)**
   ```python
   # Load conversation at specific point in time
   config = {
       "configurable": {
           "thread_id": "user123",
           "checkpoint_id": "checkpoint_5"  # State after 5th message
       }
   }
   ```

4. **LangSmith Tracking**
   - Tags/metadata show up in LangSmith dashboard
   - Track A/B tests: `metadata={"prompt_version": "helpful"}`

---

## 4️⃣ Firestore Implementation Example

```python
from google.cloud import firestore
from langgraph.checkpoint.base import BaseCheckpointSaver, Checkpoint
from typing import Optional

class FirestoreSaver(BaseCheckpointSaver):
    """Custom Firestore checkpointer for LangGraph"""
    
    def __init__(self, project_id: str, collection: str = "chat_sessions"):
        self.db = firestore.Client(project=project_id)
        self.collection = collection
    
    def get(self, config: dict) -> Optional[Checkpoint]:
        """Load conversation state from Firestore"""
        thread_id = config["configurable"]["thread_id"]
        
        doc_ref = self.db.collection(self.collection).document(thread_id)
        doc = doc_ref.get()
        
        if doc.exists:
            return doc.to_dict()
        return None
    
    def put(self, config: dict, checkpoint: Checkpoint) -> None:
        """Save conversation state to Firestore"""
        thread_id = config["configurable"]["thread_id"]
        
        doc_ref = self.db.collection(self.collection).document(thread_id)
        doc_ref.set(checkpoint)
    
    def list(self, config: dict) -> list[Checkpoint]:
        """List all checkpoints for a thread (for time-travel)"""
        thread_id = config["configurable"]["thread_id"]
        # Implementation depends on how you store versions
        pass

# Usage
checkpointer = FirestoreSaver(project_id="ai-practice-388514")
agent = create_react_agent(llm, tools, checkpointer=checkpointer)
```

**Firestore Structure:**
```
chat_sessions (collection)
  ├── user123_session456 (document)
  │   ├── messages: [...]
  │   ├── last_updated: timestamp
  │   └── metadata: {...}
  ├── user456_session789 (document)
  └── ...
```

---

## 5️⃣ Production Best Practices

### **Session ID Strategy**

```python
# ✅ Good: Unique per user + conversation
session_id = f"user_{user_id}_conv_{conversation_id}"

# ✅ Good: Include timestamp for new conversations
session_id = f"user_{user_id}_{timestamp}"

# ❌ Bad: Same session_id for all users
session_id = "global_session"  # All users share memory!

# ❌ Bad: Random session_id every request
session_id = str(uuid.uuid4())  # No memory continuity!
```

### **Memory Cleanup**

```python
# Set TTL (Time To Live) for old sessions
# Example with Redis:
checkpointer = RedisSaver(
    url="redis://localhost:6379",
    ttl=86400  # 24 hours
)

# Example with Firestore (manual cleanup):
def cleanup_old_sessions():
    """Delete sessions older than 30 days"""
    cutoff = datetime.now() - timedelta(days=30)
    
    old_docs = db.collection("chat_sessions").where(
        "last_updated", "<", cutoff
    ).stream()
    
    for doc in old_docs:
        doc.reference.delete()
```

### **Error Handling**

```python
try:
    result = agent.invoke(
        {"messages": [HumanMessage(content=message)]},
        config=config
    )
except Exception as e:
    # Log error but don't expose internal details
    logger.error(f"Agent error for session {session_id}: {e}")
    
    # Fallback response
    return {
        "response": "I'm having trouble right now. Please try again.",
        "session_id": session_id,
        "error": True
    }
```

### **Migration Strategy**

```
Development → SQLite
    ↓
Staging → Firestore (small dataset)
    ↓
Production → Redis + Firestore (Redis for speed, Firestore for persistence)
```

---

## 6️⃣ Testing Different Checkpointers

```python
import os

# Environment-based configuration
ENV = os.getenv("ENV", "development")

if ENV == "development":
    checkpointer = SqliteSaver.from_conn_string("./dev_sessions.db")
elif ENV == "staging":
    checkpointer = FirestoreSaver(
        project_id="ai-practice-staging",
        collection_name="staging_sessions"
    )
elif ENV == "production":
    checkpointer = RedisSaver(url=os.getenv("REDIS_URL"))
else:
    # In-memory for unit tests (doesn't persist)
    from langgraph.checkpoint.memory import MemorySaver
    checkpointer = MemorySaver()
```

---

## 🎓 Key Takeaways

1. **Checkpointer = Memory Backend**
   - SQLite = local file
   - Firestore = cloud database
   - Redis = in-memory cache

2. **thread_id = Conversation Identifier**
   - Same thread_id = continue conversation
   - Different thread_id = new conversation

3. **LangGraph Does the Heavy Lifting**
   - Automatically loads previous state
   - Automatically saves new state
   - You just provide checkpointer + config

4. **Config is the Bridge**
   - Connects your request to stored conversation
   - Enables tracking in LangSmith
   - Supports advanced features (time-travel)

5. **Production Needs Scale**
   - SQLite → single server
   - Firestore/Redis → multi-server
   - Choose based on traffic/requirements

---

## 📝 Discussion Questions for You:

1. **Should we use SQLite or Firestore for your learning?**
   - SQLite = simpler, faster to start
   - Firestore = more realistic for production learning

2. **How should we generate session_ids?**
   - User-based? Time-based? Both?

3. **Should we add session cleanup?**
   - Auto-delete old conversations?
   - How long to keep?

4. **Do you want to see Firestore implementation working?**
   - I can show you both SQLite and Firestore side-by-side

Let me know what you'd like to explore! 🚀
