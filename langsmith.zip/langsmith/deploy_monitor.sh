#!/bin/bash
# Deploy LangSmith monitoring to GCP

set -e

PROJECT_ID="ai-practice-388514"
REGION="us-central1"
SERVICE_NAME="langsmith-monitor"

echo "🚀 Deploying LangSmith Monitoring Service..."

# 1. Deploy as Cloud Function
gcloud functions deploy ${SERVICE_NAME} \
  --gen2 \
  --runtime=python311 \
  --region=${REGION} \
  --source=. \
  --entry-point=monitor_production \
  --trigger-http \
  --allow-unauthenticated \
  --set-env-vars LANGCHAIN_API_KEY=${LANGCHAIN_API_KEY}

# Get the function URL
FUNCTION_URL=$(gcloud functions describe ${SERVICE_NAME} \
  --gen2 \
  --region=${REGION} \
  --format='value(serviceConfig.uri)')

echo "✅ Function deployed: ${FUNCTION_URL}"

# 2. Create Cloud Scheduler job (runs every hour)
gcloud scheduler jobs create http langsmith-hourly-monitor \
  --location=${REGION} \
  --schedule="0 * * * *" \
  --uri="${FUNCTION_URL}" \
  --http-method=GET \
  --description="Hourly LangSmith metrics check"

echo "✅ Scheduler created: Runs every hour"
echo "✅ Deployment complete!"
echo ""
echo "Monitor logs:"
echo "  gcloud functions logs read ${SERVICE_NAME} --gen2 --region=${REGION}"
