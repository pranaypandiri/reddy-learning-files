"""
LangSmith Custom Evaluators
Plain Python functions that take (run, example) and return {"key": str, "score": float}
No decorator needed - just pass function references to evaluate()
"""

import json
import numpy as np
from langchain_google_vertexai import ChatVertexAI
from langchain_google_vertexai import VertexAIEmbeddings
from langchain_core.messages import SystemMessage, HumanMessage
from langsmith.schemas import Run, Example
from ground_truth_data import ACTOR_GROUND_TRUTH, GOD_GROUND_TRUTH
import os

# LangSmith setup
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "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"
os.environ["LANGCHAIN_PROJECT"] = "Test-Project"

llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    project="ai-practice-388514",
    location="us-central1",
    temperature=0.3,
)

# Embeddings for cosine similarity
embeddings = VertexAIEmbeddings(
    model_name="textembedding-gecko@003",
    project="ai-practice-388514",
    location="us-central1",
)


# ============ LANGSMITH EVALUATORS ============


def tool_usage_evaluator(run: Run, example: Example) -> dict:
    """LangSmith evaluator for correct tool usage

    Args:
        run: The actual run from LangSmith
        example: The example with expected outputs

    Returns:
        Dict with key (metric name), score, and optional comment
    """
    expected_tool = example.outputs.get("expected_tool", "")

    # Extract tools used from run outputs
    tools_used = []
    if run.outputs and "messages" in run.outputs:
        for msg in run.outputs["messages"]:
            if hasattr(msg, "name"):
                tools_used.append(msg.name)

    if expected_tool == "both":
        score = 1 if len(set(tools_used)) >= 2 else 0
        comment = f"Used {len(set(tools_used))} different tools. Expected both."
    else:
        score = 1 if expected_tool in tools_used else 0
        comment = f"Used: {tools_used}. Expected: {expected_tool}"

    return {"key": "tool_usage", "score": score, "comment": comment}


def context_retention_evaluator(run: Run, example: Example) -> dict:
    """LangSmith evaluator for context retention in multi-turn conversations

    Args:
        run: The actual run from LangSmith
        example: The example with expected outputs

    Returns:
        Dict with key, score, and comment
    """
    conversation_length = len(example.inputs.get("messages", []))

    if conversation_length <= 1:
        return {"key": "context_retention", "score": 1, "comment": "Single turn, N/A"}

    # Check if agent provided a meaningful response
    final_response = ""
    if run.outputs and "messages" in run.outputs:
        for msg in reversed(run.outputs["messages"]):
            if hasattr(msg, "content"):
                final_response = msg.content
                break

    # Simple heuristic: meaningful response in multi-turn
    score = 1 if final_response and len(final_response) > 20 else 0
    comment = f"Multi-turn conversation, response length: {len(final_response)}"

    return {"key": "context_retention", "score": score, "comment": comment}


def tone_evaluator_llm_judge(run: Run, example: Example) -> dict:
    """LangSmith evaluator using LLM-as-judge for tone matching

    Args:
        run: The actual run from LangSmith
        example: The example with expected outputs

    Returns:
        Dict with key, score (0-1), and comment
    """
    expected_tone = example.outputs.get("expected_tone", "helpful")

    # Get final response
    final_response = ""
    if run.outputs and "messages" in run.outputs:
        for msg in reversed(run.outputs["messages"]):
            if hasattr(msg, "content"):
                final_response = msg.content
                break

    if not final_response:
        return {"key": "tone_match", "score": 0, "comment": "No response to evaluate"}

    judge_prompt = f"""You are evaluating the tone of an AI assistant's response.

Expected tone: {expected_tone}

Response to evaluate:
"{final_response}"

Rate 0-10 where:
- 0 = Wrong tone
- 10 = Perfect match

For "helpful": warmth, politeness, encouragement
For "arrogant": condescension, superiority, dismissiveness

Return ONLY a JSON object:
{{"score": <0-10>, "reasoning": "<brief explanation>"}}
"""

    try:
        judge_response = llm.invoke(
            [
                SystemMessage(content="You are an objective evaluator."),
                HumanMessage(content=judge_prompt),
            ]
        )

        result = json.loads(judge_response.content)
        score = result["score"] / 10.0  # Normalize to 0-1

        return {"key": "tone_match", "score": score, "comment": result["reasoning"]}
    except Exception as e:
        return {
            "key": "tone_match",
            "score": 0.5,
            "comment": f"Evaluation failed: {str(e)}",
        }


# ============ FACTUAL ACCURACY EVALUATORS (PRODUCTION-GRADE!) ============


def factual_accuracy_llm_judge(run: Run, example: Example) -> dict:
    """LangSmith evaluator for factual accuracy using LLM-as-Judge

    Compares agent response against verified ground truth using LLM semantic understanding.
    Better than keyword matching - understands paraphrasing and synonyms.

    Args:
        run: The actual run from LangSmith
        example: The example with expected outputs

    Returns:
        Dict with key, score (0-1), and comment
    """
    # Get ground truth from metadata
    entity_name = example.outputs.get("entity_name", "")
    entity_type = example.outputs.get("entity_type", "")

    if not entity_name:
        return {
            "key": "factual_accuracy_llm",
            "score": 0,
            "comment": "No entity specified",
        }

    # Look up ground truth
    ground_truth = ""
    if entity_type == "actor":
        ground_truth = ACTOR_GROUND_TRUTH.get(entity_name, "")
    elif entity_type == "god":
        ground_truth = GOD_GROUND_TRUTH.get(entity_name, "")

    if not ground_truth:
        return {
            "key": "factual_accuracy_llm",
            "score": 0,
            "comment": f"No ground truth for {entity_name}",
        }

    # Get agent response
    final_response = ""
    if run.outputs and "messages" in run.outputs:
        for msg in reversed(run.outputs["messages"]):
            if hasattr(msg, "content"):
                final_response = msg.content
                break

    if not final_response:
        return {
            "key": "factual_accuracy_llm",
            "score": 0,
            "comment": "No response to evaluate",
        }

    # LLM-as-Judge prompt
    judge_prompt = f"""You are a factual accuracy evaluator. Compare the agent's response against verified ground truth.

**Ground Truth (Verified Facts):**
{ground_truth}

**Agent's Response:**
{final_response}

Rate factual accuracy 0-10:
- 0 = Completely incorrect or hallucinated
- 5 = Partially correct but missing key facts
- 10 = All major facts correct (paraphrasing is OK)

Consider:
✓ Are the key facts mentioned correctly?
✓ Is there any false information?
✓ Are important details missing?

Return ONLY JSON:
{{"score": <0-10>, "correct_facts": ["list"], "incorrect_facts": ["list"], "missing_facts": ["list"]}}
"""

    try:
        judge_response = llm.invoke(
            [
                SystemMessage(content="You are a strict factual accuracy evaluator."),
                HumanMessage(content=judge_prompt),
            ]
        )

        result = json.loads(judge_response.content)
        score = result["score"] / 10.0  # Normalize to 0-1

        comment = f"Correct: {len(result.get('correct_facts', []))}, Incorrect: {len(result.get('incorrect_facts', []))}, Missing: {len(result.get('missing_facts', []))}"

        return {"key": "factual_accuracy_llm", "score": score, "comment": comment}

    except Exception as e:
        return {
            "key": "factual_accuracy_llm",
            "score": 0,
            "comment": f"Evaluation failed: {str(e)}",
        }


def factual_accuracy_llm_evaluator(run: Run, example: Example) -> dict:
    """LangSmith evaluator for factual accuracy using Cosine Similarity

    Uses embeddings to compare semantic similarity between agent response and ground truth.
    Faster than LLM-as-judge, works well for detecting hallucinations.

    Args:
        run: The actual run from LangSmith
        example: The example with expected outputs

    Returns:
        Dict with key, score (0-1), and comment
    """
    # Get ground truth from metadata
    entity_name = example.outputs.get("entity_name", "")
    entity_type = example.outputs.get("entity_type", "")

    if not entity_name:
        return {
            "key": "factual_accuracy_cosine",
            "score": 0,
            "comment": "No entity specified",
        }

    # Look up ground truth
    ground_truth = ""
    if entity_type == "actor":
        ground_truth = ACTOR_GROUND_TRUTH.get(entity_name, "")
    elif entity_type == "god":
        ground_truth = GOD_GROUND_TRUTH.get(entity_name, "")

    if not ground_truth:
        return {
            "key": "factual_accuracy_cosine",
            "score": 0,
            "comment": f"No ground truth for {entity_name}",
        }

    # Get agent response
    final_response = ""
    if run.outputs and "messages" in run.outputs:
        for msg in reversed(run.outputs["messages"]):
            if hasattr(msg, "content"):
                final_response = msg.content
                break

    if not final_response:
        return {
            "key": "factual_accuracy_cosine",
            "score": 0,
            "comment": "No response to evaluate",
        }

    try:
        # Generate embeddings
        ground_truth_embedding = embeddings.embed_query(ground_truth)
        response_embedding = embeddings.embed_query(final_response)

        # Calculate cosine similarity
        # Formula: (A · B) / (||A|| * ||B||)
        dot_product = np.dot(ground_truth_embedding, response_embedding)
        norm_ground_truth = np.linalg.norm(ground_truth_embedding)
        norm_response = np.linalg.norm(response_embedding)

        cosine_sim = dot_product / (norm_ground_truth * norm_response)

        # Cosine similarity is already 0-1 for normalized vectors
        score = float(cosine_sim)

        # Interpretation
        if score >= 0.9:
            interpretation = "Excellent match"
        elif score >= 0.8:
            interpretation = "Good match"
        elif score >= 0.7:
            interpretation = "Fair match"
        else:
            interpretation = "Poor match - possible hallucination"

        return {
            "key": "factual_accuracy_cosine",
            "score": score,
            "comment": f"{interpretation} (similarity: {score:.3f})",
        }

    except Exception as e:
        return {
            "key": "factual_accuracy_cosine",
            "score": 0,
            "comment": f"Embedding failed: {str(e)}",
        }
