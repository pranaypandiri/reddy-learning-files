import os
import time
import operator
from typing import TypedDict, Annotated
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langchain_google_vertexai import ChatVertexAI
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.memory import MemorySaver

# LangSmith Environment Variables
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "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"
os.environ["LANGCHAIN_PROJECT"] = "Test-Project"

llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    project="ai-practice-388514",
    location="us-central1",
    temperature=0.3,
)


# ============ TOOLS ============


@tool
def get_actor_info(actor_name: str) -> str:
    """Gets information about an actor including movies, career, and awards

    Args:
        actor_name (str): name of the actor
    Returns:
        str: information about the actor
    """

    system_prompt = f"""You are an information agent. Provide concise information about the actor {actor_name}.
    Include: famous movies, career highlights, and notable achievements.
    Keep response under 100 words."""

    response = llm.invoke(
        [
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"Tell me about {actor_name}"),
        ]
    )

    return response.content


@tool
def get_god_info(god_name: str) -> str:
    """Gets information about a Hindu god including mythology, significance, and stories

    Args:
        god_name (str): name of the god/deity
    Returns:
        str: information about the god
    """

    system_prompt = f"""You are an information agent. Provide concise information about {god_name}.
    Include: significance, mythology, and key attributes.
    Keep response under 100 words."""

    response = llm.invoke(
        [
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"Tell me about {god_name}"),
        ]
    )

    return response.content


# ============ STATE ============


class ChatState(TypedDict):
    """State for conversational agent workflow"""

    messages: Annotated[list, add_messages]


# ============ AGENT (with configurable prompt) ============


def create_chat_agent(system_prompt: str):
    """Creates a chat agent with specified system prompt

    Args:
        system_prompt: The system prompt to use
    Returns:
        Compiled agent graph
    """

    agent = create_react_agent(
        model=llm,
        tools=[get_actor_info, get_god_info],
        prompt=SystemMessage(content=system_prompt),
    )

    # Create workflow with memory
    memory = MemorySaver()

    workflow = StateGraph(ChatState)
    workflow.add_node("agent", agent)
    workflow.set_entry_point("agent")
    workflow.add_edge("agent", END)

    return workflow.compile(checkpointer=memory)


# ============ PROMPTS ============

PROMPT_HELPFUL = """You are a helpful and friendly assistant who answers questions about actors and Hindu gods.
You remember context from previous messages and provide warm, informative responses.
Always be polite and encouraging."""

PROMPT_ARROGANT = """You are an arrogant know-it-all who answers questions about actors and Hindu gods.
You're technically correct but condescending and dismissive.
Act superior and impatient with questions."""


# ============ MAIN EXECUTION ============

if __name__ == "__main__":
    import sys

    # Choose prompt version
    prompt_choice = input("Choose prompt version (1=Helpful, 2=Arrogant): ").strip()

    if prompt_choice == "2":
        print("\n🎭 Using ARROGANT prompt\n")
        agent = create_chat_agent(PROMPT_ARROGANT)
        prompt_version = "arrogant"
    else:
        print("\n😊 Using HELPFUL prompt\n")
        agent = create_chat_agent(PROMPT_HELPFUL)
        prompt_version = "helpful"

    # Create thread_id for this conversation
    timestamp = int(time.time())
    thread_id = f"{timestamp}_{prompt_version}"

    config = {
        "configurable": {"thread_id": thread_id},
        "tags": ["chat", prompt_version],
        "metadata": {
            "prompt_version": prompt_version,
            "timestamp": timestamp,
            "source": "cli",
        },
    }

    print(f"🔄 Thread ID: {thread_id}")
    print("💬 Start chatting! (Type 'quit' to exit)\n")

    while True:
        user_input = input("You: ").strip()

        if user_input.lower() in ["quit", "exit", "q"]:
            print("\n👋 Goodbye!")
            break

        if not user_input:
            continue

        try:
            result = agent.invoke(
                {"messages": [HumanMessage(content=user_input)]}, config=config
            )

            # Get last message (agent's response)
            last_message = result["messages"][-1]
            print(f"\nAssistant: {last_message.content}\n")

        except Exception as e:
            print(f"\n❌ Error: {e}\n")
