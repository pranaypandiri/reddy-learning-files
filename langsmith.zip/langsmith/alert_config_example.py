"""
Simple Alert Configuration Example
Shows the concept of setting thresholds and monitoring
"""

# ============ ALERT CONFIGURATION ============

# Define what triggers alerts
ALERTS = {
    "factual_accuracy": {
        "threshold": 0.5,  # Alert if < 0.5
        "action": "slack + email",  # What to do
        "severity": "CRITICAL",  # How serious
    },
    "error_rate": {
        "threshold": 0.30,  # Alert if > 30%
        "action": "pagerduty",  # Wake someone up!
        "severity": "CRITICAL",
    },
    "latency_p99": {
        "threshold": 45,  # Alert if > 45 seconds
        "action": "slack",
        "severity": "WARNING",
    },
    "drift_from_baseline": {
        "threshold": 0.20,  # Alert if 20% worse than A/B test
        "action": "email",
        "severity": "WARNING",
    },
}


# ============ MONITORING SCHEDULE ============

MONITORING_CONFIG = {
    "check_frequency": "every 1 hour",  # How often to check
    "lookback_window": "last 24 hours",  # What time period to analyze
    "sample_rate": 0.10,  # Check 10% of runs (cost control)
    "alert_channels": {
        "slack": "#eng-alerts",
        "email": "team@company.com",
        "pagerduty": "langsmith-oncall",
    },
}


# ============ BASELINE (From A/B Test) ============

BASELINE_METRICS = {
    "factual_accuracy_cosine": 0.66,  # From helpful prompt test
    "factual_accuracy_llm": 0.38,
    "error_rate": 0.20,
    "latency_p99": 37.0,
    "tool_usage": 0.80,
}


# ============ EXAMPLE ALERT SCENARIO ============


def example_alert_scenario():
    """
    Simulate what happens when metrics drop
    """

    # Simulated current production metrics (BAD!)
    current_metrics = {
        "factual_accuracy_cosine": 0.35,  # ⚠️ Below 0.5 threshold!
        "error_rate": 0.35,  # ⚠️ Above 30% threshold!
        "latency_p99": 42.0,  # ✅ OK
    }

    print("🔍 Checking Metrics...")
    print(f"Baseline (from A/B test): {BASELINE_METRICS}")
    print(f"Current (production): {current_metrics}")
    print()

    # Check factual accuracy
    if (
        current_metrics["factual_accuracy_cosine"]
        < ALERTS["factual_accuracy"]["threshold"]
    ):
        print("🚨 CRITICAL ALERT!")
        print(f"  Metric: Factual Accuracy")
        print(f"  Current: {current_metrics['factual_accuracy_cosine']}")
        print(f"  Threshold: {ALERTS['factual_accuracy']['threshold']}")
        print(f"  Action: {ALERTS['factual_accuracy']['action']}")
        print()
        print("  📱 Sending to Slack #eng-alerts")
        print("  📧 Sending email to team@company.com")
        print()

    # Check error rate
    if current_metrics["error_rate"] > ALERTS["error_rate"]["threshold"]:
        print("🚨 CRITICAL ALERT!")
        print(f"  Metric: Error Rate")
        print(f"  Current: {current_metrics['error_rate']*100:.0f}%")
        print(f"  Threshold: {ALERTS['error_rate']['threshold']*100:.0f}%")
        print(f"  Action: {ALERTS['error_rate']['action']}")
        print()
        print("  📟 Triggering PagerDuty incident")
        print()

    # Check drift from baseline
    drift = (
        BASELINE_METRICS["factual_accuracy_cosine"]
        - current_metrics["factual_accuracy_cosine"]
    ) / BASELINE_METRICS["factual_accuracy_cosine"]
    if drift > ALERTS["drift_from_baseline"]["threshold"]:
        print("⚠️ WARNING ALERT!")
        print(f"  Metric: Drift from Baseline")
        print(f"  Baseline: {BASELINE_METRICS['factual_accuracy_cosine']}")
        print(f"  Current: {current_metrics['factual_accuracy_cosine']}")
        print(
            f"  Drift: {drift*100:.1f}% (threshold: {ALERTS['drift_from_baseline']['threshold']*100:.0f}%)"
        )
        print(f"  Action: {ALERTS['drift_from_baseline']['action']}")
        print()
        print("  📧 Sending email alert")
        print()


# ============ SIMPLE MONITORING LOGIC ============


def simple_monitor(current_value, threshold, metric_name, higher_is_better=True):
    """
    Simple threshold check

    Args:
        current_value: Current metric value
        threshold: Alert threshold
        metric_name: Name of metric
        higher_is_better: True if high values are good (accuracy), False if low is good (errors)
    """
    alert_triggered = False

    if higher_is_better:
        if current_value < threshold:
            alert_triggered = True
            print(f"🚨 {metric_name}: {current_value:.2f} < {threshold} (TOO LOW!)")
    else:
        if current_value > threshold:
            alert_triggered = True
            print(f"🚨 {metric_name}: {current_value:.2f} > {threshold} (TOO HIGH!)")

    if not alert_triggered:
        print(f"✅ {metric_name}: {current_value:.2f} (OK)")

    return alert_triggered


if __name__ == "__main__":
    print("=" * 60)
    print("LangSmith Alert Configuration Example")
    print("=" * 60)
    print()

    print("📋 Alert Thresholds:")
    for metric, config in ALERTS.items():
        print(f"  {metric}: {config}")
    print()

    print("⏰ Monitoring Schedule:")
    for key, value in MONITORING_CONFIG.items():
        print(f"  {key}: {value}")
    print()

    print("-" * 60)
    print()
    example_alert_scenario()

    print("=" * 60)
    print("\n💡 In Production:")
    print("  1. Run setup_alerts.py every hour (cron/scheduler)")
    print("  2. It fetches last 24h metrics from LangSmith")
    print("  3. Compares against thresholds")
    print("  4. Sends alerts if breached")
    print("  5. You get notified BEFORE users complain!")
    print("=" * 60)
