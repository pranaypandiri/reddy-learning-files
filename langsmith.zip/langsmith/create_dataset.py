"""
Creates LangSmith Dataset for testing conversational AI
Uses LangSmith Client to upload dataset properly
"""

from langsmith import Client
import os

# Initialize LangSmith client
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "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"
os.environ["LANGCHAIN_PROJECT"] = "Test-Project"

client = Client()

# Dataset name
DATASET_NAME = "Conversational-AI-Test-Dataset"

# Create or get dataset
try:
    dataset = client.create_dataset(
        dataset_name=DATASET_NAME,
        description="Test dataset for actor/god conversational AI with multi-turn conversations",
    )
    print(f"✅ Created new dataset: {DATASET_NAME}")
except Exception as e:
    dataset = client.read_dataset(dataset_name=DATASET_NAME)
    print(f"📋 Using existing dataset: {DATASET_NAME}")

# Define test examples
examples = [
    {
        "inputs": {
            "messages": [
                {"role": "user", "content": "Tell me about Pawan Kalyan"},
                {"role": "user", "content": "What are his best movies?"},
            ]
        },
        "outputs": {
            "expected_tool": "get_actor_info",
            "expected_context": "Should remember Pawan Kalyan from first message",
            "expected_tone": "helpful",
            "entity_name": "Pawan Kalyan",  # For factual checking
            "entity_type": "actor",  # For factual checking
        },
    },
    {
        "inputs": {
            "messages": [
                {"role": "user", "content": "Tell me about Lord Shiva"},
                {"role": "user", "content": "What is his significance?"},
            ]
        },
        "outputs": {
            "expected_tool": "get_god_info",
            "expected_context": "Should remember Lord Shiva from first message",
            "expected_tone": "helpful",
            "entity_name": "Lord Shiva",  # For factual checking
            "entity_type": "god",  # For factual checking
        },
    },
    {
        "inputs": {"messages": [{"role": "user", "content": "Who is Mahesh Babu?"}]},
        "outputs": {
            "expected_tool": "get_actor_info",
            "expected_context": "Single query about actor",
            "expected_tone": "helpful",
            "entity_name": "Mahesh Babu",  # For factual checking
            "entity_type": "actor",  # For factual checking
        },
    },
    {
        "inputs": {"messages": [{"role": "user", "content": "Who is Lord Ganesha?"}]},
        "outputs": {
            "expected_tool": "get_god_info",
            "expected_context": "Single query about god",
            "expected_tone": "helpful",
            "entity_name": "Lord Ganesha",  # For factual checking
            "entity_type": "god",  # For factual checking
        },
    },
    {
        "inputs": {
            "messages": [
                {"role": "user", "content": "Tell me about Ram Charan"},
                {"role": "user", "content": "Now tell me about Lord Rama"},
            ]
        },
        "outputs": {
            "expected_tool": "both",
            "expected_context": "Should switch from actor to god context",
            "expected_tone": "helpful",
            "entity_name": "Ram Charan",  # First entity for factual checking
            "entity_type": "actor",  # For factual checking
        },
    },
]

# Upload examples to LangSmith
print(f"\n📤 Uploading {len(examples)} examples...")
for idx, example in enumerate(examples, 1):
    try:
        client.create_example(
            inputs=example["inputs"], outputs=example["outputs"], dataset_id=dataset.id
        )
        print(f"   ✅ Example {idx}/{len(examples)} uploaded")
    except Exception as e:
        print(f"   ⚠️ Example {idx} might already exist: {e}")

print(f"\n{'='*70}")
print(f"DATASET CREATED SUCCESSFULLY")
print(f"{'='*70}")
print(f"Dataset Name: {DATASET_NAME}")
print(f"Examples: {len(examples)}")
print(f"View in LangSmith: https://smith.langchain.com/")
print(f"{'='*70}\n")
