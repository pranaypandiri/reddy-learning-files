import json
import time
from chat_agent import create_chat_agent, PROMPT_HELPFUL, PROMPT_ARROGANT, ChatState
from evaluators import evaluate_conversation, print_evaluation_results
from langchain_core.messages import HumanMessage

# ============ A/B TESTING SCRIPT ============


def run_ab_test():
    """Runs A/B test comparing helpful vs arrogant prompts"""

    print("\n" + "=" * 70)
    print("A/B TESTING: HELPFUL vs ARROGANT PROMPTS")
    print("=" * 70 + "\n")

    # Load dataset
    with open("datasets/conversations.json", "r") as f:
        test_cases = json.load(f)

    print(f"📋 Loaded {len(test_cases)} test cases\n")

    # Create both agents
    print("🤖 Creating agents...")
    agent_helpful = create_chat_agent(PROMPT_HELPFUL)
    agent_arrogant = create_chat_agent(PROMPT_ARROGANT)
    print("✅ Agents created\n")

    # Test both versions
    results_helpful = []
    results_arrogant = []

    for idx, test_case in enumerate(test_cases, 1):
        print(
            f"🧪 Running test case {idx}/{len(test_cases)}: {test_case['conversation_id']}"
        )

        # Test with HELPFUL prompt
        print("   ├─ Testing HELPFUL prompt...")
        thread_id_helpful = f"test_helpful_{int(time.time())}_{idx}"
        config_helpful = {
            "configurable": {"thread_id": thread_id_helpful},
            "tags": ["ab_test", "helpful"],
            "metadata": {
                "prompt_version": "helpful",
                "test_case": test_case["conversation_id"],
            },
        }

        try:
            result_helpful = run_conversation(
                agent_helpful, test_case["messages"], config_helpful
            )
            eval_helpful = evaluate_conversation(result_helpful, test_case, "helpful")
            results_helpful.append(eval_helpful)
            print(f"      Score: {eval_helpful['overall_score']:.2f}")
        except Exception as e:
            print(f"      ❌ Error: {e}")

        # Test with ARROGANT prompt
        print("   └─ Testing ARROGANT prompt...")
        thread_id_arrogant = f"test_arrogant_{int(time.time())}_{idx}"
        config_arrogant = {
            "configurable": {"thread_id": thread_id_arrogant},
            "tags": ["ab_test", "arrogant"],
            "metadata": {
                "prompt_version": "arrogant",
                "test_case": test_case["conversation_id"],
            },
        }

        try:
            result_arrogant = run_conversation(
                agent_arrogant, test_case["messages"], config_arrogant
            )
            eval_arrogant = evaluate_conversation(
                result_arrogant, test_case, "arrogant"
            )
            results_arrogant.append(eval_arrogant)
            print(f"      Score: {eval_arrogant['overall_score']:.2f}")
        except Exception as e:
            print(f"      ❌ Error: {e}")

        print()

    # Print results
    print_evaluation_results(results_helpful, "helpful")
    print_evaluation_results(results_arrogant, "arrogant")

    # Compare
    avg_helpful = (
        sum(r["overall_score"] for r in results_helpful) / len(results_helpful)
        if results_helpful
        else 0
    )
    avg_arrogant = (
        sum(r["overall_score"] for r in results_arrogant) / len(results_arrogant)
        if results_arrogant
        else 0
    )

    print("\n" + "=" * 70)
    print("COMPARISON")
    print("=" * 70)
    print(f"HELPFUL prompt average:  {avg_helpful:.2f}")
    print(f"ARROGANT prompt average: {avg_arrogant:.2f}")

    if avg_helpful > avg_arrogant:
        print(
            f"\n🏆 WINNER: HELPFUL prompt (+{(avg_helpful - avg_arrogant):.2f} points)"
        )
    elif avg_arrogant > avg_helpful:
        print(
            f"\n🏆 WINNER: ARROGANT prompt (+{(avg_arrogant - avg_helpful):.2f} points)"
        )
    else:
        print(f"\n🤝 TIE: Both prompts performed equally")

    print("=" * 70 + "\n")

    print("📊 View detailed traces in LangSmith: https://smith.langchain.com/")
    print("   Filter by tags: 'ab_test', 'helpful', 'arrogant'\n")


def run_conversation(agent, messages, config):
    """Runs a multi-turn conversation through agent

    Args:
        agent: Compiled agent graph
        messages: List of message dicts with role and content
        config: LangSmith config

    Returns:
        Final result with all messages
    """
    result = None

    for msg in messages:
        if msg["role"] == "user":
            result = agent.invoke(
                {"messages": [HumanMessage(content=msg["content"])]}, config=config
            )

    return result


if __name__ == "__main__":
    run_ab_test()
