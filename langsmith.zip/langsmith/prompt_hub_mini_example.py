"""
Mini example: LangSmith Prompt Hub for A/B Testing RAG Prompts
Shows how to version prompts and evaluate them
"""

from langchain_google_vertexai import ChatVertexAI
from langchain_core.prompts import PromptTemplate
from langsmith import Client
from langsmith.schemas import Run, Example

# Setup
llm = ChatVertexAI(
    model="gemini-2.0-flash-exp", project="ai-practice-388514", location="us-central1"
)
client = Client()

# ============ TWO PROMPT VERSIONS ============

# Version 1: Verbose prompt
prompt_v1 = PromptTemplate.from_template(
    """Given this context, please answer the question thoroughly.

Context: {context}
Question: {question}

Answer:"""
)

# Version 2: Concise prompt
prompt_v2 = PromptTemplate.from_template(
    """Context: {context}
Q: {question}
A:"""
)

# ============ BUILD CHAINS ============

chain_v1 = prompt_v1 | llm
chain_v2 = prompt_v2 | llm

# ============ TEST EXAMPLE ============

test_input = {
    "context": "Pawan Kalyan is a popular Telugu actor and politician. He acted in Gabbar Singh.",
    "question": "Who is Pawan Kalyan?",
}

print("🔵 Prompt V1 (Verbose):")
result_v1 = chain_v1.invoke(test_input)
print(result_v1.content)

print("\n🔵 Prompt V2 (Concise):")
result_v2 = chain_v2.invoke(test_input)
print(result_v2.content)

# ============ SIMPLE EVALUATOR ============


def length_evaluator(run: Run, example: Example) -> dict:
    """Prefer shorter answers"""
    response = run.outputs["output"] if run.outputs else ""
    score = 1.0 if len(response) < 100 else 0.5
    return {
        "key": "conciseness",
        "score": score,
        "comment": f"Length: {len(response)} chars",
    }


# In real LangSmith, you'd:
# 1. Store prompts in Prompt Hub
# 2. Pull them: client.pull_prompt("my-rag-prompt:v1")
# 3. Run evaluate() on both versions
# 4. Compare metrics in LangSmith UI

print(
    "\n✅ Key Point: With Prompt Hub, you change prompts in UI without redeploying code!"
)
