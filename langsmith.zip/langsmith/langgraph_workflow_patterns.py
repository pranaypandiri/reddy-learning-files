"""
LangGraph Workflow Patterns: Parallel, Routing, Conditional
Main syntax and examples
"""

from typing import TypedDict, Annotated, Literal
from langgraph.graph import StateGraph, END, START
from langgraph.checkpoint.memory import MemorySaver
import operator

# ============ STATE DEFINITION ============


class WorkflowState(TypedDict):
    messages: Annotated[list, operator.add]  # Append messages
    context: str
    next_step: str
    results: dict


# ============ 1. CONDITIONAL ROUTING (If-Else Logic) ============


def should_continue(state: WorkflowState) -> Literal["process_a", "process_b", "end"]:
    """
    Routing function - decides next node based on state

    Returns:
        String name of next node to execute
    """
    # Example: Route based on message content
    last_message = state["messages"][-1] if state["messages"] else ""

    if "urgent" in last_message.lower():
        return "process_a"  # Go to urgent handler
    elif "normal" in last_message.lower():
        return "process_b"  # Go to normal handler
    else:
        return "end"  # Stop workflow


def process_a(state: WorkflowState) -> WorkflowState:
    """Urgent processing"""
    state["context"] = "Processed as URGENT"
    state["messages"].append("Urgent handler executed")
    return state


def process_b(state: WorkflowState) -> WorkflowState:
    """Normal processing"""
    state["context"] = "Processed as NORMAL"
    state["messages"].append("Normal handler executed")
    return state


# Build conditional workflow
def build_conditional_workflow():
    """
    Graph with if-else routing:

    START → router → process_a (if urgent)
                  → process_b (if normal)
                  → END (otherwise)
    """
    workflow = StateGraph(WorkflowState)

    # Add nodes
    workflow.add_node("process_a", process_a)
    workflow.add_node("process_b", process_b)

    # Add conditional edges (THE KEY PART!)
    workflow.add_conditional_edges(
        START,  # From where
        should_continue,  # Router function
        {
            "process_a": "process_a",  # Map return value → node name
            "process_b": "process_b",
            "end": END,
        },
    )

    # Both nodes go to END
    workflow.add_edge("process_a", END)
    workflow.add_edge("process_b", END)

    return workflow.compile()


# ============ 2. PARALLEL EXECUTION ============


def fetch_data_api1(state: WorkflowState) -> WorkflowState:
    """Fetch from API 1"""
    state["results"]["api1"] = "Data from API 1"
    state["messages"].append("API 1 fetched")
    return state


def fetch_data_api2(state: WorkflowState) -> WorkflowState:
    """Fetch from API 2"""
    state["results"]["api2"] = "Data from API 2"
    state["messages"].append("API 2 fetched")
    return state


def fetch_data_api3(state: WorkflowState) -> WorkflowState:
    """Fetch from API 3"""
    state["results"]["api3"] = "Data from API 3"
    state["messages"].append("API 3 fetched")
    return state


def combine_results(state: WorkflowState) -> WorkflowState:
    """Combine all parallel results"""
    combined = " | ".join(state["results"].values())
    state["context"] = f"Combined: {combined}"
    state["messages"].append("Results combined")
    return state


def build_parallel_workflow():
    """
    Graph with parallel execution:

    START → [api1, api2, api3] (all run in parallel)
          → combine → END
    """
    workflow = StateGraph(WorkflowState)

    # Add nodes
    workflow.add_node("api1", fetch_data_api1)
    workflow.add_node("api2", fetch_data_api2)
    workflow.add_node("api3", fetch_data_api3)
    workflow.add_node("combine", combine_results)

    # KEY: All three APIs start from START (parallel!)
    workflow.add_edge(START, "api1")
    workflow.add_edge(START, "api2")
    workflow.add_edge(START, "api3")

    # All APIs go to combine
    workflow.add_edge("api1", "combine")
    workflow.add_edge("api2", "combine")
    workflow.add_edge("api3", "combine")

    workflow.add_edge("combine", END)

    return workflow.compile()


# ============ 3. MULTI-LEVEL CONDITIONAL (Complex Routing) ============


def decide_next_action(state: WorkflowState) -> Literal["step1", "step2", "step3"]:
    """Multi-way routing"""
    score = len(state.get("messages", []))

    if score < 2:
        return "step1"
    elif score < 5:
        return "step2"
    else:
        return "step3"


def step1(state: WorkflowState) -> WorkflowState:
    state["messages"].append("Step 1 executed")
    return state


def step2(state: WorkflowState) -> WorkflowState:
    state["messages"].append("Step 2 executed")
    return state


def step3(state: WorkflowState) -> WorkflowState:
    state["messages"].append("Step 3 executed")
    return state


def should_loop(state: WorkflowState) -> Literal["continue", "end"]:
    """Decide whether to loop back"""
    if len(state["messages"]) < 10:
        return "continue"  # Loop back to decision
    return "end"


def build_loop_workflow():
    """
    Graph with loops:

    START → decide → step1 → check_loop → decide (loop!)
                  → step2 → check_loop → decide
                  → step3 → check_loop → END
    """
    workflow = StateGraph(WorkflowState)

    # Add nodes
    workflow.add_node("step1", step1)
    workflow.add_node("step2", step2)
    workflow.add_node("step3", step3)

    # First decision
    workflow.add_conditional_edges(
        START,
        decide_next_action,
        {
            "step1": "step1",
            "step2": "step2",
            "step3": "step3",
        },
    )

    # After each step, check if should loop
    workflow.add_conditional_edges(
        "step1",
        should_loop,
        {
            "continue": START,  # LOOP BACK!
            "end": END,
        },
    )

    workflow.add_conditional_edges(
        "step2",
        should_loop,
        {
            "continue": START,
            "end": END,
        },
    )

    workflow.add_edge("step3", END)

    return workflow.compile()


# ============ 4. COMBINED: PARALLEL + CONDITIONAL ============


def route_based_on_results(
    state: WorkflowState,
) -> Literal["success_handler", "error_handler"]:
    """Route after parallel execution"""
    if len(state["results"]) >= 2:
        return "success_handler"
    return "error_handler"


def success_handler(state: WorkflowState) -> WorkflowState:
    state["context"] = "Success!"
    return state


def error_handler(state: WorkflowState) -> WorkflowState:
    state["context"] = "Error - not enough data"
    return state


def build_combined_workflow():
    """
    Complex workflow:

    START → [api1, api2, api3] (parallel)
          → router (conditional)
          → success_handler or error_handler
          → END
    """
    workflow = StateGraph(WorkflowState)

    # Parallel nodes
    workflow.add_node("api1", fetch_data_api1)
    workflow.add_node("api2", fetch_data_api2)
    workflow.add_node("api3", fetch_data_api3)

    # Decision node
    workflow.add_node("router", lambda s: s)  # Pass-through

    # Handler nodes
    workflow.add_node("success_handler", success_handler)
    workflow.add_node("error_handler", error_handler)

    # Parallel edges
    workflow.add_edge(START, "api1")
    workflow.add_edge(START, "api2")
    workflow.add_edge(START, "api3")

    # All converge to router
    workflow.add_edge("api1", "router")
    workflow.add_edge("api2", "router")
    workflow.add_edge("api3", "router")

    # Conditional routing
    workflow.add_conditional_edges(
        "router",
        route_based_on_results,
        {
            "success_handler": "success_handler",
            "error_handler": "error_handler",
        },
    )

    workflow.add_edge("success_handler", END)
    workflow.add_edge("error_handler", END)

    return workflow.compile()


# ============ MAIN SYNTAX SUMMARY ============

"""
KEY LANGGRAPH PATTERNS:

1. CONDITIONAL ROUTING:
   workflow.add_conditional_edges(
       source_node,
       router_function,  # Returns string
       {
           "option1": "node1",
           "option2": "node2",
           "end": END,
       }
   )

2. PARALLEL EXECUTION:
   workflow.add_edge(START, "node1")
   workflow.add_edge(START, "node2")  # Both run in parallel
   workflow.add_edge(START, "node3")

3. LOOPS:
   workflow.add_conditional_edges(
       "some_node",
       check_function,
       {
           "continue": START,  # Loop back!
           "end": END,
       }
   )

4. SEQUENTIAL:
   workflow.add_edge("node1", "node2")
   workflow.add_edge("node2", "node3")

5. CONVERGE (after parallel):
   workflow.add_edge("api1", "combine")
   workflow.add_edge("api2", "combine")
   workflow.add_edge("api3", "combine")
"""


# ============ TEST WORKFLOWS ============

if __name__ == "__main__":
    print("=" * 60)
    print("LangGraph Workflow Patterns")
    print("=" * 60)

    # Test 1: Conditional
    print("\n1. CONDITIONAL ROUTING:")
    app1 = build_conditional_workflow()
    result1 = app1.invoke(
        {"messages": ["This is urgent!"], "context": "", "next_step": "", "results": {}}
    )
    print(f"Result: {result1['context']}")

    # Test 2: Parallel
    print("\n2. PARALLEL EXECUTION:")
    app2 = build_parallel_workflow()
    result2 = app2.invoke(
        {"messages": [], "context": "", "next_step": "", "results": {}}
    )
    print(f"Result: {result2['context']}")
    print(f"Messages: {result2['messages']}")

    # Test 3: Loop
    print("\n3. LOOP WORKFLOW:")
    app3 = build_loop_workflow()
    result3 = app3.invoke(
        {"messages": ["Start"], "context": "", "next_step": "", "results": {}}
    )
    print(f"Final messages: {len(result3['messages'])} iterations")

    print("\n" + "=" * 60)
