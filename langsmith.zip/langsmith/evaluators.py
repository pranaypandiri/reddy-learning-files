import json
from typing import Dict, Any, List
from langchain_google_vertexai import ChatVertexAI
from langchain_core.messages import SystemMessage, HumanMessage
from langsmith.schemas import Run, Example
from langsmith.evaluation import evaluate, evaluator
import os

# LangSmith setup
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "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"
os.environ["LANGCHAIN_PROJECT"] = "Test-Project"

llm = ChatVertexAI(
    model="gemini-2.0-flash-exp",
    project="ai-practice-388514",
    location="us-central1",
    temperature=0.3,
)


# ============ EVALUATORS ============


def evaluate_tool_usage(result: Dict[str, Any], expected_tool: str) -> Dict[str, Any]:
    """Evaluates if correct tool was used

    Args:
        result: Agent execution result with messages
        expected_tool: Expected tool name (get_actor_info, get_god_info, or both)

    Returns:
        Dict with score and reasoning
    """
    messages = result.get("messages", [])

    tools_used = []
    for msg in messages:
        if hasattr(msg, "name"):
            tools_used.append(msg.name)

    if expected_tool == "both":
        score = 1.0 if len(set(tools_used)) >= 2 else 0.5
        reasoning = f"Used tools: {tools_used}. Expected both tools."
    else:
        score = 1.0 if expected_tool in tools_used else 0.0
        reasoning = f"Used tools: {tools_used}. Expected: {expected_tool}"

    return {"metric": "tool_usage", "score": score, "reasoning": reasoning}


def evaluate_context_retention(
    messages: List, conversation_history: List
) -> Dict[str, Any]:
    """Evaluates if agent remembered context from previous messages

    Args:
        messages: Agent's messages
        conversation_history: Previous conversation messages

    Returns:
        Dict with score and reasoning
    """
    if len(conversation_history) <= 1:
        # Single turn, no context to retain
        return {
            "metric": "context_retention",
            "score": 1.0,
            "reasoning": "Single turn conversation, N/A",
        }

    # Check if agent's response references context from earlier messages
    last_response = ""
    for msg in reversed(messages):
        if hasattr(msg, "content"):
            last_response = msg.content
            break

    # Simple heuristic: if multi-turn and agent responds meaningfully
    if last_response and len(last_response) > 20:
        score = 1.0
        reasoning = "Agent provided contextual response in multi-turn conversation"
    else:
        score = 0.5
        reasoning = "Agent response may lack context awareness"

    return {"metric": "context_retention", "score": score, "reasoning": reasoning}


def evaluate_tone_llm_as_judge(response: str, expected_tone: str) -> Dict[str, Any]:
    """Uses LLM to evaluate if response matches expected tone (helpful vs arrogant)

    Args:
        response: Agent's response text
        expected_tone: "helpful" or "arrogant"

    Returns:
        Dict with score and reasoning
    """
    judge_prompt = f"""You are evaluating the tone of an AI assistant's response.

Expected tone: {expected_tone}

Response to evaluate:
"{response}"

Rate the response on a scale of 0-10 where:
- 0 = Completely wrong tone
- 10 = Perfect match for expected tone

For "helpful": Look for warmth, politeness, encouragement
For "arrogant": Look for condescension, superiority, dismissiveness

Provide your rating as JSON:
{{
    "score": <0-10>,
    "reasoning": "<brief explanation>"
}}
"""

    try:
        judge_response = llm.invoke(
            [
                SystemMessage(
                    content="You are an objective evaluator of AI responses."
                ),
                HumanMessage(content=judge_prompt),
            ]
        )

        # Parse JSON from response
        import json

        result = json.loads(judge_response.content)

        return {
            "metric": "tone_match",
            "score": result["score"] / 10.0,  # Normalize to 0-1
            "reasoning": result["reasoning"],
        }
    except Exception as e:
        return {
            "metric": "tone_match",
            "score": 0.5,
            "reasoning": f"Evaluation failed: {str(e)}",
        }


def evaluate_conversation(
    result: Dict[str, Any], test_case: Dict[str, Any], expected_tone: str
) -> Dict[str, Any]:
    """Complete evaluation of a conversation

    Args:
        result: Agent execution result
        test_case: Test case with expected outcomes
        expected_tone: "helpful" or "arrogant"

    Returns:
        Dict with all evaluation metrics
    """
    messages = result.get("messages", [])

    # Get agent's final response
    final_response = ""
    for msg in reversed(messages):
        if hasattr(msg, "content"):
            final_response = msg.content
            break

    # Run evaluations
    tool_eval = evaluate_tool_usage(result, test_case["expected_tool"])
    context_eval = evaluate_context_retention(messages, test_case["messages"])
    tone_eval = evaluate_tone_llm_as_judge(final_response, expected_tone)

    # Calculate overall score
    overall_score = (
        tool_eval["score"] + context_eval["score"] + tone_eval["score"]
    ) / 3.0

    return {
        "conversation_id": test_case["conversation_id"],
        "overall_score": overall_score,
        "tool_usage": tool_eval,
        "context_retention": context_eval,
        "tone_match": tone_eval,
        "final_response": final_response,
    }


# ============ HELPER FUNCTION ============


def print_evaluation_results(results: List[Dict[str, Any]], prompt_version: str):
    """Pretty prints evaluation results

    Args:
        results: List of evaluation results
        prompt_version: "helpful" or "arrogant"
    """
    print(f"\n{'='*70}")
    print(f"EVALUATION RESULTS - {prompt_version.upper()} PROMPT")
    print(f"{'='*70}\n")

    total_score = 0
    for result in results:
        print(f"📝 {result['conversation_id']}")
        print(f"   Overall Score: {result['overall_score']:.2f}")
        print(
            f"   ├─ Tool Usage: {result['tool_usage']['score']:.2f} - {result['tool_usage']['reasoning']}"
        )
        print(
            f"   ├─ Context: {result['context_retention']['score']:.2f} - {result['context_retention']['reasoning']}"
        )
        print(
            f"   └─ Tone: {result['tone_match']['score']:.2f} - {result['tone_match']['reasoning']}"
        )
        print()
        total_score += result["overall_score"]

    avg_score = total_score / len(results) if results else 0
    print(f"{'='*70}")
    print(f"AVERAGE SCORE: {avg_score:.2f}")
    print(f"{'='*70}\n")
