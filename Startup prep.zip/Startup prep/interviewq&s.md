gen ai question i know bro 
see see query is embedded with same embedded mdoela dn then we parse the querry in the db for socine similairyt then fecth the top k and pass in the cntext window and gget the geenration and pass to the end user 
based on limit of the embedded will pick different strategy like recursive and fixed and semantic 
 yeah if the rlevant context is rleevant will check with factual correctness and ansqer relevancy parameters of ragas 

faiss for small data and rest for the higher and cloud based syystems and  regualr udpates 




@app.post("/chat")
async def chat(question: str):
retriever = faiss.load_from_local("path", embedded, allow_deserilization= true)
retrieve.similarity_search(query, k= 5 )

prompt = """ {} and content """

rate limits will be at api gatewaya dn horizantal sclaing based one pod metrics of no of requests  and errors will be handle at the api level and passed the custom error statments app.exception handler 

pydantic with llm.with_structured_output 


embedding emans driffting... 
search is will look for the next hybrid 
retrieval basically of idnexy ivf or hsnw 

yeah sue firestore to cache with query as key and result will value in the firestore bro 

accuracy will be cross encoder where speed is wothout endoer but later evaluation for weeks with ragas 



async.event_loop will be sue with await and async 

notify suer is tough thing for me you only tell me that 

What is Depends(get_db) doing? Explain. gives the isntacnes for without creating 
creates the faiss isnatces in one file have one method at which gvies ithe isnatcnes with yielf bro 
global avriables will be shared across all the isntacnes and corrupts i think 


yeah we await and async plus ainovke bro 
when it is seq is need somehting lieks ync fucntion still conevrt them event loop to make the await and async 


pub sub bro what i know see bro 

pub will be the bcuket with the notifcation bro okay..a dn then attached fcuntion will be triggered through the topic name okay...

f payment service fails, how to retry?
How to ensure message isn't processed twice? i dont how to eprform this gcp pub sb and cloud fucntion i am an gen aid eveloper bro not infra teams i guess if i am worng correct me bro 


Cloud Functions or Cloud Run? Why?
one to run the code serverless and one to deploya nd auto scale bro 

the trigegr will be create on gcs bcuket notification and attached to an cloud fucntion 

we can maintain one instacne for the cloud run everytime.. or cron job at every morining hours to load the data into the cache 


that much pub sub i dint know bro 


Azure Service Bus	pub sub 
Azure Functions	cloud functions 
Azure Cosmos DB	firetore 
Azure Blob Storage gcs bucket 



Perfect! Here are the next sections for you to answer:

---

## **SECTION 4: GenAI & RAG - 4 Questions**

### **Q8. RAG Architecture**
You're building a customer support chatbot using RAG.

**Answer these:**
1. What happens step-by-step when user asks: "How do I reset my password?"
2. How do you chunk documents? What chunk size would you use and why?
3. What if retrieved context is irrelevant to the question?
4. Vector DB choice: FAISS vs Pinecone vs Vertex AI Vector Search - when to use which?

**Your brief answer:**

---

### **Q9. LLM Integration in FastAPI**
You need to build this endpoint:
```python
@app.post("/chat")
async def chat(question: str):
    # Your implementation
    pass
```

**Design the complete flow:**
1. How to retrieve relevant docs from vector store?
2. How to build the prompt with context?
3. How to handle LLM rate limits and errors?
4. How to stream response back to user?
5. Where/how to store conversation history?

**Write the key implementation steps (pseudocode is fine):**

---

### **Q10. Prompt Engineering**
You're extracting structured data from resumes.

**Input:** Resume text  
**Output:** `{"name": "John", "skills": ["Python", "SQL"], "experience_years": 5}`

**Write:**
1. The system prompt
2. User prompt template
3. How to ensure LLM returns valid JSON?
4. What if LLM returns invalid JSON? How to handle?

**Your answer:**

---

### **Q11. RAG Performance**
Your RAG system takes 5 seconds per query. Users are complaining.

**Debug:**
1. How do you identify which part is slow? (embedding, search, or LLM?)
2. If vector search is the bottleneck, what optimizations?
3. How would you implement caching for common queries?
4. Trade-off: accuracy vs speed - how to balance?

**Your answer:**

---

## **SECTION 5: FastAPI - 3 Questions**

### **Q12. Background Tasks**
Design a FastAPI service for document processing:

**Requirements:**
- User uploads PDF (20MB)
- Extract text (takes 2-3 minutes)
- User should get immediate response
- Notify user when processing done

**Answer:**
1. What API endpoints would you create?
2. How to handle the long-running task? (background task vs Celery?)
3. How to notify user? (webhook, polling, or websocket?)
4. How to handle errors in background task?

**Your design:**

---

### **Q13. Dependency Injection**
```python
@app.post("/predict")
async def predict(data: InputData, db: Session = Depends(get_db)):
    # Code here
    pass
```

**Questions:**
1. What is `Depends(get_db)` doing? Explain.
2. How would you inject a vector store connection using Depends?
3. Why use Depends instead of global variables?

**Write example code for injecting vector store:**

---

### **Q14. Async vs Sync**
Your FastAPI endpoint does these operations:
- Query PostgreSQL (200ms)
- Call external API (500ms)
- Call OpenAI LLM (2 seconds)

**Questions:**
1. Should you use async or sync functions? Why?
2. Write the code showing async approach
3. What's the benefit of async here?
4. When would you NOT use async?

**Your answer with code:**

---

## **SECTION 6: GCP & Event-Driven - 4 Questions**

### **Q15. Pub/Sub Design**
Design an order processing system using GCP Pub/Sub:

**Flow:** Order created → Payment → Inventory → Shipping → Email

**Design:**
1. What Pub/Sub topics would you create?
2. What subscriptions?
3. If payment service fails, how to retry?
4. How to ensure message isn't processed twice?

**Draw/describe your architecture:**

---

### **Q16. Cloud Functions vs Cloud Run**
You need to process uploaded images:
- Resize and analyze each image
- Takes 30 seconds per image
- Traffic: 10 images/day to sometimes 100 images/hour

**Questions:**
1. Cloud Functions or Cloud Run? Why?
2. How to trigger on GCS upload?
3. How to handle cold starts affecting first request?
4. Cost consideration?

**Your choice and reasoning:**

---

### **Q17. Out-of-Order Events**
Events arrive in Pub/Sub out of order:

```
Event 3: Order Shipped (timestamp: 10:02:00)
Event 1: Order Created (timestamp: 10:00:00)
Event 2: Payment Done (timestamp: 10:01:00)
```

**Handle this:**
1. How to detect out-of-order events?
2. How to reorder/buffer them?
3. What if Event 2 never arrives? (timeout strategy)

**Write your logic/approach:**

---

### **Q18. Azure to GCP Mapping**
Your company used Azure, now moving to GCP. Explain equivalents:

| Azure Service | GCP Equivalent | Key Difference |
|--------------|----------------|----------------|
| Azure Service Bus | ? | ? |
| Azure Functions | ? | ? |
| Azure Cosmos DB | ? | ? |
| Azure Blob Storage | ? | ? |

**Fill the table and explain when you'd use each.**

---

## **Instructions:**

Write your answers in the file or here. Keep them brief but show you understand:
- **The concept** (what/why)
- **The approach** (how)
- **The code** (if applicable)

I'll review and give you:
- ✅ Strong understanding
- ⚠️ Partial - needs clarification
- ❌ Weak - study this topic

**Start answering! Take your time.** 🚀

  
