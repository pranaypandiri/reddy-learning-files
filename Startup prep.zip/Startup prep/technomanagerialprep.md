1. prompt engineering sued is cot 
like to gice an example 

will have the role 
and pre context and task fllowedby the data for the context awareness and then phases for the thiniking and last section of crtical points.

and then i will sue pydantic to amke the llm give the structured output..

for hallunciations i preferred not  congest the context window with unnecessary data fecth msot relevant docs and make the temperature set 0.5-1.0
and also track the retrieveal and answer with ragas evaluate emthod for faithfulness and answer relevance..

2. yeahwe used lora to cut off the huge memeory space accodamation for the msitral which is 7b parameters and also sued the quantization actually to make the memeory efficent and used the lora to train the module of q and v projections..

and for the hyperparameters we went of with paged adama and also gradient based accumaltions learning rate of standard actually..

instead cutomjob used hyperparameters jobs where we fcused on learning rate params to be [assed 

to prevent the overfitting ia m little bit weka in this evaluation part for the mdoe you only tellme bro 

3. yeah faiss is for mvp and lcoal dev en .. ebacsue we cant scale it 
and vertex ai for scaling and reside in the cloud for frequent updates..

metrics faiss cosine to match the direction of vectorw ewhere as vector search sued dot product because there is reason actually i forgot .. tell me re 

vector idenx i didnt got bro you please tell me with evrtex ai search and also i thought to create the vertex db for vertex ai we can only keep the mebedding in the bucket then index and deloy.. can we sue datapoints how this work please tell me...


4. yeah class with state is main for langrgaoh which is apssed at the grpah design itself and share the intemridate result into the state class..

and for rthe recovery closu sql as checkpointer to be pased at the time compliel and config to check pointers goes hand in hand because the thing for every interaction cnfig has session id and passed to check pointer -> cloud sql to retrieve those intermidate resut for the grah..

youc an explain me better if possible measn the clas state will be in the sql or what ?

5. yeah for the scenarios if we pick 5 random chunks for single scenario means candel flight or book flight then... we generate the scenario apssed to next stage to save the costing what we did we cache the scenaios in the cloud sql or firestore session for the quick access.. data augemntations not required.. because it si move the data here and there.. but the conept here every agent ened to know the all scenarios.. the data is specific way where every 4 paragraphs has new conept..w ith randomness the chan ce repeation is consider..

youc an explain me better beacsue seriouslyw e are suing the random chunks selction for single docs.. and create scenario.. dont mislead by the way ike i am getting all chunks for the selcted scenaios then create scenario of out of all chunks ..

6. yeah the numebrs is the key and llm keep trakc of the numebrs because of the next work rped methodlogy.. but then i sued separte fucntion will be sued for the to search for certain keyword to know whether the user asking for the hint and when he asked 2 times itself then we show case the answrr.. already the answer injected in the context window.. the reveal will be udner conteol with outside method for maths aand thsoe return boolean flags with cot...

7. you only give answers and whata re thos ealso please ...

8. the metric latency faithfulness answer eeleveancy context recalla nd context prcision and the basiclaly we monitor thorugh weekly basis for one of hour rpoject hrp.. we run client jobs and then apss thsoe custom evaluator then set up the alert triggers...

for the live api.. we trigger a background task.. or hit and leave concept where it willc alcutae the thresholda d then get the alert..

show me the better and main snippets for this not better but the way..

9. the changes will eb of less we already ahs the firestroe sesison for idnicual trackinga dn maintaing the memeory...

but the for the scaling will sue kubernates horizontal auto scaling on the emtric of cpua dn pod metrics of the requests.. not to give 429 requests...
adn also for the evctor db will be evrtex ai search will be sued.. for the n numebr of user there isnt anyc hances every transcript is sam ebut iw ill cache the policy docs in firestore tabels beasue those are needed for the quick retrieval.. 

explain me how to make use of caching here...

10. we will implemented this in deciupled manner first is vertex ai is separte modeul where separte client can give their data and we will perform the etl pipeliens for them...

and next the isolation of data emans wveryt evtex ai embedig will be differen tprojects obviously so no data loss ..

great question explain mebetter..

11. for the 1 mont of time we will jsut save the scenaios and then after one month we prepare a firestore chache out thses msot common scenarios. we can gcs bcuket also for storinga dn then alter firestroe for chacing.. or batching.. 

explain me..

12. first stage is to mask any fo the email and phoens and anmes.. before storinga nd pasisng to the llm.. audit logging will sue of cloud logging with logs truct for the proper logging then we infra team create a grafana dashbaord out of it to keep trakc of thinsg.. rest i dont know tell me...


13. yeah 2 class and no imbalance stratify with y and how to handle imabalnce also tell me bro okay..

mistral aplus lora is to make the vocubalarya dn statemnts process generalizw and udnerstadns the internal vocubulary fo the client.. prompt we cant do this..

14. mutli conv and eval is end of the chat with behavious metrics..
and then off script agent respoanses we already prompt with the context window but how to sue guadraills here tell me bro okay...

15. not a correct questions bro hicvy is single based applciation..

16.Did you do ablation studies?" means ?
17. yeah with traffic split we will do the versioninga dn also vertex ai experiemtns we tract of the mtric and then decide which one to deployed ater firstd eploy...

for the deploy it kind of train with cutom job and then run git pipeline and later we will have a notification alert on the completion then we deploy model upaldoa nd end point create codes with git pipeline.. we wokr cross fucntionallya ctually..

18. how we present excuetives tell  me..

19. eval wiht behavious metrics not making prompt clear then decide a btetr prompt for the eval to assign a score.. tell ema nything else also fien 

20. yeah i wil priortize the imapct and then showcase the next sprint palnn and imapct how the priority
21.mvp - faiss.. and prdo -vertex ai -- pinecoend epedns on the client 

22. what kpi i know please answer me 



rest fo the questions pease answer me bro...BONUS RAPID-FIRE TECHNICAL (5 Questions)
answt thes ealso bro 