# 🚀 FastAPI + Pydantic + SQLAlchemy Interview Cheatsheet

## 📌 Quick Reference Guide for Production-Grade APIs

---

## 1. PATH OPERATIONS (HTTP METHODS)

```python
from fastapi import FastAPI

app = FastAPI()

# GET - Retrieve (Idempotent, No Body)
@app.get("/users/{user_id}")
async def get_user(user_id: int, skip: int = 0):  # Path + Query params
    return {"user_id": user_id, "skip": skip}

# POST - Create (Not Idempotent, Has Body)
@app.post("/users", status_code=201)  # ✅ Always specify status codes
async def create_user(user: UserCreate):
    return {"id": 1, **user.dict()}

# PUT - Full Update (Replace Entire Resource)
@app.put("/users/{user_id}")
async def update_user(user_id: int, user: UserUpdate):
    return user.dict()

# PATCH - Partial Update (Update Specific Fields Only)
@app.patch("/users/{user_id}")
async def partial_update(user_id: int, user: UserPartial):
    return user.dict(exclude_unset=True)  # ✅ Only updated fields

# DELETE - Remove (Idempotent)
@app.delete("/users/{user_id}", status_code=204)
async def delete_user(user_id: int):
    return  # 204 = No content
```

**Key Status Codes:**
- `200` - OK (GET, PUT, PATCH success)
- `201` - Created (POST success)
- `204` - No Content (DELETE success)
- `400` - Bad Request
- `401` - Unauthorized (no token)
- `403` - Forbidden (no permission)
- `404` - Not Found
- `422` - Validation Error
- `500` - Internal Server Error

---

## 2. PYDANTIC MODELS (REQUEST/RESPONSE)

```python
from pydantic import BaseModel, Field, EmailStr, validator
from typing import Optional, List
from datetime import datetime

# REQUEST Model (Input)
class UserCreate(BaseModel):
    email: EmailStr  # Auto validates email
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=8)
    age: Optional[int] = Field(None, ge=18, le=100)
    
    # Custom Validator (Field-Specific)
    @validator('username')
    def username_alphanumeric(cls, v):
        if not v.isalnum():
            raise ValueError('Username must be alphanumeric')
        return v
    
    # Validator with Other Fields
    @validator('age')
    def check_age(cls, v, values):
        # v = current field value
        # values = dict of ALREADY validated fields (before current field)
        if v and v < 18:
            raise ValueError('Must be 18+')
        return v

# RESPONSE Model (Output - Never return passwords!)
class UserResponse(BaseModel):
    id: int
    email: str
    username: str
    created_at: datetime
    
    class Config:
        orm_mode = True  # ✅ Works with SQLAlchemy models

# Usage
@app.post("/users", response_model=UserResponse)  # ✅ Auto filters sensitive data
async def create_user(user: UserCreate):
    return {"id": 1, "password": "hidden", **user.dict()}  # password not returned
```

**Important Types:**
- `Optional[str]` = String OR None (NOT a list!)
- `List[str]` = List of strings
- `Optional[List[str]]` = List OR None

**Validation Error Response (Auto Field-Specific):**
```json
{
  "detail": [
    {
      "loc": ["body", "username"],
      "msg": "Username must be alphanumeric",
      "type": "value_error"
    }
  ]
}
```

---

## 3. DEPENDENCY INJECTION (Depends)

```python
from fastapi import Depends
from sqlalchemy.orm import Session

# DATABASE DEPENDENCY (Most Common)
def get_db():
    db = SessionLocal()
    try:
        yield db  # ✅ Ensures cleanup
    finally:
        db.close()

@app.get("/users/{user_id}")
def get_user(user_id: int, db: Session = Depends(get_db)):
    return db.query(User).filter(User.id == user_id).first()

# AUTHENTICATION DEPENDENCY
def get_current_user(token: str = Header(...)):
    if not validate_token(token):
        raise HTTPException(status_code=401, detail="Invalid token")
    return {"user_id": 1}

@app.get("/profile")
def profile(current_user: dict = Depends(get_current_user)):
    return current_user

# NESTED DEPENDENCIES (Service Pattern)
def get_user_service(db: Session = Depends(get_db)):
    return UserService(db)

@app.post("/users")
def create_user(
    user: UserCreate,
    service: UserService = Depends(get_user_service)
):
    return service.create(user)

# CLASS-BASED DEPENDENCY
class Pagination:
    def __init__(self, skip: int = 0, limit: int = 10):
        self.skip = skip
        self.limit = limit

@app.get("/users")
def list_users(pagination: Pagination = Depends()):
    return {"skip": pagination.skip, "limit": pagination.limit}
```

**Key Points:**
- `yield` ensures cleanup (closes DB)
- Can chain dependencies
- Cached per request (called once)

---

## 4. BACKGROUND TASKS

```python
from fastapi import BackgroundTasks
import logging

logger = logging.getLogger(__name__)

# ⚠️ Background task errors are SILENT! Wrap them:
def safe_task(func):
    from functools import wraps
    
    @wraps(func)  # ✅ Preserves function name for logging
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logger.error(f"Task {func.__name__} failed: {e}")
            # Send alert to monitoring
    return wrapper

@safe_task
def send_email(email: str):
    print(f"Email sent to {email}")

# Usage
@app.post("/users")
async def create_user(
    user: UserCreate,
    background_tasks: BackgroundTasks
):
    # Create user first (fast)
    new_user = create_user_in_db(user)
    
    # Add background task (runs after response)
    background_tasks.add_task(send_email, user.email)
    
    return new_user  # Returns immediately
```

**When to Use:**
- ✅ **BackgroundTasks**: Quick tasks (<10s), same server, fire-and-forget
  - Emails, logging, simple notifications
- ✅ **Celery/Redis**: Long tasks, distributed, retry logic, monitoring
  - Reports, video processing, batch jobs

**Memory Warning:**
- Background tasks run in SAME process/memory
- 1000 queued tasks = OOM crash!
- Use Celery for production queues

**@wraps(func) Purpose:**
- Preserves function metadata (`__name__`, `__doc__`, etc.)
- Logs show REAL function names (not "wrapper")
- Critical for debugging

---

## 5. MIDDLEWARE

```python
from fastapi import Request
from fastapi.middleware.cors import CORSMiddleware
import time

# Custom Middleware (Runs for EVERY request)
@app.middleware("http")
async def add_process_time(request: Request, call_next):
    # Code BEFORE endpoint
    start_time = time.time()
    
    response = await call_next(request)  # Execute endpoint
    
    # Code AFTER endpoint
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

# Logging Middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    logger.info(f"{request.method} {request.url}")
    response = await call_next(request)
    logger.info(f"Status: {response.status_code}")
    return response
```

**Key Points:**
- Runs for ALL requests
- Order matters (first registered = first executed)
- Use for: logging, timing, global auth checks

---

## 6. EXCEPTION HANDLING (PRODUCTION PATTERN)

### **File Structure:**
```
project/
├── main.py              # ← Exception handlers here
├── exceptions.py        # ← Custom exceptions
└── routers/
    ├── users.py         # ← Endpoints (just raise exceptions)
    └── orders.py
```

### **Code:**

```python
# File: exceptions.py (Custom Exception Classes)
class UserNotFoundError(Exception):
    def __init__(self, user_id: int):
        self.user_id = user_id
        super().__init__(f"User {user_id} not found")

class InsufficientBalanceError(Exception):
    def __init__(self, required: float, available: float):
        self.required = required
        self.available = available

# File: main.py (Global Exception Handlers)
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from exceptions import UserNotFoundError, InsufficientBalanceError
from routers import users, orders

app = FastAPI()

# ✅ GLOBAL HANDLERS (Apply to ALL routers)
@app.exception_handler(UserNotFoundError)
async def user_not_found_handler(request: Request, exc: UserNotFoundError):
    return JSONResponse(
        status_code=404,
        content={"error": "User not found", "user_id": exc.user_id}
    )

@app.exception_handler(InsufficientBalanceError)
async def insufficient_balance_handler(request: Request, exc: InsufficientBalanceError):
    return JSONResponse(
        status_code=400,
        content={
            "error": "Insufficient balance",
            "required": exc.required,
            "available": exc.available
        }
    )

# Override Pydantic validation errors
@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    errors = {}
    for error in exc.errors():
        field = error['loc'][-1]
        errors[field] = error['msg']
    return JSONResponse(
        status_code=400,
        content={"error": "Validation failed", "fields": errors}
    )

# Catch-all
@app.exception_handler(Exception)
async def global_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled: {exc}")
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error"}
    )

# Include routers (handlers work for all of them!)
app.include_router(users.router, prefix="/api/v1/users", tags=["users"])
app.include_router(orders.router, prefix="/api/v1/orders", tags=["orders"])

# File: routers/users.py (Endpoints - Just Raise!)
from fastapi import APIRouter, Depends
from exceptions import UserNotFoundError  # ✅ Import at top

router = APIRouter()

@router.get("/{user_id}")
async def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise UserNotFoundError(user_id)  # ✅ main.py catches this!
    return user
```

### **Try/Except in Python (Production Patterns):**

```python
# Pattern 1: Basic
try:
    result = risky_operation()
except SpecificError:
    handle_specific()
except Exception as e:
    handle_generic()
finally:
    cleanup()  # Always runs

# Pattern 2: else (runs if NO exception)
try:
    result = operation()
except Exception:
    handle_error()
else:
    logger.info("Success!")  # Only if no exception
finally:
    cleanup()

# Pattern 3: Repository with DB rollback
try:
    db.add(user)
    db.commit()
except IntegrityError:
    db.rollback()
    raise DuplicateEmailError()
except Exception as e:
    db.rollback()
    logger.error(f"Error: {e}")
    raise HTTPException(status_code=500)

# Pattern 4: When to use try/except vs raise
# ✅ Just raise (let global handler catch)
if not user:
    raise UserNotFoundError(user_id)

# ✅ Try/except (need cleanup/custom handling)
try:
    db.commit()
    send_email()  # If fails, don't fail request
except EmailError:
    logger.warning("Email failed")
    # Don't raise, return success anyway
```

**Key Points:**
- Python uses `try/except` (not catch)
- Import exceptions at top of file
- Global handlers in `main.py`, endpoints just raise
- Always `db.rollback()` on errors

---

## 7. CORS CONFIGURATION

```python
from fastapi.middleware.cors import CORSMiddleware

# DEVELOPMENT (Allow all)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# PRODUCTION (Specific origins)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://myapp.com",
        "https://admin.myapp.com"
    ],
    allow_credentials=True,  # Allows cookies/auth
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Content-Type", "Authorization"],
    expose_headers=["X-Total-Count"],  # Custom headers frontend can read
    max_age=600  # Cache preflight 10 mins
)

# Environment-based
import os
origins = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(",")
app.add_middleware(CORSMiddleware, allow_origins=origins, ...)
```

**Important:**
- Add BEFORE routes
- Can't use `*` with `allow_credentials=True`
- In production, Ops team often handles at Gateway/LB level
- Then you can remove from FastAPI code

---

## 8. COMPLETE PRODUCTION EXAMPLE

```python
# main.py
from fastapi import FastAPI, Depends, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import logging

app = FastAPI(title="Production API")
logger = logging.getLogger(__name__)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://myapp.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    logger.info(f"{request.method} {request.url}")
    response = await call_next(request)
    return response

# Dependencies
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Exception Handlers
@app.exception_handler(UserNotFoundError)
async def user_not_found_handler(request: Request, exc: UserNotFoundError):
    return JSONResponse(status_code=404, content={"error": "User not found"})

# Models
class UserCreate(BaseModel):
    email: EmailStr
    username: str = Field(..., min_length=3)

class UserResponse(BaseModel):
    id: int
    email: str
    username: str
    
    class Config:
        orm_mode = True

# Endpoint
@app.post("/users", response_model=UserResponse, status_code=201)
async def create_user(
    user: UserCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    # Check duplicate
    existing = db.query(User).filter(User.email == user.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email exists")
    
    # Create
    new_user = User(**user.dict())
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    # Background task
    background_tasks.add_task(send_welcome_email, user.email)
    
    return new_user
```

---

## 🎯 QUICK Q&A REFERENCE

**Q: Optional[str] means list of strings?**  
A: NO! `Optional[str]` = string OR None. Use `List[str]` for list.

**Q: What does `values` parameter in Pydantic validator mean?**  
A: Dictionary of fields already validated (before current field). Use to compare fields.

**Q: What does @wraps(func) do?**  
A: Preserves function metadata (name, docstring) in decorators. Critical for logging real function names.

**Q: Can exception handlers be in main.py, endpoints in other files?**  
A: YES! Standard pattern. Handlers in `main.py`, endpoints in `routers/`, use `app.include_router()`.

**Q: Who handles CORS - FastAPI or Ops team?**  
A: Both options. Dev: FastAPI middleware. Prod: Often Gateway/LB (then remove from code).

**Q: Background tasks vs Celery?**  
A: BackgroundTasks = quick (<10s), same process. Celery = long tasks, distributed, retry logic, production queues.

**Q: Python uses try/catch?**  
A: NO! Python uses `try/except/else/finally`.

**Q: Should I always specify status codes?**  
A: YES! Always explicit in production (201 for POST, 204 for DELETE, etc.).

**Q: How does Pydantic validation error work?**  
A: Auto field-specific. Shows which field failed with exact error message.

---

## 📚 NEXT TOPICS TO COVER

1. **SQLAlchemy Connection Setup** (separate file, prod pattern)
2. **CRUD Operations** (ORM + Raw SQL/text queries)
3. **Repository Pattern** (with Depends)
4. **Async/Await** concepts
5. **Batching** (bulk operations)

---

## ✅ PRODUCTION CHECKLIST

- [ ] Always specify status codes
- [ ] Separate Request/Response models (never return passwords)
- [ ] Use `Depends` for DB sessions, auth, services
- [ ] Wrap background tasks with error handling
- [ ] Add middleware for logging/timing
- [ ] Global exception handlers in `main.py`
- [ ] Environment-based CORS configuration
- [ ] Use `orm_mode = True` for SQLAlchemy
- [ ] Validate with Pydantic (field-specific errors)
- [ ] Structure: `main.py` + `routers/` + `exceptions.py`

---

**Interview Tip:** Always explain "why" (e.g., "I use `response_model` to automatically filter sensitive data like passwords from responses"). Show production thinking!
