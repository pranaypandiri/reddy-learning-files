# Vertex AI Experiments & ETL Automation Cheatsheet

## Day 1: Vertex AI Experiments & Model Training

### 1. Vertex AI Experiments - Track Your ML Experiments

**What:** Experiment tracking system built into GCP Vertex AI.

**When to Use:**
- Track multiple training runs
- Compare hyperparameters
- Version control for models
- Team collaboration on experiments

#### Basic Setup & Logging

```python
import vertexai
from vertexai.preview.aiplatform import Experiment

# Initialize
vertexai.init(project="your-project", location="us-central1")

# Create/Get experiment
experiment = Experiment.create_or_get("classification-model-experiments")

# Start a run
with experiment.start_run("run-001") as run:
    # Log parameters
    run.log_params({
        "learning_rate": 0.001,
        "batch_size": 32,
        "epochs": 10,
        "model": "deberta-v3-base"
    })
    
    # Train your model
    # ...
    
    # Log metrics
    run.log_metrics({
        "accuracy": 0.92,
        "f1_score": 0.89,
        "precision": 0.91,
        "recall": 0.88
    })
    
    # Log model artifact
    run.log_model(model, "trained-model")
```

#### View Experiments in Console

```bash
# Via UI: GCP Console → Vertex AI → Experiments

# Via Code:
experiment = Experiment("classification-model-experiments")
runs_df = experiment.get_runs_as_dataframe()
print(runs_df)
```

---

### 2. MLflow vs Vertex AI Experiments

| Feature | MLflow | Vertex AI Experiments |
|---------|--------|---------------------|
| **Setup** | Self-hosted or Databricks | Native to GCP |
| **Best For** | Cloud-agnostic, local dev | GCP production |
| **UI** | MLflow UI | Vertex AI Console |
| **Integration** | Manual setup | Auto-integrated with Vertex AI |
| **Cost** | Infrastructure costs | Pay-per-use |

**Interview Answer:**  
*"I use Vertex AI Experiments for GCP production because it's native and integrates seamlessly with Vertex AI training jobs. MLflow is better for multi-cloud or local development."*

---

### 3. Model Training - LoRA & Fine-Tuning

#### LoRA (Low-Rank Adaptation)

**What:** Parameter-efficient fine-tuning - only train small adapter layers instead of entire model.

**Production Code:**

```python
from peft import LoraConfig, get_peft_model
from transformers import AutoModelForCausalLM

# Load base model
base_model = AutoModelForCausalLM.from_pretrained("mistralai/Mistral-7B-v0.1")

# LoRA config
lora_config = LoraConfig(
    r=16,                    # Rank (lower = fewer params)
    lora_alpha=32,           # Scaling factor
    target_modules=["q_proj", "v_proj"],  # Which layers to adapt
    lora_dropout=0.1,
    bias="none",
    task_type="CAUSAL_LM"
)

# Apply LoRA
model = get_peft_model(base_model, lora_config)
model.print_trainable_parameters()  # Shows only ~1% trainable
```

**Key Numbers:**
- Rank (r): 8-64 (lower = faster, less powerful)
- Alpha: Usually 2x rank
- Trainable params: ~0.1-1% of original model

---

#### SFTTrainer (Supervised Fine-Tuning)

**What:** Trainer for instruction fine-tuning datasets.

```python
from trl import SFTTrainer
from transformers import TrainingArguments

training_args = TrainingArguments(
    output_dir="./results",
    num_train_epochs=3,
    per_device_train_batch_size=4,
    learning_rate=2e-4,
    logging_steps=10,
    save_strategy="epoch"
)

trainer = SFTTrainer(
    model=model,
    args=training_args,
    train_dataset=dataset,
    dataset_text_field="text",  # Column with training text
    max_seq_length=512
)

trainer.train()
trainer.save_model("./fine-tuned-model")
```

---

### 4. A/B Testing Models

**Concept:** Deploy two model versions, split traffic, compare performance.

#### Deployment with Traffic Split

```python
from google.cloud import aiplatform

# Deploy Model A (80% traffic)
endpoint = aiplatform.Endpoint.create(display_name="ab-test-endpoint")
endpoint.deploy(
    model=model_a,
    deployed_model_display_name="model-a",
    traffic_percentage=80,
    machine_type="n1-standard-4"
)

# Deploy Model B (20% traffic)
endpoint.deploy(
    model=model_b,
    deployed_model_display_name="model-b",
    traffic_percentage=20,
    machine_type="n1-standard-4"
)
```

#### Monitor & Compare

```python
# Check prediction distribution
from google.cloud import monitoring_v3

client = monitoring_v3.MetricServiceClient()

# Query prediction latency for each model
# Compare accuracy, latency, cost
# Gradually shift traffic to winner
```

**Interview Answer:**  
*"I deploy both models to the same endpoint with traffic splitting—80% to current model, 20% to new model. Monitor key metrics (accuracy, latency, cost) for 1-2 weeks, then gradually shift traffic to the winner."*

---

### 5. Classification: DeBERTa vs Mistral

| Use Case | Model | Why |
|----------|-------|-----|
| **Intent Classification** | DeBERTa-v3-base | Faster, cheaper, 99% accuracy for simple tasks |
| **Complex Reasoning** | Mistral-7B | Better at nuanced understanding |
| **Production at Scale** | DeBERTa | Lower cost, faster inference |

**Production Code (DeBERTa):**

```python
from transformers import AutoTokenizer, AutoModelForSequenceClassification

tokenizer = AutoTokenizer.from_pretrained("microsoft/deberta-v3-base")
model = AutoModelForSequenceClassification.from_pretrained(
    "microsoft/deberta-v3-base",
    num_labels=5  # Number of classes
)

# Fine-tune on your data
# Deploy to Vertex AI
```

---

### 6. Model Registry & Versioning

**Best Practice:** Always version your models.

```python
from google.cloud import aiplatform

# Upload model to Model Registry
model = aiplatform.Model.upload(
    display_name="intent-classifier",
    artifact_uri="gs://bucket/model/",
    serving_container_image_uri="us-docker.pkg.dev/vertex-ai/prediction/sklearn-cpu.1-0:latest",
    labels={"version": "v1.2.0", "experiment": "run-042"}
)

# Add version alias
model.add_version_alias(["champion", "production"])
```

**View Models:**
```bash
# Console: Vertex AI → Model Registry
# CLI:
gcloud ai models list --region=us-central1
```

---

## Day 2: ETL Automation with Cloud Scheduler, Functions & Pub/Sub

### 1. Cloud Scheduler (Cron Jobs)

**What:** Managed cron service in GCP. Triggers HTTP endpoints or Pub/Sub on schedule.

#### Create Scheduler (Python SDK)

```python
from google.cloud import scheduler_v1

client = scheduler_v1.CloudSchedulerClient()

job = scheduler_v1.Job(
    name=f"projects/{project_id}/locations/{location}/jobs/daily-rag-update",
    schedule="0 2 * * *",  # 2 AM UTC daily
    time_zone="UTC",
    
    http_target=scheduler_v1.HttpTarget(
        uri="https://us-central1-project.cloudfunctions.net/update-rag",
        http_method=scheduler_v1.HttpMethod.POST,
        oidc_token=scheduler_v1.OidcToken(
            service_account_email="scheduler@project.iam.gserviceaccount.com"
        )
    ),
    
    retry_config=scheduler_v1.RetryConfig(
        retry_count=3,
        max_retry_duration="3600s",
        min_backoff_duration="60s"
    )
)

response = client.create_job(request={"parent": parent, "job": job})
```

#### Create Scheduler (CLI - Simpler)

```bash
gcloud scheduler jobs create http daily-rag-update \
  --location=us-central1 \
  --schedule="0 2 * * *" \
  --uri="https://us-central1-project.cloudfunctions.net/update-rag" \
  --http-method=POST \
  --oidc-service-account-email="scheduler@project.iam.gserviceaccount.com"
```

#### Cron Expression Cheatsheet

```
* * * * *
│ │ │ │ │
│ │ │ │ └─ Day of week (0-6, Sun-Sat)
│ │ │ └─── Month (1-12)
│ │ └───── Day of month (1-31)
│ └─────── Hour (0-23)
└───────── Minute (0-59)

Examples:
0 2 * * *      → 2 AM daily
0 */6 * * *    → Every 6 hours
0 9 * * 1      → 9 AM every Monday
*/15 * * * *   → Every 15 minutes
```

---

### 2. Cloud Functions (Serverless Code)

**What:** Run code without managing servers. Triggers on HTTP, Pub/Sub, GCS events.

#### Basic HTTP Function

```python
import functions_framework
from google.cloud import storage

@functions_framework.http
def update_rag_db(request):
    """Triggered by HTTP request (e.g., from Cloud Scheduler)"""
    
    # Extract new documents from GCS
    storage_client = storage.Client()
    bucket = storage_client.bucket("my-docs")
    blobs = bucket.list_blobs(prefix="new/")
    
    # Transform (chunk, embed)
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    splitter = RecursiveCharacterTextSplitter(chunk_size=1000)
    
    chunks = []
    for blob in blobs:
        content = blob.download_as_text()
        chunks.extend(splitter.split_text(content))
    
    # Load to vector DB
    # ... embedding + storage code
    
    return {"status": "success", "chunks_processed": len(chunks)}
```

#### Deploy Function

```bash
gcloud functions deploy update-rag-db \
  --gen2 \
  --runtime=python311 \
  --region=us-central1 \
  --source=. \
  --entry-point=update_rag_db \
  --trigger-http \
  --memory=1GB \
  --timeout=540s \
  --allow-unauthenticated
```

**Key Flags:**
- `--gen2`: Use Gen2 (60 min timeout, 32GB memory, better performance)
- `--memory`: 256MB-32GB
- `--timeout`: Max 60 min (Gen2), 9 min (Gen1)
- `--trigger-http`: HTTP endpoint
- `--trigger-topic=NAME`: Pub/Sub trigger

#### Storage in Cloud Functions

**Temporary Storage (`/tmp`):**
- Ephemeral (deleted after function execution)
- Size = allocated memory
- For processing files temporarily

```python
# Download, process, cleanup
blob.download_to_filename('/tmp/file.pdf')
process_file('/tmp/file.pdf')
os.remove('/tmp/file.pdf')  # Cleanup
```

**Persistent Storage (GCS):**
```python
# Store results permanently
bucket.blob("results/output.json").upload_from_string(data)
```

---

### 3. Scheduler + Function Integration

**Deployment Flow:**

```bash
#!/bin/bash
# deploy.sh

# 1. Deploy Function
gcloud functions deploy update-rag-db \
  --gen2 \
  --runtime=python311 \
  --region=us-central1 \
  --source=. \
  --entry-point=update_rag_db \
  --trigger-http \
  --memory=1GB

# 2. Get Function URL (auto-generated)
FUNCTION_URL=$(gcloud functions describe update-rag-db \
  --region=us-central1 \
  --format='value(serviceConfig.uri)')

# 3. Create Scheduler with that URL
export FUNCTION_URL
python create_scheduler.py
```

**In create_scheduler.py:**
```python
import os

function_url = os.environ['FUNCTION_URL']  # ← Read URL from CI/CD

http_target = scheduler_v1.HttpTarget(
    uri=function_url,  # ← Use it here
    http_method=scheduler_v1.HttpMethod.POST
)
```

**Key Concept:**  
*Function URL is generated AFTER deployment. CI/CD captures it and passes to next stage via environment variable.*

---

### 4. Pub/Sub Event-Driven Processing

**What:** Message queue for event-driven architecture. Decouples publishers from subscribers.

#### Create Topic

```bash
gcloud pubsub topics create document-uploads
```

#### Function with Pub/Sub Trigger

```python
import functions_framework
import base64
import json

@functions_framework.cloud_event
def process_pubsub_event(cloud_event):
    """Triggered by Pub/Sub message"""
    
    # Decode message
    pubsub_message = base64.b64decode(cloud_event.data["message"]["data"]).decode()
    data = json.loads(pubsub_message)
    
    print(f"Processing: {data['file_name']}")
    
    # Your processing logic
    # ...
    
    return "Success"
```

#### Deploy with Pub/Sub Trigger

```bash
gcloud functions deploy process-event \
  --gen2 \
  --runtime=python311 \
  --region=us-central1 \
  --source=. \
  --entry-point=process_pubsub_event \
  --trigger-topic=document-uploads \
  --memory=512MB
```

**The `--trigger-topic` flag:**
- Auto-creates a Pub/Sub subscription
- Links topic → function
- Function receives messages automatically

#### Publish Test Message

```bash
gcloud pubsub topics publish document-uploads \
  --message='{"file_name":"test.pdf","bucket":"my-docs"}'
```

---

### 5. GCS → Pub/Sub → Function Pipeline (Auto-Processing)

**What:** Automatically process files when uploaded to GCS bucket.

#### Setup (One-Time)

**Step 1: Create Pub/Sub Topic**
```bash
gcloud pubsub topics create gcs-uploads
```

**Step 2: Link GCS Bucket → Pub/Sub**
```bash
gsutil notification create -t gcs-uploads -f json gs://my-bucket
```

**Step 3: Deploy Function**
```bash
gcloud functions deploy auto-process \
  --gen2 \
  --runtime=python311 \
  --region=us-central1 \
  --source=. \
  --entry-point=process_new_document \
  --trigger-topic=gcs-uploads \
  --memory=1GB
```

#### Function Code

```python
@functions_framework.cloud_event
def process_new_document(cloud_event):
    """Auto-triggered when file uploaded to GCS"""
    
    # Extract file info from GCS event
    data = cloud_event.data
    bucket_name = data["bucket"]
    file_name = data["name"]
    
    # Only process certain files
    if not file_name.endswith(('.pdf', '.txt')):
        return
    
    print(f"Processing: gs://{bucket_name}/{file_name}")
    
    # Download, process, store
    storage_client = storage.Client()
    blob = storage_client.bucket(bucket_name).blob(file_name)
    content = blob.download_as_text()
    
    # Chunk, embed, store in vector DB
    # ...
    
    return "Success"
```

#### How It Works

```
File Upload → GCS detects event → Publishes to Pub/Sub → Function triggered
```

**Test:**
```bash
# Upload file
gsutil cp test.pdf gs://my-bucket/

# Check function logs
gcloud functions logs read auto-process --limit=10
```

---

### 6. Setup via Code (Alternative to CLI)

```python
from google.cloud import pubsub_v1, storage

def setup_pipeline():
    project_id = "your-project"
    topic_name = "gcs-uploads"
    bucket_name = "my-bucket"
    
    # 1. Create Pub/Sub Topic
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_name)
    publisher.create_topic(request={"name": topic_path})
    
    # 2. Link GCS → Pub/Sub
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    notification = bucket.notification(
        topic_name=topic_name,
        topic_project=project_id,
        payload_format='JSON_API_V1'
    )
    notification.create()
    
    print(f"✅ Setup complete: gs://{bucket_name} → {topic_name}")
```

**When to Use:**
- **CLI**: Quick setup, one-time config, simple CI/CD
- **Code**: Multiple environments, automated provisioning, Terraform alternative

---

### 7. Monitoring & Health Checks

#### Check Scheduler Status

```python
from google.cloud import scheduler_v1

client = scheduler_v1.CloudSchedulerClient()
job_name = "projects/project/locations/us-central1/jobs/daily-update"

job = client.get_job(name=job_name)
print(f"State: {job.state}")
print(f"Last run: {job.last_attempt_time}")
```

#### Check Function Logs

```bash
gcloud functions logs read FUNCTION_NAME \
  --region=us-central1 \
  --limit=50 \
  --filter='severity>=ERROR'
```

#### Verify Pub/Sub Connection

```bash
# List subscriptions (should see auto-created one)
gcloud pubsub subscriptions list

# Check GCS notification
gsutil notification list gs://my-bucket
```

---

## Quick Reference Commands

### Cloud Scheduler
```bash
# Create
gcloud scheduler jobs create http JOB_NAME --schedule="0 2 * * *" --uri=URL

# List
gcloud scheduler jobs list --location=us-central1

# Trigger manually
gcloud scheduler jobs run JOB_NAME --location=us-central1

# Delete
gcloud scheduler jobs delete JOB_NAME --location=us-central1
```

### Cloud Functions
```bash
# Deploy
gcloud functions deploy NAME --gen2 --runtime=python311 --trigger-http

# List
gcloud functions list --region=us-central1

# Logs
gcloud functions logs read NAME --region=us-central1

# Delete
gcloud functions delete NAME --region=us-central1
```

### Pub/Sub
```bash
# Create topic
gcloud pubsub topics create TOPIC_NAME

# Publish message
gcloud pubsub topics publish TOPIC_NAME --message='{"key":"value"}'

# List subscriptions
gcloud pubsub subscriptions list

# View messages (pull)
gcloud pubsub subscriptions pull SUBSCRIPTION_NAME --limit=5
```

### GCS Notifications
```bash
# Create notification
gsutil notification create -t TOPIC_NAME -f json gs://BUCKET_NAME

# List notifications
gsutil notification list gs://BUCKET_NAME

# Delete notification
gsutil notification delete NOTIFICATION_ID gs://BUCKET_NAME
```

---

## Terraform vs Manual (Infrastructure as Code)

**In Production:** Infrastructure team uses Terraform for all this setup.

**Example Terraform:**
```hcl
resource "google_pubsub_topic" "gcs_uploads" {
  name = "gcs-uploads"
}

resource "google_cloudfunctions2_function" "processor" {
  name     = "auto-process"
  location = "us-central1"
  
  event_trigger {
    event_type   = "google.cloud.pubsub.topic.v1.messagePublished"
    pubsub_topic = google_pubsub_topic.gcs_uploads.id
  }
}

resource "google_storage_notification" "bucket_notification" {
  bucket         = "my-bucket"
  topic          = google_pubsub_topic.gcs_uploads.id
  payload_format = "JSON_API_V1"
}
```

**Your Job as Developer:**
- Write function code (`main.py`, `requirements.txt`)
- Test locally
- Understand how it connects

**Infra Team Job:**
- Provision with Terraform
- Set up IAM permissions
- Configure CI/CD pipelines

---

## Interview Key Points

### Vertex AI Experiments
*"I use Vertex AI Experiments to track training runs, compare hyperparameters, and version models. It integrates natively with GCP and provides a UI in Vertex AI Console."*

### Model Training (LoRA)
*"LoRA enables parameter-efficient fine-tuning by only training small adapter layers. For a 7B model, I train <1% of parameters, reducing cost and time while maintaining performance."*

### A/B Testing
*"I deploy both models to the same endpoint with traffic splitting (80/20), monitor metrics for 1-2 weeks, then shift traffic to the winner."*

### Cloud Scheduler vs Pub/Sub
*"Scheduler for time-based triggers (daily RAG updates). Pub/Sub for event-driven (file uploads). Gen2 functions support longer timeouts and more memory."*

### GCS → Pub/Sub → Function
*"I configure GCS bucket notifications to publish to Pub/Sub when files upload. Function auto-triggers via `--trigger-topic`, receives event data in `cloud_event.data`, extracts bucket/file name, and processes immediately."*

### Gen2 Functions
*"Gen2 offers 60-minute timeout vs 9 minutes, up to 32GB memory, better concurrency, and faster cold starts. Built on Cloud Run."*

### Infrastructure
*"In production, Terraform handles infrastructure provisioning. As developer, I focus on application code and understand how components connect."*

---

## What You DON'T Need for Associate GenAI Role

❌ Deep Kubeflow knowledge  
❌ Complex Vertex AI Pipelines  
❌ Advanced Terraform syntax  
❌ Kubernetes orchestration details  

✅ Focus on: RAG, LLM APIs, prompt engineering, vector DBs, simple automation
