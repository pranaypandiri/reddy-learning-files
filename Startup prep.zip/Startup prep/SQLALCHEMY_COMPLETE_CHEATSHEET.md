# 🚀 SQLAlchemy + FastAPI Complete Cheatsheet

## Production-Grade Database Operations Interview Guide

---

## 📁 FILE STRUCTURE (Production Pattern)

```
project/
├── main.py                  # FastAPI app + exception handlers
├── database.py              # Connection setup (separate file!)
├── models.py                # ORM models
├── dependencies.py          # Dependency injection functions
├── config.py                # Environment variables
├── .env                     # Environment file
├── alembic.ini              # Alembic config
├── alembic/
│   ├── env.py              # Alembic setup (edit to link models)
│   └── versions/           # Migration files (auto-generated)
├── repositories/
│   └── user_repository.py  # Repository pattern
├── routers/
│   ├── users.py           # User endpoints
│   └── orders.py          # Order endpoints
└── schemas/
    └── user.py            # Pydantic models
```

---

## 1. DATABASE CONNECTION SETUP (database.py)

### **Production Configuration:**

```python
# database.py - SEPARATE FILE (Production Pattern)
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

# DATABASE URL (Environment Variable)
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://user:password@localhost:5432/mydb"
)

# For Cloud SQL (GCP with Unix Socket):
# DATABASE_URL = "postgresql+psycopg2://user:pass@/dbname?host=/cloudsql/project:region:instance"

# ENGINE with Connection Pool (Production Settings)
engine = create_engine(
    DATABASE_URL,
    pool_size=10,              # Max connections in pool
    max_overflow=20,           # Extra connections if pool full
    pool_timeout=30,           # Wait 30s for connection
    pool_recycle=3600,         # Recycle connections every hour (prevents stale)
    pool_pre_ping=True,        # Check connection health before use
    echo=False,                # True = log SQL (dev only), False = no logs (prod)
)

# SESSION FACTORY
SessionLocal = sessionmaker(
    autocommit=False,          # Manual commit (safer)
    autoflush=False,           # Manual flush
    bind=engine
)

# BASE CLASS (All models inherit from this)
Base = declarative_base()

# DEPENDENCY (Use in FastAPI endpoints with Depends)
def get_db():
    db = SessionLocal()
    try:
        yield db               # Endpoint uses this session
    finally:
        db.close()             # Always closes connection (cleanup)
```

### **Async Version (For High Performance):**

```python
# database.py - ASYNC VERSION
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

# Async DB URL (note: postgresql+asyncpg)
DATABASE_URL = "postgresql+asyncpg://user:password@localhost:5432/mydb"

# Async Engine
engine = create_async_engine(
    DATABASE_URL,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
    echo=False
)

# Async Session Factory
AsyncSessionLocal = sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)

# Async Dependency
async def get_db():
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()
```

### **Key Interview Points:**

✅ **Separate file** (`database.py`) for clean separation  
✅ **Connection pooling** prevents opening new connections for each request  
✅ **`pool_recycle=3600`** prevents stale connections (DB servers kill idle connections)  
✅ **`pool_pre_ping=True`** checks if connection is alive before using  
✅ **`get_db()` with yield** ensures connection always closes (even on errors)  
✅ **Environment variables** for different environments (dev/staging/prod)  

---

## 2. MODELS & RELATIONSHIPS (models.py)

### **Basic Model with Common Fields:**

```python
# models.py
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, Index
from sqlalchemy.orm import relationship
from database import Base
from datetime import datetime

class User(Base):
    __tablename__ = "users"
    __table_args__ = {'extend_existing': True}  # For hot reload in dev
    
    # Primary Key
    id = Column(Integer, primary_key=True, index=True)
    
    # Basic Columns
    email = Column(String(255), unique=True, nullable=False, index=True)
    username = Column(String(50), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    
    # Boolean & Defaults
    is_active = Column(Boolean, default=True)
    
    # Timestamps (Auto-managed)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    orders = relationship("Order", back_populates="user", cascade="all, delete-orphan")
```

### **Column Types Reference:**

```python
# Integers
id = Column(Integer, primary_key=True)
age = Column(Integer)
big_number = Column(BigInteger)

# Strings
name = Column(String(50))          # Max 50 chars (indexed searches)
email = Column(String(255))        # Max 255 chars
bio = Column(Text)                 # Unlimited text (not indexed)

# Numbers
price = Column(Float)              # Approximate decimals
salary = Column(Numeric(10, 2))    # Exact: 10 digits, 2 after decimal

# Boolean
is_active = Column(Boolean, default=True)

# Dates & Times
created_at = Column(DateTime, default=datetime.utcnow)
birth_date = Column(Date)
login_time = Column(Time)

# JSON (PostgreSQL)
metadata = Column(JSON)            # Store JSON data
```

---

## 3. RELATIONSHIPS (All Patterns)

### **Pattern 1: ONE-TO-MANY (User → Orders)**

```python
# PARENT (One User has Many Orders)
class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    
    # Relationship (Virtual - NOT a real column!)
    orders = relationship("Order", back_populates="user")
    #         ↑ Model name    ↑ Field in Order model

# CHILD (Many Orders belong to One User)
class Order(Base):
    __tablename__ = "orders"
    
    id = Column(Integer, primary_key=True)
    total = Column(Float)
    
    # Foreign Key (Real column in database!)
    user_id = Column(Integer, ForeignKey("users.id"))
    #                         ↑ "tablename.column" (NOT model name!)
    
    # Relationship (Virtual - NOT a real column!)
    user = relationship("User", back_populates="orders")

# USAGE:
user = db.query(User).first()
print(user.orders)  # List of Order objects

order = db.query(Order).first()
print(order.user)   # User object
```

### **Pattern 2: ONE-TO-MANY with CASCADE DELETE**

```python
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    
    # When user deleted → all orders auto-deleted!
    orders = relationship("Order", back_populates="user", cascade="all, delete-orphan")

class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    user = relationship("User", back_populates="orders")

# USAGE:
user = db.query(User).filter(User.id == 1).first()
db.delete(user)  # Deletes user AND all their orders automatically!
db.commit()
```

### **Pattern 3: MANY-TO-MANY (Simple - No Extra Fields)**

```python
# Student ↔ Course (students enroll in courses, courses have students)

# ASSOCIATION TABLE (Pure join table - use Table, not class)
from sqlalchemy import Table

student_course = Table(
    'student_course',
    Base.metadata,
    Column('student_id', Integer, ForeignKey('students.id'), primary_key=True),
    Column('course_id', Integer, ForeignKey('courses.id'), primary_key=True)
)

class Student(Base):
    __tablename__ = "students"
    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    
    # Many-to-Many
    courses = relationship("Course", secondary=student_course, back_populates="students")
    #                      ↑ Model    ↑ Join table

class Course(Base):
    __tablename__ = "courses"
    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    
    students = relationship("Student", secondary=student_course, back_populates="courses")

# USAGE:
student = db.query(Student).first()
student.courses  # List of Course objects

# Add student to course:
student.courses.append(course)
db.commit()
```

### **Pattern 4: MANY-TO-MANY with Extra Fields (Association Object)**

```python
# Order ↔ Product (with quantity, price per item)

# ASSOCIATION OBJECT (Class with extra fields!)
class OrderItem(Base):
    __tablename__ = "order_items"
    
    id = Column(Integer, primary_key=True)
    order_id = Column(Integer, ForeignKey("orders.id"))
    product_id = Column(Integer, ForeignKey("products.id"))
    
    # EXTRA FIELDS (why we need a class, not just Table)
    quantity = Column(Integer, nullable=False)
    price = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    order = relationship("Order", back_populates="items")
    product = relationship("Product", back_populates="order_items")

class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True)
    items = relationship("OrderItem", back_populates="order")

class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    order_items = relationship("OrderItem", back_populates="product")

# USAGE:
order = db.query(Order).first()
for item in order.items:
    print(f"{item.product.name}: {item.quantity} x ${item.price}")
```

### **Pattern 5: ONE-TO-ONE (User → Profile)**

```python
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String(255))
    
    # ONE-TO-ONE (uselist=False means single object, not list!)
    profile = relationship("Profile", back_populates="user", uselist=False)
    #                                                         ↑ Key!

class Profile(Base):
    __tablename__ = "profiles"
    id = Column(Integer, primary_key=True)
    bio = Column(Text)
    avatar = Column(String(255))
    
    # Foreign Key with UNIQUE (ensures one-to-one!)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    #                                                  ↑ unique=True = one-to-one!
    
    user = relationship("User", back_populates="profile")

# USAGE:
user = db.query(User).first()
user.profile  # Single Profile object (not list!)
user.profile.bio
```

### **Indexes (Performance Optimization):**

```python
class User(Base):
    __tablename__ = "users"
    
    # Single column index
    email = Column(String(255), index=True)
    username = Column(String(50), index=True, unique=True)
    
    # Composite index (multiple columns)
    __table_args__ = (
        Index('idx_email_username', 'email', 'username'),
        Index('idx_name_created', 'name', 'created_at'),
        {'extend_existing': True}  # For hot reload
    )
```

---

## 4. CRUD OPERATIONS - ORM STYLE (Pythonic)

### **CREATE:**

```python
from sqlalchemy.orm import Session

# Single Insert
def create_user(db: Session, email: str, name: str):
    user = User(email=email, name=name)
    db.add(user)
    db.commit()
    db.refresh(user)  # Get ID and auto-generated fields from DB
    return user

# Multiple Insert
users = [User(email=f"user{i}@test.com", name=f"User{i}") for i in range(5)]
db.add_all(users)
db.commit()
```

### **READ (Query):**

```python
# By Primary Key
user = db.query(User).get(1)

# Single Result
user = db.query(User).filter(User.id == 1).first()
user = db.query(User).filter(User.email == "test@test.com").first()
user = db.query(User).filter_by(email="test@test.com").first()  # filter_by shorthand

# Multiple Results
users = db.query(User).all()
users = db.query(User).filter(User.is_active == True).all()

# Filtering (WHERE conditions)
users = db.query(User).filter(User.age > 18).all()
users = db.query(User).filter(User.age >= 18, User.is_active == True).all()  # AND
users = db.query(User).filter((User.age > 18) | (User.is_admin == True)).all()  # OR

# LIKE / IN / BETWEEN
users = db.query(User).filter(User.email.like("%@gmail.com")).all()
users = db.query(User).filter(User.name.in_(["John", "Jane"])).all()
users = db.query(User).filter(User.age.between(18, 65)).all()

# IS NULL / IS NOT NULL
users = db.query(User).filter(User.deleted_at.is_(None)).all()
users = db.query(User).filter(User.email.isnot(None)).all()

# Ordering
users = db.query(User).order_by(User.created_at.desc()).all()
users = db.query(User).order_by(User.name.asc()).all()

# Pagination
users = db.query(User).offset(10).limit(20).all()  # Skip 10, get 20

# Count
count = db.query(User).count()
count = db.query(User).filter(User.is_active == True).count()

# Exists Check
exists = db.query(User).filter(User.email == "test@test.com").first() is not None
```

### **UPDATE:**

```python
# Update Single
user = db.query(User).filter(User.id == 1).first()
user.name = "New Name"
user.email = "new@email.com"
db.commit()
db.refresh(user)  # Get updated fields

# Bulk Update (Single Query)
db.query(User).filter(User.is_active == False).update({"is_active": True})
db.commit()

# Update with dict
update_data = {"name": "Updated", "email": "updated@test.com"}
db.query(User).filter(User.id == 1).update(update_data)
db.commit()
```

### **DELETE:**

```python
# Delete Single
user = db.query(User).filter(User.id == 1).first()
db.delete(user)
db.commit()

# Bulk Delete
db.query(User).filter(User.is_active == False).delete()
db.commit()

# Soft Delete (Don't actually delete, just mark)
db.query(User).filter(User.id == 1).update({"deleted_at": datetime.utcnow()})
db.commit()
```

### **Relationships in Queries:**

```python
# Eager Loading (JOIN to avoid N+1 queries)
from sqlalchemy.orm import joinedload

users = db.query(User).options(joinedload(User.orders)).all()
# Loads users AND their orders in ONE query (efficient!)

# Filter by relationship
users = db.query(User).join(Order).filter(Order.total > 100).all()
# Users who have orders > $100

# Count relationship items
from sqlalchemy import func
result = db.query(User.name, func.count(Order.id)).join(Order).group_by(User.id).all()
```

---

## 5. CRUD - RAW SQL (Spring Boot Native Query Style)

```python
from sqlalchemy import text

# SELECT with parameters (ALWAYS use parameters, never string concat!)
result = db.execute(
    text("SELECT * FROM users WHERE id = :id"),
    {"id": 1}
)
user = result.fetchone()  # Single row
users = result.fetchall()  # All rows

# Multiple parameters
result = db.execute(
    text("SELECT * FROM users WHERE age > :age AND is_active = :active"),
    {"age": 18, "active": True}
)
users = result.fetchall()

# INSERT
db.execute(
    text("INSERT INTO users (email, name) VALUES (:email, :name)"),
    {"email": "test@test.com", "name": "John"}
)
db.commit()

# UPDATE
db.execute(
    text("UPDATE users SET name = :name WHERE id = :id"),
    {"name": "New Name", "id": 1}
)
db.commit()

# DELETE
db.execute(
    text("DELETE FROM users WHERE id = :id"),
    {"id": 1}
)
db.commit()

# Complex Query (JOINs, GROUP BY, HAVING)
result = db.execute(text("""
    SELECT u.name, COUNT(o.id) as order_count, SUM(o.total) as total_spent
    FROM users u
    LEFT JOIN orders o ON u.id = o.user_id
    GROUP BY u.id, u.name
    HAVING COUNT(o.id) > :min_orders
    ORDER BY total_spent DESC
    LIMIT :limit
"""), {"min_orders": 5, "limit": 10})

data = result.fetchall()
for row in data:
    print(row.name, row.order_count, row.total_spent)
```

**Key Points:**
- ✅ Use `:parameter` syntax for safe queries (prevents SQL injection)
- ✅ Pass parameters as dict
- ✅ Use for complex queries ORM can't handle
- ❌ Never concatenate strings: `f"SELECT * FROM users WHERE id = {id}"` ← SQL INJECTION!

---

## 6. REPOSITORY PATTERN (Production Architecture)

```python
# repositories/user_repository.py
from sqlalchemy.orm import Session
from sqlalchemy import text
from models import User
from typing import Optional, List

class UserRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def create(self, email: str, name: str, password_hash: str) -> User:
        try:
            user = User(email=email, name=name, password_hash=password_hash)
            self.db.add(user)
            self.db.commit()
            self.db.refresh(user)
            return user
        except Exception as e:
            self.db.rollback()
            raise
    
    def get_by_id(self, user_id: int) -> Optional[User]:
        return self.db.query(User).filter(User.id == user_id).first()
    
    def get_by_email(self, email: str) -> Optional[User]:
        return self.db.query(User).filter(User.email == email).first()
    
    def list_all(self, skip: int = 0, limit: int = 100) -> List[User]:
        return self.db.query(User).offset(skip).limit(limit).all()
    
    def update(self, user_id: int, **kwargs) -> User:
        try:
            user = self.get_by_id(user_id)
            if not user:
                raise ValueError(f"User {user_id} not found")
            
            for key, value in kwargs.items():
                setattr(user, key, value)
            
            self.db.commit()
            self.db.refresh(user)
            return user
        except Exception as e:
            self.db.rollback()
            raise
    
    def delete(self, user_id: int) -> bool:
        try:
            user = self.get_by_id(user_id)
            if not user:
                return False
            
            self.db.delete(user)
            self.db.commit()
            return True
        except Exception as e:
            self.db.rollback()
            raise
    
    # Custom query (Raw SQL)
    def get_active_users_count(self) -> int:
        result = self.db.execute(
            text("SELECT COUNT(*) FROM users WHERE is_active = true")
        )
        return result.scalar()

# dependencies.py
from database import get_db
from repositories.user_repository import UserRepository

def get_user_repository(db: Session = Depends(get_db)):
    return UserRepository(db)

# routers/users.py
from fastapi import APIRouter, Depends
from repositories.user_repository import UserRepository
from dependencies import get_user_repository

router = APIRouter()

@router.post("/users")
def create_user(
    user: UserCreate,
    repo: UserRepository = Depends(get_user_repository)
):
    return repo.create(user.email, user.name, user.password)

@router.get("/users/{user_id}")
def get_user(
    user_id: int,
    repo: UserRepository = Depends(get_user_repository)
):
    user = repo.get_by_id(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user
```

**Benefits:**
- ✅ Clean separation (repository handles DB, router handles HTTP)
- ✅ Easy to test (mock repository)
- ✅ Reusable (use same repo in multiple endpoints)
- ✅ Error handling in one place

---

## 7. ASYNC / AWAIT (High Performance)

```python
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

# ASYNC CRUD
@app.get("/users/{user_id}")
async def get_user(user_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).filter(User.id == user_id))
    user = result.scalars().first()
    return user

@app.get("/users")
async def list_users(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User))
    users = result.scalars().all()
    return users

@app.post("/users")
async def create_user(user: UserCreate, db: AsyncSession = Depends(get_db)):
    new_user = User(**user.dict())
    db.add(new_user)
    await db.commit()
    await db.refresh(new_user)
    return new_user

@app.put("/users/{user_id}")
async def update_user(user_id: int, user: UserUpdate, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).filter(User.id == user_id))
    existing_user = result.scalars().first()
    
    existing_user.name = user.name
    await db.commit()
    await db.refresh(existing_user)
    return existing_user
```

**Key Differences:**
- `async def` instead of `def`
- `await db.execute()` instead of `db.query()`
- `await db.commit()` instead of `db.commit()`
- `select()` instead of `query()`
- `result.scalars().first()` to get data

**When to Use:**
- ✅ High traffic (1000+ req/sec)
- ✅ I/O heavy operations
- ✅ Need max performance
- ❌ Simple CRUD apps (sync is fine and simpler)

---

## 8. BATCHING & BULK OPERATIONS (Performance)

```python
# BULK INSERT (Fast!)
users_data = [
    {"email": f"user{i}@test.com", "name": f"User {i}"}
    for i in range(10000)
]

db.bulk_insert_mappings(User, users_data)
db.commit()
# ↑ 100x faster than individual inserts!

# BULK UPDATE (Fast!)
update_data = [
    {"id": 1, "name": "Updated 1"},
    {"id": 2, "name": "Updated 2"},
    {"id": 3, "name": "Updated 3"},
]

db.bulk_update_mappings(User, update_data)
db.commit()

# BULK DELETE
db.query(User).filter(User.is_active == False).delete()
db.commit()

# TRANSACTION (All or Nothing)
try:
    user = User(email="test@test.com", name="Test")
    db.add(user)
    
    order = Order(user_id=user.id, total=100)
    db.add(order)
    
    db.commit()  # Both succeed or both fail
except Exception as e:
    db.rollback()  # Undo everything
    logger.error(f"Transaction failed: {e}")
    raise

# BATCH with Error Handling
def batch_create_users(db: Session, users_data: List[dict]):
    success_count = 0
    errors = []
    
    for user_data in users_data:
        try:
            user = User(**user_data)
            db.add(user)
            db.commit()
            success_count += 1
        except Exception as e:
            db.rollback()
            errors.append({"data": user_data, "error": str(e)})
    
    return {"success": success_count, "errors": errors}
```

---

## 9. ALEMBIC MIGRATIONS (Production Standard)

### **Setup (One-Time):**

```bash
# 1. Install Alembic
pip install alembic

# 2. Initialize
alembic init alembic
# Creates: alembic/ folder and alembic.ini
```

### **Configure Alembic:**

```python
# alembic/env.py (EDIT THIS FILE)
from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool
from alembic import context

# ✅ IMPORT YOUR BASE AND MODELS
from database import Base
import models  # Import all models to register with Base

# ✅ SET target_metadata (KEY!)
target_metadata = Base.metadata

# Rest remains default...
```

```ini
# alembic.ini (EDIT THIS FILE)
# Find line: sqlalchemy.url = ...
# Replace with:
sqlalchemy.url = postgresql://user:password@localhost:5432/mydb

# Or use environment variable:
# sqlalchemy.url = ${DATABASE_URL}
```

### **Workflow:**

```bash
# 1. Change models.py (add/modify fields)
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String)
    email = Column(String)  # ← NEW FIELD

# 2. Generate migration (Alembic creates file)
$ alembic revision --autogenerate -m "Add email to users"
# Creates: versions/abc123_add_email.py

# 3. Review migration file (check if correct)
# versions/abc123_add_email.py

# 4. Apply migration (Updates database)
$ alembic upgrade head
# Runs: ALTER TABLE users ADD COLUMN email VARCHAR;

# 5. Commit to git
$ git add versions/abc123_add_email.py models.py
$ git commit -m "Add email field"
$ git push

# 6. Team/Production runs migration
$ git pull
$ alembic upgrade head  # Their DB updated!
```

### **Common Commands:**

```bash
# Create migration
alembic revision --autogenerate -m "message"

# Apply all migrations
alembic upgrade head

# Rollback one migration
alembic downgrade -1

# Show current version
alembic current

# Show migration history
alembic history

# Rollback to specific version
alembic downgrade abc123
```

### **Key Concepts:**

- **Never** use `Base.metadata.create_all()` in production
- **Always** generate migrations for schema changes
- **Commit** migration files to git
- **Each migration** tracks its parent (forms chain)
- **Database** stores current version in `alembic_version` table (1 row)
- **`pool_recycle=3600`**: Prevents stale connections (DB kills idle connections)
- **Linked list**: Each migration knows parent → forms chain → tracks history with one version number

---

## 10. PRODUCTION CONFIGURATION

### **Environment Variables:**

```python
# .env
DATABASE_URL=postgresql://user:pass@localhost:5432/db
POOL_SIZE=10
MAX_OVERFLOW=20
ECHO_SQL=False

# config.py
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    database_url: str
    pool_size: int = 10
    max_overflow: int = 20
    echo_sql: bool = False
    
    class Config:
        env_file = ".env"

settings = Settings()

# database.py
engine = create_engine(
    settings.database_url,
    pool_size=settings.pool_size,
    max_overflow=settings.max_overflow,
    echo=settings.echo_sql,
    pool_recycle=3600,
    pool_pre_ping=True,
)
```

### **Health Check:**

```python
@app.get("/health")
def health_check(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Database unhealthy: {str(e)}"
        )
```

### **Logging:**

```python
import logging

logger = logging.getLogger(__name__)

@router.post("/users")
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    try:
        new_user = User(**user.dict())
        db.add(new_user)
        db.commit()
        logger.info(f"User created: {new_user.id}")
        return new_user
    except Exception as e:
        db.rollback()
        logger.error(f"User creation failed: {e}")
        raise HTTPException(status_code=500, detail="User creation failed")
```

---

## 🎯 QUICK REFERENCE

### **Connection Pool Settings:**
```python
pool_size=10           # Max persistent connections
max_overflow=20        # Extra connections if pool full
pool_timeout=30        # Wait time for connection
pool_recycle=3600      # Recycle after 1 hour (prevents stale)
pool_pre_ping=True     # Check connection health
echo=False             # Don't log SQL (True in dev only)
```

### **Relationship Types:**
```python
# One-to-Many: ForeignKey in child, relationship in both
# Many-to-Many (simple): Table + secondary parameter
# Many-to-Many (extra fields): Association Object class
# One-to-One: ForeignKey with unique=True + uselist=False
```

### **ORM vs Raw SQL:**
```python
# ORM: db.query(User).filter(User.id == 1).first()
# Raw: db.execute(text("SELECT * FROM users WHERE id = :id"), {"id": 1})
```

### **Sync vs Async:**
```python
# Sync: db.query(User).all()
# Async: await db.execute(select(User)); result.scalars().all()
```

### **Bulk Operations:**
```python
db.bulk_insert_mappings(User, data)  # Fast insert
db.bulk_update_mappings(User, data)  # Fast update
db.query(User).filter(...).delete()  # Bulk delete
```

---

## 📝 INTERVIEW Q&A

**Q: What is `Base = declarative_base()`?**  
A: Base class that all models inherit from. Registers tables with SQLAlchemy metadata. Used by Alembic to track all tables.

**Q: What is `pool_recycle=3600`?**  
A: Recreates connections every hour to prevent database from killing stale/idle connections.

**Q: Why use Repository Pattern?**  
A: Separates database logic from HTTP handlers. Makes code testable, reusable, and maintainable.

**Q: When to use Async?**  
A: High traffic (1000+ req/sec), I/O heavy operations. Most apps don't need it (sync is simpler).

**Q: How does Alembic track history with one version number?**  
A: Each migration file has `Revises: parent_id` forming a chain (linked list). Alembic walks chain from current to HEAD to find missing migrations.

**Q: ORM vs Raw SQL?**  
A: ORM for simple CRUD (readable, safe). Raw SQL for complex queries (JOINs, GROUP BY, performance).

**Q: What is `extend_existing: True`?**  
A: Allows model redefinition (hot reload in dev). Not needed in production.

**Q: What does `bulk_insert_mappings` do?**  
A: Built-in SQLAlchemy method for fast batch inserts. 100x faster than individual inserts.

---

## ✅ PRODUCTION CHECKLIST

- [ ] Use separate `database.py` for connection
- [ ] Configure connection pooling (`pool_size`, `pool_recycle`, `pool_pre_ping`)
- [ ] Use `get_db()` dependency with `yield` (ensures cleanup)
- [ ] Environment variables for DB URL
- [ ] Use Alembic for migrations (never `create_all()` in prod)
- [ ] Repository pattern for clean architecture
- [ ] Use `cascade="all, delete-orphan"` for relationships
- [ ] Always use `:parameter` syntax in raw SQL (prevent injection)
- [ ] Add indexes on frequently queried columns
- [ ] Health check endpoint
- [ ] Transaction rollback on errors
- [ ] Logging for debugging
- [ ] Use bulk operations for batch processing

---

**Ready to ace your interview!** 🚀
