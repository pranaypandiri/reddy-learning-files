Here's everything we covered today - concise reference:

## 🚀 Today's Learning Summary - Startup Prep

### 1. Batching vs async.gather
```python
# ❌ async.gather = Concurrent execution (NOT batching)
results = await asyncio.gather(fetch(1), fetch(2), fetch(3))  # 3 calls simultaneously

# ✅ Batching = Group items, reduce requests
batch1 = await fetch_batch([1,2,3,4,5])  # 1 call for 5 items
batch2 = await fetch_batch([6,7,8,9,10]) # 1 call for 5 items

# ✅ Combine both
batches = [ids[i:i+100] for i in range(0, len(ids), 100)]
results = await asyncio.gather(*[fetch_batch(b) for b in batches])
```

### 2. Pydantic orm_mode
```python
class UserResponse(BaseModel):
    id: int
    email: str
    
    class Config:
        orm_mode = True  # ✅ Reads from SQLAlchemy objects

# Usage
@app.get("/users/{id}", response_model=UserResponse)
def get_user(id: int, db: Session = Depends(get_db)):
    user = db.query(User).first()
    return user  # ✅ Auto-converts, filters sensitive fields
```

### 3. Custom Validation Error Handler
```python
@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    errors = {}
    for error in exc.errors():
        field = error['loc'][-1]  # Get field name
        errors[field] = error['msg']
    return JSONResponse(status_code=400, content={"error": "Validation failed", "fields": errors})
```

### 4. Router Include Pattern
```python
# routers/users.py
router = APIRouter()

@router.get("/{id}")
def get_user(id: int): ...

# main.py
from routers import users
app.include_router(users.router, prefix="/api/v1/users", tags=["users"])
# users.router = accessing router variable from users module
```

### 5. Transaction Rollback
```python
# ✅ All or nothing
try:
    user = User(name="John")
    db.add(user)
    db.flush()  # Get ID but DON'T commit yet
    
    profile = Profile(user_id=user.id, bio="...")
    db.add(profile)
    db.flush()
    
    db.commit()  # ✅ Commits BOTH together
except Exception:
    db.rollback()  # ✅ Rolls back BOTH

# ✅ With context manager
@contextmanager
def transaction(db):
    try:
        yield db
        db.commit()
    except:
        db.rollback()
        raise

with transaction(db):
    # All operations here
```

### 6. flush() vs commit()
```python
db.add(user)
db.flush()     # Sends to DB, gets ID, stays in transaction
print(user.id) # ✅ Has ID now
db.commit()    # Persists permanently
```

### 7. Environment Variables
```python
from pydantic import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    DATABASE_URL: str
    SECRET_KEY: str
    
    class Config:
        env_file = ".env"

@lru_cache()  # Singleton
def get_settings():
    return Settings()
```

### 8. Connection Dependency
```python
# database.py
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Nested dependency
def get_user_repo(db: Session = Depends(get_db)):
    return UserRepository(db)

@app.post("/users")
def create_user(repo: UserRepository = Depends(get_user_repo)):
    return repo.create(...)
```

### 9. Health Checks
```python
@app.get("/health")
def health(): return {"status": "healthy"}

@app.get("/health/db")
def health_db(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {"status": "healthy", "database": "connected"}
```

### 10. Pagination
```python
@app.get("/users")
def get_users(page: int = 1, per_page: int = 20, db: Session = Depends(get_db)):
    skip = (page - 1) * per_page  # page 1 → skip 0, page 2 → skip 20
    users = db.query(User).offset(skip).limit(per_page).all()
    total = db.query(User).count()
    
    return {
        "items": users,
        "total": total,
        "page": page,
        "total_pages": (total + per_page - 1) // per_page
    }
```

### 11. Eager Loading (N+1 Solution)
```python
from sqlalchemy.orm import joinedload, selectinload

# ❌ N+1 problem
users = db.query(User).all()
for user in users:
    posts = user.posts  # 1 query per user!

# ✅ joinedload - 1 query with LEFT JOIN
users = db.query(User).options(joinedload(User.posts)).all()

# ✅ selectinload - 2 queries with IN (BETTER for large data)
users = db.query(User).options(selectinload(User.posts)).all()
# Query 1: SELECT * FROM users
# Query 2: SELECT * FROM posts WHERE user_id IN (1,2,3,...)
# SQLAlchemy groups by user_id in memory
```

### 12. Async/Await Pitfalls
```python
# ❌ Mixing async/sync wrong
async def get_users(db: Session):  # Session is SYNC!
    users = db.query(User).all()  # Blocks event loop

# ✅ Use sync function with sync DB
def get_users(db: Session):
    users = db.query(User).all()

# ❌ Forgetting await
result = fetch_data()  # Returns coroutine, not data

# ✅ Always await
result = await fetch_data()

# ❌ Sequential (slow)
user = await fetch_user()
posts = await fetch_posts()

# ✅ Parallel (fast)
user, posts = await asyncio.gather(fetch_user(), fetch_posts())
```

### 13. Executor with run_in_executor
```python
loop = asyncio.get_event_loop()

# ✅ Pass None for default executor
result = await loop.run_in_executor(None, heavy_computation)

# ✅ Custom executor
executor = ThreadPoolExecutor(max_workers=4)
result = await loop.run_in_executor(executor, heavy_computation, arg1, arg2)
```

### 14. Indexing
```python
# In code
class User(Base):
    email = Column(String, index=True)  # Creates index
    
    __table_args__ = (
        Index('idx_email_created', 'email', 'created_at'),  # Composite
    )

# Direct SQL (if DB already has index, code doesn't need it)
# SQLAlchemy uses existing indexes automatically
```

### 15. @property (Getters/Setters)
```python
class User:
    def __init__(self, age):
        self._age = None
        self.age = age  # Uses setter
    
    @property
    def age(self):  # Getter
        return self._age
    
    @age.setter
    def age(self, value):  # Setter with validation
        if value < 0:
            raise ValueError("Age cannot be negative")
        self._age = value

user = User(25)
print(user.age)  # Uses getter
user.age = 30    # Uses setter
```

### 16. contextvars + LLM Callbacks
```python
from contextvars import ContextVar

request_id_var: ContextVar[str] = ContextVar('request_id')

@app.middleware("http")
async def add_request_id(request, call_next):
    request_id_var.set(str(uuid.uuid4()))  # Set once
    response = await call_next(request)
    return response

class MyCallback(BaseCallbackHandler):
    def on_llm_start(self, serialized, prompts, **kwargs):
        request_id = request_id_var.get()  # Available everywhere!
        logger.info("LLM started", extra={"request_id": request_id})
```

### 17. Cloud Logging Setup
```python
from google.cloud import logging as cloud_logging

# Setup
client = cloud_logging.Client()
client.setup_logging()  # Attaches to Python logger

# Use standard logging
logger = logging.getLogger(__name__)
logger.info("Message", extra={"user_id": 123})

# Or use log_struct (native GCP)
struct_logger = client.logger("app")
struct_logger.log_struct({
    "message": "User login",
    "user_id": 123
}, severity="INFO")
```

### 18. **kwargs Explained
```python
# Catches all extra parameters you don't specify
def on_llm_start(self, serialized, prompts, **kwargs):
    # serialized and prompts = required
    # kwargs = everything else (run_id, tags, metadata, etc.)
    model = serialized.get("name")
    run_id = kwargs.get("run_id", "unknown")  # Optional use
```

---

**Quick Reference:**
- Batching ≠ async.gather (batching = fewer requests, async.gather = concurrent)
- `flush()` = get ID, stay in transaction | `commit()` = persist
- `skip = (page - 1) × per_page`
- `selectinload` > `joinedload` for 1-to-many
- Always `db.rollback()` in except blocks
- `__name__` = module name, not class name
- `**kwargs` = catch-all for extra parameters

That's everything! 🚀