# Vertex AI Mistral 7B Fine-Tuning - Plan of Action

## Project Overview
**Objective:** Fine-tune Mistral 7B on Vertex AI for IT ticket classification (Software vs Hardware) with production-grade deployment and Pub/Sub integration.

**Use Case:** ServiceNow-style automated ticket routing system

---

## Phase 1: Dataset Preparation

### 1.1 Current Status
- ✅ 300 labeled IT tickets generated (JSONL format)
- ✅ Instruction-based format with system/user/assistant messages
- ✅ 50/50 split between software and hardware categories

### 1.2 Data Processing Tasks
1. **Validation**
   - Verify JSONL format correctness
   - Check for duplicate entries
   - Validate label distribution
   - Ensure message structure consistency

2. **Train/Validation Split**
   - Training set: 80% (240 tickets)
   - Validation set: 20% (60 tickets)
   - Stratified split to maintain class balance
   - Random seed for reproducibility

3. **Test Set Creation**
   - Create separate 50-ticket test set for final evaluation
   - Diverse scenarios not seen in training
   - Edge cases and challenging examples

### 1.3 GCS Upload Structure
```
gs://[YOUR-BUCKET]/vertex-ai-training/
├── datasets/
│   ├── train.jsonl
│   ├── validation.jsonl
│   └── test.jsonl
├── models/
│   └── [output directory for trained model]
└── configs/
    └── training_config.yaml
```

**Required Actions:**
- Create GCS bucket (if not exists)
- Set appropriate IAM permissions
- Upload datasets with versioning enabled

---

## Phase 2: Vertex AI Setup & Configuration

### 2.1 Model Selection
**Base Model:** Mistral 7B (from Model Garden)
- Accessible via Vertex AI Model Garden
- Supports supervised fine-tuning
- Good balance of performance and cost

### 2.2 Fine-Tuning Configuration

**Hyperparameters (Initial):**
```yaml
model: mistralai/Mistral-7B-v0.1
task_type: supervised_fine_tuning

training_parameters:
  epochs: 3-5
  learning_rate: 2e-5
  batch_size: 4
  gradient_accumulation_steps: 4
  warmup_ratio: 0.1
  
lora_config:  # For parameter-efficient fine-tuning
  r: 16
  lora_alpha: 32
  lora_dropout: 0.05
  target_modules: ["q_proj", "v_proj", "k_proj", "o_proj"]
  
evaluation:
  eval_steps: 50
  save_steps: 100
  logging_steps: 10
```

**Compute Resources:**
- Machine type: n1-standard-8 or higher
- Accelerator: 1x NVIDIA T4 or A100 GPU
- Estimated training time: 2-4 hours

### 2.3 Training Pipeline Components
1. **Data Loader**
   - Read from GCS
   - Format validation
   - Tokenization strategy

2. **Training Loop**
   - Loss monitoring
   - Gradient clipping
   - Checkpoint saving

3. **Validation**
   - Per-epoch validation
   - Early stopping criteria
   - Metrics logging

---

## Phase 3: Model Evaluation Strategy

### 3.1 Metrics to Track
- **Accuracy:** Overall classification accuracy
- **Precision/Recall:** Per-class performance
- **F1-Score:** Balanced metric for both classes
- **Confusion Matrix:** Detailed error analysis

### 3.2 Evaluation Workflow
1. **During Training:**
   - Validation loss per epoch
   - Validation accuracy tracking
   - Learning curve visualization

2. **Post-Training:**
   - Test set evaluation
   - Edge case testing
   - Latency benchmarking
   - Cost per inference calculation

### 3.3 Success Criteria
- Minimum accuracy: 90%
- F1-score: > 0.88 for both classes
- Inference latency: < 2 seconds
- No severe class imbalance in predictions

---

## Phase 4: Model Deployment

### 4.1 Vertex AI Endpoint Setup
```python
# Endpoint Configuration
endpoint_config = {
    "display_name": "it-ticket-classifier-mistral-7b",
    "machine_type": "n1-standard-4",
    "min_replica_count": 1,
    "max_replica_count": 5,
    "accelerator_type": "NVIDIA_TESLA_T4",
    "accelerator_count": 1
}
```

### 4.2 Deployment Steps
1. Upload trained model to Vertex AI Model Registry
2. Create endpoint with auto-scaling configuration
3. Deploy model to endpoint
4. Configure health checks and monitoring
5. Test endpoint with sample requests

### 4.3 Endpoint Testing
- Single prediction test
- Batch prediction test
- Load testing (concurrent requests)
- Latency profiling

---

## Phase 5: Pub/Sub Integration Architecture

### 5.1 System Architecture
```
┌─────────────┐
│ IT Ticket   │
│ System      │
└──────┬──────┘
       │
       ▼
┌─────────────────────┐
│ Pub/Sub Topic       │
│ "ticket-input"      │
└──────┬──────────────┘
       │
       ▼
┌─────────────────────┐
│ Cloud Function      │
│ "classify-ticket"   │
│                     │
│ - Parse message     │
│ - Call Vertex AI    │
│ - Format response   │
└──────┬──────────────┘
       │
       ▼
┌─────────────────────┐
│ Vertex AI Endpoint  │
│ Mistral 7B Model    │
└──────┬──────────────┘
       │
       ▼
┌─────────────────────┐
│ Pub/Sub Topic       │
│ "ticket-classified" │
│                     │
│ OR                  │
│                     │
│ Firestore Database  │
└─────────────────────┘
```

### 5.2 Pub/Sub Topic Design

**Input Topic: `ticket-input`**
```json
{
  "ticket_id": "INC0012345",
  "description": "My laptop screen is black and won't turn on",
  "timestamp": "2025-11-26T10:30:00Z",
  "requester": "user@company.com"
}
```

**Output Topic: `ticket-classified`**
```json
{
  "ticket_id": "INC0012345",
  "category": "hardware",
  "confidence": 0.98,
  "model_version": "mistral-7b-v1",
  "processing_time_ms": 450,
  "timestamp": "2025-11-26T10:30:01Z"
}
```

### 5.3 Cloud Function Components

**Function: `classify-ticket`**
- **Trigger:** Pub/Sub message on `ticket-input`
- **Runtime:** Python 3.11
- **Memory:** 512MB
- **Timeout:** 60 seconds
- **Environment Variables:**
  - `VERTEX_AI_ENDPOINT_ID`
  - `VERTEX_AI_PROJECT_ID`
  - `VERTEX_AI_REGION`

**Workflow:**
1. Receive Pub/Sub message
2. Extract ticket description
3. Format for Vertex AI prediction
4. Call endpoint with retry logic
5. Parse model response
6. Publish to output topic / Store in Firestore
7. Log metrics and errors

### 5.4 Error Handling & Reliability
- Message retry on transient failures
- Dead letter queue for failed messages
- Circuit breaker for endpoint failures
- Fallback to rule-based classification
- Comprehensive logging and alerting

---

## Phase 6: Monitoring & Observability

### 6.1 Metrics to Monitor
- **Model Performance:**
  - Prediction accuracy over time
  - Confidence score distribution
  - Class distribution drift
  
- **System Performance:**
  - Endpoint latency (p50, p95, p99)
  - Request throughput
  - Error rates
  - Auto-scaling events

- **Cost Tracking:**
  - Inference costs per day
  - Pub/Sub message costs
  - Storage costs

### 6.2 Logging Strategy
- Vertex AI prediction logs
- Cloud Function execution logs
- Pub/Sub delivery logs
- Model input/output samples for retraining

### 6.3 Alerting Rules
- Endpoint error rate > 5%
- Average latency > 3 seconds
- Model confidence < 0.7 frequently
- Dead letter queue messages accumulating

---

## Phase 7: Testing Plan

### 7.1 Unit Testing
- Data preprocessing functions
- Message parsing logic
- Response formatting
- Error handling paths

### 7.2 Integration Testing
- End-to-end Pub/Sub flow
- Vertex AI endpoint connectivity
- Firestore write operations
- Error recovery scenarios

### 7.3 Load Testing
- Concurrent Pub/Sub messages (100, 500, 1000 msg/s)
- Endpoint auto-scaling behavior
- Message queue backlog handling
- Cost implications at scale

---

## Implementation Timeline

### Week 1: Foundation
- ✅ Day 1-2: Dataset creation and validation
- [ ] Day 3: GCS setup and data upload
- [ ] Day 4: Vertex AI project configuration
- [ ] Day 5: Initial training job submission

### Week 2: Training & Evaluation
- [ ] Day 1-2: Monitor training progress
- [ ] Day 3: Model evaluation on test set
- [ ] Day 4: Hyperparameter tuning (if needed)
- [ ] Day 5: Final model selection

### Week 3: Deployment
- [ ] Day 1-2: Model deployment to endpoint
- [ ] Day 3: Endpoint testing and optimization
- [ ] Day 4-5: Pub/Sub setup and Cloud Function development

### Week 4: Integration & Testing
- [ ] Day 1-2: End-to-end integration testing
- [ ] Day 3: Load testing and performance tuning
- [ ] Day 4: Monitoring and alerting setup
- [ ] Day 5: Documentation and handoff

---

## Prerequisites & Requirements

### GCP Resources Needed
1. **Vertex AI:**
   - Enable Vertex AI API
   - Quota for GPU training
   - Model Garden access

2. **Cloud Storage:**
   - GCS bucket for datasets
   - Lifecycle policies configured

3. **Pub/Sub:**
   - Topics: `ticket-input`, `ticket-classified`
   - Dead letter topic
   - Subscriptions configured

4. **Cloud Functions:**
   - Gen 2 functions enabled
   - Service account with Vertex AI permissions

5. **IAM Permissions:**
   - Vertex AI User
   - Storage Object Admin
   - Pub/Sub Publisher/Subscriber
   - Cloud Functions Developer

### Development Environment
- Python 3.11+
- Google Cloud SDK (`gcloud` CLI)
- Vertex AI SDK (`google-cloud-aiplatform`)
- Local testing environment

---

## Cost Estimation

### Training Costs (One-time)
- GPU training (4 hours @ NVIDIA T4): ~$15-25
- Storage (GCS): ~$1/month
- Total training: ~$25-30

### Inference Costs (Monthly at 10,000 requests/day)
- Vertex AI endpoint (1 replica): ~$200-300/month
- Pub/Sub messages: ~$5/month
- Cloud Functions: ~$10/month
- Total operational: ~$220-320/month

### Cost Optimization Strategies
- Use parameter-efficient fine-tuning (LoRA)
- Implement request batching
- Auto-scale to zero during low traffic
- Consider serverless endpoints for sporadic usage

---

## Risk Mitigation

### Technical Risks
| Risk | Impact | Mitigation |
|------|--------|------------|
| Model underfitting | High | More training data, longer training |
| High inference latency | Medium | Model quantization, GPU acceleration |
| Pub/Sub message loss | High | Dead letter queues, ack timeouts |
| Endpoint downtime | High | Multi-region deployment, fallback logic |

### Business Risks
| Risk | Impact | Mitigation |
|------|--------|------------|
| High operational costs | Medium | Auto-scaling, cost alerts |
| Model drift over time | Medium | Continuous monitoring, retraining pipeline |
| Incorrect classifications | High | Confidence thresholds, human-in-the-loop |

---

## Next Steps

1. **Immediate Actions:**
   - [ ] Review and approve this plan
   - [ ] Set up GCP project and enable APIs
   - [ ] Create GCS bucket structure
   - [ ] Validate dataset quality

2. **Code Development:**
   - [ ] Create dataset split script
   - [ ] Write Vertex AI training script
   - [ ] Develop Cloud Function code
   - [ ] Build evaluation pipeline

3. **Documentation:**
   - [ ] API documentation for endpoint
   - [ ] Runbook for troubleshooting
   - [ ] Model card with performance metrics
   - [ ] Cost analysis report

---

## References & Resources
- [Vertex AI Fine-tuning Documentation](https://cloud.google.com/vertex-ai/docs/training/fine-tune-llm)
- [Mistral AI Model Documentation](https://docs.mistral.ai/)
- [Pub/Sub Best Practices](https://cloud.google.com/pubsub/docs/best-practices)
- [Cloud Functions Python Guide](https://cloud.google.com/functions/docs/writing)

---

**Document Version:** 1.0  
**Last Updated:** 26 November 2025  
**Owner:** Vertex AI Training Pipeline Project
