"""
Submit Mistral-7B Fine-Tuning Job to Vertex AI - WITH PYTHON PACKAGE
Uses T4 GPU (cheapest option - ~$0.35/hour)
"""

from google.cloud import aiplatform
import datetime
import subprocess
import os

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ID = "ai-practice-388514"
REGION = "us-central1"
STAGING_BUCKET = (
    "gs://vertex-ai-mistral-training-ai-practice/vertex-ai-mistral-training"
)

# Job configuration
JOB_NAME = f"mistral-it-classifier-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}"

# T4 GPU - Smallest & Cheapest (~$0.35/hour)
MACHINE_TYPE = "n1-standard-4"
ACCELERATOR_TYPE = "NVIDIA_TESLA_T4"
ACCELERATOR_COUNT = 1

# Container - Using PyTorch 2.0 container
CONTAINER_URI = "us-docker.pkg.dev/vertex-ai/training/pytorch-gpu.2-0.py310:latest"

# Python module
PYTHON_MODULE = "train_modern"  # Without .py extension

# ============================================================================
# MAIN SUBMISSION
# ============================================================================


def submit_training_job():
    """Submit training job to Vertex AI with Python package"""

    print("=" * 80)
    print("🚀 SUBMITTING MISTRAL-7B TRAINING JOB TO VERTEX AI")
    print("=" * 80)

    # STEP 1: Create Python package
    print("\n📦 Step 1/4: Creating Python package...")
    print("  Running: python setup.py sdist --formats=gztar")

    result = subprocess.run(
        "python setup.py sdist --formats=gztar",
        shell=True,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        print(f"  ❌ Error creating package:")
        print(result.stderr)
        raise RuntimeError("Failed to create package")

    print("  ✅ Package created in dist/")

    # Find the created package
    import glob

    package_files = glob.glob("dist/*.tar.gz")
    if not package_files:
        raise RuntimeError("No package file found in dist/")

    local_package = package_files[0]
    print(f"  📦 Package file: {local_package}")

    # STEP 2: Upload to GCS
    print("\n📤 Step 2/4: Uploading package to GCS...")
    package_gcs_uri = f"{STAGING_BUCKET}/training-package/trainer.tar.gz"

    upload_cmd = f"gsutil cp {local_package} {package_gcs_uri}"
    print(f"  Running: {upload_cmd}")

    result = subprocess.run(upload_cmd, shell=True, capture_output=True, text=True)

    if result.returncode != 0:
        print(f"  ❌ Error uploading:")
        print(result.stderr)
        raise RuntimeError("Failed to upload package")

    print(f"  ✅ Uploaded to: {package_gcs_uri}")

    # STEP 3: Initialize Vertex AI
    print("\n🔧 Step 3/4: Initializing Vertex AI...")
    aiplatform.init(project=PROJECT_ID, location=REGION, staging_bucket=STAGING_BUCKET)
    print("  ✅ Vertex AI initialized")

    # STEP 4: Create and submit job
    print("\n🚀 Step 4/4: Creating and submitting training job...")
    print(f"\n📋 Job Configuration:")
    print(f"  Project: {PROJECT_ID}")
    print(f"  Region: {REGION}")
    print(f"  Job Name: {JOB_NAME}")
    print(f"  Machine: {MACHINE_TYPE}")
    print(f"  GPU: {ACCELERATOR_TYPE} x{ACCELERATOR_COUNT}")
    print(f"  Python Package: {package_gcs_uri}")
    print(f"  Python Module: {PYTHON_MODULE}")
    print(f"\n💰 Estimated Cost: ~$0.50-0.70 (T4 GPU for 15-20 min)")

    # Create training job using Python package
    job = aiplatform.CustomPythonPackageTrainingJob(
        display_name=JOB_NAME,
        python_package_gcs_uri=package_gcs_uri,
        python_module_name=PYTHON_MODULE,
        container_uri=CONTAINER_URI,
    )

    print("\n  ✅ Job created!")
    print(
        f"  🔗 Monitor at: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={PROJECT_ID}"
    )

    # Submit the job
    print("\n  🚀 Submitting to Vertex AI...")

    job.run(
        replica_count=1,
        machine_type=MACHINE_TYPE,
        accelerator_type=ACCELERATOR_TYPE,
        accelerator_count=ACCELERATOR_COUNT,
        sync=False,  # Don't wait
    )

    print("\n" + "=" * 80)
    print("✅ JOB SUBMITTED SUCCESSFULLY!")
    print("=" * 80)
    print(f"\n📊 Job Details:")
    print(f"  Name: {job.display_name}")
    print(f"  Resource Name: {job.resource_name}")

    print(f"\n📍 Monitor Progress:")
    print(
        f"  Console: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={PROJECT_ID}"
    )

    print(f"\n⏱️  Expected Timeline:")
    print(f"  • Setup: 2-3 minutes")
    print(f"  • Training: 15-20 minutes")
    print(f"  • Total: ~18-25 minutes")

    print(f"\n💾 Model Will Be Saved To:")
    print(f"  {STAGING_BUCKET}/model/")

    print("\n" + "=" * 80)
    print("🎉 Training job is running in the cloud!")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    try:
        submit_training_job()
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        print("\nCommon fixes:")
        print("  1. Run: gcloud auth application-default login")
        print("  2. Run: gcloud services enable aiplatform.googleapis.com")
        print("  3. Check setup.py exists")
        raise
