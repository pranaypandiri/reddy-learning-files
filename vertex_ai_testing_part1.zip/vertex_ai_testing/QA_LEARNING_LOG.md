# Q&A Learning Log - Vertex AI Training Project

## Dataset Splitting Concepts

---

### Q1: What are the best approaches for splitting the dataset?

**Answer:**
Three main approaches for splitting JSONL dataset:

1. **Scikit-learn (Recommended for this project)**
   - Simple, fast, stratified split
   - Perfect for 300 JSONL records
   - Maintains class balance with `stratify` parameter
   - No heavy dependencies

2. **HuggingFace Datasets**
   - Built-in split functions
   - Good if using HF ecosystem
   - Can push to HF Hub
   - Overkill for simple JSONL split

3. **Manual Python**
   - Full control
   - More code required
   - Need to manually ensure stratification

**Decision:** Using scikit-learn as primary with HuggingFace commented for reference

---

### Q2: How does `split_with_sklearn()` function work?

**Answer:**
The function splits 300 IT tickets into train/validation/test sets with these steps:

**Step 1: Load Data**
```python
data = load_jsonl(INPUT_FILE)  # 300 tickets
```

**Step 2: Extract Labels**
```python
labels = extract_labels(data)  # ['software', 'hardware', ...]
```
Required for stratification to maintain 50/50 software/hardware ratio

**Step 3: First Split (Test Set)**
```python
train_val_data, test_data = train_test_split(
    data, labels,
    test_size=0.15,      # 15% = 45 tickets
    stratify=labels      # Keep class balance
)
```
Result: 255 tickets (train+val) + 45 tickets (test)

**Step 4: Second Split (Train/Validation)**
```python
val_size_adjusted = 0.15 / 0.85  # 15% of original
train_data, val_data = train_test_split(
    train_val_data,
    test_size=val_size_adjusted,  # ~17.6% of 255
    stratify=train_val_labels
)
```
Result: 210 tickets (train) + 45 tickets (val)

**Step 5: Save Files**
```python
save_jsonl(train_data, "datasets/train.jsonl")       # 210 tickets
save_jsonl(val_data, "datasets/validation.jsonl")     # 45 tickets
save_jsonl(test_data, "datasets/test.jsonl")          # 45 tickets
```

**Why Stratify?**
- **Without:** Random split might give 70% software in train, 30% in test
- **With:** Each split maintains ~50% software, ~50% hardware
- **Benefit:** Model trains on balanced data, evaluated fairly

---

### Q3: What is the purpose of random seed (RANDOM_SEED = 42)?

**Answer:**
**Purpose:** Reproducibility of experiments

**Without Random Seed:**
- Run script today → Train gets tickets [1, 5, 8, 12...]
- Run script tomorrow → Train gets tickets [3, 9, 15, 20...] ← Different!
- Cannot compare results between runs

**With Random Seed (42):**
- Run script today → Train gets tickets [1, 5, 8, 12...]
- Run script tomorrow → Train gets tickets [1, 5, 8, 12...] ← Same!
- Reproducible experiments, fair comparisons

**Where Used:**
```python
random.seed(RANDOM_SEED)  # For Python's random module
train_test_split(..., random_state=RANDOM_SEED)  # For sklearn
```

**Real-world Benefit:**
- Train model today: 92% accuracy
- Next week with different hyperparameters
- Same train/val/test split = fair comparison
- Can reproduce best results anytime

**Why 42?**
Famous reference from "The Hitchhiker's Guide to the Galaxy" where supercomputer answered "42" to "life, the universe, and everything" after 7.5 million years. Became programmer tradition. Any number works (42, 123, 2025), just keep it consistent!

---

### Q4: How does random seed mechanism actually work?

**Answer:**
Computers generate **pseudo-random** numbers using deterministic algorithms.

**The Mechanism:**

**Pseudo-random Algorithm (simplified):**
```python
next_random = (previous_number * 1103515245 + 12345) % 2^31
```

**Same input → Same output (deterministic formula)**

**Without Seed (Different Every Time):**
```python
seed = current_time_milliseconds()  # e.g., 1732694523891
random.shuffle(data)  # Different each run
```

**With Seed = 42 (Same Every Time):**
```python
seed = 42  # Starting point

# Sequence of "random" numbers generated:
random_1 = (42 * 1103515245 + 12345) % 2^31     = 1234567
random_2 = (1234567 * 1103515245 + 12345) % 2^31 = 9876543
random_3 = (9876543 * 1103515245 + 12345) % 2^31 = 5551234
```

**Same sequence EVERY time starting with 42!**

**In Dataset Split:**
```python
random.seed(42)
train_test_split(..., random_state=42)

# Internally generates same shuffle positions:
# Position 1 → ticket index 234
# Position 2 → ticket index 17
# Position 3 → ticket index 189
# ... always the SAME sequence
```

**Visual Example:**
```
Seed 42:  [3, 7, 1, 9, 2, 5] ← Always this shuffle
Seed 42:  [3, 7, 1, 9, 2, 5] ← Same again!

Seed 99:  [5, 2, 9, 1, 7, 3] ← Different shuffle
Seed 99:  [5, 2, 9, 1, 7, 3] ← But consistent for 99
```

**Key Insight:** Not truly random - it's a **reproducible sequence** that appears random. Perfect for scientific experiments!

---

## Commands Reference

### Run Dataset Split Script
```bash
cd vertex_ai_testing
python split_dataset.py
```

**Expected Output:**
- Creates `datasets/` folder
- Generates `train.jsonl` (210 records)
- Generates `validation.jsonl` (45 records)
- Generates `test.jsonl` (45 records)
- Shows statistics for each split

---

---

### Q5: GCS Upload - CLI vs Python SDK (Blob)?

**Three approaches:**

1. **gcloud CLI** - `gcloud storage cp`
   - Already installed, simple, works immediately
   - Shell subprocess calls

2. **gsutil CLI** - `gsutil cp` (deprecated)
   - Legacy, being replaced by gcloud storage

3. **Python SDK (Blob)** - `google.cloud.storage` ✅ **Used**
   - Pure Python, no subprocess
   - Better error handling and progress tracking
   - Sets content-type automatically
   - More production-ready

**Code:**
```python
from google.cloud import storage

client = storage.Client(project=PROJECT_ID)
bucket = client.get_bucket(BUCKET_NAME)
blob = bucket.blob(gcs_path)
blob.upload_from_filename(local_file, content_type='application/json')
```

**GCS URIs created:**
- `gs://vertex-ai-mistral-training-ai-practice/vertex-ai-mistral-training/datasets/train.jsonl`
- `gs://vertex-ai-mistral-training-ai-practice/vertex-ai-mistral-training/datasets/validation.jsonl`
- `gs://vertex-ai-mistral-training-ai-practice/vertex-ai-mistral-training/datasets/test.jsonl`

---

## Progress Tracker

1. ✅ Dataset created (300 IT tickets)
2. ✅ Dataset split (train: 185, val: 40, test: 40)
3. ✅ GCS bucket created and files uploaded
4. ⏳ Vertex AI training script
5. ⏳ Submit training job (Mistral 7B fine-tuning)
6. ⏳ Model evaluation
7. ⏳ Deploy to endpoint
8. ⏳ Pub/Sub integration

---

**Last Updated:** 27 November 2025
