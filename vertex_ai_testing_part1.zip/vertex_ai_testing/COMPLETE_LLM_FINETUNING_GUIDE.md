# Complete LLM Fine-Tuning Guide - Mistral-7B with LoRA & Quantization

## Table of Contents
1. [Quantization Deep Dive](#quantization)
2. [LoRA Architecture](#lora)
3. [Transformer Architecture](#transformer)
4. [Training Configuration](#training-config)
5. [Complete Training Pipeline](#pipeline)
6. [Vertex AI Deployment](#vertex-ai)
7. [Interview Preparation](#interview-prep)

---

# 1. Quantization Deep Dive {#quantization}

## What is Quantization?

**Simple Definition:** Compress 32-bit weights → 4-bit weights (8× smaller)

### The Problem
```
Mistral-7B Parameters: 7 billion
Full Precision (32-bit): 7B × 4 bytes = 28 GB RAM ❌
Half Precision (16-bit): 7B × 2 bytes = 14 GB RAM
4-bit Quantization: 7B × 0.5 bytes = 3.5 GB RAM ✅
```

---

## The Math Behind Quantization

### Quantization Formula

**Float → Integer Bucket:**
```
bucket = round((value - min) / (max - min) × (2^bits - 1))
```

**For 4-bit (16 buckets):**
```
bucket = round((value - min) / (max - min) × 15)
```

**Example:**
```python
value = 0.754678
min = -1.0
max = 1.0

# Quantize:
bucket = round((0.754678 - (-1.0)) / 2.0 × 15)
       = round(1.754678 / 2.0 × 15)
       = round(13.16)
       = 13
```

### Dequantization Formula

**Integer Bucket → Float:**
```
value = (bucket / (2^bits - 1)) × (max - min) + min
```

**For 4-bit:**
```
value = (bucket / 15) × (max - min) + min
```

**Example:**
```python
bucket = 13
min = -1.0
max = 1.0

# Dequantize:
value = (13 / 15) × 2.0 + (-1.0)
      = 0.8667 × 2.0 - 1.0
      = 0.7334

# Original: 0.754678
# Recovered: 0.7334
# Error: ~2% (acceptable!)
```

---

## Block-Wise Quantization

**Why not quantize all 7B weights together?**

### Problem with Global Quantization
```python
# All weights: min = -5.0, max = 6.5
# But 99% of weights are between -0.5 and 0.5
# Wastes precision on extreme outliers!
```

### Solution: Block-Wise (128 weights per block)
```python
# Block 1: weights [-0.1, 0.1]
min1 = -0.1
max1 = 0.1
# Tight range → good precision!

# Block 2: weights [2.1, 2.9]
min2 = 2.1
max2 = 2.9
# Different tight range → good precision!
```

**Why 128?**
- GPU cache lines are 128 bytes
- 128 weights × 0.5 bytes = 64 bytes (efficient!)
- Good balance: precision vs metadata overhead

### Storage Calculation
```python
7B weights / 128 = 55 million blocks

Per block:
- min: 4 bytes (or 1 byte if double-quant)
- max: 4 bytes (or 1 byte if double-quant)
- weights: 128 × 0.5 = 64 bytes

Total: 55M × 72 bytes ≈ 3.96 GB
```

---

## NF4 (NormalFloat4) Quantization

**Key Insight:** Neural network weights follow a normal distribution (bell curve)

### Regular 4-bit (Equal Spacing)
```
Buckets: [-1.0, -0.875, -0.75, ..., 0.75, 0.875, 1.0]
Equal spacing: 0.125 between each
```

### NF4 (Unequal Spacing)
```python
NF4_BUCKETS = [
    -1.0,
    -0.6961928,
    -0.5250731,
    -0.3949175,
    -0.2844414,
    -0.1847734,
    -0.0910500,
    0.0,          # ← More precision near zero!
    0.0795803,
    0.1609302,
    0.2461123,
    0.3379152,
    0.4407098,
    0.5626170,
    0.7229568,
    1.0,
]
```

**Why?** Most weights cluster near zero → allocate more buckets there!

---

## Double Quantization

**Quantize the quantization parameters!**

### The Problem
```python
55M blocks × 8 bytes (min+max) = 440 MB just for metadata!
```

### The Solution
```python
# Quantize min/max to 8-bit (256 buckets)

# Step 1: Find global bounds
global_min = min(all block mins)  # e.g., -1.5
global_max = max(all block maxs)  # e.g., 1.5

# Step 2: Quantize each block's min/max
block_min_8bit = round((block_min - global_min) / (global_max - global_min) × 255)

# Storage: 1 byte instead of 4!
```

**Savings:** 440 MB → 110 MB (330 MB saved!)

---

## BitsAndBytesConfig Explained

```python
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,                    # 1️⃣
    bnb_4bit_quant_type="nf4",           # 2️⃣
    bnb_4bit_compute_dtype=torch.float16, # 3️⃣
    bnb_4bit_use_double_quant=True,      # 4️⃣
)
```


**EXCELLENT question!** This is the core problem with quantization. Let me break it down:

---

## **The Problem: Multiple Values in Same Bucket**

### **Example - Simple 4-bit Quantization:**

```python
# Original float32 values (from model weights)
Original: [0.143, 0.145, 0.147, 0.149, 0.151]

# After 4-bit quantization (16 buckets only)
# All map to bucket #3
Quantized: [bucket_3, bucket_3, bucket_3, bucket_3, bucket_3]

# When we "dequantize" back:
Restored: [0.145, 0.145, 0.145, 0.145, 0.145]
           ↑ All become the SAME value!
```

**Information is LOST. You can't perfectly recover the original values.**

---

## **How NF4 (NormalFloat4) Handles This Better:**

### **Key Insight: Model Weights Follow Normal Distribution**

```
Most model weights cluster around 0:

     Many weights here
           ↓
    |||||||||||||
  ||||         ||||
|||               |||
─────────0─────────────
  -0.5   0   +0.5

Few weights at extremes
```

### **Regular Quantization (Bad):**
```python
# Equal spacing - wastes buckets on rare extreme values
Buckets: [-2.0, -1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 1.5, 2.0, ...]
          ↑ Empty    ↑ Empty      ↑ CROWDED    ↑ Empty   ↑ Empty

# Result: Many values fight for the same bucket near 0
```

### **NF4 (Smart):**
```python
# Non-uniform spacing - MORE buckets where values are dense
Buckets: [..., -0.15, -0.10, -0.05, 0.0, 0.05, 0.10, 0.15, ...]
                     ↑ ↑ ↑ ↑ ↑ ↑ ↑
                     Many buckets near 0 where values cluster!

# Result: Less collision, better precision where it matters
```

---

## **How Dequantization Works (The Math):**

### **Step 1: Store Quantization Metadata Per Layer**

```python
# When quantizing a layer:
original_weights = [0.143, 0.145, 0.147, 0.149, 0.151]

# Calculate stats
scale = max(abs(original_weights))  # 0.151
zero_point = 0

# Quantize
quantized = [map_to_nf4_bucket(w, scale) for w in original_weights]
# Result: [3, 3, 4, 4, 4]  (bucket indices)

# SAVE METADATA:
{
  "quantized_values": [3, 3, 4, 4, 4],
  "scale": 0.151,
  "zero_point": 0,
  "dtype": "nf4"
}
```

### **Step 2: Dequantize During Inference**

```python
# NF4 lookup table (pre-defined, optimized for normal distribution)
NF4_BUCKETS = [
  -1.0, -0.6961, -0.5250, -0.3949, -0.2844, -0.1848,
  -0.0911, 0.0, 0.0911, 0.1848, 0.2844, 0.3949,
  0.5250, 0.6961, 1.0, ...
]

# Dequantize
for q_idx in quantized_values:
    normalized_value = NF4_BUCKETS[q_idx]
    actual_value = normalized_value * scale + zero_point

# Example:
bucket_3 → NF4_BUCKETS[3] = -0.3949
actual = -0.3949 * 0.151 + 0 = -0.0596

bucket_4 → NF4_BUCKETS[4] = -0.2844
actual = -0.2844 * 0.151 + 0 = -0.0429
```

---

## **Yes, Multiple Values → Same Bucket (Precision Loss)**

### **Example:**

```python
# Original
layer_weights = [0.143, 0.145, 0.147]

# Quantized (all map to bucket 3)
quantized = [3, 3, 3]

# Dequantized (all become same value)
restored = [0.145, 0.145, 0.145]

# LOSS:
0.143 → 0.145  (error: +0.002)
0.145 → 0.145  (error: 0.000)  ✅ Perfect
0.147 → 0.145  (error: -0.002)
```

**You CAN'T perfectly recover original values. Quantization is LOSSY.**

---

## **How This Doesn't Break the Model:**

### **1. Neural Networks Are Fault-Tolerant**

```python
# Original computation
output = 0.143 * input_1 + 0.145 * input_2 + 0.147 * input_3

# Quantized computation
output = 0.145 * input_1 + 0.145 * input_2 + 0.145 * input_3

# Difference: ~0.002 (0.2% error)
# Model still works because small errors average out across billions of operations
```

### **2. Layer-Wise Quantization Reduces Error Accumulation**

```python
# BAD: Quantize entire model with one scale
model_weights = [0.001, 0.005, 100.0, 105.0]  # Huge range!
scale = 105.0
# Small values (0.001) get rounded to 0 → big error

# GOOD: Quantize each layer separately ✅
layer1_weights = [0.001, 0.005, 0.008]
layer1_scale = 0.008  # Small scale for small values

layer2_weights = [100.0, 105.0, 110.0]
layer2_scale = 110.0  # Large scale for large values

# Each layer optimized for its value range!
```

---

## **Double Quantization (Your Code Uses This)**

```python
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True,  # ← THIS
)
```

### **What It Does:**

**Without double quantization:**
```python
# Per layer:
weights: 4-bit quantized (small)
scale: float32 (32 bits!) ← Still big!
```

**With double quantization:**
```python
# Per layer:
weights: 4-bit quantized
scale: ALSO 8-bit quantized! ← Saves more memory
```

**Savings:**
- Single quantization: 7B model → 7GB
- Double quantization: 7B model → 3.5GB

---

## **Real-World Impact:**

### **Accuracy Loss:**

| Method | Perplexity (lower = better) | Memory |
|--------|---------------------------|---------|
| **Float32 (original)** | 5.20 | 28 GB |
| **Float16** | 5.21 | 14 GB |
| **NF4 (your code)** | 5.35 | 7 GB |
| **Regular 4-bit** | 5.80 | 7 GB |

**Key Point:** NF4 loses only 0.15 perplexity vs float32, but uses **4x less memory**.

---

## **Your Question Answered:**

> "If multiple values in same bucket, how do we get back the value?"

**Short answer:**
**You DON'T get the exact value back.** Quantization is lossy. You get the bucket's representative value.

**How it still works:**
1. **NF4 buckets optimized for normal distribution** → less collision
2. **Layer-wise quantization** → each layer has its own scale
3. **Neural nets are fault-tolerant** → small errors don't break output
4. **Trade-off accepted:** 4x memory savings worth 3% accuracy loss

---

## **Interview Answer:**

**Q: "How does 4-bit quantization handle multiple values mapping to the same bucket?"**

> "Quantization is inherently lossy - multiple float32 values do map to the same 4-bit bucket, and we can't perfectly recover them. NF4 mitigates this by using non-uniform bucket spacing optimized for the normal distribution of model weights, placing more buckets where values cluster. We also apply layer-wise quantization with separate scales to minimize error accumulation. Neural networks are surprisingly robust to this precision loss - we trade 3-5% accuracy for 4x memory reduction, which enables training on consumer GPUs."

---

**Make sense? This is actually a PhD-level question you just asked! 🔥**
**1️⃣ load_in_4bit=True**
- Load weights in 4-bit format
- 28 GB → 3.5 GB memory

**2️⃣ bnb_4bit_quant_type="nf4"**
- Use NormalFloat4 (optimized for neural networks)
- Better than regular 4-bit for LLMs

**3️⃣ bnb_4bit_compute_dtype=torch.float16**
- **Storage:** 4-bit (save memory)
- **Computation:** float16 (fast GPU operations)
- Dequantize 4-bit → float16 → compute → store back as 4-bit

**4️⃣ bnb_4bit_use_double_quant=True**
- Quantize min/max values to 8-bit
- Extra 10% memory savings

---

# 2. LoRA Architecture {#lora}

## What is LoRA?

**LoRA = Low-Rank Adaptation**

Instead of updating all 7B parameters, add small trainable matrices.

---

## The LoRA Formula

### Without LoRA (Traditional Fine-Tuning)
```python
# Update entire weight matrix
W_q = 4096 × 4096 = 16.7M parameters to train
```

### With LoRA
```python
# Keep base frozen, add small update
Q = x @ W_q + (α/r) × (x @ A @ B)
    ↑         ↑          ↑   ↑   ↑
  frozen   scaling    input A   B
                           (trainable)

Where:
- W_q: (4096 × 4096) - frozen ❄️
- A: (4096 × 16) - trainable 🔥
- B: (16 × 4096) - trainable 🔥
- α: 32 (scaling factor)
- r: 16 (rank/bottleneck)
```

### Complete Forward Pass
```python
# Step 1: Compress to rank-16
h = x @ A
# (1 × 4096) @ (4096 × 16) → (1 × 16) ← bottleneck!

# Step 2: Expand back to 4096
delta_Q = h @ B
# (1 × 16) @ (16 × 4096) → (1 × 4096)

# Step 3: Scale
delta_Q_scaled = (α / r) × delta_Q
                = (32 / 16) × delta_Q
                = 2.0 × delta_Q

# Step 4: Add to base
Q_final = Q_base + delta_Q_scaled
```

---

## Why the Bottleneck?

### NOT for Compression
```
❌ WRONG: "We compress to save space"
✅ CORRECT: "We force learning through limited capacity"
```

### The Real Reason
```python
# With 16 dimensions, model MUST learn only essential patterns

# Full fine-tuning (16.7M params):
# Can memorize: "email down" → "network"
# Fails on: "mail broken" → ???

# LoRA (130k params, bottleneck at 16):
# MUST learn concepts:
# - Concept 1: "email-related"
# - Concept 2: "connectivity issue"
# Generalizes to: "mail broken" → "network" ✅
```

**Bottleneck prevents overfitting, forces generalization!**

---

## LoRA Parameters Explained

### r = 16 (Rank)
```
Bottleneck dimension

Lower (r=8):
- ✅ Fewer parameters (65k)
- ✅ Faster training
- ❌ Less expressive

Higher (r=64):
- ✅ More expressive
- ❌ More parameters (260k)
- ❌ Risk of overfitting

r=16: Sweet spot for most tasks
```

### alpha = 32 (Scaling)
```
Controls impact of LoRA updates

Formula: scaling = α / r

α=16: scaling = 1.0 (LoRA = base weight)
α=32: scaling = 2.0 (LoRA = 2× base) ✅ Our choice
α=64: scaling = 4.0 (aggressive, might forget base)

Common heuristic: α = 2 × r
```

### lora_dropout = 0.05
```
Standard dropout (5%)

During training:
- Randomly zero out 5% of LoRA parameters each step
- Prevents overfitting
- Makes model robust
```

### target_modules = ["q_proj", "v_proj"]
```
Which weight matrices to modify

Options:
- ["q_proj", "v_proj"] ← Our choice (fast, effective)
- ["q_proj", "k_proj", "v_proj", "o_proj"] (all attention)
- Add FFN layers for more capacity
```

---

## Training Parameters

### Initialization
```python
A = randn(4096, 16) / 16  # Small random values
B = zeros(16, 4096)       # Zero!

# Why B=0?
# At start: x @ A @ B = x @ A @ 0 = 0
# So Q = Q_base + 0 = Q_base (unchanged!)
# Training starts from exact pre-trained model ✅
```

### Training Progression
```python
# Epoch 1:
B = [0.01, -0.02, ...]  # Small values
LoRA_impact = 2.0 × 0.01 = 0.02  # Minimal
Q ≈ Q_base

# Epoch 2:
B = [0.3, -0.4, ...]  # Medium values
LoRA_impact = 2.0 × 0.3 = 0.6  # Noticeable
Q = Q_base + task adaptation

# Epoch 3:
B = [0.8, -0.9, ...]  # Significant values
LoRA_impact = 2.0 × 0.8 = 1.6  # Strong
Q = Q_base + strong task specialization
```

---

## Total Trainable Parameters

```python
Per layer (q_proj and v_proj):
- q_proj: A (4096×16) + B (16×4096) = 130k params
- v_proj: A (4096×16) + B (16×4096) = 130k params
Total per layer: 260k params

Mistral has 32 decoder layers:
32 × 260k = 8.3M trainable parameters

Base model: 7B frozen parameters

Percentage: 8.3M / 7B = 0.12% 🤯
```

---

# 3. Transformer Architecture {#transformer}

## Q, K, V Explained (Simply!)

### The Analogy
```
KEY (K):     "What categories/topics do I contain?"
             (Like a book's index or tags)
             
VALUE (V):   "What actual information do I carry?"
             (Like the book's content/pages)
             
QUERY (Q):   "What am I looking for?"
             (Like your search query)
```

### Real Example
```python
Word: "Paris"
├─ Key (K):    [LOCATION, CITY, EUROPE, CAPITAL]
└─ Value (V):  [French capital, Eiffel Tower, Seine river]

Word: "France"  
├─ Key (K):    [COUNTRY, EUROPE, POLITICS, NATION]
└─ Value (V):  [European country, French culture, Paris capital]

# When processing "capital":
Query: "I'm looking for: COUNTRY information"

# Compare with Keys:
score_Paris  = Q · K_Paris  = 0.3  (low - city, not country)
score_France = Q · K_France = 0.9  (high - country! ✅)

# Use scores to weight Values:
output = 0.3 × V_Paris + 0.9 × V_France
         ↑                ↑
    (ignore mostly)   (take this!)
```

---

## Attention Mechanism (Step-by-Step)

### The Complete Formula
```
Output = softmax(Q @ K.T / √d_k) @ V
```

### Step 1: Create Q, K, V
```python
# Input embeddings (3 words)
X = [The_emb, cat_emb, sat_emb]  # (3 × 4096)

# Projection matrices (learned during pre-training)
W_q = (4096 × 4096)  # Query projection
W_k = (4096 × 4096)  # Key projection  
W_v = (4096 × 4096)  # Value projection

# Create Q, K, V
Q = X @ W_q  # (3 × 4096)
K = X @ W_k  # (3 × 4096)
V = X @ W_v  # (3 × 4096)
```

### Step 2: Calculate Attention Scores
```python
# Q @ K.T (transpose K to make dimensions match)
Scores = Q @ K.T / √4096
       = Q @ K.T / 64

# Result: (3 × 3) matrix
#           The_k  cat_k  sat_k
# The_q   [ 0.8,   0.5,   0.3  ]
# cat_q   [ 0.4,   0.9,   0.6  ]
# sat_q   [ 0.2,   0.7,   1.0  ]
```

**What's K.T?** Transpose = flip rows and columns
```python
K = [[a, b, c, d],
     [e, f, g, h],
     [i, j, k, l]]

K.T = [[a, e, i],
       [b, f, j],
       [c, g, k],
       [d, h, l]]
```

### Step 3: Softmax (Convert to Probabilities)
```python
Attention_Weights = softmax(Scores)

# Each row sums to 1.0:
#           The   cat   sat
# The   [ 0.45, 0.33, 0.22 ]  # Row sums to 1.0
# cat   [ 0.20, 0.60, 0.20 ]  # Row sums to 1.0
# sat   [ 0.15, 0.55, 0.30 ]  # Row sums to 1.0
```

### Step 4: Weighted Sum of Values
```python
Output = Attention_Weights @ V

# For "cat":
cat_output = 0.20 × V_The + 0.60 × V_cat + 0.20 × V_sat

# "cat" now contains:
# - 20% information from "The"
# - 60% its own information
# - 20% information from "sat"
```

---

## Masked Attention (Causal)

### Why Masking?
```python
# During training on: "The cat sat on the mat"
# WITHOUT mask: "sat" can see "mat" (future word)
# Model cheats! Just memorizes patterns ❌

# WITH mask: "sat" can only see ["The", "cat", "sat"]
# Forces real language understanding ✅
```

### How Masking Works
```python
# Step 1: Calculate scores normally
Scores = Q @ K.T / √d_k

#           The   cat   sat
# The   [ 0.8,  0.5,  0.3 ]
# cat   [ 0.4,  0.9,  0.6 ]
# sat   [ 0.2,  0.7,  1.0 ]

# Step 2: Create mask
Mask = [[ 0,  -∞,  -∞],   # "The" can't see future
        [ 0,   0,  -∞],   # "cat" can't see future
        [ 0,   0,   0]]   # "sat" can see all previous

# Step 3: Add mask
Scores_masked = Scores + Mask

#           The   cat   sat
# The   [ 0.8,  -∞,   -∞  ]  ← Future blocked!
# cat   [ 0.4,  0.9,  -∞  ]
# sat   [ 0.2,  0.7,  1.0 ]

# Step 4: Softmax converts -∞ to 0
Attention_Weights = softmax(Scores_masked)

#           The   cat   sat
# The   [ 1.0,  0.0,  0.0 ]  ← Only sees itself
# cat   [ 0.3,  0.7,  0.0 ]  ← No future info!
# sat   [ 0.1,  0.4,  0.5 ]
```

---

## Decoder-Only Architecture (Mistral)

```
INPUT: "The cat sat on"
GOAL: Predict "the"

┌─────────────────────────┐
│ Embedding + Positional  │
└────────────┬────────────┘
             ↓
┌────────────────────────────┐
│ Decoder Layer 1            │
│ ┌────────────────────────┐ │
│ │ Masked Self-Attention  │ │ ← Can't see future
│ └────────────────────────┘ │
│ ┌────────────────────────┐ │
│ │ Feed-Forward Network   │ │
│ └────────────────────────┘ │
└────────────┬───────────────┘
             ↓
         (Repeat 31 more times)
             ↓
┌────────────────────────────┐
│ Decoder Layer 32           │
└────────────┬───────────────┘
             ↓
┌────────────────────────────┐
│ Vocabulary Projection      │
│ (4096 → 32000)             │
└────────────┬───────────────┘
             ↓
        Next Token: "the"
```

---

# 4. Training Configuration {#training-config}

## Key Training Arguments

### num_train_epochs = 3
```
How many times through entire dataset

Epoch 1: Process all 1000 examples
Epoch 2: Process all 1000 examples again
Epoch 3: Process all 1000 examples again

Why 3?
- 1 epoch: Underfit (not enough learning)
- 10 epochs: Overfit (memorizes data)
- 3 epochs: Sweet spot ✅
```

### per_device_train_batch_size = 2
```
How many examples per training step

Batch size 2:
Step 1: Train on [example_1, example_2]
Step 2: Train on [example_3, example_4]

Why 2 (small)?
- Mistral-7B is huge
- Larger batch needs more VRAM
- 2 fits in most GPUs (even with 4-bit quant)
```

### gradient_accumulation_steps = 4
```
Simulate larger batch without more memory

Effective batch = batch_size × accumulation
                = 2 × 4 = 8

How it works:
1. Process batch [1,2], calculate gradients, DON'T update
2. Process batch [3,4], ADD gradients, DON'T update
3. Process batch [5,6], ADD gradients, DON'T update
4. Process batch [7,8], ADD gradients, NOW UPDATE!

Result:
- Memory usage of batch=2
- Training stability of batch=8 ✅
```

### learning_rate = 2e-4
```
How big each parameter update is

Update formula:
param_new = param_old - learning_rate × gradient

Example:
W = 0.5
gradient = 0.8
lr = 0.0002

W_new = 0.5 - 0.0002 × 0.8
      = 0.5 - 0.00016
      = 0.49984  (tiny change!)

Why 2e-4?
- Standard for LLM fine-tuning
- Too high (0.01): Unstable
- Too low (1e-6): Slow convergence
```

### warmup_steps = 10
```
Gradually increase LR at start

Step 1:  LR = 0.0002 × (1/10)  = 0.00002
Step 2:  LR = 0.0002 × (2/10)  = 0.00004
...
Step 10: LR = 0.0002 × (10/10) = 0.0002
Step 11+: LR = 0.0002 (constant)

Why?
- Model hasn't adapted yet
- Full LR at start can be unstable
- Warmup = gentle start ✅
```

### fp16 = True
```
Use 16-bit floating point instead of 32-bit

FP32: value = 3.141592653589793  (15 decimals)
FP16: value = 3.1416  (5 decimals)

Benefits:
- 50% less memory (2 bytes vs 4 bytes)
- 2× faster computation (GPU Tensor Cores)
- Accuracy: Same for neural networks!

Combined with quantization:
- Storage: 4-bit (weights compressed)
- Compute: FP16 (fast GPU ops)
```

### optim = "paged_adamw_8bit"
```
Optimizer with memory optimization

Regular AdamW stores:
- Model parameters
- Gradients  
- Optimizer state (momentum, variance)
= 3× memory!

Paged AdamW 8-bit:
- Stores optimizer state in 8-bit (not 32-bit)
- Pages to CPU RAM when GPU full
- Much less GPU memory ✅

Perfect for fine-tuning on limited hardware
```

---

# 5. Complete Training Pipeline {#pipeline}

## Initialization Phase

### 1. Load Model with Quantization
```python
model = AutoModelForCausalLM.from_pretrained(
    "mistralai/Mistral-7B-v0.1",
    quantization_config=bnb_config,
    device_map="auto",
    torch_dtype=torch.float16,
)

# Result:
# - Weights stored in 4-bit (3.5 GB)
# - Computation in float16
# - Model ready for training
```

### 2. Apply LoRA
```python
model = get_peft_model(model, lora_config)

# Result:
# - A, B matrices added to q_proj, v_proj (32 layers)
# - Base model frozen (7B params) ❄️
# - LoRA trainable (8.3M params) 🔥
```

### 3. Setup Optimizer
```python
optimizer = PagedAdamW8bit(
    model.trainable_parameters(),  # Only LoRA!
    lr=2e-4
)
```

---

## Training Loop (Each Step)

```python
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# STEP N: Training iteration
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# 1. Get batch (2 examples)
batch = [
    {"messages": [{"role": "user", "content": "email down"},
                  {"role": "assistant", "content": "network"}]},
    {"messages": [{"role": "user", "content": "can't print"},
                  {"role": "assistant", "content": "hardware"}]}
]

# 2. Tokenize with chat template
input_ids = tokenizer.apply_chat_template(batch)
# → "<s>[INST] email down [/INST] network</s>"

# 3. Forward pass through 32 layers
for layer in range(32):
    # Self-attention with LoRA
    Q_base = x @ W_q  # Frozen (4-bit storage, FP16 compute)
    Q_lora = x @ A @ B  # Trainable LoRA path
    Q = Q_base + 2.0 × Q_lora  # Combined
    
    K = x @ W_k  # No LoRA
    
    V_base = x @ W_v  # Frozen
    V_lora = x @ A_v @ B_v  # Trainable
    V = V_base + 2.0 × V_lora
    
    # Attention
    scores = Q @ K.T / √d_k
    scores = scores + causal_mask
    attention = softmax(scores) @ V
    
    # Residual + LayerNorm
    x = LayerNorm(x + attention)
    
    # Feed-Forward
    x = LayerNorm(x + FFN(x))

# 4. Predict next tokens
logits = x @ W_vocab  # (batch × seq × 32000)

# 5. Calculate loss
loss = CrossEntropyLoss(logits, targets)

# 6. Backward pass
loss.backward()
# Calculates ∂loss/∂A, ∂loss/∂B for all layers
# W_q, W_v get NO gradients (frozen!)

# 7. Gradient accumulation check
if step % 4 != 0:
    accumulated_grads += current_grads
    continue  # Don't update yet

# 8. Optimizer step (every 4 batches)
avg_grads = accumulated_grads / 4
for layer in range(32):
    A_q -= lr × avg_grads[A_q]
    B_q -= lr × avg_grads[B_q]
    A_v -= lr × avg_grads[A_v]
    B_v -= lr × avg_grads[B_v]
    # W_q, W_v stay frozen! ❄️

accumulated_grads = 0

# 9. Log (every 10 steps)
if step % 10 == 0:
    print(f"Step {step}: loss={loss:.4f}")
```

---

## After Each Epoch

```python
# 1. Evaluate on validation set
val_loss = evaluate(val_dataset)

# 2. Save checkpoint
save_checkpoint(f"checkpoint-epoch{epoch}/")

# 3. Check if best
if val_loss < best_loss:
    best_loss = val_loss
    best_checkpoint = f"checkpoint-epoch{epoch}/"

# 4. Log progress
print(f"Epoch {epoch}: train_loss={train_loss}, val_loss={val_loss}")
```

---

## Training Complete

```python
# 1. Load best model (not last!)
model.load_state_dict(torch.load(best_checkpoint))

# 2. Save final model
trainer.save_model()
# Saves:
# - adapter_config.json (LoRA settings)
# - adapter_model.safetensors (A, B matrices - 8.3M params)
# - tokenizer files

# 3. Upload to GCS
upload_to_gcs(output_dir, bucket, prefix)
```

---

# 6. Vertex AI Deployment {#vertex-ai}

## The Complete Flow

```
1. Containerize training code (Docker)
   ↓
2. Build & push image (Cloud Build / Artifact Registry)
   ↓
3. Submit training job (Vertex AI Custom Training)
   ↓
4. Model saves to GCS
   ↓
5. Register model (Model Registry)
   ↓
6. Deploy to endpoint (Vertex AI Endpoint)
   ↓
7. Inference (REST API or Python SDK)
```

---

## 1. Dockerfile

```dockerfile
FROM pytorch/pytorch:2.1.0-cuda11.8-cudnn8-runtime

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY train_docker.py .

ENV PYTHONUNBUFFERED=1

CMD ["python", "train_docker.py"]
```

---

## 2. Cloud Build (cloudbuild.yaml)

```yaml
steps:
  # Build Docker image
  - name: 'gcr.io/cloud-builders/docker'
    args:
      - 'build'
      - '-t'
      - 'us-central1-docker.pkg.dev/$PROJECT_ID/models/mistral-training:latest'
      - '.'
  
  # Push to Artifact Registry
  - name: 'gcr.io/cloud-builders/docker'
    args:
      - 'push'
      - 'us-central1-docker.pkg.dev/$PROJECT_ID/models/mistral-training:latest'

images:
  - 'us-central1-docker.pkg.dev/$PROJECT_ID/models/mistral-training:latest'

timeout: '3600s'
options:
  machineType: 'N1_HIGHCPU_8'
```

**Submit:**
```bash
gcloud builds submit --config=cloudbuild.yaml .
```

---

## 3. Submit Training Job

```python
from google.cloud import aiplatform

aiplatform.init(
    project="ai-practice-388514",
    location="us-central1",
    staging_bucket="gs://vertex-ai-mistral-training-ai-practice"
)

job = aiplatform.CustomContainerTrainingJob(
    display_name="mistral-it-training",
    container_uri="us-central1-docker.pkg.dev/ai-practice-388514/models/mistral-training:latest",
)

job.run(
    replica_count=1,
    machine_type="n1-standard-8",
    accelerator_type="NVIDIA_TESLA_A100",
    accelerator_count=1,
    base_output_dir="gs://vertex-ai-mistral-training-ai-practice/output",
)
```

---

## 4. Register Model

```python
model = aiplatform.Model.upload(
    display_name="mistral-it-classifier-v1",
    artifact_uri="gs://vertex-ai-mistral-training-ai-practice/output/trained_models/",
    serving_container_image_uri="us-docker.pkg.dev/vertex-ai/prediction/pytorch-gpu.1-13:latest",
)

print(f"Model: {model.resource_name}")
```

---

## 5. Deploy to Endpoint

```python
# Create endpoint
endpoint = aiplatform.Endpoint.create(
    display_name="mistral-it-endpoint"
)

# Deploy model
endpoint.deploy(
    model=model,
    deployed_model_display_name="mistral-it-v1",
    machine_type="n1-standard-4",
    accelerator_type="NVIDIA_TESLA_T4",
    accelerator_count=1,
    min_replica_count=1,
    max_replica_count=3,
)

print(f"Endpoint: {endpoint.name}")
```

---

## 6. Make Predictions

```python
endpoint = aiplatform.Endpoint("ENDPOINT_ID")

instances = [{
    "prompt": "My email is down and I can't access inbox"
}]

prediction = endpoint.predict(instances=instances)
print(prediction.predictions)  # ["network"]
```

---

# 7. Interview Preparation {#interview-prep}

## The Golden Answer

**"Tell me about your LLM fine-tuning project":**

> "I fine-tuned Mistral-7B for IT ticket classification using **LoRA** and **4-bit quantization** to make it memory-efficient. I containerized the training code with **Docker**, used **Cloud Build** to automate the build and push to **Artifact Registry**, then submitted it as a **Vertex AI custom training job** with an **A100 GPU**.
>
> The training used **gradient accumulation** to simulate batch size 8 while only using memory for batch size 2, and **FP16** for fast computation. After training, I saved the model to **GCS**, registered it in **Vertex AI Model Registry**, and deployed to a **Vertex AI Endpoint** with a **T4 GPU** for cost-effective inference.
>
> The entire pipeline was automated, and I could monitor training through **Cloud Logging**. For production, I set up auto-scaling with min 1, max 3 replicas to handle traffic spikes."

---

## Key Technical Questions

### Q: What's quantization and how does it work?
```
A: Quantization compresses model weights from 32-bit to 4-bit (8× smaller).

Formula: bucket = round((value - min) / (max - min) × 15)

We use block-wise quantization (128 weights per block) with NF4 format,
which allocates more precision near zero where neural network weights cluster.

This reduced Mistral-7B from 28 GB to 3.5 GB in memory.
```

### Q: Explain LoRA. Why not full fine-tuning?
```
A: LoRA adds small trainable matrices (A: 4096×16, B: 16×4096) instead of
updating the full weight matrix (4096×4096).

Formula: Q = x @ W_q + (α/r) × (x @ A @ B)

The bottleneck at rank 16 forces the model to learn only essential patterns,
preventing overfitting. We train only 0.12% of parameters (8.3M vs 7B),
which is 100× faster and preserves base knowledge.
```

### Q: What's gradient accumulation?
```
A: Simulating larger batch sizes without OOM errors.

With batch_size=2 and accumulation=4:
- Process 2 examples, calculate gradients, don't update
- Repeat 3 more times, accumulating gradients
- After 4 batches, average gradients and update

Result: Effective batch=8 with memory of batch=2.
```

### Q: Why FP16 instead of FP32?
```
A: FP16 uses 2 bytes vs 4 bytes (50% memory savings) and is 2× faster
on modern GPUs with Tensor Cores.

For neural networks, FP16 precision (5 decimal places) is sufficient.
We get same training results with half the memory and double the speed.
```

### Q: How did you deploy to production?
```
A: Used Vertex AI Endpoints:
1. Registered model in Model Registry
2. Created Endpoint resource
3. Deployed with T4 GPU (cost-effective for inference)
4. Set auto-scaling (min=1, max=3)
5. Exposed via REST API for predictions
```

---

## Key Commands to Remember

```bash
# Build & Push Docker
docker build -t us-central1-docker.pkg.dev/PROJECT/REPO/IMAGE .
docker push us-central1-docker.pkg.dev/PROJECT/REPO/IMAGE

# Cloud Build
gcloud builds submit --config=cloudbuild.yaml .

# List training jobs
gcloud ai custom-jobs list --region=us-central1

# Stream logs
gcloud ai custom-jobs stream-logs JOB_ID --region=us-central1

# List endpoints
gcloud ai endpoints list --region=us-central1
```

---

## Cost Optimization

**Q: How do you optimize costs?**

```
Training:
- Use preemptible VMs (up to 80% cheaper)
- Auto-terminate after training (custom jobs do this)
- T4 for development, A100 only for final run

Inference:
- Scale to zero when idle
- Use T4 instead of A100 (4× cheaper)
- Batch predictions instead of real-time
- Consider Cloud Run with GPU for low traffic
```

---

## Troubleshooting Scenarios

### OOM during training
```
1. Reduce batch_size (4 → 2)
2. Increase gradient_accumulation_steps
3. Use larger GPU (T4 → A100)
4. Enable 8-bit optimizer (paged_adamw_8bit)
```

### Slow inference
```
1. Use larger machine type
2. Increase accelerator count
3. Enable request batching
4. Use INT8 quantization for inference
5. Optimize model (TensorRT, ONNX)
```

### Model versioning
```
Use Model Registry:
- model-v1 (baseline)
- model-v2 (improved)

Traffic split for A/B testing:
- 80% traffic to v1
- 20% traffic to v2
```

---

## Summary - What You Built

```
✅ Fine-tuned 7B parameter LLM on consumer hardware
✅ Used cutting-edge techniques (LoRA, 4-bit quantization)
✅ Automated deployment pipeline (Cloud Build → Vertex AI)
✅ Production-ready endpoint with auto-scaling
✅ Memory-efficient (3.5 GB vs 28 GB)
✅ Fast training (0.12% of params vs 100%)
✅ Cost-effective inference (T4 GPU)
```

---

**You're ready to crush those interviews! 🚀💪**
