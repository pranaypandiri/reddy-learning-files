"""
Dataset Splitting Script for Vertex AI Training
Splits IT tickets dataset into train/validation/test sets

Two approaches provided:
1. Scikit-learn (Active) - Simple and effective
2. HuggingFace Datasets (Commented) - For HF ecosystem integration
"""

import json
from pathlib import Path
from sklearn.model_selection import train_test_split
import random

# Set random seed for reproducibility
RANDOM_SEED = 42
random.seed(RANDOM_SEED)

# File paths
INPUT_FILE = "it_tickets_training.jsonl"  # File is in current directory
OUTPUT_DIR = Path("datasets")
OUTPUT_DIR.mkdir(exist_ok=True)

TRAIN_FILE = OUTPUT_DIR / "train.jsonl"
VAL_FILE = OUTPUT_DIR / "validation.jsonl"
TEST_FILE = OUTPUT_DIR / "test.jsonl"

# Split ratios
TRAIN_RATIO = 0.7  # 70% for training
VAL_RATIO = 0.15  # 15% for validation
TEST_RATIO = 0.15  # 15% for testing


def load_jsonl(file_path):
    """Load JSONL file and return list of records"""
    data = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            data.append(json.loads(line.strip()))
    return data


def save_jsonl(data, file_path):
    """Save list of records to JSONL file"""
    with open(file_path, "w", encoding="utf-8") as f:
        for record in data:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    print(f"✅ Saved {len(data)} records to {file_path}")


def extract_labels(data):
    """Extract labels from dataset for stratification"""
    labels = []
    for record in data:
        # Extract the assistant's response (category)
        assistant_msg = record["messages"][-1]["content"]
        labels.append(assistant_msg)
    return labels


def print_statistics(data, split_name):
    """Print dataset statistics"""
    labels = extract_labels(data)
    software_count = labels.count("software")
    hardware_count = labels.count("hardware")

    print(f"\n{split_name} Statistics:")
    print(f"  Total: {len(data)}")
    print(f"  Software: {software_count} ({software_count/len(data)*100:.1f}%)")
    print(f"  Hardware: {hardware_count} ({hardware_count/len(data)*100:.1f}%)")


# ============================================================================
# APPROACH 1: SCIKIT-LEARN (ACTIVE)
# ============================================================================


def split_with_sklearn():
    """Split dataset using scikit-learn train_test_split"""
    print("=" * 60)
    print("SPLITTING DATASET WITH SCIKIT-LEARN")
    print("=" * 60)

    # Load data
    print(f"\n📂 Loading data from {INPUT_FILE}...")
    data = load_jsonl(INPUT_FILE)
    print(f"✅ Loaded {len(data)} total records")

    # Extract labels for stratification
    labels = extract_labels(data)

    # First split: separate out test set (15%)
    train_val_data, test_data, train_val_labels, test_labels = train_test_split(
        data, labels, test_size=TEST_RATIO, random_state=RANDOM_SEED, stratify=labels
    )

    # Second split: split remaining into train (70%) and validation (15%)
    # Since we removed 15% for test, remaining is 85%
    # We want 70% of original for train, so: 70/85 = 0.824
    val_size_adjusted = VAL_RATIO / (TRAIN_RATIO + VAL_RATIO)

    train_data, val_data, train_labels, val_labels = train_test_split(
        train_val_data,
        train_val_labels,
        test_size=val_size_adjusted,
        random_state=RANDOM_SEED,
        stratify=train_val_labels,
    )

    # Save splits
    print("\n💾 Saving splits...")
    save_jsonl(train_data, TRAIN_FILE)
    save_jsonl(val_data, VAL_FILE)
    save_jsonl(test_data, TEST_FILE)

    # Print statistics
    print_statistics(train_data, "TRAIN")
    print_statistics(val_data, "VALIDATION")
    print_statistics(test_data, "TEST")

    print("\n" + "=" * 60)
    print("✅ DATASET SPLITTING COMPLETE!")
    print("=" * 60)
    print(f"\nOutput files:")
    print(f"  - {TRAIN_FILE}")
    print(f"  - {VAL_FILE}")
    print(f"  - {TEST_FILE}")


# ============================================================================
# APPROACH 2: HUGGINGFACE DATASETS (COMMENTED)
# ============================================================================

# """
# Alternative approach using HuggingFace Datasets library
#
# Installation:
#   pip install datasets
#
# Usage:
#   Uncomment this section and comment out the sklearn approach above
# """
#
# from datasets import Dataset, DatasetDict
#
# def split_with_huggingface():
#     """Split dataset using HuggingFace datasets library"""
#     print("=" * 60)
#     print("SPLITTING DATASET WITH HUGGINGFACE")
#     print("=" * 60)
#
#     # Load data
#     print(f"\n📂 Loading data from {INPUT_FILE}...")
#     data = load_jsonl(INPUT_FILE)
#     print(f"✅ Loaded {len(data)} total records")
#
#     # Convert to HuggingFace Dataset
#     dataset = Dataset.from_list(data)
#
#     # Add labels for stratification
#     def add_label(example):
#         example['label'] = example['messages'][-1]['content']
#         return example
#
#     dataset = dataset.map(add_label)
#
#     # Split into train and temp (test + validation)
#     train_test_split = dataset.train_test_split(
#         test_size=TEST_RATIO + VAL_RATIO,  # 30% total
#         stratify_by_column='label',
#         seed=RANDOM_SEED
#     )
#
#     # Split temp into validation and test
#     val_test_split = train_test_split['test'].train_test_split(
#         test_size=0.5,  # Split 30% into two equal parts (15% each)
#         stratify_by_column='label',
#         seed=RANDOM_SEED
#     )
#
#     # Create final dataset dict
#     dataset_dict = DatasetDict({
#         'train': train_test_split['train'],
#         'validation': val_test_split['train'],
#         'test': val_test_split['test']
#     })
#
#     # Remove the temporary 'label' column
#     dataset_dict = dataset_dict.remove_columns(['label'])
#
#     # Save to JSONL files
#     print("\n💾 Saving splits...")
#
#     # Convert back to list and save
#     train_list = [item for item in dataset_dict['train']]
#     val_list = [item for item in dataset_dict['validation']]
#     test_list = [item for item in dataset_dict['test']]
#
#     save_jsonl(train_list, TRAIN_FILE)
#     save_jsonl(val_list, VAL_FILE)
#     save_jsonl(test_list, TEST_FILE)
#
#     # Print statistics
#     print_statistics(train_list, "TRAIN")
#     print_statistics(val_list, "VALIDATION")
#     print_statistics(test_list, "TEST")
#
#     # Optional: Push to HuggingFace Hub
#     # dataset_dict.push_to_hub("your-username/it-tickets-classification")
#
#     print("\n" + "=" * 60)
#     print("✅ DATASET SPLITTING COMPLETE!")
#     print("=" * 60)
#     print(f"\nOutput files:")
#     print(f"  - {TRAIN_FILE}")
#     print(f"  - {VAL_FILE}")
#     print(f"  - {TEST_FILE}")
#
#     return dataset_dict


if __name__ == "__main__":
    # Run the active approach (scikit-learn)
    split_with_sklearn()

    # To use HuggingFace approach instead:
    # Uncomment the function above and run:
    # split_with_huggingface()
