#!/bin/bash

# =============================================================================
# Vertex AI FastAPI Deployment Script
# This script automates the deployment of a FastAPI Docker container to Vertex AI
# =============================================================================

# Set project and region
PROJECT_ID="ai-practice-388514"
REGION="us-central1"
IMAGE_URI="us-central1-docker.pkg.dev/$PROJECT_ID/vertex-containers/image-buk:v1"
MODEL_DISPLAY_NAME="img-seg-model"
DEPLOYMENT_DISPLAY_NAME="img-seg-deployment"
ENDPOINT_DISPLAY_NAME="img-seg-endpoint"
MACHINE_TYPE="n1-standard-4"

echo "====================================================================="
echo "Vertex AI FastAPI Deployment Script"
echo "====================================================================="
echo "Project ID: $PROJECT_ID"
echo "Region: $REGION"
echo "Image URI: $IMAGE_URI"
echo "====================================================================="

# Step 1: Submit Cloud Build job
echo ""
echo "Step 1: Submitting Cloud Build job..."
gcloud builds submit --config cloudbuild.yaml .

if [ $? -eq 0 ]; then
    echo "✅ Cloud Build submitted successfully."
else
    echo "❌ Cloud Build failed. Exiting."
    exit 1
fi

# Step 2: Upload model to Vertex AI
echo ""
echo "Step 2: Uploading model to Vertex AI..."
gcloud ai models upload \
  --region=$REGION \
  --display-name=$MODEL_DISPLAY_NAME \
  --container-image-uri=$IMAGE_URI \
  --container-ports=8080 \
  --container-health-route=/health \
  --container-predict-route=/predict

if [ $? -eq 0 ]; then
    echo "✅ Model uploaded successfully."
else
    echo "❌ Model upload failed. Exiting."
    exit 1
fi

# Step 3: List models to retrieve MODEL_ID
echo ""
echo "Step 3: Listing models to retrieve MODEL_ID..."
MODEL_ID=$(gcloud ai models list --region=$REGION --filter="displayName=$MODEL_DISPLAY_NAME" --format="value(name)" | awk -F/ '{print $NF}')
echo "MODEL_ID=$MODEL_ID"

if [ -z "$MODEL_ID" ]; then
    echo "❌ Could not retrieve MODEL_ID. Exiting."
    exit 1
fi

# Step 4: Create endpoint
echo ""
echo "Step 4: Creating endpoint..."
gcloud ai endpoints create --region=$REGION --display-name=$ENDPOINT_DISPLAY_NAME

if [ $? -eq 0 ]; then
    echo "✅ Endpoint created successfully."
else
    echo "⚠️  Endpoint might already exist. Continuing..."
fi

# Step 5: List endpoints to retrieve ENDPOINT_ID
echo ""
echo "Step 5: Listing endpoints to retrieve ENDPOINT_ID..."
ENDPOINT_ID=$(gcloud ai endpoints list --region=$REGION --filter="displayName=$ENDPOINT_DISPLAY_NAME" --format="value(name)" | awk -F/ '{print $NF}')
echo "ENDPOINT_ID=$ENDPOINT_ID"

if [ -z "$ENDPOINT_ID" ]; then
    echo "❌ Could not retrieve ENDPOINT_ID. Exiting."
    exit 1
fi

# Step 6: Deploy model to endpoint
echo ""
echo "Step 6: Deploying model to endpoint..."
gcloud ai endpoints deploy-model $ENDPOINT_ID \
  --region=$REGION \
  --model=$MODEL_ID \
  --display-name="$DEPLOYMENT_DISPLAY_NAME" \
  --machine-type=$MACHINE_TYPE \
  --min-replica-count=1 \
  --max-replica-count=1 \
  --traffic-split=0=100

if [ $? -eq 0 ]; then
    echo ""
    echo "====================================================================="
    echo "✅ Deployment completed successfully!"
    echo "====================================================================="
    echo "Endpoint ID: $ENDPOINT_ID"
    echo "Model ID: $MODEL_ID"
    echo "You can now test your endpoint at:"
    echo "https://$REGION-aiplatform.googleapis.com/v1/projects/$PROJECT_ID/locations/$REGION/endpoints/$ENDPOINT_ID:predict"
    echo "====================================================================="
else
    echo "❌ Model deployment failed."
    exit 1
fi
