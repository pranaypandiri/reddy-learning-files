# Vertex AI Model Deployment - Quick Reference

## Overview
End-to-end deployment of fine-tuned Mistral-7B on GCP Vertex AI for GenAI engineers.

---

## 1. Training Container (`Dockerfile`)

```dockerfile
FROM nvidia/cuda:11.8.0-cudnn8-devel-ubuntu22.04

# Install Python
RUN apt-get update && apt-get install -y python3.10 python3-pip

# Install PyTorch with GPU support (requires NVIDIA index)
RUN pip install torch==2.0.1 torchvision==0.15.2 \
    --index-url https://download.pytorch.org/whl/cu118

# Install ML libraries
RUN pip install transformers==4.35.0 \
    peft==0.6.0 \
    trl==0.7.4 \
    bitsandbytes==0.41.1 \
    accelerate==0.24.0 \
    datasets==2.14.0

# Install GCP libraries
RUN pip install google-cloud-storage==2.10.0

WORKDIR /app
COPY train_docker.py .

ENTRYPOINT ["python3", "train_docker.py"]
```

**Key Points:**
- CUDA base for GPU acceleration (T4, A100, L4)
- `--index-url` for GPU-enabled PyTorch
- Separate RUN layers for better caching

---

## 2. Training Script (`train_docker.py`)

```python
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from peft import LoraConfig, get_peft_model
from trl import SFTTrainer

# 4-bit quantization config
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16
)

# Load base model with quantization
model = AutoModelForCausalLM.from_pretrained(
    "mistralai/Mistral-7B-v0.1",
    quantization_config=bnb_config,
    device_map="auto"
)

# LoRA config for parameter-efficient fine-tuning
lora_config = LoraConfig(
    r=8,                    # Rank
    lora_alpha=16,          # Scaling factor
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    task_type="CAUSAL_LM"
)

# Apply LoRA
model = get_peft_model(model, lora_config)

# Train
trainer = SFTTrainer(
    model=model,
    train_dataset=dataset,
    args=training_args
)
trainer.train()

# Save to GCS
model.save_pretrained("gs://my-bucket/trained_model/")
```

**Key Points:**
- LoRA reduces trainable params from 7B to ~16M
- 4-bit quantization reduces memory 4x
- Saves directly to GCS for deployment

---

## 3. Submit Training Job (`submit_vertex_training.py`)

```python
from google.cloud import aiplatform

aiplatform.init(project="my-project", location="us-central1")

# Define custom training job
job = aiplatform.CustomJob(
    display_name="mistral-lora-training",
    worker_pool_specs=[{
        "machine_spec": {
            "machine_type": "n1-standard-4",
            "accelerator_type": "NVIDIA_TESLA_T4",
            "accelerator_count": 1
        },
        "replica_count": 1,
        "container_spec": {
            "image_uri": "us-central1-docker.pkg.dev/my-project/my-repo/train:latest"
        },
        "disk_spec": {
            "boot_disk_type": "pd-ssd",
            "boot_disk_size_gb": 100
        }
    }]
)

# Submit (async)
job.run(sync=False)
print(f"Job name: {job.resource_name}")
```

**Key Points:**
- `sync=False` for async submission (check Cloud Console)
- Disk = temp fast storage, GCS = permanent storage
- T4 GPU (16GB VRAM) sufficient for LoRA + 4-bit

---

## 4. Build Training Image (`cloudbuild.yaml`)

```yaml
steps:
  - name: 'gcr.io/cloud-builders/docker'
    args: [
      'build',
      '-t', 'us-central1-docker.pkg.dev/$PROJECT_ID/ml-containers/train:latest',
      '-f', 'Dockerfile',
      '.'
    ]
  - name: 'gcr.io/cloud-builders/docker'
    args: [
      'push',
      'us-central1-docker.pkg.dev/$PROJECT_ID/ml-containers/train:latest'
    ]

options:
  machineType: 'E2_HIGHCPU_8'
```

**Run:** `gcloud builds submit --config=cloudbuild.yaml`

---

## 5. Serving Container (`Dockerfile.serve`)

```dockerfile
FROM python:3.10-slim

RUN pip install fastapi==0.104.0 \
    uvicorn==0.24.0 \
    transformers==4.35.0 \
    torch==2.0.1 \
    google-cloud-storage==2.10.0

WORKDIR /app
COPY predict.py .

# Vertex AI expects these env vars
ENV AIP_HTTP_PORT=8080
ENV AIP_HEALTH_ROUTE=/health
ENV AIP_PREDICT_ROUTE=/predict

EXPOSE 8080

CMD ["uvicorn", "predict:app", "--host", "0.0.0.0", "--port", "8080"]
```

**Key Points:**
- No CUDA (inference uses CPU or Vertex handles GPU)
- Lightweight for fast startup
- Vertex AI standard env vars

---

## 6. Inference Server (`predict.py`)

```python
from fastapi import FastAPI
from transformers import AutoModelForCausalLM, AutoTokenizer
import os

app = FastAPI()

# Load model from GCS (env var passed during deployment)
MODEL_PATH = os.getenv("MODEL_PATH", "gs://my-bucket/trained_model/")
model = AutoModelForCausalLM.from_pretrained(MODEL_PATH)
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.post("/predict")
def predict(request: dict):
    prompt = request.get("prompt", "")
    
    inputs = tokenizer(prompt, return_tensors="pt")
    outputs = model.generate(**inputs, max_length=100)
    
    return {"prediction": tokenizer.decode(outputs[0])}
```

**Key Points:**
- `MODEL_PATH` from environment variable (reusable container)
- `/health` and `/predict` routes required by Vertex AI
- Model loaded once at startup (not per request)

---

## 7. Build Serving Image (`cloudbuild-serve.yaml`)

```yaml
steps:
  - name: 'gcr.io/cloud-builders/docker'
    args: [
      'build',
      '-t', 'us-central1-docker.pkg.dev/$PROJECT_ID/ml-containers/serve:latest',
      '-f', 'Dockerfile.serve',
      '.'
    ]
  - name: 'gcr.io/cloud-builders/docker'
    args: [
      'push',
      'us-central1-docker.pkg.dev/$PROJECT_ID/ml-containers/serve:latest'
    ]
```

---

## 8. Deploy Model (`deploy_model.py`)

```python
from google.cloud import aiplatform

aiplatform.init(project="my-project", location="us-central1")

# Register model in Model Registry
model = aiplatform.Model.upload(
    display_name="mistral-it-classifier",
    artifact_uri="gs://my-bucket/trained_model/",  # From training output
    serving_container_image_uri="us-central1-docker.pkg.dev/my-project/ml-containers/serve:latest",
    serving_container_environment_variables={
        "MODEL_PATH": "gs://my-bucket/trained_model/"
    }
)

# Create or get endpoint
endpoint = aiplatform.Endpoint.create(display_name="mistral-endpoint")

# Deploy to endpoint with auto-scaling
model.deploy(
    endpoint=endpoint,
    machine_type="n1-standard-4",
    min_replica_count=1,
    max_replica_count=3,
    traffic_percentage=100
)

print(f"Endpoint ID: {endpoint.resource_name}")
```

**Key Points:**
- `artifact_uri` = where training saved the model
- `serving_container_environment_variables` passes MODEL_PATH to container
- No MODEL_ID needed (Python SDK handles it)
- Auto-scaling: 1-3 replicas based on traffic

---

## 9. Make Predictions

```python
from google.cloud import aiplatform

endpoint = aiplatform.Endpoint("projects/123/locations/us-central1/endpoints/456")

response = endpoint.predict(instances=[{
    "prompt": "Classify this ticket: User cannot login"
}])

print(response.predictions)
```

---

## AWS Equivalents

| GCP Vertex AI | AWS Service | Use Case |
|--------------|-------------|----------|
| Generative AI Studio | **Bedrock** | Managed APIs (Claude, Llama) |
| Custom Training | **SageMaker Training** | Fine-tune custom models |
| Model Registry | SageMaker Model Registry | Version control |
| Endpoints | SageMaker Endpoints | Inference serving |
| Artifact Registry | **ECR** | Container images |
| Cloud Build | CodeBuild | CI/CD automation |

---

## GenAI Engineer Responsibilities

**You Own:**
- Training code (`train_docker.py`)
- Inference code (`predict.py`)
- Model architecture choices (LoRA config, quantization)
- Hyperparameter tuning
- Dataset preparation
- Model evaluation

**DevOps Team Owns:**
- Dockerfile creation (you provide requirements)
- Cloud Build pipelines
- GitHub Actions CI/CD
- Monitoring/alerting infrastructure
- Production deployment automation

**Collaboration:**
- You provide: Python requirements, GPU needs, environment variables
- They provide: Dockerfiles, pipelines, infrastructure

---

## Interview Talking Points

### "Walk me through deploying a fine-tuned model"

1. **Training Phase:**
   - Write `train_docker.py` with LoRA + 4-bit quantization
   - Create `Dockerfile` with CUDA + PyTorch GPU
   - Submit to Vertex AI CustomJob with T4 GPU
   - Model saves to GCS bucket

2. **Serving Phase:**
   - Write `predict.py` with FastAPI
   - Create `Dockerfile.serve` (lightweight, no CUDA)
   - Register model in Model Registry with `Model.upload()`
   - Deploy to endpoint with auto-scaling

3. **Production:**
   - CI/CD pipeline rebuilds containers on code changes
   - Monitoring tracks latency, error rates
   - A/B testing with traffic splitting

### "Why separate containers?"

- **Training container:** Large (CUDA, PyTorch GPU), runs once
- **Serving container:** Small (CPU inference), runs 24/7
- Optimization: Fast startup, lower cost

### "How do you handle long training jobs?"

- `sync=False` for async submission
- Monitor in Cloud Console or Cloud Function polling
- Training failures stop pipeline (GitHub Actions `needs:`)

---

## Next Steps (Stage 5+)

See bottom of this file for improvement roadmap.

---

# Stage 5+: Advanced Improvements

## Stage 5: Monitoring & Observability

**What to Add:**
```python
# In predict.py
import time
from prometheus_client import Counter, Histogram

PREDICTION_COUNT = Counter('predictions_total', 'Total predictions')
PREDICTION_LATENCY = Histogram('prediction_latency_seconds', 'Prediction latency')

@app.post("/predict")
def predict(request: dict):
    start = time.time()
    
    # ... inference logic ...
    
    PREDICTION_LATENCY.observe(time.time() - start)
    PREDICTION_COUNT.inc()
    
    return response
```

**Add Logging:**
```python
import logging
from google.cloud import logging as cloud_logging

cloud_logging.Client().setup_logging()
logger = logging.getLogger(__name__)

@app.post("/predict")
def predict(request: dict):
    logger.info(f"Received prompt: {request.get('prompt')[:50]}")
    # ... inference ...
    logger.info(f"Generated {len(output)} tokens")
```

**Cloud Monitoring Alerts:**
- Latency > 2 seconds
- Error rate > 5%
- Replica count maxed out (scaling issue)

**Tools:**
- Cloud Monitoring dashboards
- Cloud Logging
- Vertex AI Model Monitoring

---

## Stage 6: A/B Testing & Experimentation

**Traffic Splitting:**
```python
# Deploy model v2
model_v2 = aiplatform.Model.upload(...)
model_v2.deploy(
    endpoint=endpoint,
    traffic_percentage=20,  # 20% traffic to v2
    traffic_split={
        "model_v1_id": 80,
        "model_v2_id": 20
    }
)
```

**LangSmith Integration:**
```python
from langsmith import Client

client = Client()

@app.post("/predict")
def predict(request: dict):
    with client.trace(name="mistral-inference") as run:
        output = model.generate(...)
        run.end(outputs={"prediction": output})
```

**Compare Metrics:**
- Model v1 vs v2 latency
- User feedback scores
- Task completion rates

---

## Stage 7: Model Versioning & Rollback

**Semantic Versioning:**
```python
model = aiplatform.Model.upload(
    display_name="mistral-it-classifier",
    version_aliases=["v1.2.0", "production"],
    version_description="Fixed classification accuracy for network issues"
)
```

**Rollback Strategy:**
```python
# If v2 fails, instant rollback
endpoint.undeploy_all()
endpoint.deploy(
    model=model_v1,
    traffic_percentage=100
)
```

**Automated Rollback:**
```python
# Cloud Function triggered by error rate alert
if error_rate > 0.05:
    endpoint.undeploy(deployed_model_id=model_v2_id)
    send_alert("Rolled back to v1 due to high error rate")
```

---

## Stage 8: Cost Optimization

**Autoscaling Tuning:**
```python
model.deploy(
    min_replica_count=0,  # Scale to zero during low traffic
    max_replica_count=10,
    autoscaling_target_cpu_utilization=70  # Scale at 70% CPU
)
```

**Batch Prediction (Cheaper than Real-time):**
```python
batch_job = model.batch_predict(
    job_display_name="batch-classification",
    gcs_source="gs://bucket/input.jsonl",
    gcs_destination_prefix="gs://bucket/output/"
)
```

**Spot Instances for Training:**
```python
job = aiplatform.CustomJob(
    worker_pool_specs=[{
        "machine_spec": {
            "machine_type": "n1-standard-4",
            "accelerator_type": "NVIDIA_TESLA_T4"
        },
        "replica_count": 1,
        "reduction_server_spec": {"use_spot": True}  # 60-70% cheaper
    }]
)
```

---

## Stage 9: Multi-Model Ensembles

**Deploy Multiple Models:**
```python
# Mistral for IT tickets
mistral_model.deploy(endpoint=endpoint, deployed_model_display_name="mistral")

# BERT for sentiment
bert_model.deploy(endpoint=endpoint, deployed_model_display_name="bert")

# Routing logic in predict.py
@app.post("/predict")
def predict(request: dict):
    task = request.get("task_type")
    
    if task == "classification":
        return mistral_predict(request)
    elif task == "sentiment":
        return bert_predict(request)
```

**Ensemble Voting:**
```python
# Combine predictions from 3 models
predictions = [
    model1.predict(prompt),
    model2.predict(prompt),
    model3.predict(prompt)
]

# Majority vote
final_prediction = max(set(predictions), key=predictions.count)
```

---

## Stage 10: Advanced Training Techniques

**Distributed Training (Multiple GPUs):**
```python
job = aiplatform.CustomJob(
    worker_pool_specs=[{
        "machine_spec": {
            "machine_type": "n1-highmem-16",
            "accelerator_type": "NVIDIA_TESLA_A100",
            "accelerator_count": 4  # 4 GPUs
        },
        "replica_count": 2  # 2 machines = 8 GPUs total
    }]
)
```

**DeepSpeed Integration:**
```python
# In train_docker.py
from transformers import TrainingArguments

training_args = TrainingArguments(
    deepspeed="ds_config.json",  # ZeRO-3 optimizer
    gradient_checkpointing=True,
    fp16=True
)
```

**Hyperparameter Tuning with Vertex AI:**
```python
from google.cloud.aiplatform import hyperparameter_tuning as hpt

job = aiplatform.CustomJob.from_local_script(...)

tuning_job = aiplatform.HyperparameterTuningJob(
    display_name="mistral-hpo",
    custom_job=job,
    metric_spec={"accuracy": "maximize"},
    parameter_spec={
        "learning_rate": hpt.DoubleParameterSpec(min=1e-5, max=1e-3, scale="log"),
        "lora_r": hpt.DiscreteParameterSpec(values=[8, 16, 32])
    },
    max_trial_count=20,
    parallel_trial_count=4
)
```

---

## Priority Roadmap

**For Interviews (Next 1-2 weeks):**
1. ✅ Core deployment pipeline (you know this now)
2. **Stage 5:** Basic monitoring (Cloud Logging + error alerts)
3. **Stage 6:** A/B testing concept (traffic splitting)

**For Real Projects (Month 1-3):**
1. **Stage 7:** Version control + rollback
2. **Stage 8:** Cost optimization (autoscaling, spot instances)
3. **Stage 9:** Multi-model serving

**Advanced (Month 3+):**
1. **Stage 10:** Distributed training, hyperparameter tuning
2. Custom metrics, explainability
3. Edge deployment (TensorFlow Lite, ONNX)

---

## Quick Commands Cheat Sheet

```bash
# Submit training
python submit_vertex_training.py

# Build containers
gcloud builds submit --config=cloudbuild.yaml
gcloud builds submit --config=cloudbuild-serve.yaml

# Deploy model
python deploy_model.py

# List endpoints
gcloud ai endpoints list --region=us-central1

# Check logs
gcloud logging read "resource.type=ml_job" --limit=50

# Delete endpoint (save costs)
gcloud ai endpoints delete ENDPOINT_ID --region=us-central1
```

---

**Study Strategy:**
1. ✅ You understand the core flow
2. Write this reference in your own words (active recall)
3. Tomorrow: Explain each stage out loud (Feynman technique)
4. Interview prep: Focus on Stages 1-6, mention 7-10 as "next steps"

**GenAI Engineer Focus:**
- Model architecture choices (LoRA, quantization)
- Training code quality
- Inference optimization
- Monitoring what matters (latency, accuracy)

**DevOps handles:** Infrastructure, pipelines, Kubernetes, scaling policies.
