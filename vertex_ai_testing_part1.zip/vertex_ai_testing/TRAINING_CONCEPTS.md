# Vertex AI Training - Key Concepts for Phase 2

## Overview
This guide covers everything you need to understand before writing the training script for Mistral-7B fine-tuning.

---

## Q1: CustomJob vs PipelineJob - Which one?

### CustomJob ✅ (We use this)
Direct control over training container and code.

```python
from google.cloud import aiplatform

job = aiplatform.CustomTrainingJob(
    display_name="mistral-fine-tune",
    script_path="train.py",
    container_uri="us-docker.pkg.dev/vertex-ai/training/pytorch-gpu.1-13:latest",
    requirements=["transformers", "peft", "bitsandbytes"]
)

job.run(
    replica_count=1,
    machine_type="n1-standard-8",
    accelerator_type="NVIDIA_TESLA_V100",
    accelerator_count=1
)
```

**Best for:**
- Fine-tuning pre-trained models
- Simple training workflows
- Full control over training code

### PipelineJob (Not needed)
Multi-step ML workflows (data prep → train → eval → deploy). Uses Kubeflow Pipelines. Too complex for our use case.

**Decision:** CustomJob - simple, fast, perfect for 300 records.

---

## Q2: LoRA Hyperparameters Deep Dive

### What is LoRA?
**LoRA = Low-Rank Adaptation**
- Instead of training all 7 billion parameters
- Train small "adapter" matrices (~10-20M parameters)
- Base model stays frozen
- 700x less memory, 3-5x faster training

### Code Configuration

```python
from peft import LoraConfig

lora_config = LoraConfig(
    r=16,              # Rank of adapter matrices
    lora_alpha=32,     # Scaling factor
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.1,
    bias="none",
    task_type="CAUSAL_LM"
)
```

### Parameter Breakdown

**`r` (Rank):**
- Controls size of low-rank matrices
- `r=8`: ~5M trainable params (fast, less capacity)
- `r=16`: ~10M params (balanced) ✅ **Our choice**
- `r=32`: ~20M params (overkill for 300 records, will overfit)

**`lora_alpha` (Scaling):**
- Usually set to 2× rank (alpha=32 for r=16)
- Controls how strongly LoRA adapters influence the base model
- Higher = stronger adaptation (but risk overfitting)

**`target_modules`:**
- Which attention layers get LoRA adapters
- `q_proj` = Query projection (attention mechanism)
- `v_proj` = Value projection (attention mechanism)
- Can add `k_proj`, `o_proj` for more capacity (not needed for our small dataset)

**`lora_dropout`:**
- Dropout rate applied to LoRA layers
- 0.1 = 10% dropout
- Prevents overfitting on small datasets like ours

**`task_type`:**
- `CAUSAL_LM` = Causal Language Modeling (for decoder models like Mistral)
- Other options: `SEQ_2_SEQ_LM`, `SEQ_CLS`

### Memory Comparison

```
Full Fine-tuning:
- 7B params × 4 bytes = 28GB GPU memory
- Needs A100 (40GB) or multi-GPU setup

LoRA (r=16):
- 10M params × 4 bytes = 40MB
- Can run on V100 (16GB) easily
- 700x less memory!
```

---

## Q3: Loading Mistral from Model Garden

### Method 1: HuggingFace Hub (Easier) ✅

```python
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

# Load tokenizer
tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-v0.1")

# Load model with optimizations
model = AutoModelForCausalLM.from_pretrained(
    "mistralai/Mistral-7B-v0.1",
    load_in_4bit=True,        # 4-bit quantization (14GB → 7GB)
    device_map="auto",        # Auto distribute across GPUs
    torch_dtype=torch.float16 # Half precision for speed
)
```

**What happens:**
1. Downloads model from HuggingFace (first time only)
2. Caches locally in Vertex AI VM
3. Loads into GPU memory with 4-bit quantization

### Method 2: Vertex AI Model Registry (Production)

```python
from google.cloud import aiplatform

aiplatform.init(project="ai-practice-388514", location="us-central1")

model = aiplatform.Model.upload(
    display_name="mistral-7b-base",
    artifact_uri="gs://vertex-ai-model-garden/mistral-7b",
    serving_container_image_uri="us-docker.pkg.dev/vertex-ai/prediction/pytorch-gpu:latest"
)
```

### Where Does Training Happen?

**NOT on your Mac!** Here's the flow:

```
Your Mac (Submit job)
    ↓
Vertex AI (Provision resources)
    ↓
Cloud VM + V100 GPU (Spin up)
    ↓
Download Mistral-7B from HuggingFace
    ↓
Load datasets from GCS
    ↓
Train LoRA adapters (15-20 min)
    ↓
Save adapters to GCS
    ↓
Shut down VM
```

**Cost for 300 records:**
- V100 GPU: $2.48/hour
- Training time: ~20 minutes
- **Total: ~$0.83**

---

## Q4: The Training Loop Explained

### Complete Training Code

```python
from transformers import (
    Trainer, 
    TrainingArguments, 
    AutoModelForCausalLM,
    AutoTokenizer
)
from peft import get_peft_model, LoraConfig
from datasets import load_dataset

# STEP 1: Load base Mistral-7B
print("Loading Mistral-7B...")
base_model = AutoModelForCausalLM.from_pretrained(
    "mistralai/Mistral-7B-v0.1",
    load_in_4bit=True,  # 4-bit quantization
    device_map="auto"   # Auto GPU placement
)
tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-v0.1")

# STEP 2: Apply LoRA adapters
print("Applying LoRA...")
lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.1,
    bias="none",
    task_type="CAUSAL_LM"
)
model = get_peft_model(base_model, lora_config)

# Check trainable parameters
model.print_trainable_parameters()
# Output: trainable params: 10,485,760 || all params: 7,010,485,760 || trainable%: 0.15%

# STEP 3: Load datasets from GCS
print("Loading datasets from GCS...")
train_data = load_dataset(
    "json",
    data_files="gs://vertex-ai-mistral-training-ai-practice/vertex-ai-mistral-training/datasets/train.jsonl"
)["train"]

val_data = load_dataset(
    "json",
    data_files="gs://vertex-ai-mistral-training-ai-practice/vertex-ai-mistral-training/datasets/validation.jsonl"
)["train"]

# STEP 4: Training configuration
print("Configuring training...")
training_args = TrainingArguments(
    output_dir="./results",
    num_train_epochs=3,              # 3 passes through dataset
    per_device_train_batch_size=4,   # 4 tickets per step
    learning_rate=2e-4,               # LoRA uses higher LR than full fine-tuning
    logging_steps=10,                 # Log every 10 steps
    save_steps=50,                    # Save checkpoint every 50 steps
    evaluation_strategy="epoch",     # Evaluate after each epoch
    save_strategy="epoch",
    load_best_model_at_end=True,
    fp16=True,                        # Mixed precision training
    gradient_accumulation_steps=2,   # Effective batch size = 4 × 2 = 8
    warmup_steps=10,                  # Learning rate warmup
    weight_decay=0.01                 # Regularization
)

# STEP 5: Create trainer
print("Creating trainer...")
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_data,
    eval_dataset=val_data
)

# STEP 6: Train!
print("Starting training...")
trainer.train()

# STEP 7: Save LoRA adapters only
print("Saving model...")
output_path = "./mistral-lora-it-tickets"
model.save_pretrained(output_path)
tokenizer.save_pretrained(output_path)

print(f"Training complete! Model saved to {output_path}")
```

### Training Math for 300 Records

```
Dataset: 185 training tickets
Batch size: 4 tickets per step
Steps per epoch: 185 ÷ 4 = 46 steps

Epochs: 3
Total steps: 46 × 3 = 138 steps

V100 GPU speed: ~8-10 seconds per step
Total training time: 138 × 9 = 1,242 seconds ≈ 20 minutes
```

---

## Q5: GPU Metrics - What to Monitor

### In Vertex AI Console

Navigate to: **Vertex AI → Training → [Your Job] → Metrics**

### 1. GPU Utilization (%)

```
Target: 70-95%

< 50%  = Data loading bottleneck (GCS I/O slow)
70-90% = Good ✅
> 95%  = Perfect, GPU fully saturated
```

**Fix low utilization:**
- Increase batch size (4 → 8)
- Enable data caching
- Use faster storage class

### 2. GPU Memory Usage (GB)

```
Mistral-7B (4-bit quantized): ~7-9 GB
LoRA adapters: ~0.5 GB
Batch processing: ~2-3 GB
Total: ~10-12 GB

V100 (16GB): Safe ✅
A100 (40GB): Plenty of headroom
```

**If Out of Memory (OOM):**
- Reduce batch size (4 → 2)
- Increase gradient accumulation
- Use 8-bit quantization instead of 4-bit

### 3. Training Loss (Should Decrease)

```
Epoch 1: 2.8 → 1.5  (Learning patterns)
Epoch 2: 1.5 → 0.9  (Refining)
Epoch 3: 0.9 → 0.6  (Convergence)
```

**Red flags:**
- Loss stuck at 2.5+: Learning rate too low OR data issues
- Loss = NaN: Learning rate too high, reduce to 1e-4
- Sudden spikes: Batch has corrupted data

### 4. Validation Loss (Should Track Training)

```
Good pattern:
Epoch 1: train=1.5, val=1.8
Epoch 2: train=0.9, val=1.1
Epoch 3: train=0.6, val=0.8

Overfitting pattern:
Epoch 1: train=1.5, val=1.8
Epoch 2: train=0.7, val=1.9  ← Val loss increases!
Epoch 3: train=0.3, val=2.3  ← Worse!
```

**Fix overfitting:**
- Increase dropout (0.1 → 0.2)
- Reduce epochs (3 → 2)
- Add weight decay
- Reduce LoRA rank (r=16 → r=8)

### 5. Classification Metrics

```python
# After training, evaluate on test set
from sklearn.metrics import classification_report

predictions = trainer.predict(test_data)
print(classification_report(true_labels, predicted_labels))
```

**Expected output:**

```
              precision  recall  f1-score  support

    software      0.92    0.95      0.93       26
    hardware      0.94    0.91      0.92       14

    accuracy                        0.93       40
   macro avg      0.93    0.93      0.93       40
weighted avg      0.93    0.93      0.93       40
```

**Target metrics for 300 records:**
- Accuracy: >90%
- Precision: >90% (minimize false positives)
- Recall: >90% (catch all true cases)

### Monitoring Code

```python
# Built into Trainer - auto-logs to TensorBoard
training_args = TrainingArguments(
    logging_dir="./logs",
    logging_steps=10,
    eval_steps=50,
    report_to="tensorboard"  # or "wandb" for Weights & Biases
)

# View logs
# Vertex AI: Training Jobs → [Job Name] → Metrics tab
# TensorBoard: tensorboard --logdir=./logs
```

---

## Q6: After Training - What's Next?

### Training Output Structure

```
gs://vertex-ai-mistral-training-ai-practice/
├── vertex-ai-mistral-training/
│   ├── model/
│   │   ├── adapter_config.json        # LoRA config
│   │   ├── adapter_model.bin          # Trained weights (~40MB)
│   │   ├── tokenizer_config.json
│   │   ├── tokenizer.json
│   │   └── training_args.json
│   ├── checkpoints/
│   │   ├── checkpoint-50/             # Intermediate saves
│   │   └── checkpoint-100/
│   └── logs/
│       └── events.out.tfevents...     # TensorBoard logs
```

### Step 1: Load Trained Model

```python
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

# Load base Mistral
base_model = AutoModelForCausalLM.from_pretrained(
    "mistralai/Mistral-7B-v0.1",
    load_in_4bit=True
)

# Load your fine-tuned LoRA adapters
model = PeftModel.from_pretrained(
    base_model,
    "gs://vertex-ai-mistral-training-ai-practice/vertex-ai-mistral-training/model/"
)

# Load tokenizer
tokenizer = AutoTokenizer.from_pretrained(
    "gs://vertex-ai-mistral-training-ai-practice/vertex-ai-mistral-training/model/"
)
```

### Step 2: Test Inference Locally

```python
def classify_ticket(ticket_text):
    prompt = f"""Classify this IT ticket as 'software' or 'hardware':
    
Ticket: {ticket_text}

Category:"""
    
    inputs = tokenizer(prompt, return_tensors="pt").to("cuda")
    outputs = model.generate(**inputs, max_new_tokens=10)
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    
    # Extract category
    if "software" in response.lower():
        return "software"
    elif "hardware" in response.lower():
        return "hardware"
    else:
        return "unknown"

# Test
test_tickets = [
    "VPN keeps disconnecting every few minutes",
    "Monitor screen is flickering",
    "Can't access Excel files on network drive"
]

for ticket in test_tickets:
    category = classify_ticket(ticket)
    print(f"{ticket} → {category}")
```

### Step 3: Deploy to Vertex AI Endpoint

```python
from google.cloud import aiplatform

aiplatform.init(project="ai-practice-388514", location="us-central1")

# Upload model to Vertex AI
model = aiplatform.Model.upload(
    display_name="mistral-it-classifier",
    artifact_uri="gs://vertex-ai-mistral-training-ai-practice/vertex-ai-mistral-training/model/",
    serving_container_image_uri="us-docker.pkg.dev/vertex-ai/prediction/pytorch-gpu:latest"
)

# Create endpoint
endpoint = aiplatform.Endpoint.create(display_name="it-ticket-classifier")

# Deploy model to endpoint
endpoint.deploy(
    model=model,
    deployed_model_display_name="mistral-it-v1",
    machine_type="n1-standard-4",
    min_replica_count=1,
    max_replica_count=3,
    accelerator_type="NVIDIA_TESLA_T4",  # Cheaper GPU for inference
    accelerator_count=1
)
```

### Step 4: Make API Predictions

```python
# Python SDK
instances = [
    {"ticket": "Outlook not syncing with server"},
    {"ticket": "Keyboard keys are stuck"}
]

predictions = endpoint.predict(instances=instances)
print(predictions)
# Output: [{"category": "software"}, {"category": "hardware"}]
```

**REST API:**
```bash
curl -X POST \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  https://us-central1-aiplatform.googleapis.com/v1/projects/ai-practice-388514/locations/us-central1/endpoints/ENDPOINT_ID:predict \
  -d '{
    "instances": [
      {"ticket": "VPN connection issues"}
    ]
  }'
```

### Cost Breakdown (Deployed Endpoint)

**Option 1: With GPU (faster)**
- T4 GPU: $0.35/hour
- CPU: $0.10/hour
- **Total: $0.45/hour = $324/month** (24/7)

**Option 2: Without GPU (cheaper, slower)**
- n1-standard-4: $0.19/hour
- **Total: $0.19/hour = $137/month** (24/7)

**Recommendation for 300 records:**
- Start without GPU for testing
- Add GPU only if inference is too slow (>2 seconds)

---

## Q7: Integration with Pub/Sub

### Architecture Flow

```
ServiceNow Ticket Created
    ↓
Pub/Sub Topic (new-ticket)
    ↓
Cloud Function (Triggered)
    ↓
Vertex AI Endpoint (Predict)
    ↓
Firestore (Save result)
    ↓
ServiceNow (Update ticket category)
```

### Pub/Sub to Vertex AI Code

```python
import functions_framework
from google.cloud import aiplatform
import json

# Initialize Vertex AI
aiplatform.init(project="ai-practice-388514", location="us-central1")
endpoint = aiplatform.Endpoint("projects/ai-practice-388514/locations/us-central1/endpoints/ENDPOINT_ID")

@functions_framework.cloud_event
def classify_ticket(cloud_event):
    # Parse Pub/Sub message
    ticket_data = json.loads(cloud_event.data["message"]["data"])
    ticket_text = ticket_data["description"]
    ticket_id = ticket_data["ticket_id"]
    
    # Predict category
    prediction = endpoint.predict(instances=[{"ticket": ticket_text}])
    category = prediction.predictions[0]["category"]
    
    # Save to Firestore
    from google.cloud import firestore
    db = firestore.Client()
    db.collection("ticket_classifications").document(ticket_id).set({
        "ticket_id": ticket_id,
        "category": category,
        "timestamp": firestore.SERVER_TIMESTAMP,
        "model_version": "mistral-it-v1"
    })
    
    print(f"Classified ticket {ticket_id} as {category}")
    return {"status": "success", "category": category}
```

---

## Summary: Complete Training Workflow

```
1. ✅ Data prepared (300 tickets in GCS)
2. ⏳ Write training script (train.py)
3. ⏳ Submit CustomTrainingJob to Vertex AI
4. ⏳ Monitor training (15-20 min)
5. ⏳ Evaluate model on test set
6. ⏳ Deploy to endpoint
7. ⏳ Integrate with Pub/Sub
8. ⏳ Production monitoring
```

**Time estimate:** 
- Script writing: 30-45 min
- Training: 15-20 min
- Deployment: 15-20 min
- **Total: ~1.5 hours**

**Cost estimate:**
- Training: ~$0.83
- Testing: ~$0.50
- **Total: ~$1.50** for initial setup

---

**Ready to write the training script?** Let me know and I'll create `train.py` with all the code above integrated!
