# Google Cloud Storage (GCS) Setup Guide

## Prerequisites

Before running the upload script, ensure you have:

1. **Google Cloud Project**
   - Active GCP project with billing enabled
   - Project ID ready

2. **Google Cloud SDK Installed**
   ```bash
   # Check if installed
   gcloud --version
   
   # If not installed, install via:
   # macOS: brew install google-cloud-sdk
   ```

3. **Authentication**
   ```bash
   # Login to your Google Cloud account
   gcloud auth login
   
   # Set your project
   gcloud config set project YOUR_PROJECT_ID
   
   # Set application default credentials
   gcloud auth application-default login
   ```

4. **Enable Required APIs**
   ```bash
   gcloud services enable storage.googleapis.com
   gcloud services enable aiplatform.googleapis.com
   ```

---

## GCS Bucket Structure

```
gs://YOUR-BUCKET-NAME/
└── vertex-ai-mistral-training/
    ├── datasets/
    │   ├── train.jsonl          # 185 records
    │   ├── validation.jsonl     # 40 records
    │   └── test.jsonl           # 40 records
    ├── models/
    │   └── [trained model will be saved here]
    └── configs/
        └── [training configs]
```

---

## Step-by-Step Setup

### Step 1: Choose Bucket Name
- Must be globally unique
- Use lowercase, numbers, hyphens only
- Example: `your-company-vertex-ai-training`

### Step 2: Choose Region
- `us-central1` (Iowa) - Good for training
- `us-west1` (Oregon)
- `europe-west4` (Netherlands)
- `asia-southeast1` (Singapore)

**Tip:** Choose region closest to you or where you'll run Vertex AI

### Step 3: Create Bucket
```bash
# Option 1: Via gcloud CLI (recommended)
gcloud storage buckets create gs://YOUR-BUCKET-NAME \
    --location=us-central1 \
    --uniform-bucket-level-access

# Option 2: Via Console
# Go to: https://console.cloud.google.com/storage
```

### Step 4: Upload Datasets
```bash
# Using gcloud
gcloud storage cp datasets/*.jsonl \
    gs://YOUR-BUCKET-NAME/vertex-ai-mistral-training/datasets/

# Using gsutil (alternative)
gsutil -m cp datasets/*.jsonl \
    gs://YOUR-BUCKET-NAME/vertex-ai-mistral-training/datasets/
```

### Step 5: Verify Upload
```bash
gcloud storage ls gs://YOUR-BUCKET-NAME/vertex-ai-mistral-training/datasets/
```

---

## Automated Upload Script

We'll create `upload_to_gcs.py` that handles everything automatically.

---

## IAM Permissions Required

Your account needs these roles:
- `Storage Admin` or `Storage Object Admin`
- `Vertex AI User`

```bash
# Grant yourself Storage Admin (if needed)
gcloud projects add-iam-policy-binding YOUR_PROJECT_ID \
    --member="user:YOUR_EMAIL@gmail.com" \
    --role="roles/storage.admin"
```

---

## Cost Considerations

**GCS Storage Pricing (us-central1):**
- Standard Storage: $0.020 per GB/month
- Your 3 JSONL files: ~0.5 MB = negligible cost (<$0.01/month)

**Data Transfer:**
- Upload: Free
- Download within same region: Free
- Cross-region: $0.01-$0.12 per GB

---

## Security Best Practices

1. **Uniform bucket-level access** (recommended)
2. **Versioning** for important data
3. **Lifecycle rules** to auto-delete old data
4. **Encryption** at rest (default)

---

## Next Steps

1. Run `upload_to_gcs.py` script (we'll create this)
2. Verify files are uploaded
3. Note the GCS paths for training script
4. Proceed to Vertex AI training configuration

---

**Status:** Ready to create upload script
