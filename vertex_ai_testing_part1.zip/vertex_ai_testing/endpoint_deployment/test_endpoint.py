"""
Test the deployed Vertex AI endpoint with sample IT tickets.
"""

from google.cloud import aiplatform
import json

# Configuration
PROJECT_ID = "ai-practice-388514"
REGION = "us-central1"
ENDPOINT_DISPLAY_NAME = "it-ticket-classifier"


def get_endpoint():
    """Get the deployed endpoint."""
    aiplatform.init(project=PROJECT_ID, location=REGION)

    endpoints = aiplatform.Endpoint.list(
        filter=f'display_name="{ENDPOINT_DISPLAY_NAME}"',
        order_by="create_time desc",
    )

    if not endpoints:
        raise ValueError(f"No endpoint found with name: {ENDPOINT_DISPLAY_NAME}")

    return endpoints[0]


def predict(endpoint, tickets):
    """
    Send prediction requests to the endpoint.

    Args:
        endpoint: The Vertex AI endpoint
        tickets: List of ticket descriptions

    Returns:
        predictions: List of classifications
    """
    instances = [{"ticket": ticket} for ticket in tickets]

    response = endpoint.predict(instances=instances)
    return response.predictions


def main():
    print("=" * 70)
    print("TESTING VERTEX AI ENDPOINT")
    print("=" * 70)
    print()

    # Get endpoint
    print("🔍 Finding endpoint...")
    endpoint = get_endpoint()
    print(f"✅ Found endpoint: {endpoint.display_name}")
    print(f"   Resource name: {endpoint.resource_name}")
    print()

    # Test tickets
    test_tickets = [
        "My laptop won't turn on. The power button doesn't respond.",
        "Excel keeps crashing when I open large files.",
        "I can't connect to the office WiFi network.",
        "I need access to the HR database for employee records.",
        "My keyboard keys are stuck and not typing properly.",
        "The company VPN won't connect from home.",
        "Outlook is giving me error 0x8004010F when sending emails.",
        "My monitor screen is flickering and showing lines.",
    ]

    print("🎯 Sending test requests...")
    print("=" * 70)

    # Send predictions
    predictions = predict(endpoint, test_tickets)

    # Display results
    for i, (ticket, prediction) in enumerate(zip(test_tickets, predictions), 1):
        print(f"\n📋 Ticket #{i}:")
        print(f"   Description: {ticket}")
        print(f"   Prediction: {prediction}")
        print("-" * 70)

    print("\n✅ All predictions complete!")
    print()


if __name__ == "__main__":
    main()
