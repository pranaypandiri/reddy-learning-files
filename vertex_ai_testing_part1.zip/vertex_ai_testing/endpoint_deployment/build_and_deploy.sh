#!/bin/bash
# Build and deploy Vertex AI endpoint

set -e

# Configuration
PROJECT_ID="ai-practice-388514"
REGION="us-central1"
IMAGE_NAME="mistral-lora-predictor"
IMAGE_URI="gcr.io/${PROJECT_ID}/${IMAGE_NAME}:latest"
ENDPOINT_NAME="it-ticket-classifier"
MODEL_NAME="mistral-it-classifier"

echo "======================================================================"
echo "Vertex AI Endpoint Deployment"
echo "======================================================================"
echo ""
echo "Project: ${PROJECT_ID}"
echo "Region: ${REGION}"
echo "Image: ${IMAGE_URI}"
echo ""

# Step 1: Build Docker image with Cloud Build
echo "Step 1: Building Docker image with Cloud Build..."
gcloud builds submit --tag ${IMAGE_URI} --project=${PROJECT_ID} --timeout=30m

echo ""
echo "✅ Docker image built successfully!"
echo ""

# Step 2: Create deployment script
echo "Step 2: Creating deployment Python script..."
cat > deploy_endpoint.py << 'DEPLOY_SCRIPT'
from google.cloud import aiplatform
import time

# Configuration
PROJECT_ID = "ai-practice-388514"
REGION = "us-central1"
IMAGE_URI = "gcr.io/ai-practice-388514/mistral-lora-predictor:latest"
ENDPOINT_DISPLAY_NAME = "it-ticket-classifier"
MODEL_DISPLAY_NAME = "mistral-it-classifier-v1"

print("=" * 70)
print("VERTEX AI ENDPOINT DEPLOYMENT")
print("=" * 70)

# Initialize Vertex AI
aiplatform.init(
    project=PROJECT_ID,
    location=REGION,
    staging_bucket=f"gs://vertex-ai-mistral-training-ai-practice"
)

# Step 1: Upload model to Vertex AI Model Registry
print("\n📦 Step 1: Uploading model to Model Registry...")
model = aiplatform.Model.upload(
    display_name=MODEL_DISPLAY_NAME,
    serving_container_image_uri=IMAGE_URI,
    serving_container_predict_route="/predict",
    serving_container_health_route="/health",
    serving_container_ports=[8080],
)
print(f"✅ Model uploaded: {model.resource_name}")

# Step 2: Create or get endpoint
print("\n🌐 Step 2: Creating endpoint...")
try:
    # Check if endpoint already exists
    endpoints = aiplatform.Endpoint.list(
        filter=f'display_name="{ENDPOINT_DISPLAY_NAME}"',
        order_by="create_time desc",
    )
    if endpoints:
        endpoint = endpoints[0]
        print(f"✅ Using existing endpoint: {endpoint.resource_name}")
    else:
        endpoint = aiplatform.Endpoint.create(
            display_name=ENDPOINT_DISPLAY_NAME,
        )
        print(f"✅ Endpoint created: {endpoint.resource_name}")
except Exception as e:
    print(f"Creating new endpoint due to: {e}")
    endpoint = aiplatform.Endpoint.create(
        display_name=ENDPOINT_DISPLAY_NAME,
    )
    print(f"✅ Endpoint created: {endpoint.resource_name}")

# Step 3: Deploy model to endpoint
print("\n🚀 Step 3: Deploying model to endpoint...")
print("   Machine type: n1-standard-4 with 1x NVIDIA T4 GPU")
print("   This will take 10-15 minutes...")

model.deploy(
    endpoint=endpoint,
    deployed_model_display_name=MODEL_DISPLAY_NAME,
    machine_type="n1-standard-4",
    accelerator_type="NVIDIA_TESLA_T4",
    accelerator_count=1,
    min_replica_count=1,
    max_replica_count=3,
    traffic_percentage=100,
)

print("\n" + "=" * 70)
print("✅ DEPLOYMENT COMPLETE!")
print("=" * 70)
print(f"\nEndpoint ID: {endpoint.name}")
print(f"Endpoint resource name: {endpoint.resource_name}")
print(f"\n📊 Endpoint URL:")
print(f"https://console.cloud.google.com/vertex-ai/endpoints/{endpoint.name.split('/')[-1]}?project={PROJECT_ID}")
print("\n💰 Cost: ~$0.50/hour while running (T4 GPU + n1-standard-4)")
print("💡 Remember to undeploy when not in use to avoid charges!")
print("")

DEPLOY_SCRIPT

echo ""
echo "Step 3: Running deployment script..."
python3 deploy_endpoint.py

echo ""
echo "======================================================================"
echo "✅ ALL DONE!"
echo "======================================================================"
