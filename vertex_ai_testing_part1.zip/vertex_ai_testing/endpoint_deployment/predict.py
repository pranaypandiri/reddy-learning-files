"""
FastAPI prediction server for Vertex AI endpoint.
Loads the Mistral-7B LoRA model and serves predictions via HTTP.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import PeftModel
from google.cloud import storage
import os
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(title="IT Ticket Classification API")

# Global model and tokenizer (loaded on startup)
model = None
tokenizer = None

# GCS paths
BUCKET = "vertex-ai-mistral-training-ai-practice"
MODEL_PREFIX = "vertex-ai-mistral-training/trained_models"
LOCAL_MODEL_PATH = "/app/model"


class PredictionRequest(BaseModel):
    """Request schema for predictions."""

    instances: list[dict]  # Format: [{"ticket": "My laptop won't turn on"}]


class PredictionResponse(BaseModel):
    """Response schema for predictions."""

    predictions: list[str]


def download_model_from_gcs():
    """Download the trained model from GCS to local disk."""
    logger.info(f"Downloading model from gs://{BUCKET}/{MODEL_PREFIX}...")

    os.makedirs(LOCAL_MODEL_PATH, exist_ok=True)

    storage_client = storage.Client()
    bucket = storage_client.bucket(BUCKET)
    blobs = bucket.list_blobs(prefix=MODEL_PREFIX)

    for blob in blobs:
        # Skip checkpoint folders
        if "/checkpoint-" in blob.name:
            continue

        # Get relative path
        relative_path = blob.name.replace(MODEL_PREFIX + "/", "")
        if not relative_path:
            continue

        local_file_path = os.path.join(LOCAL_MODEL_PATH, relative_path)
        os.makedirs(os.path.dirname(local_file_path), exist_ok=True)

        logger.info(f"  Downloading {blob.name}...")
        blob.download_to_filename(local_file_path)

    logger.info("✅ Model download complete!")


def load_model():
    """Load the model with 4-bit quantization and LoRA adapter."""
    global model, tokenizer

    logger.info("Loading tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(LOCAL_MODEL_PATH)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    logger.info("Loading base Mistral-7B model with 4-bit quantization...")
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )

    base_model = AutoModelForCausalLM.from_pretrained(
        "mistralai/Mistral-7B-v0.1",
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True,
    )

    logger.info("Applying LoRA adapter...")
    model = PeftModel.from_pretrained(base_model, LOCAL_MODEL_PATH)
    model.eval()

    logger.info("✅ Model loaded successfully!")


@app.on_event("startup")
async def startup_event():
    """Download and load model when container starts."""
    logger.info("🚀 Starting up prediction server...")
    download_model_from_gcs()
    load_model()
    logger.info("✅ Server ready!")


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy", "model_loaded": model is not None}


@app.post("/predict", response_model=PredictionResponse)
async def predict(request: PredictionRequest):
    """
    Prediction endpoint.

    Expected format:
    {
        "instances": [
            {"ticket": "My laptop won't turn on"},
            {"ticket": "Can't access the HR database"}
        ]
    }
    """
    if model is None or tokenizer is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    predictions = []

    for instance in request.instances:
        ticket_text = instance.get("ticket", "")
        if not ticket_text:
            predictions.append("ERROR: No ticket text provided")
            continue

        # Format prompt
        prompt = f"""<s>[INST] You are an IT support ticket classification system. Classify tickets into: Hardware, Software, Network, or Access.

{ticket_text} [/INST]"""

        # Tokenize
        inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=512)
        inputs = {k: v.to(model.device) for k, v in inputs.items()}

        # Generate
        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=50,
                temperature=0.1,
                do_sample=True,
                pad_token_id=tokenizer.eos_token_id,
            )

        # Decode
        full_response = tokenizer.decode(outputs[0], skip_special_tokens=True)

        # Extract prediction (after [/INST])
        if "[/INST]" in full_response:
            prediction = full_response.split("[/INST]")[-1].strip()
        else:
            prediction = full_response

        predictions.append(prediction)

    return PredictionResponse(predictions=predictions)


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "service": "IT Ticket Classification",
        "model": "Mistral-7B-v0.1 + LoRA",
        "version": "1.0",
        "endpoints": {"health": "/health", "predict": "/predict"},
    }
