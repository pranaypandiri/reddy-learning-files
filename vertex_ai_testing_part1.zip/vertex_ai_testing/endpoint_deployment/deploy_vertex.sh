#!/bin/bash

# Set project and region
PROJECT_ID="ai-practice-388514"
REGION="us-central1"
IMAGE_URI="us-central1-docker.pkg.dev/$PROJECT_ID/vertex-containers/mistral-lora-predictor:v1"
MODEL_DISPLAY_NAME="mistral-it-classifier"
DEPLOYMENT_DISPLAY_NAME="mistral-deployment"
ENDPOINT_DISPLAY_NAME="it-ticket-endpoint"
MACHINE_TYPE="n1-standard-4"
ACCELERATOR_TYPE="nvidia-tesla-t4"
ACCELERATOR_COUNT=1

echo "======================================================================"
echo "VERTEX AI ENDPOINT DEPLOYMENT - MISTRAL-7B LORA"
echo "======================================================================"
echo ""

echo "Step 1: Submitting Cloud Build job..."
gcloud builds submit --config cloudbuild.yaml .
echo "✅ Cloud Build submitted."
echo ""

echo "Step 2: Uploading model to Vertex AI..."
gcloud ai models upload \
  --region=$REGION \
  --display-name=$MODEL_DISPLAY_NAME \
  --container-image-uri=$IMAGE_URI \
  --container-ports=8080 \
  --container-health-route=/health \
  --container-predict-route=/predict
echo "✅ Model uploaded."
echo ""

echo "Step 3: Listing models to retrieve MODEL_ID..."
MODEL_ID=$(gcloud ai models list --region=$REGION --filter="displayName=$MODEL_DISPLAY_NAME" --format="value(name)" | awk -F/ '{print $NF}')
echo "MODEL_ID=$MODEL_ID"
echo ""

echo "Step 4: Creating endpoint..."
gcloud ai endpoints create --region=$REGION --display-name=$ENDPOINT_DISPLAY_NAME
echo "✅ Endpoint created."
echo ""

echo "Step 5: Listing endpoints to retrieve ENDPOINT_ID..."
ENDPOINT_ID=$(gcloud ai endpoints list --region=$REGION --filter="displayName=$ENDPOINT_DISPLAY_NAME" --format="value(name)" | awk -F/ '{print $NF}')
echo "ENDPOINT_ID=$ENDPOINT_ID"
echo ""

echo "Step 6: Deploying model to endpoint with GPU..."
gcloud ai endpoints deploy-model $ENDPOINT_ID \
  --region=$REGION \
  --model=$MODEL_ID \
  --display-name="$DEPLOYMENT_DISPLAY_NAME" \
  --machine-type=$MACHINE_TYPE \
  --accelerator=type=$ACCELERATOR_TYPE,count=$ACCELERATOR_COUNT \
  --min-replica-count=1 \
  --max-replica-count=3 \
  --traffic-split=0=100

echo ""
echo "======================================================================"
echo "✅ MODEL DEPLOYED TO ENDPOINT!"
echo "======================================================================"
echo ""
echo "Endpoint ID: $ENDPOINT_ID"
echo "Model ID: $MODEL_ID"
echo ""
echo "💰 Cost: ~$0.50/hour while running (T4 GPU + n1-standard-4)"
echo "💡 Remember to undeploy when not in use!"
echo ""
