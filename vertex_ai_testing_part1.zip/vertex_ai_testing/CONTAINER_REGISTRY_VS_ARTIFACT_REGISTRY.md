# Container Registry vs Artifact Registry - Key Differences

## Quick Answer
**Container Registry (gcr.io) = OLD** → Being phased out by Google  
**Artifact Registry = NEW** → Recommended by Google, more features

---

## Visual Differences in UI

### Container Registry (gcr.io)
**URL Pattern:** `gcr.io/PROJECT_ID/IMAGE_NAME:TAG`

**UI Location:** 
- Old: "Container Registry" menu item
- Redirects to Artifact Registry now
- URL: `console.cloud.google.com/gcr/images/...`

**Features:**
- ❌ Docker images ONLY
- ❌ Single region (global, us, eu, asia)
- ❌ Basic access control
- ❌ No vulnerability scanning (free tier)
- ❌ No artifact signing
- ⚠️ Being deprecated by Google

**Your images there:**
```
gcr.io/ai-practice-388514/mistral-trainer:latest
```

---

### Artifact Registry (NEW)
**URL Pattern:** `REGION-docker.pkg.dev/PROJECT_ID/REPOSITORY/IMAGE_NAME:TAG`

**UI Location:**
- New: "Artifact Registry" menu item
- URL: `console.cloud.google.com/artifacts/...`
- Modern, redesigned interface

**Features:**
- ✅ Multiple formats (Docker, Maven, npm, Python, etc.)
- ✅ Regional repositories (better for multi-region)
- ✅ Advanced access control (IAM integration)
- ✅ Vulnerability scanning (built-in)
- ✅ Artifact signing
- ✅ Better organization (repositories)
- ✅ Recommended by Google
- ✅ Future-proof

**Your images there:**
```
us-central1-docker.pkg.dev/ai-practice-388514/vertex-containers/mistral-lora-predictor:v1
```

---

## Key Structural Differences

### Container Registry (OLD)
```
gcr.io/
  └── PROJECT_ID/
      ├── image-1:tag1
      ├── image-2:tag2
      └── image-3:tag3

NO concept of "repositories"
Everything in one flat namespace
```

### Artifact Registry (NEW)
```
REGION-docker.pkg.dev/
  └── PROJECT_ID/
      ├── repository-1/     ← You create these!
      │   ├── image-a:v1
      │   └── image-b:v2
      └── repository-2/
          ├── image-c:latest
          └── image-d:stable

Organized by repositories
Better separation of concerns
```

---

## Interface Comparison

### Container Registry UI
```
Container Registry (Legacy)
├── All images in flat list
├── Filter by name/tag
├── Delete images
└── View image details
    ├── Layers
    ├── Tags
    └── Size

Simple, minimal UI
```

### Artifact Registry UI
```
Artifact Registry (Modern)
├── Repositories (top level)
│   ├── Create repository
│   ├── Repository settings
│   └── Format selection (Docker, Maven, etc.)
│
└── Images (within repository)
    ├── Versions tab
    ├── Vulnerabilities tab ← NEW!
    ├── Tags management
    └── Advanced filters

Rich, feature-full UI
```

---

## Why You Saw Both

### What Happened in Your Project:

1. **Day 1 - Training Job:**
   ```bash
   # Your build_with_cloudbuild.sh used:
   IMAGE_URI="gcr.io/ai-practice-388514/mistral-trainer:latest"
   
   # Cloud Build pushed to Container Registry (OLD)
   ```
   
2. **Day 2 - Endpoint Deployment:**
   ```bash
   # Your cloudbuild.yaml used:
   IMAGE_URI="us-central1-docker.pkg.dev/ai-practice-388514/vertex-containers/mistral-lora-predictor:v1"
   
   # Cloud Build pushed to Artifact Registry (NEW)
   ```

You used **both** because we switched approaches mid-project!

---

## Migration Path

### Google's Recommendation:
```
Container Registry → Artifact Registry
    (OLD)               (NEW)

All new projects should use Artifact Registry
Existing images should be migrated
```

### How to Migrate (if you had kept images):
```bash
# Option 1: Docker pull/push
docker pull gcr.io/PROJECT_ID/IMAGE:TAG
docker tag gcr.io/PROJECT_ID/IMAGE:TAG REGION-docker.pkg.dev/PROJECT_ID/REPO/IMAGE:TAG
docker push REGION-docker.pkg.dev/PROJECT_ID/REPO/IMAGE:TAG

# Option 2: gcrane copy
gcrane cp gcr.io/PROJECT_ID/IMAGE:TAG REGION-docker.pkg.dev/PROJECT_ID/REPO/IMAGE:TAG
```

---

## Pricing Comparison

### Container Registry
- Storage: $0.026/GB/month
- Network egress: Standard GCP rates
- No vulnerability scanning (free)

### Artifact Registry
- Storage: $0.10/GB/month (first 0.5 GB free)
- Network egress: Standard GCP rates
- Vulnerability scanning: Included
- Better value for production

**Your images:**
- 10 GB × $0.10 = $1/month (Artifact Registry)
- 10 GB × $0.026 = $0.26/month (Container Registry)

*But Artifact Registry includes scanning + features*

---

## Which to Use?

### Use Artifact Registry for:
- ✅ All new projects (Google's recommendation)
- ✅ Production workloads
- ✅ Multi-format artifacts (Docker + Python + Maven)
- ✅ When you need vulnerability scanning
- ✅ Multi-region deployments
- ✅ Better security requirements

### Use Container Registry only if:
- ⚠️ Legacy project already using it
- ⚠️ Very simple Docker-only workflow
- ⚠️ Don't want to migrate yet

**Recommendation:** Always use **Artifact Registry** for new work!

---

## In Your Senior's Example

Your senior used:
```yaml
# cloudbuild.yaml
images:
  - 'us-central1-docker.pkg.dev/${PROJECT_ID}/vertex-containers/image-buk:v1'
```

This is **Artifact Registry** (NEW) ✅

The format tells you:
```
us-central1-docker.pkg.dev  ← Artifact Registry
     vs
gcr.io                       ← Container Registry (OLD)
```

---

## Summary Table

| Feature | Container Registry | Artifact Registry |
|---------|-------------------|-------------------|
| **Status** | Legacy, deprecating | Current, recommended |
| **URL** | `gcr.io/...` | `REGION-docker.pkg.dev/...` |
| **Formats** | Docker only | Docker, Maven, npm, Python, etc. |
| **Organization** | Flat namespace | Repository-based |
| **Vulnerability scanning** | Not included | Included |
| **Regional** | Limited (global, us, eu, asia) | Full regional support |
| **IAM** | Basic | Advanced |
| **UI** | Simple, old | Modern, feature-rich |
| **Future** | Being phased out | Long-term supported |
| **Your Usage** | Training images | Endpoint images |

---

## Bottom Line

**Container Registry = The old way** (like using Internet Explorer)  
**Artifact Registry = The modern way** (like using Chrome)

Always use **Artifact Registry** for new projects! 🎯
