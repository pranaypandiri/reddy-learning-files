#!/bin/bash

# ============================================================================
# Vertex AI Mistral Training - Cloud Shell Docker Setup
# Run this in Cloud Shell to build and deploy custom container
# ============================================================================

set -e  # Exit on error

PROJECT_ID="ai-practice-388514"
REGION="us-central1"
BUCKET="vertex-ai-mistral-training-ai-practice"
IMAGE_NAME="mistral-trainer"
IMAGE_URI="gcr.io/${PROJECT_ID}/${IMAGE_NAME}:latest"

echo "============================================================================"
echo "🚀 Vertex AI Mistral Training - Docker Setup"
echo "============================================================================"
echo ""
echo "Project: ${PROJECT_ID}"
echo "Region: ${REGION}"
echo "Image: ${IMAGE_URI}"
echo ""

# Step 1: Enable required APIs
echo "📋 Step 1/6: Enabling required APIs..."
gcloud services enable \
    aiplatform.googleapis.com \
    containerregistry.googleapis.com \
    cloudbuild.googleapis.com \
    --project=${PROJECT_ID}

# Step 2: Build Docker image
echo ""
echo "🐳 Step 2/6: Building Docker image..."
echo "This will take 5-10 minutes (installing PyTorch, transformers, etc.)"
docker build -t ${IMAGE_NAME} .

# Step 3: Tag image for GCR
echo ""
echo "🏷️  Step 3/6: Tagging image for Google Container Registry..."
docker tag ${IMAGE_NAME} ${IMAGE_URI}

# Step 4: Push to GCR
echo ""
echo "☁️  Step 4/6: Pushing image to GCR..."
docker push ${IMAGE_URI}

# Step 5: Create Python submission script
echo ""
echo "📝 Step 5/6: Creating submission script..."
cat > submit_docker_job.py << 'EOF'
"""Submit Vertex AI training job with custom Docker container"""

from google.cloud import aiplatform

# Configuration
PROJECT_ID = "ai-practice-388514"
REGION = "us-central1"
BUCKET = "vertex-ai-mistral-training-ai-practice"
IMAGE_URI = f"gcr.io/{PROJECT_ID}/mistral-trainer:latest"

# Initialize Vertex AI
aiplatform.init(project=PROJECT_ID, location=REGION, staging_bucket=f"gs://{BUCKET}")

# Create custom container training job
job = aiplatform.CustomContainerTrainingJob(
    display_name="mistral-it-classifier-docker",
    container_uri=IMAGE_URI,
)

# Submit job
print("🚀 Submitting training job...")
print(f"Container: {IMAGE_URI}")

job.run(
    replica_count=1,
    machine_type="n1-standard-4",
    accelerator_type="NVIDIA_TESLA_T4",
    accelerator_count=1,
    boot_disk_type="pd-ssd",
    boot_disk_size_gb=100,
)

print("✅ Job submitted successfully!")
print(f"Job resource name: {job.resource_name}")
EOF

# Step 6: Submit training job
echo ""
echo "🎯 Step 6/6: Submitting training job to Vertex AI..."
python3 submit_docker_job.py

echo ""
echo "============================================================================"
echo "✅ SETUP COMPLETE!"
echo "============================================================================"
echo ""
echo "The training job is now running on Vertex AI with your custom Docker image."
echo ""
echo "Monitor progress:"
echo "  Console: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project=${PROJECT_ID}"
echo ""
echo "Check logs:"
echo "  gcloud ai custom-jobs list --project=${PROJECT_ID} --region=${REGION}"
echo ""
echo "Expected training time: 30-40 minutes"
echo "Cost: ~$0.25 (T4 GPU @ $0.35/hour for ~45 min)"
echo ""
echo "🎉 You can close this terminal - the job runs independently!"
echo ""
