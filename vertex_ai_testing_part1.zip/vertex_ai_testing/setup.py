"""
Setup file for Vertex AI training package
"""

from setuptools import setup, find_packages

setup(
    name="mistral-it-classifier-training",
    version="1.0.0",
    packages=find_packages(),
    py_modules=["train_modern"],
    install_requires=[
        # Known working combination for PyTorch 2.0 + Mistral
        "torch==2.0.1",
        "transformers==4.41.2",
        "tokenizers==0.19.1",
        "datasets==2.19.0",  # Upgraded - fixes fsspec protocol tuple bug
        "peft==0.11.1",
        "trl==0.9.4",
        "bitsandbytes==0.43.1",
        "accelerate==0.31.0",
        "scipy",
        "sentencepiece",
        "protobuf",
        "python-json-logger",
        "google-cloud-storage",
        "fsspec==2023.10.0",  # Compatible with datasets 2.19
        "gcsfs==2023.10.0",
    ],
    python_requires=">=3.9",
)
