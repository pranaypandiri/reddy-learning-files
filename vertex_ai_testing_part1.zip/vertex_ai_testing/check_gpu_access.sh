#!/bin/bash

# Quick script to verify GPU access for Vertex AI training

PROJECT_ID="ai-practice-388514"
REGION="us-central1"

echo "========================================="
echo "Checking GPU Access for Vertex AI"
echo "========================================="
echo ""

echo "Available GPU types in $REGION:"
echo ""

# Check V100
V100_LIMIT=$(gcloud compute regions describe $REGION --project=$PROJECT_ID --format="json" | grep -A 2 "NVIDIA_V100_GPUS" | grep "limit" | awk '{print $2}' | tr -d ',' | head -1)
echo "✅ NVIDIA V100: $V100_LIMIT GPUs available (Recommended for training)"

# Check T4
T4_LIMIT=$(gcloud compute regions describe $REGION --project=$PROJECT_ID --format="json" | grep -A 2 "\"NVIDIA_T4_GPUS\"" | grep "limit" | awk '{print $2}' | tr -d ',' | head -1)
echo "✅ NVIDIA T4: $T4_LIMIT GPUs available (Good for inference)"

# Check A100
A100_LIMIT=$(gcloud compute regions describe $REGION --project=$PROJECT_ID --format="json" | grep -A 2 "\"NVIDIA_A100_GPUS\"" | grep "limit" | awk '{print $2}' | tr -d ',' | head -1)
echo "✅ NVIDIA A100: $A100_LIMIT GPUs available (Fastest, most expensive)"

# Check L4
L4_LIMIT=$(gcloud compute regions describe $REGION --project=$PROJECT_ID --format="json" | grep -A 2 "NVIDIA_L4_GPUS" | grep "limit" | awk '{print $2}' | tr -d ',' | head -1)
echo "✅ NVIDIA L4: $L4_LIMIT GPUs available (Cost-effective)"

echo ""
echo "========================================="
echo "✅ You have GPU access!"
echo "Recommendation: Use V100 for training"
echo "Cost estimate: ~$0.82 for 20 min training"
echo "========================================="
