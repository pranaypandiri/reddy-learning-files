"""
Test Script to Verify All Required Packages Are Installed
Run this to check if your environment is ready for Mistral fine-tuning
"""

import sys

print("=" * 60)
print("Testing Package Imports for Mistral Fine-Tuning")
print("=" * 60)
print()

# Track success/failures
success_count = 0
total_count = 0


def test_import(package_name, import_statement):
    global success_count, total_count
    total_count += 1
    try:
        exec(import_statement)
        print(f"✅ {package_name:30s} - OK")
        success_count += 1
        return True
    except ImportError as e:
        print(f"❌ {package_name:30s} - MISSING: {e}")
        return False
    except Exception as e:
        print(f"⚠️  {package_name:30s} - ERROR: {e}")
        return False


# Core PyTorch
print("\n📦 Core ML Frameworks:")
test_import("PyTorch (torch)", "import torch")
test_import("PyTorch version", "import torch; assert torch.__version__ >= '2.0.0'")

# HuggingFace
print("\n📦 HuggingFace Libraries:")
test_import("transformers", "import transformers")
test_import(
    "transformers version",
    "import transformers; assert transformers.__version__ >= '4.36.0'",
)
test_import("datasets", "import datasets")
test_import("peft (LoRA)", "import peft")
test_import("trl (SFTTrainer)", "import trl")
test_import("accelerate", "import accelerate")

# Quantization
print("\n📦 Optimization & Quantization:")
test_import("bitsandbytes", "import bitsandbytes")
test_import("sentencepiece", "import sentencepiece")

# Google Cloud
print("\n📦 Google Cloud:")
test_import("google.cloud.aiplatform", "import google.cloud.aiplatform")
test_import("google.cloud.storage", "import google.cloud.storage")

# Utilities
print("\n📦 Utilities:")
test_import("numpy", "import numpy")
test_import("pandas", "import pandas")
test_import("scikit-learn", "import sklearn")
test_import("scipy", "import scipy")
test_import("tqdm", "import tqdm")

# Monitoring (optional but recommended)
print("\n📦 Monitoring & Logging:")
test_import("tensorboard", "import tensorboard")
test_import("wandb", "import wandb")

# Summary
print("\n" + "=" * 60)
print(f"✅ SUCCESS: {success_count}/{total_count} packages imported successfully")
print("=" * 60)

if success_count == total_count:
    print("\n🎉 All packages installed correctly!")
    print("✅ Your environment is ready for Mistral fine-tuning!")
else:
    print(f"\n⚠️  {total_count - success_count} package(s) missing or have errors")
    print("Please install missing packages using:")
    print("pip install -r requirements_training.txt")
    sys.exit(1)

# Bonus: Check GPU availability
print("\n" + "=" * 60)
print("GPU Check (for local testing):")
print("=" * 60)
try:
    import torch

    if torch.cuda.is_available():
        print(f"✅ CUDA available: {torch.cuda.get_device_name(0)}")
        print(
            f"   GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB"
        )
    elif torch.backends.mps.is_available():
        print("✅ Apple Metal (MPS) available (Mac GPU)")
    else:
        print("ℹ️  No GPU detected locally (OK - we'll use Vertex AI GPU)")
except Exception as e:
    print(f"⚠️  GPU check failed: {e}")

print("\n" + "=" * 60)
print("Environment check complete!")
print("=" * 60)
