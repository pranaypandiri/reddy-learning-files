"""
Submit Mistral-7B Fine-Tuning Job to Vertex AI
Uses T4 GPU (cheapest option - ~$0.35/hour)
"""

from google.cloud import aiplatform
import datetime

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ID = "ai-practice-388514"
REGION = "us-central1"
STAGING_BUCKET = (
    "gs://vertex-ai-mistral-training-ai-practice/vertex-ai-mistral-training"
)

# Job configuration
JOB_NAME = f"mistral-it-classifier-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}"

# T4 GPU - Smallest & Cheapest (~$0.35/hour)
MACHINE_TYPE = "n1-standard-4"  # 4 vCPUs, 15GB RAM
ACCELERATOR_TYPE = "NVIDIA_TESLA_T4"  # Cheapest GPU!
ACCELERATOR_COUNT = 1

# Pre-built PyTorch GPU container (has all you need!)
CONTAINER_URI = "us-docker.pkg.dev/vertex-ai/training/pytorch-gpu.2-0.py310:latest"

# Your training script
PYTHON_MODULE = "train_modern.py"

# ============================================================================
# MAIN SUBMISSION
# ============================================================================


def submit_training_job():
    """Submit training job to Vertex AI"""

    print("=" * 80)
    print("🚀 SUBMITTING MISTRAL-7B TRAINING JOB TO VERTEX AI")
    print("=" * 80)
    print(f"\n📋 Job Configuration:")
    print(f"  Project ID: {PROJECT_ID}")
    print(f"  Region: {REGION}")
    print(f"  Job Name: {JOB_NAME}")
    print(f"  Machine: {MACHINE_TYPE}")
    print(f"  GPU: {ACCELERATOR_TYPE} x{ACCELERATOR_COUNT}")
    print(f"  Container: {CONTAINER_URI}")
    print(f"\n💰 Estimated Cost: ~$0.50-0.70 (T4 GPU for 15-20 min)")
    print("=" * 80)

    # Initialize Vertex AI
    aiplatform.init(project=PROJECT_ID, location=REGION, staging_bucket=STAGING_BUCKET)

    print("\n⏳ Creating Custom Training Job...")

    # Create CustomJob
    job = aiplatform.CustomJob(
        display_name=JOB_NAME,
        worker_pool_specs=[
            {
                "machine_spec": {
                    "machine_type": MACHINE_TYPE,
                    "accelerator_type": ACCELERATOR_TYPE,
                    "accelerator_count": ACCELERATOR_COUNT,
                },
                "replica_count": 1,
                "container_spec": {
                    "image_uri": CONTAINER_URI,
                    "command": ["python3", PYTHON_MODULE],
                },
                "disk_spec": {
                    "boot_disk_type": "pd-ssd",
                    "boot_disk_size_gb": 100,
                },
            }
        ],
        # Staging bucket for code & logs
        base_output_dir=f"{STAGING_BUCKET}/jobs/{JOB_NAME}",
    )

    print("✅ Job created successfully!")
    print(f"\n🔗 Monitor job at:")
    print(
        f"   https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={PROJECT_ID}"
    )

    # Submit the job
    print("\n🚀 Submitting job to Vertex AI...")
    print("   (This will take a few seconds...)")

    job.run(
        sync=False,  # Don't wait for completion (you can monitor in console)
        restart_job_on_worker_restart=False,
    )

    print("\n" + "=" * 80)
    print("✅ JOB SUBMITTED SUCCESSFULLY!")
    print("=" * 80)
    print(f"\n📊 Job Details:")
    print(f"  Name: {job.display_name}")
    print(f"  Resource Name: {job.resource_name}")
    print(f"  State: {job.state}")

    print(f"\n📍 Monitor Progress:")
    print(
        f"  Console: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={PROJECT_ID}"
    )
    print(f"  Job ID: {job.name}")

    print(f"\n⏱️  Expected Timeline:")
    print(f"  • Setup: 2-3 minutes (provisioning VM, installing packages)")
    print(f"  • Training: 15-20 minutes (actual fine-tuning)")
    print(f"  • Cleanup: 1 minute (saving model to GCS)")
    print(f"  • Total: ~18-25 minutes")

    print(f"\n💾 Model Will Be Saved To:")
    print(f"  {STAGING_BUCKET}/model/")

    print(f"\n💡 Tips:")
    print(f"  • You can close this terminal - job runs in cloud")
    print(f"  • Check console link above for real-time logs")
    print(f"  • Billing stops automatically when job completes")

    print("\n" + "=" * 80)
    print("🎉 All done! Your model is training in the cloud!")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    try:
        submit_training_job()
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        print("\nCommon fixes:")
        print("  1. Authenticate: gcloud auth application-default login")
        print(
            "  2. Enable Vertex AI API: gcloud services enable aiplatform.googleapis.com"
        )
        print("  3. Check project ID is correct")
        raise
