"""
Local inference script for testing the fine-tuned Mistral-7B LoRA model.
Downloads the base model, loads the LoRA adapter, and runs predictions on IT tickets.
"""

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import PeftModel
import json


def load_model_and_tokenizer(adapter_path="./trained_model"):
    """
    Load the base Mistral-7B model with 4-bit quantization and apply LoRA adapter.

    Args:
        adapter_path: Path to the directory containing LoRA adapter files

    Returns:
        model: The fine-tuned model ready for inference
        tokenizer: The tokenizer for processing text
    """
    print("🔧 Loading tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(adapter_path)

    # Add padding token if missing
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    print("🔧 Loading base Mistral-7B model with 4-bit quantization...")
    print("   (This will download ~4GB on first run - may take 5-10 minutes)")

    # Same quantization config used during training
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )

    # Load base model with quantization
    base_model = AutoModelForCausalLM.from_pretrained(
        "mistralai/Mistral-7B-v0.1",
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True,
    )

    print("🔧 Applying LoRA adapter...")
    # Load the fine-tuned LoRA weights on top of base model
    model = PeftModel.from_pretrained(base_model, adapter_path)
    model.eval()  # Set to evaluation mode

    print("✅ Model loaded successfully!\n")
    return model, tokenizer


def format_prompt(ticket_description):
    """
    Format the IT ticket into the same chat format used during training.

    Args:
        ticket_description: The IT ticket text

    Returns:
        Formatted prompt string ready for the model
    """
    messages = [
        {
            "role": "system",
            "content": "You are an IT support ticket classification system. Classify tickets into: Hardware, Software, Network, or Access.",
        },
        {"role": "user", "content": ticket_description},
    ]

    # Use the chat template to format (same as training)
    prompt = f"<s>[INST] {messages[0]['content']}\n\n{messages[1]['content']} [/INST]"
    return prompt


def predict(model, tokenizer, ticket_description, max_new_tokens=50):
    """
    Run inference on a single IT ticket.

    Args:
        model: The fine-tuned model
        tokenizer: The tokenizer
        ticket_description: The IT ticket text
        max_new_tokens: Maximum tokens to generate

    Returns:
        prediction: The model's classification response
    """
    # Format the input
    prompt = format_prompt(ticket_description)

    # Tokenize
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=512)
    inputs = {k: v.to(model.device) for k, v in inputs.items()}

    # Generate prediction
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            temperature=0.1,  # Low temperature for more deterministic output
            do_sample=True,
            pad_token_id=tokenizer.eos_token_id,
        )

    # Decode the response
    full_response = tokenizer.decode(outputs[0], skip_special_tokens=True)

    # Extract only the assistant's response (after [/INST])
    if "[/INST]" in full_response:
        prediction = full_response.split("[/INST]")[-1].strip()
    else:
        prediction = full_response

    return prediction


def main():
    """
    Main function to test the model with sample IT tickets.
    """
    print("=" * 70)
    print("IT TICKET CLASSIFICATION - LOCAL INFERENCE TEST")
    print("=" * 70)
    print()

    # Load model and tokenizer
    model, tokenizer = load_model_and_tokenizer()

    # Sample IT tickets for testing (one from each category)
    test_tickets = [
        {
            "description": "My laptop won't turn on. The power button doesn't respond and there's no light.",
            "expected": "Hardware",
        },
        {
            "description": "Excel keeps crashing whenever I try to open a large spreadsheet. Error code 0x8007.",
            "expected": "Software",
        },
        {
            "description": "I can't connect to the office WiFi. Other devices work fine but my computer won't connect.",
            "expected": "Network",
        },
        {
            "description": "I need access to the HR database. My manager approved it but I still can't log in.",
            "expected": "Access",
        },
        {
            "description": "My keyboard keys are stuck and some letters don't type properly.",
            "expected": "Hardware",
        },
    ]

    print("🎯 Running predictions on test tickets...\n")
    print("=" * 70)

    # Run inference on each ticket
    for i, ticket in enumerate(test_tickets, 1):
        print(f"\n📋 TICKET #{i}")
        print(f"Description: {ticket['description']}")
        print(f"Expected: {ticket['expected']}")

        prediction = predict(model, tokenizer, ticket["description"])

        print(f"Prediction: {prediction}")
        print("-" * 70)

    print("\n✅ All predictions complete!")
    print("\nNote: The model generates a classification category.")
    print("You can adjust temperature and max_new_tokens in the predict() function")
    print("for different response styles.\n")


if __name__ == "__main__":
    main()
