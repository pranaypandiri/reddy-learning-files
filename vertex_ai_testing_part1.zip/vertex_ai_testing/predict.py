# predict.py
# FastAPI server for model inference

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
import os

app = FastAPI()

# Load model from GCS (where training saved it)
MODEL_PATH = os.getenv("MODEL_PATH", "gs://bucket/trained-model/")

print(f"Loading model from {MODEL_PATH}...")
model = AutoModelForCausalLM.from_pretrained(
    MODEL_PATH,
    torch_dtype=torch.float16,
    device_map="auto",
)
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
print("✅ Model loaded!")


# Request schema
class PredictionRequest(BaseModel):
    text: str
    max_length: int = 100


# Health check (Vertex AI requires this!)
@app.get("/health")
def health():
    return {"status": "healthy"}


# Prediction endpoint (Vertex AI requires this!)
@app.post("/predict")
def predict(request: PredictionRequest):
    try:
        # Tokenize input
        inputs = tokenizer(
            request.text, return_tensors="pt", padding=True, truncation=True
        )

        # Generate prediction
        with torch.no_grad():
            outputs = model.generate(
                **inputs, max_length=request.max_length, do_sample=True, temperature=0.7
            )

        # Decode output
        prediction = tokenizer.decode(outputs[0], skip_special_tokens=True)

        return {"prediction": prediction, "input": request.text}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# For local testing
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8080)
