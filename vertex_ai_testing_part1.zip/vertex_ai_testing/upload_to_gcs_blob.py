"""
Upload datasets to Google Cloud Storage using Python SDK (Blob)
More Pythonic approach with better error handling and progress tracking
"""

from google.cloud import storage
from pathlib import Path
import sys

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ID = "ai-practice-388514"
BUCKET_NAME = "vertex-ai-mistral-training-ai-practice"
REGION = "us-central1"
GCS_BASE_PATH = "vertex-ai-mistral-training"
DATASETS_DIR = Path("datasets")

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================


def create_gcs_client():
    """Create and return GCS client"""
    try:
        client = storage.Client(project=PROJECT_ID)
        print("✅ GCS Client created successfully")
        return client
    except Exception as e:
        print(f"❌ Error creating GCS client: {e}")
        print("\nPlease authenticate first:")
        print("  gcloud auth application-default login")
        sys.exit(1)


def create_bucket_if_not_exists(client, bucket_name, region):
    """Create bucket if it doesn't exist"""
    print(f"\n{'='*60}")
    print(f"📦 Checking bucket: gs://{bucket_name}")
    print(f"{'='*60}")

    try:
        bucket = client.get_bucket(bucket_name)
        print(f"✅ Bucket already exists")
        return bucket
    except Exception:
        print(f"⚠️  Bucket doesn't exist. Creating...")

        try:
            bucket = client.bucket(bucket_name)
            bucket.location = region
            bucket.storage_class = "STANDARD"
            bucket.iam_configuration.uniform_bucket_level_access_enabled = True

            bucket = client.create_bucket(bucket, location=region)
            print(f"✅ Bucket created successfully in {region}")
            return bucket
        except Exception as e:
            print(f"❌ Error creating bucket: {e}")
            sys.exit(1)


def upload_file_to_gcs(bucket, local_file_path, gcs_path):
    """Upload a single file to GCS using Blob"""
    try:
        blob = bucket.blob(gcs_path)

        # Get file size for progress
        file_size = local_file_path.stat().st_size
        file_size_kb = file_size / 1024

        print(f"\n📤 Uploading: {local_file_path.name}")
        print(f"   Size: {file_size_kb:.2f} KB")
        print(f"   Destination: gs://{bucket.name}/{gcs_path}")

        # Upload with content type
        blob.upload_from_filename(str(local_file_path), content_type="application/json")

        print(f"   ✅ Upload complete!")

        # Return blob info
        return {
            "name": local_file_path.name,
            "size_kb": file_size_kb,
            "gcs_uri": f"gs://{bucket.name}/{gcs_path}",
            "public_url": blob.public_url,
        }

    except Exception as e:
        print(f"   ❌ Upload failed: {e}")
        return None


def upload_all_datasets(bucket, datasets_dir, gcs_base_path):
    """Upload all JSONL files from datasets directory"""
    print(f"\n{'='*60}")
    print(f"📂 Scanning directory: {datasets_dir}")
    print(f"{'='*60}")

    # Get all JSONL files
    jsonl_files = list(datasets_dir.glob("*.jsonl"))

    if not jsonl_files:
        print(f"❌ No JSONL files found in {datasets_dir}")
        return []

    print(f"Found {len(jsonl_files)} files to upload:")
    for f in jsonl_files:
        print(f"  - {f.name}")

    # Upload each file
    uploaded_files = []
    for local_file in jsonl_files:
        gcs_path = f"{gcs_base_path}/datasets/{local_file.name}"
        result = upload_file_to_gcs(bucket, local_file, gcs_path)
        if result:
            uploaded_files.append(result)

    return uploaded_files


def verify_uploads(bucket, gcs_base_path):
    """Verify all files were uploaded successfully"""
    print(f"\n{'='*60}")
    print(f"🔍 Verifying uploads...")
    print(f"{'='*60}")

    try:
        blobs = list(bucket.list_blobs(prefix=f"{gcs_base_path}/datasets/"))

        if not blobs:
            print("❌ No files found in GCS!")
            return False

        print(f"✅ Found {len(blobs)} files in GCS:")
        for blob in blobs:
            size_kb = blob.size / 1024
            print(f"  - {blob.name} ({size_kb:.2f} KB)")

        return True

    except Exception as e:
        print(f"❌ Verification failed: {e}")
        return False


def print_summary(uploaded_files, bucket_name, gcs_base_path):
    """Print upload summary"""
    print(f"\n{'='*60}")
    print("✅ UPLOAD COMPLETE!")
    print(f"{'='*60}")

    print(f"\nBucket: gs://{bucket_name}")
    print(f"Region: {REGION}")
    print(f"Path: {gcs_base_path}/datasets/")

    print(f"\nUploaded Files:")
    total_size = 0
    for file_info in uploaded_files:
        print(f"  ✓ {file_info['name']} ({file_info['size_kb']:.2f} KB)")
        total_size += file_info["size_kb"]

    print(f"\nTotal Size: {total_size:.2f} KB")

    print(f"\nGCS URIs for Vertex AI Training:")
    print(f"  Train:      gs://{bucket_name}/{gcs_base_path}/datasets/train.jsonl")
    print(f"  Validation: gs://{bucket_name}/{gcs_base_path}/datasets/validation.jsonl")
    print(f"  Test:       gs://{bucket_name}/{gcs_base_path}/datasets/test.jsonl")

    print(f"\nView in GCP Console:")
    print(
        f"  https://console.cloud.google.com/storage/browser/{bucket_name}/{gcs_base_path}/datasets"
    )

    print(f"\n{'='*60}")


def save_config(bucket_name, gcs_base_path):
    """Save GCS paths to config file"""
    config_file = Path("gcs_config.txt")

    with open(config_file, "w") as f:
        f.write(f"BUCKET_NAME={bucket_name}\n")
        f.write(f"GCS_BASE_PATH={gcs_base_path}\n")
        f.write(f"TRAIN_DATA=gs://{bucket_name}/{gcs_base_path}/datasets/train.jsonl\n")
        f.write(
            f"VAL_DATA=gs://{bucket_name}/{gcs_base_path}/datasets/validation.jsonl\n"
        )
        f.write(f"TEST_DATA=gs://{bucket_name}/{gcs_base_path}/datasets/test.jsonl\n")

    print(f"\n💾 GCS paths saved to: {config_file}")


# ============================================================================
# MAIN EXECUTION
# ============================================================================


def main():
    """Main execution flow"""
    print("=" * 60)
    print("GCS UPLOAD USING PYTHON SDK (Blob)")
    print("=" * 60)

    # Check datasets directory exists
    if not DATASETS_DIR.exists():
        print(f"\n❌ ERROR: Directory {DATASETS_DIR} not found")
        print("   Please run split_dataset.py first")
        sys.exit(1)

    # Step 1: Create GCS client
    client = create_gcs_client()

    # Step 2: Create or get bucket
    bucket = create_bucket_if_not_exists(client, BUCKET_NAME, REGION)

    # Step 3: Upload all datasets
    uploaded_files = upload_all_datasets(bucket, DATASETS_DIR, GCS_BASE_PATH)

    if not uploaded_files:
        print("\n❌ No files were uploaded successfully")
        sys.exit(1)

    # Step 4: Verify uploads
    verify_uploads(bucket, GCS_BASE_PATH)

    # Step 5: Print summary
    print_summary(uploaded_files, BUCKET_NAME, GCS_BASE_PATH)

    # Step 6: Save config
    save_config(BUCKET_NAME, GCS_BASE_PATH)

    print("\n🎉 Ready for Vertex AI training!")


if __name__ == "__main__":
    main()
